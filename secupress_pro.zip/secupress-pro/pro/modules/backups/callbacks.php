<?php
defined( 'ABSPATH' ) or die( 'Something went wrong.' );

/** --------------------------------------------------------------------------------------------- */
/** ON FORM SUBMIT ============================================================================== */
/** ----------------------------------------------------------------------------------------------*/

/**
 * Callback to filter, sanitize.
 *
 * @since 1.0
 *
 * @param (array) $settings The module settings.
 *
 * @return (array) The sanitized and validated settings.
 */
function secupress_pro_backups_settings_callback( $settings ) {
	$modulenow = 'backups-storage';
	$locations = secupress_backups_storage_labels();
	$settings  = $settings && is_array( $settings ) ? $settings : array();

	if ( isset( $settings['sanitized'] ) ) {
		return $settings;
	}
	$settings['sanitized'] = 1;

	if ( ! isset( $settings[ $modulenow . '_location' ] ) || ! isset( $locations[ $settings[ $modulenow . '_location' ] ] ) ) {
		unset( $settings[ $modulenow . '_location' ] );
	}

	$current = get_site_option( 'secupress_backups_settings', [] );
	$current = is_array( $current ) ? $current : [];
	$keep    = [
		'backups-storage_password_hash',
		'backups-storage_password_constant',
		'backups-storage_password_generation',
	];
	foreach ( $keep as $key ) {
		if ( ! isset( $settings[ $key ] ) && isset( $current[ $key ] ) ) {
			$settings[ $key ] = $current[ $key ];
		}
	}

	unset( $settings['backups-storage_password'], $settings['backups-storage_password_old'] );

	$posted   = isset( $_POST['secupress_backups_settings'] ) && is_array( $_POST['secupress_backups_settings'] ) ? wp_unslash( $_POST['secupress_backups_settings'] ) : [];
	$new_pass = isset( $posted['backups-storage_password'] ) ? (string) $posted['backups-storage_password'] : '';
	$old_pass = isset( $posted['backups-storage_password_old'] ) ? (string) $posted['backups-storage_password_old'] : '';
	$hash     = isset( $settings['backups-storage_password_hash'] ) ? $settings['backups-storage_password_hash'] : '';

	if ( $new_pass || $old_pass ) {
		if ( ! secupress_backup_zip_encryption_is_available() ) {
			secupress_add_settings_error( 'general', 'backup_password_no_aes', __( 'Expected encryption is not available on this server (ZIP AES-256). The backup password has not been saved.', 'secupress' ), 'error' );
		} elseif ( $hash && secupress_backup_password_is_locked() ) {
			secupress_add_settings_error( 'general', 'backup_password_locked', secupress_get_backup_password_lock_message(), 'error' );
		} elseif ( $hash && ! password_verify( $old_pass, $hash ) ) {
			secupress_backup_password_add_failed_attempt();
			if ( secupress_backup_password_is_locked() ) {
				secupress_add_settings_error( 'general', 'backup_password_locked', secupress_get_backup_password_lock_message(), 'error' );
			} else {
				secupress_add_settings_error( 'general', 'backup_password_wrong', __( 'The current backup password is not correct.', 'secupress' ), 'error' );
			}
		} elseif ( $hash && '' === $new_pass ) {
			if ( ! secupress_remove_backup_password_constant() ) {
				secupress_add_settings_error( 'general', 'backup_password_not_removed', __( 'The backup password constant could not be removed from the configuration file.', 'secupress' ), 'error' );
			} else {
				unset( $settings['backups-storage_password_hash'], $settings['backups-storage_password_constant'] );
				secupress_backup_password_clear_failed_attempts();
			}
		} elseif ( $new_pass && ( ! $hash || $new_pass !== $old_pass ) ) {
			$name = ! empty( $settings['backups-storage_password_constant'] ) ? $settings['backups-storage_password_constant'] : secupress_get_backup_password_constant_name( true );
			if ( ! secupress_write_backup_password_constant( $new_pass, $name ) ) {
				secupress_add_settings_error( 'general', 'backup_password_not_written', __( 'The backup password could not be written to wp-config.php.', 'secupress' ), 'error' );
			} else {
				$settings['backups-storage_password_hash']       = password_hash( $new_pass, PASSWORD_DEFAULT );
				$settings['backups-storage_password_constant']   = $name;
				$generation = isset( $settings['backups-storage_password_generation'] ) ? (int) $settings['backups-storage_password_generation'] : 0;
				$settings['backups-storage_password_generation'] = $generation + 1;
				secupress_backup_password_clear_failed_attempts();
			}
		}
	}

	return $settings;
}


add_action( 'wp_ajax_secupress_backup_files',    'secupress_backup_files_ajax_post_cb' );
add_action( 'admin_post_secupress_backup_files', 'secupress_backup_files_ajax_post_cb' );
/**
 * Will do a files backup.
 *
 * @since 1.0
 */
function secupress_backup_files_ajax_post_cb() {
	secupress_check_user_capability();
	secupress_check_admin_referer( 'secupress_backup_files' );

	// Sanitize and save the ignored directories.
	$abspath   = wp_normalize_path( ABSPATH );
	$ignored   = ! empty( $_POST['ignored_directories'] ) ? $_POST['ignored_directories'] : '';
	$ignored   = explode( "\n", $ignored );
	$ignored   = array_filter( $ignored );
	$default_ignored = array(
		WP_CONTENT_DIR . '/cache',
	);
	$backups_parent  = untrailingslashit( wp_normalize_path( secupress_get_parent_backups_path() ) );
	if ( 0 === strpos( $backups_parent, $abspath ) ) {
		$default_ignored[] = $backups_parent;
	}
	$ignored   = array_merge( $default_ignored, $ignored );
	$ignored   = array_flip( $ignored );
	$dirs      = array();

	foreach ( $ignored as $directory => $i ) {
		$directory = wp_normalize_path( trim( $directory ) );
		$directory = str_replace( $abspath, '', $directory );
		$directory = sanitize_text_field( $directory );
		$directory = untrailingslashit( $directory );

		if ( empty( $dirs[ $directory ] ) && ! preg_match( '@^/?\.?\.?$@', $directory ) ) {
			$dirs[ $directory ] = 1;
		}
	}

	$ignored = implode( "\n", array_keys( $dirs ) );

	update_site_option( 'secupress_file-backups_settings', array( 'ignored_directories' => $ignored ) );

	// Backup.
	if ( ! class_exists( 'ZipArchive' ) ) {
		secupress_admin_die( sprintf( __( 'Class %s is missing, the zip archive cannot be created.', 'secupress' ), '<code>ZipArchive</code>' ) );
	}

	$backup_file = secupress_do_files_backup();

	if ( ! $backup_file ) {
		$error = function_exists( 'secupress_backup_last_error' ) ? secupress_backup_last_error() : '';
		secupress_admin_die( $error ? $error : __( 'No backup file created.', 'secupress' ) );
	}

	$backup_files = secupress_get_backup_file_list();

	secupress_admin_send_response_or_redirect( array(
		'ignoredFiles' => $ignored,
		'elemRow'      => secupress_print_backup_file_formated( $backup_file, false ),
		'countText'    => sprintf( _n( '%s available Backup', '%s available Backups', count( $backup_files ), 'secupress' ), number_format_i18n( count( $backup_files ) ) ),
	) );
}


add_action( 'wp_ajax_secupress_backup_db',    'secupress_backup_db_ajax_post_cb' );
add_action( 'admin_post_secupress_backup_db', 'secupress_backup_db_ajax_post_cb' );
/**
 * Will do a DB backup.
 *
 * @since 1.0
 */
function secupress_backup_db_ajax_post_cb() {
	secupress_check_user_capability();
	secupress_check_admin_referer( 'secupress_backup_db' );

	// Sanitize and save the tables to backup.
	$other_tables  = secupress_get_non_wp_tables();
	$chosen_tables = array();

	if ( $other_tables ) {
		$chosen_tables = ! empty( $_POST['other_tables'] ) && is_array( $_POST['other_tables'] ) ? $_POST['other_tables'] : array();
		$chosen_tables = array_intersect( $other_tables, $chosen_tables );
		$chosen_tables = array_values( $chosen_tables );
	}

	update_site_option( 'secupress_database-backups_settings', array( 'other_tables' => $chosen_tables ) );

	// Backup.
	if ( ! class_exists( 'ZipArchive' ) ) {
		secupress_admin_die( sprintf( __( 'Class %s is missing, the zip archive cannot be created.', 'secupress' ), secupress_code_me( 'ZipArchive' ) ) );
	}

	$backup_file = secupress_do_db_backup();

	if ( ! $backup_file ) {
		$error = function_exists( 'secupress_backup_last_error' ) ? secupress_backup_last_error() : '';
		secupress_admin_die( $error ? $error : __( 'No backup file created.', 'secupress' ) );
	}

	$backup_files = secupress_get_backup_file_list();

	secupress_admin_send_response_or_redirect( array(
		'elemRow'   => secupress_print_backup_file_formated( $backup_file, false ),
		'countText' => sprintf( _n( '%s available Backup', '%s available Backups', count( $backup_files ), 'secupress' ), number_format_i18n( count( $backup_files ) ) ),
	) );
}


add_action( 'admin_post_secupress_download_backup', 'secupress_download_backup_ajax_post_cb' );
/**
 * Will download a requested backup.
 * No need any AJAX support here.
 *
 * @since 1.0
 */
function secupress_download_backup_ajax_post_cb() {
	if ( ! isset( $_GET['file'] ) ) {
		secupress_admin_die();
	}

	secupress_check_user_capability();
	secupress_check_admin_referer( 'secupress_download_backup-' . $_GET['file'] );

	$file = glob( secupress_get_local_backups_path() . '*' . $_GET['file'] . '*.{zip,sql}', GLOB_BRACE );

	if ( ! $file ) {
		secupress_admin_die();
	}

	if ( ini_get( 'zlib.output_compression' ) ) {
		ini_set( 'zlib.output_compression', 'Off' );
	}

	ob_start();

	$file = reset( $file );
	$size = filesize( $file );

	header( $_SERVER['SERVER_PROTOCOL'] . ' 200 OK' );
	header( 'Expires: 0' );
	header( 'Pragma: public' );
	header( 'Cache-Control: must-revalidate, post-check=0, pre-check=0' );
	header( 'Cache-Control: private', false );
	header( 'Content-Type: application/octet-stream' );
	header( 'Content-Disposition: attachment; filename="' . basename( str_replace( array( '@', '#' ), '-', $file ) ) . '"' );
	header( 'Last-Modified: ' . gmdate( 'D, d M Y H:i:s', filemtime( $file ) ) . ' GMT' );
	header( 'Content-Length: ' . $size );
	header( 'Connection: close' );
	ob_end_clean();

	if ( $size < 64 * 1024 ) {
		readfile( $file );
	} else {
		secupress_time_limit( 0 );
		$fp = fopen( $file, 'rb' );

		while ( ! feof( $fp ) ) {
			echo fread( $fp, 64 * 1024 );
			flush();
		}
		fclose( $fp );
	}
	die();
}


add_action( 'wp_ajax_secupress_delete_backup',    'secupress_delete_backup_ajax_post_cb' );
add_action( 'admin_post_secupress_delete_backup', 'secupress_delete_backup_ajax_post_cb' );
/**
 * Will delete a specified backup file.
 *
 * @since 1.0
 */
function secupress_delete_backup_ajax_post_cb() {
	if ( ! isset( $_GET['file'] ) ) {
		secupress_admin_die();
	}

	secupress_check_user_capability();
	secupress_check_admin_referer( 'secupress_delete_backup-' . $_GET['file'] );

	$files = glob( secupress_get_local_backups_path() . '*' . $_GET['file'] . '*.{zip,sql}', GLOB_BRACE );

	if ( ! $files ) {
		secupress_admin_die();
	}

	@array_map( 'unlink', $files );

	$backup_files = secupress_get_backup_file_list();

	secupress_admin_send_response_or_redirect( array(
		'countText' => sprintf( _n( '%s available Backup', '%s available Backups', count( $backup_files ), 'secupress' ), number_format_i18n( count( $backup_files ) ) ),
	) );
}


add_action( 'wp_ajax_secupress_delete_backups',    'secupress_delete_backups_ajax_post_cb' );
add_action( 'admin_post_secupress_delete_backups', 'secupress_delete_backups_ajax_post_cb' );
/**
 * Will delete all the backups.
 *
 * @since 1.0
 */
function secupress_delete_backups_ajax_post_cb() {
	secupress_check_user_capability();
	secupress_check_admin_referer( 'secupress_delete_backups' );

	$files = glob( secupress_get_local_backups_path() . '*.{zip,sql}', GLOB_BRACE );

	if ( ! $files ) {
		secupress_admin_die();
	}

	@array_map( 'unlink', $files );

	secupress_admin_send_response_or_redirect( 1 );
}


add_action( 'admin_post_secupress_send_backup_password_reset', 'secupress_send_backup_password_reset_admin_post_cb' );
/**
 * Send a backup password reset link to admin_email.
 *
 * @since 2.7
 * @author Julio Potier
 */
function secupress_send_backup_password_reset_admin_post_cb() {
	secupress_check_user_capability();
	secupress_check_admin_referer( 'secupress_send_backup_password_reset' );

	if ( ! secupress_get_module_option( 'backups-storage_password_hash', '', 'backups' ) ) {
		secupress_admin_die();
	}

	if ( ! secupress_get_backup_password_failed_attempts() ) {
		secupress_admin_die();
	}

	$cooldown = secupress_get_backup_password_reset_cooldown_message();
	if ( $cooldown ) {
		secupress_add_transient_notice( $cooldown, 'error' );
		wp_safe_redirect( wp_get_referer() );
		die();
	}

	$token = wp_generate_password( 32, false, false );
	set_site_transient( 'secupress_backup_password_reset', wp_hash( $token ), HOUR_IN_SECONDS );
	set_site_transient( 'secupress_backup_password_reset_sent', time(), secupress_get_backup_password_reset_cooldown() );

	$url     = add_query_arg(
		[
			'action'   => 'secupress_confirm_backup_password_reset',
			'token'    => $token,
			'_wpnonce' => wp_create_nonce( 'secupress_confirm_backup_password_reset' ),
		],
		admin_url( 'admin-post.php' )
	);
	$subject = sprintf( __( '[%s] Reset your backup password', 'secupress' ), '###SITENAME###' );
	$message = sprintf(
		__( "Someone requested to reset the backup ZIP password on ###SITENAME###.\n\nClick this link to remove the password protection (you will be able to set a new one afterwards):\n%s\n\nThis link expires in one hour.\nExisting backup files remain encrypted with the previous password.", 'secupress' ),
		$url
	);

	secupress_send_mail( get_option( 'admin_email' ), $subject, $message );
	secupress_add_transient_notice( __( 'A reset link has been sent to the main administrator.', 'secupress' ) );

	wp_safe_redirect( wp_get_referer() );
	die();
}


add_action( 'admin_post_secupress_confirm_backup_password_reset', 'secupress_confirm_backup_password_reset_admin_post_cb' );
/**
 * Confirm a backup password reset.
 *
 * @since 2.7
 * @author Julio Potier
 */
function secupress_confirm_backup_password_reset_admin_post_cb() {
	secupress_check_user_capability();
	secupress_check_admin_referer( 'secupress_confirm_backup_password_reset' );

	$token   = isset( $_GET['token'] ) ? wp_unslash( $_GET['token'] ) : '';
	$stored  = get_site_transient( 'secupress_backup_password_reset' );

	if ( ! $token || ! $stored || ! hash_equals( $stored, wp_hash( $token ) ) ) {
		secupress_add_transient_notice( __( 'This reset link is invalid or has expired.', 'secupress' ), 'error' );
		wp_safe_redirect( secupress_admin_url( 'modules', 'backups' ) );
		die();
	}

	if ( ! secupress_remove_backup_password_constant() ) {
		secupress_add_transient_notice( __( 'The backup password constant could not be removed from the configuration file.', 'secupress' ), 'error' );
		wp_safe_redirect( secupress_admin_url( 'modules', 'backups' ) );
		die();
	}

	$options = get_site_option( 'secupress_backups_settings', [] );
	$options = is_array( $options ) ? $options : [];
	unset( $options['backups-storage_password_hash'], $options['backups-storage_password_constant'] );
	update_site_option( 'secupress_backups_settings', $options );
	delete_site_transient( 'secupress_backup_password_reset' );
	delete_site_transient( 'secupress_backup_password_reset_sent' );
	secupress_backup_password_clear_failed_attempts();

	secupress_add_transient_notice( __( 'The backup password has been removed. Existing backup files remain encrypted with the previous password. You can set a new password now.', 'secupress' ) );

	wp_safe_redirect( secupress_admin_url( 'modules', 'backups' ) );
	die();
}


/** --------------------------------------------------------------------------------------------- */
/** TOOLS ======================================================================================= */
/** ----------------------------------------------------------------------------------------------*/

/**
 * List the existing backup files (`.zip`, `.sql`).
 *
 * @since 1.0
 *
 * @return (array|bool) An array of file paths. False on error.
 */
function secupress_get_backup_file_list() {
	return glob( secupress_get_local_backups_path() . '*.{zip,sql}', GLOB_BRACE );
}


/**
 * Print an HTML markup for a backup: creation date, download link, deletion link, etc.
 *
 * @since 1.0
 *
 * @param (string) $file The file path.
 * @param (bool)   $echo Return or echo the markup.
 *
 * @return (string)
 */
function secupress_print_backup_file_formated( $file, $echo = true ) {

	list( $_date, $_type, $_prefix, $file_uniqid ) = explode( '.', esc_html( basename( $file ) ) );

	$_date   = strtotime( substr_replace( $_date, ':', 13, 1 ) ) + ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS );
	$_date   = date_i18n( __( 'M jS Y', 'secupress' ) . ' ' . __( 'G:i', 'secupress' ), $_date, true );
	$_prefix = str_replace( array( '@', '#' ), array( '.', '/' ), $_prefix );

	switch ( $_type ) :
		case 'database' :
			$_type = __( 'Database', 'secupress' );
		break;

		case 'files' :
			$_type = __( 'Files', 'secupress' );
		break;

		default :
			$_type = ucwords( $_type );
	endswitch;

	$download_url = esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=secupress_download_backup&file=' . $file_uniqid ), 'secupress_download_backup-' . $file_uniqid ) );
	$delete_url   = esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=secupress_delete_backup&file=' . $file_uniqid ), 'secupress_delete_backup-' . $file_uniqid ) );

	$file_format  = sprintf( '<p class="secupress-large-row">%s <strong>%s</strong> <em>(%s)</em>', $_type, $_prefix, $_date );
	if ( preg_match( '/\.p(\d+)\.zip$/', basename( $file ), $generation_match ) ) {
		$generation         = (int) $generation_match[1];
		$current_generation = (int) secupress_get_module_option( 'backups-storage_password_generation', 0, 'backups' );
		if ( $generation === $current_generation && 'ok' === secupress_get_backup_password_status() ) {
			$badge = __( 'current password', 'secupress' );
		} else {
			$badge = sprintf( __( 'previous password (#%d)', 'secupress' ), $generation );
		}
		$file_format .= ' <span class="description">' . esc_html( $badge ) . '</span>';
	}
	$file_format .= sprintf( '<span><a href="%s">%s</a> | <a href="%s" class="a-delete-backup" data-file-uniqid="%s">%s</a></span></p>', $download_url, _x( 'Download', 'verb', 'secupress' ), $delete_url, $file_uniqid, __( 'Delete', 'secupress' ) );

	if ( ! $echo ) {
		return $file_format;
	}

	echo $file_format;
}
