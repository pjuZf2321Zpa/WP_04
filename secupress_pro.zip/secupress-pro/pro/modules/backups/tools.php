<?php
defined( 'ABSPATH' ) or die( 'Something went wrong.' );

/**
 * Get temporary backups folder path.
 *
 * @since 1.0
 * @author Grégory Viguier
 *
 * @param (bool) $relative Set to true to get the path relative to the site's root.
 *
 * @return (string) The absolute (or relative) path to the temporary backups folder.
 */
function secupress_get_temporary_backups_path( $relative = false ) {
	static $abs_path;
	static $rel_path;

	if ( ! isset( $abs_path ) ) {
		$abs_path = secupress_get_parent_backups_path() . 'secupress-' . secupress_generate_hash( 'backups-tmp', 8, 8 ) . '-tmp/';
		$rel_path = str_replace( rtrim( wp_normalize_path( ABSPATH ), '/' ), '', $abs_path );
	}

	return $relative ? $rel_path : $abs_path;
}


/**
 * Get the path to the folder containing the local backups.
 *
 * @since 1.0
 * @author Grégory Viguier
 *
 * @param (bool) $relative Set to true to get the path relative to the site's root.
 *
 * @return (string) The absolute (or relative) path to the folder containing the local backups.
 */
function secupress_get_local_backups_path( $relative = false ) {
	static $abs_path;
	static $rel_path;

	if ( ! isset( $abs_path ) ) {
		$abs_path = secupress_get_hashed_folder_name( 'backup', secupress_get_parent_backups_path() );
		$rel_path = str_replace( rtrim( wp_normalize_path( ABSPATH ), '/' ), '', $abs_path );
	}

	return $relative ? $rel_path : $abs_path;
}


/**
 * Perform a backup of the files.
 *
 * @since 1.0
 * @author Grégory Viguier
 *
 * @return (bool) True on success, false on failure.
 */
function secupress_do_files_backup() {
	if ( ! class_exists( 'ZipArchive' ) || ! secupress_pre_backup() ) {
		return false;
	}

	if ( ! secupress_backup_password_allows_backup() ) {
		return false;
	}

	require_once( SECUPRESS_PRO_MODULES_PATH . 'backups/plugins/class-secupress-backup.php' );
	require_once( SECUPRESS_PRO_MODULES_PATH . 'backups/plugins/class-secupress-backup-files.php' );

	$backup_storage = secupress_get_module_option( 'backups-storage_location', 'local', 'backups' );

	if ( 'local' === $backup_storage ) {
		require_once( SECUPRESS_PRO_MODULES_PATH . 'backups/plugins/class-secupress-backup-files-local.php' );

		$zip = new SecuPress_Backup_Files_Local;
	} else {
		// DropBox, etc ////.
		return false;
	}

	return $zip->do_backup();
}


/**
 * Perform a backup of the database.
 *
 * @since 1.0
 * @author Grégory Viguier
 *
 * @return (bool) True on success, false on failure.
 */
function secupress_do_db_backup() {
	if ( ! class_exists( 'ZipArchive' ) || ! secupress_pre_backup() ) {
		return false;
	}

	if ( ! secupress_backup_password_allows_backup() ) {
		return false;
	}

	require_once( SECUPRESS_PRO_MODULES_PATH . 'backups/plugins/class-secupress-backup.php' );
	require_once( SECUPRESS_PRO_MODULES_PATH . 'backups/plugins/class-secupress-backup-db.php' );

	$backup_storage = secupress_get_module_option( 'backups-storage_location', 'local', 'backups' );

	if ( 'local' === $backup_storage ) {
		require_once( SECUPRESS_PRO_MODULES_PATH . 'backups/plugins/class-secupress-backup-db-local.php' );

		$zip = new SecuPress_Backup_Db_Local;
	} else {
		// DropBox, etc ////.
		return false;
	}

	return $zip->do_backup();
}


/**
 * Prepare the backups folder: create the folder if it doesn't exist and place a `.htaccess` file inside, denying access to.
 *
 * @since 2.7 Skip server rules when the folder is outside the web root.
 * @since 1.0
 *
 * @return (bool) True if the folder is writable (and the `.htaccess` file exists when required).
 */
function secupress_pre_backup() {
	global $is_apache, $is_nginx, $is_iis7;

	$backups_dir = secupress_get_parent_backups_path();
	$backup_dir  = secupress_get_local_backups_path();
	$tmp_dir     = secupress_get_temporary_backups_path();
	$filesystem  = secupress_get_filesystem();

	secupress_mkdir_p( $backup_dir );
	secupress_mkdir_p( $tmp_dir );

	if ( function_exists( 'secupress_backups_path_is_outside_web_root' ) && secupress_backups_path_is_outside_web_root() ) {
		return wp_is_writable( $backup_dir ) && wp_is_writable( $tmp_dir );
	}

	if ( $is_apache ) {
		$file = '.htaccess';
	} elseif ( $is_iis7 ) {
		$file = 'web.config';
	} elseif ( $is_nginx ) {
		return wp_is_writable( $backup_dir ) && wp_is_writable( $tmp_dir );
	} else {
		return false;
	}

	$file = $backups_dir . $file;

	if ( $filesystem->exists( $file ) ) {
		return wp_is_writable( $backup_dir ) && wp_is_writable( $tmp_dir );
	}

	$filesystem->put_contents( $file, secupress_backup_get_protection_content() );

	return wp_is_writable( $backup_dir ) && wp_is_writable( $tmp_dir ) && $filesystem->exists( $file );
}


/**
 * Get rules to be added to a `.htaccess`/`nginx.conf`/`web.config` file to protect the backups folder.
 *
 * @since 2.7 Return an empty string when the folder is outside the web root.
 * @since 1.0
 *
 * @return (string) The rules to insert.
 */
function secupress_backup_get_protection_content() {
	global $is_apache, $is_nginx, $is_iis7;

	$file_content = '';

	if ( function_exists( 'secupress_backups_path_is_outside_web_root' ) && secupress_backups_path_is_outside_web_root() ) {
		return $file_content;
	}

	if ( $is_apache ) {
		// Apache.
		$file_content = "<IfModule mod_authz_core.c>
  Require all denied
</IfModule>
<IfModule !mod_authz_core.c>
  Order allow,deny
  Deny from all
</IfModule>";
	} elseif ( $is_iis7 ) {
		/*
		 * IIS7.
		 * https://www.iis.net/configreference/system.webserver/security/authorization
		 * https://technet.microsoft.com/en-us/library/cc772441%28v=ws.10%29.aspx
		 */
		$file_content = '<?xml version="1.0" encoding="utf-8" ?>
<configuration>
  <system.webServer>
    <security>
      <authorization>
        <remove users="*" roles="" verbs="" />
        <add accessType="Deny" users="*" roles="" verbs="" />
      </authorization>
    </security>
  </system.webServer>
</configuration>';
	} elseif ( $is_nginx ) {
		// Nginx.
		$backup_dir   = secupress_get_local_backups_path( true );
		$path         = secupress_get_rewrite_bases();
		$path         = $path['home_from'] . rtrim( dirname( $backup_dir ), '/' );
		$file_content = "
server {
	location ~* $path {
		deny all;
	}
}";
	}

	return $file_content;
}

/**
 * Put contents with 'ab' (the end of) param instead of 'wb' (the begining of)
 *
 * @since 1.4.6
 * @param (string) $file The backup file.
 * @param (string) $contents The backup content.
 * @author Julio Potier
 **/
function secupress_backup_put_contents( $file, $contents ) {
	$fp = @fopen( $file, 'ab' );

	if ( ! $fp ) {
		return false;
	}
	mbstring_binary_safe_encoding();
	$data_length = strlen( $contents );
	$bytes_written = fwrite( $fp, $contents );
	reset_mbstring_encoding();
	fclose( $fp );
}

/**
 * Tell if ZipArchive can encrypt entries with AES-256.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @return (bool)
 */
function secupress_backup_zip_encryption_is_available() {
	if ( ! class_exists( 'ZipArchive' ) ) {
		return false;
	}
	if ( ! method_exists( 'ZipArchive', 'setEncryptionName' ) ) {
		return false;
	}
	if ( ! defined( 'ZipArchive::EM_AES_256' ) ) {
		return false;
	}
	if ( method_exists( 'ZipArchive', 'isEncryptionMethodSupported' ) && ! ZipArchive::isEncryptionMethodSupported( ZipArchive::EM_AES_256 ) ) {
		return false;
	}
	return true;
}

/**
 * Get or set the password waiting to be written in wp-config.php.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @param (string|null) $set Optional. Set the pending password.
 *
 * @return (string|null)
 */
function secupress_backup_password_pending( $set = null ) {
	static $pending;
	if ( 0 < func_num_args() ) {
		$pending = $set;
	}
	return $pending;
}

/**
 * Get or set the constant name waiting to be written in wp-config.php.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @param (string|null) $set Optional. Set the pending name.
 *
 * @return (string|null)
 */
function secupress_backup_password_pending_name( $set = null ) {
	static $pending;
	if ( 0 < func_num_args() ) {
		$pending = $set;
	}
	return $pending;
}

/**
 * Get or set the last backup error message.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @param (string|null) $set Optional. Set the error message.
 *
 * @return (string)
 */
function secupress_backup_last_error( $set = null ) {
	static $error = '';
	if ( 0 < func_num_args() ) {
		$error = (string) $set;
	}
	return $error;
}

/**
 * Get the wp-config constant name used for the backup ZIP password.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @param (bool) $create Generate a name if none is stored.
 *
 * @return (string)
 */
function secupress_get_backup_password_constant_name( $create = false ) {
	$stored = secupress_get_module_option( 'backups-storage_password_constant', '', 'backups' );
	if ( $stored ) {
		return $stored;
	}
	$pending = secupress_backup_password_pending_name();
	if ( $pending ) {
		return $pending;
	}
	if ( ! $create ) {
		return '';
	}
	return 'SECUPRESS_BACKUP_ZIP_PASSWORD_' . strtoupper( secupress_generate_key_for_object( 'backup_zip_password', 8 ) );
}

/**
 * Get the backup password configuration status.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @return (string) none, ok, missing_constant, missing_hash, mismatch.
 */
function secupress_get_backup_password_status() {
	$hash    = secupress_get_module_option( 'backups-storage_password_hash', '', 'backups' );
	$name    = secupress_get_backup_password_constant_name();
	$defined = $name && defined( $name );
	$has_hash = (bool) $hash;

	if ( ! $has_hash && ! $defined ) {
		return 'none';
	}
	if ( $has_hash && ! $defined ) {
		return 'missing_constant';
	}
	if ( ! $has_hash && $defined ) {
		return 'missing_hash';
	}
	if ( password_verify( (string) constant( $name ), $hash ) ) {
		return 'ok';
	}
	return 'mismatch';
}

/**
 * Message used when a backup is aborted because of the password.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @return (string)
 */
function secupress_get_backup_password_abort_message() {
	$status = secupress_get_backup_password_status();
	if ( in_array( $status, [ 'ok', 'none' ], true ) ) {
		return '';
	}
	return __( 'The backup password is misconfigured. No backup file was created. Please fix or remove the backup password.', 'secupress' );
}

/**
 * Whether the backup password is in a usable state to create a ZIP.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @return (bool)
 */
function secupress_backup_password_allows_backup() {
	$status = secupress_get_backup_password_status();
	if ( in_array( $status, [ 'ok', 'none' ], true ) ) {
		if ( 'ok' === $status && ! secupress_backup_zip_encryption_is_available() ) {
			secupress_backup_last_error( __( 'Expected encryption is not available on this server (ZIP AES-256). No backup file was created.', 'secupress' ) );
			return false;
		}
		return true;
	}
	secupress_backup_last_error( secupress_get_backup_password_abort_message() );
	return false;
}

add_action( 'admin_init', 'secupress_backup_password_admin_notices' );
/**
 * Admin notices for the backup password.
 *
 * @since 2.7
 * @author Julio Potier
 */
function secupress_backup_password_admin_notices() {
	if ( ! function_exists( 'secupress_add_notice' ) ) {
		return;
	}
	secupress_require_class( 'Admin', 'Notices' );
	if ( ! current_user_can( secupress_get_capability() ) ) {
		return;
	}

	$status  = secupress_get_backup_password_status();
	$modules = secupress_admin_url( 'modules', 'backups' );

	if ( ! in_array( $status, [ 'ok', 'none' ], true ) ) {
		$message  = '<p><strong>' . __( 'Warning, the backup password is misconfigured.', 'secupress' ) . '</strong></p>';
		$message .= '<p>' . _x( 'Please change it or remove it.', '"it" is a password', 'secupress' ) . '</p>';
		$message .= '<p><a href="' . esc_url( $modules ) . '">' . __( 'Backup settings', 'secupress' ) . '</a></p>';
		secupress_add_notice( $message, 'error', false );
		return;
	}

	if ( 'none' !== $status ) {
		return;
	}
	if ( ! secupress_is_submodule_active( 'schedules', 'schedules-backups' ) ) {
		return;
	}
	if ( ! secupress_backup_zip_encryption_is_available() ) {
		return;
	}

	$message  = '<p><strong>' . __( 'Protect your scheduled backups with a password.', 'secupress' ) . '</strong></p>';
	$message .= '<p>' . __( 'A password can now be added to encrypt your backup files.', 'secupress' ) . '</p>';
	$message .= '<p><a href="' . esc_url( $modules ) . '">' . __( 'Backup settings', 'secupress' ) . '</a></p>';
	secupress_add_notice( $message, 'warning', 'backup-password-available' );
}

/**
 * Write the backup password constant into wp-config.php.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @param (string) $password The password.
 * @param (string) $name     The constant name.
 *
 * @return (bool)
 */
function secupress_write_backup_password_constant( $password, $name ) {
	secupress_backup_password_pending( $password );
	secupress_backup_password_pending_name( $name );
	$result = secupress_wpconfig_modules_activation( 'backup_password', true );
	secupress_backup_password_pending( null );
	secupress_backup_password_pending_name( null );
	return true === $result;
}

/**
 * Remove the backup password constant from wp-config.php.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @return (bool)
 */
function secupress_remove_backup_password_constant() {
	if ( ! secupress_is_wpconfig_writable() ) {
		return false;
	}
	$name = secupress_get_backup_password_constant_name( true );
	secupress_backup_password_pending_name( $name );
	secupress_wpconfig_modules_deactivation( 'backup_password' );
	secupress_backup_password_pending_name( null );
	$path = secupress_find_wpconfig_path();
	if ( ! $path ) {
		return false;
	}
	$content = secupress_get_filesystem()->get_contents( $path );
	return ! preg_match( '@# BEGIN SecuPress backup_password\s.*# END SecuPress@sU', $content );
}

/**
 * Transient name used to count failed backup password attempts.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @return (string)
 */
function secupress_get_backup_password_attempts_transient_name() {
	return 'secupress_backup_password_attempts_' . get_current_user_id();
}

/**
 * Get the number of failed backup password attempts.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @return (int)
 */
function secupress_get_backup_password_failed_attempts() {
	return (int) get_site_transient( secupress_get_backup_password_attempts_transient_name() );
}

/**
 * Whether backup password retries are locked for 24 hours.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @return (bool)
 */
function secupress_backup_password_is_locked() {
	return 3 <= secupress_get_backup_password_failed_attempts();
}

/**
 * Record a failed backup password attempt.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @return (int) The new attempts count.
 */
function secupress_backup_password_add_failed_attempt() {
	$attempts = secupress_get_backup_password_failed_attempts() + 1;
	set_site_transient( secupress_get_backup_password_attempts_transient_name(), $attempts, DAY_IN_SECONDS );
	if ( 3 === $attempts ) {
		secupress_send_backup_password_attempts_alert();
	}
	return $attempts;
}

/**
 * Clear failed backup password attempts.
 *
 * @since 2.7
 * @author Julio Potier
 */
function secupress_backup_password_clear_failed_attempts() {
	delete_site_transient( secupress_get_backup_password_attempts_transient_name() );
}

/**
 * Message displayed when backup password retries are locked.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @return (string)
 */
function secupress_get_backup_password_lock_message() {
	return __( 'Too many failed attempts. Please wait 24 hours before trying again. An alert email has been sent to the webmaster.', 'secupress' );
}

/**
 * Cooldown duration after a backup password reset email.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @return (int)
 */
function secupress_get_backup_password_reset_cooldown() {
	return 15 * MINUTE_IN_SECONDS;
}

/**
 * Message displayed while a backup password reset email is in cooldown.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @return (string)
 */
function secupress_get_backup_password_reset_cooldown_message() {
	$sent = (int) get_site_transient( 'secupress_backup_password_reset_sent' );
	if ( 1000 > $sent ) {
		return '';
	}
	$now       = time();
	$remaining = $sent + secupress_get_backup_password_reset_cooldown() - $now;
	if ( 0 >= $remaining ) {
		return '';
	}
	$ago_minutes  = max( 1, (int) floor( ( $now - $sent ) / MINUTE_IN_SECONDS ) );
	$wait_minutes = max( 1, (int) ceil( $remaining / MINUTE_IN_SECONDS ) );
	return sprintf(
		__( 'A reset email has already been sent <strong>%1$s ago</strong>. Another one can be requested in <strong>%2$s</strong>.', 'secupress' ),
		sprintf( _n( '%s minute', '%s minutes', $ago_minutes, 'secupress' ), number_format_i18n( $ago_minutes ) ),
		sprintf( _n( '%s minute', '%s minutes', $wait_minutes, 'secupress' ), number_format_i18n( $wait_minutes ) )
	);
}

/**
 * Send an alert to the webmaster after too many failed backup password attempts.
 *
 * @since 2.7
 * @author Julio Potier
 */
function secupress_send_backup_password_attempts_alert() {
	$user    = wp_get_current_user();
	$subject = sprintf( __( '[%s] Alert: too many failed backup password attempts', 'secupress' ), '###SITENAME###' );
	$message = sprintf(
		__( '3 failed attempts to change the backup ZIP password have been recorded on ###SITENAME###.

User: %1$s (%2$s)
IP address: %3$s

Further attempts are blocked for 24 hours.', 'secupress' ),
		$user->user_login,
		$user->user_email,
		secupress_get_ip()
	);
	secupress_send_mail( get_option( 'admin_email' ), $subject, $message );
}
