<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( );
}
/**
 * @Packge    : construz
 * @version   : 1.0
 * @Author    : favdevs
 * @Author URI: https://www.favdevs.com/
 */
 
// demo import file
function construz_import_files() {
    return array(
        array(
            'import_file_name'             => esc_html__('Construz Demo','construz'),
            'local_import_file'            =>  CONSTRUZ_DEMO_DIR_PATH  . 'construz-demo.xml',
            'local_import_widget_file'     =>  CONSTRUZ_DEMO_DIR_PATH  . 'construz-widgets-demo.wie',
            'local_import_redux'           => array(
                array(
                    'file_path'   =>  CONSTRUZ_DEMO_DIR_PATH . 'redux_options_demo.json',
                    'option_name' => 'construz_opt',
                ),
            ),
        ),
    );
}
add_filter( 'pt-ocdi/import_files', 'construz_import_files' );

// demo import setup
function construz_after_import_setup() {
	// Assign menus to their locations.
	$main_menu   = get_term_by( 'name', 'Header Menu', 'nav_menu' );

	set_theme_mod( 'nav_menu_locations', array(
			'primary-menu'    => $main_menu->term_id,
			'mobile-menu'     =>  $main_menu ->term_id,
		)
	);

	// Assign front page and posts page (blog page).
	$front_page_id 	= get_page_by_title( 'Home 01' );
	$blog_page_id  	= get_page_by_title( 'Blog' );

	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $front_page_id->ID );
	update_option( 'page_for_posts', $blog_page_id->ID );

    
    
    construz_elementor_settings();
    $elem_clear_cache = new \Elementor\Core\Files\Manager();
    $elem_clear_cache->clear_cache();
    
}
add_action( 'pt-ocdi/after_import', 'construz_after_import_setup' );


//disable the branding notice after successful demo import
add_filter( 'pt-ocdi/disable_pt_branding', '__return_true' );

//change the location, title and other parameters of the plugin page
function construz_import_plugin_page_setup( $default_settings ) {
	$default_settings['parent_slug'] = 'themes.php';
	$default_settings['page_title']  = esc_html__( 'Construz Demo Import' , 'construz' );
	$default_settings['menu_title']  = esc_html__( 'Import Demo Data' , 'construz' );
	$default_settings['capability']  = 'import';
	$default_settings['menu_slug']   = 'construz-demo-import';

	return $default_settings;
}
add_filter( 'pt-ocdi/plugin_page_setup', 'construz_import_plugin_page_setup' );
 
// Enqueue scripts
function construz_demo_import_custom_scripts(){
	if( isset( $_GET['page'] ) && $_GET['page'] == 'construz-demo-import' ){
		// style
		wp_enqueue_style( 'construz-demo-import', CONSTRUZ_DEMO_DIR_URI.'css/construz.demo.import.css', array(), '1.0', false );
	}
}
add_action( 'admin_enqueue_scripts', 'construz_demo_import_custom_scripts' );

//Global Color Option
function construz_elementor_settings() {
    $kit_id = get_option( 'elementor_active_kit' );
    $meta_old = get_post_meta( $kit_id, '_elementor_page_settings' );

    $settings = json_decode( '[{"system_colors":[{"_id":"construz_opt_primary","title":"Primary","color":"#EA5501"},{"_id":"construz_opt_headline","title":"Heading","color":"#15161C"},{"_id":"construz_opt_body","title":"Body","color":"#737373"},{"_id":"construz_opt_body_bg","title":"Body Background","color":"#ffffff"},{"_id":"construz_opt_light_color","title":"Light Color","color":"#9fa2ad"},{"_id":"construz_opt_black_color","title":"Black Color","color":"#202020"},{"_id":"construz_opt_white_color","title":"White Color","color":"#ffffff"},{"_id":"construz_opt_gray_color","title":"Gray Color","color":"#232323"},{"_id":"construz_opt_yellow_color","title":"Yellow Color","color":"#FFB539"},{"_id":"construz_opt_success_color","title":"Success Color","color":"#28a745"},{"_id":"construz_opt_error_color","title":"Error Color","color":"#dc3545"},{"_id":"construz_opt_border_color","title":"Border Color","color":"#15161c26"},{"_id":"construz_opt_construz_smoke","title":"Smoke Color","color":"#FAFAFA"}],"system_typography":[],"__globals__":[]}]', true );

    return update_post_meta( $kit_id, '_elementor_page_settings', $settings[0] );
}