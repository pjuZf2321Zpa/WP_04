<?php
/**
 * Classic cart Share Cart button and modal.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var array $users Share targets.
 */
?>
<button type="button" id="ccp_sahre_cart" class="button add_buttn ccp_sahre_cart wwp-ccp-share-cart-btn" name="ccp_sahre_cart">
	<?php esc_html_e( 'Share cart', 'woocommerce-wholesale-pricing' ); ?>
</button>

<div id="ccp_myModal" class="modal wwp-ccp-modal" hidden>
	<div class="modal-content">
		<div class="modal-header">
			<h4 class="ccp_response_heading"><?php esc_html_e( 'Share cart', 'woocommerce-wholesale-pricing' ); ?></h4>
			<button type="button" class="close wwp-ccp-modal__close" aria-label="<?php esc_attr_e( 'Close', 'woocommerce-wholesale-pricing' ); ?>">&times;</button>
		</div>
		<div class="modal-body ccp_response_body">
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="ccp_share_title"><?php esc_html_e( 'Title', 'woocommerce-wholesale-pricing' ); ?></label>
				<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="ccp_share_title" id="ccp_share_title">
			</p>
			<p class="woocommerce-form-row woocommerce-form-row--ccp_share_user form-row form-row-ccp_share_user">
				<label for="ccp_share_user"><?php esc_html_e( 'User(s)', 'woocommerce-wholesale-pricing' ); ?></label>
				<select name="ccp_share_user" id="ccp_share_user">
					<option value=""><?php esc_html_e( 'Select User', 'woocommerce-wholesale-pricing' ); ?></option>
					<?php foreach ( $users as $user ) : ?>
						<option value="<?php echo esc_attr( $user['user_id'] ); ?>"><?php echo esc_html( $user['display_name'] ); ?></option>
					<?php endforeach; ?>
				</select>
			</p>
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<button type="button" id="ccp_sahre_cart_save" class="button ccp_sahre_cart_save wwp-ccp-btn wwp-ccp-btn--primary" name="ccp_sahre_cart_save">
					<?php esc_html_e( 'Share cart', 'woocommerce-wholesale-pricing' ); ?>
				</button>
			</p>
		</div>
	</div>
</div>
