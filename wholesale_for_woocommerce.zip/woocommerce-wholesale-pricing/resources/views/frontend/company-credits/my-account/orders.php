<?php
/**
 * Company orders tab.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int    $company_id Company post ID.
 * @var string $ccp_company_role Company role.
 */

if ( ! authentication_role( 'orders' ) ) {
	return;
}

$company_users = array();
if ( ! empty( $company_id ) ) {
	$company_users = get_users(
		array(
			'meta_key'   => 'ccp_company_id',
			'meta_value' => $company_id,
		)
	);
}

$can_filter_users = in_array( $ccp_company_role, array( 'ccp_manager', 'ccp_owner' ), true );
?>
<section class="wwp-ccp-panel wwp-ccp-panel--orders">
	<div class="wwp-ccp-panel__header">
		<div class="wwp-ccp-panel__heading-wrap">
			<span class="wwp-ccp-panel__icon dashicons dashicons-cart" aria-hidden="true"></span>
			<h4 class="ccp_headding wwp-ccp-panel__title"><?php esc_html_e( 'Company Orders', 'woocommerce-wholesale-pricing' ); ?></h4>
		</div>
		<button type="button" id="ccp_filter_panel" class="ccp_Orders add_buttn wwp-ccp-icon-btn" aria-expanded="false" aria-controls="ccp_filter_panel_wrap" title="<?php esc_attr_e( 'Filters', 'woocommerce-wholesale-pricing' ); ?>">
			<span class="dashicons dashicons-filter" aria-hidden="true"></span>
			<span class="screen-reader-text"><?php esc_html_e( 'Filters', 'woocommerce-wholesale-pricing' ); ?></span>
		</button>
	</div>

	<div id="ccp_filter_panel_wrap" class="wwp-ccp-filters" hidden>
		<p class="wwp-ccp-filters__title"><?php esc_html_e( 'Filters', 'woocommerce-wholesale-pricing' ); ?></p>
		<form id="ccp_form_filter" class="wwp-ccp-filters__form" method="post" action="#">
			<p class="woocommerce-form-row woocommerce-form-row--first form-row form-row-first">
				<label for="start_date"><?php esc_html_e( 'Start Date', 'woocommerce-wholesale-pricing' ); ?></label>
				<input type="date" class="woocommerce-Input woocommerce-Input--text input-text" name="start_date" id="start_date">
			</p>
			<p class="woocommerce-form-row woocommerce-form-row--last form-row form-row-last">
				<label for="end_date"><?php esc_html_e( 'End Date', 'woocommerce-wholesale-pricing' ); ?></label>
				<input type="date" class="woocommerce-Input woocommerce-Input--text input-text" name="end_date" id="end_date">
			</p>
			<?php if ( $can_filter_users ) : ?>
				<p class="woocommerce-form-row woocommerce-form-row--ccp_select_user form-row form-row-ccp_select_user">
					<label for="ccp_select_user"><?php esc_html_e( 'Select User', 'woocommerce-wholesale-pricing' ); ?></label>
					<select name="ccp_select_user" id="ccp_select_user">
						<option value=""><?php esc_html_e( 'Select User', 'woocommerce-wholesale-pricing' ); ?></option>
						<?php foreach ( $company_users as $company_user ) : ?>
							<option value="<?php echo esc_attr( $company_user->ID ); ?>"><?php echo esc_html( $company_user->display_name ); ?></option>
						<?php endforeach; ?>
					</select>
				</p>
			<?php endif; ?>
			<p class="woocommerce-form-row woocommerce-form-row--search form-row form-row-search wwp-ccp-filters__actions">
				<button type="button" id="ccp-search-now" class="wwp-ccp-btn wwp-ccp-btn--primary"><?php esc_html_e( 'Search', 'woocommerce-wholesale-pricing' ); ?></button>
				<button type="reset" id="ccp-search-clear" class="wwp-ccp-btn wwp-ccp-btn--ghost"><?php esc_html_e( 'Clear', 'woocommerce-wholesale-pricing' ); ?></button>
			</p>
		</form>
	</div>

	<div class="wwp-ccp-table-card">
		<table id="ccp_order_table" class="display wwp-ccp-table" style="width:100%">
			<thead>
				<tr>
					<th><?php esc_html_e( 'ID', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Date', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Email', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Status', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Action', 'woocommerce-wholesale-pricing' ); ?></th>
				</tr>
			</thead>
			<tbody></tbody>
		</table>
	</div>
</section>
