<?php
/**
 * Credit requests tab (Owner) — manager/member → owner queue.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int    $company_id Company post ID.
 * @var string $ccp_company_role Company role.
 */

if ( ! authentication_role( 'credit-requests' ) ) {
	return;
}

unset( $ccp_company_role );

$all_requests = ccp_get_credit_requests( $company_id );
$requests     = ccp_filter_credit_requests( $all_requests, 'owner' );

$pending_count = 0;
foreach ( $requests as $request ) {
	if ( isset( $request['status'] ) && 'pending' === $request['status'] ) {
		$pending_count++;
	}
}
?>
<section class="wwp-ccp-panel wwp-ccp-panel--credit-requests" data-company-id="<?php echo esc_attr( $company_id ); ?>">
	<div class="wwp-ccp-panel__header">
		<div class="wwp-ccp-panel__heading-wrap">
			<span class="wwp-ccp-panel__icon dashicons dashicons-clipboard" aria-hidden="true"></span>
			<h4 class="ccp_headding wwp-ccp-panel__title"><?php esc_html_e( 'Credit Requests', 'woocommerce-wholesale-pricing' ); ?></h4>
		</div>
		<?php if ( $pending_count > 0 ) : ?>
			<span class="wwp-ccp-badge wwp-ccp-badge--pending wwp-ccp-pending-badge">
				<?php
				printf(
					/* translators: %d: pending request count */
					esc_html( _n( '%d pending', '%d pending', $pending_count, 'woocommerce-wholesale-pricing' ) ),
					(int) $pending_count
				);
				?>
			</span>
		<?php endif; ?>
	</div>
	<p class="wwp-ccp-panel__desc"><?php esc_html_e( 'Review credit requests from managers and members. Approving allocates company credits to their wallet.', 'woocommerce-wholesale-pricing' ); ?></p>

	<div class="wwp-ccp-table-card">
		<?php if ( ! empty( $requests ) ) : ?>
			<table id="ccp_credit_requests_table" class="display wwp-ccp-table" style="width:100%">
				<thead>
					<tr>
						<th><?php esc_html_e( 'User', 'woocommerce-wholesale-pricing' ); ?></th>
						<th><?php esc_html_e( 'Current Wallet', 'woocommerce-wholesale-pricing' ); ?></th>
						<th><?php esc_html_e( 'Requested', 'woocommerce-wholesale-pricing' ); ?></th>
						<th><?php esc_html_e( 'Reason', 'woocommerce-wholesale-pricing' ); ?></th>
						<th><?php esc_html_e( 'Status', 'woocommerce-wholesale-pricing' ); ?></th>
						<th><?php esc_html_e( 'Requested On', 'woocommerce-wholesale-pricing' ); ?></th>
						<th><?php esc_html_e( 'Action', 'woocommerce-wholesale-pricing' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $requests as $index => $request ) : ?>
						<?php
						$request_status      = isset( $request['status'] ) ? $request['status'] : 'pending';
						$badge_class = 'pending' === $request_status ? 'wwp-ccp-badge--pending' : ( 'approved' === $request_status ? 'wwp-ccp-badge--approved' : 'wwp-ccp-badge--declined' );
						?>
						<tr data-request-index="<?php echo esc_attr( $index ); ?>">
							<td>
								<strong><?php echo esc_html( isset( $request['name'] ) ? $request['name'] : '' ); ?></strong>
								<?php if ( ! empty( $request['email'] ) ) : ?>
									<br><span class="wwp-ccp-muted"><?php echo esc_html( $request['email'] ); ?></span>
								<?php endif; ?>
							</td>
							<td><?php echo esc_html( isset( $request['current_limit'] ) ? $request['current_limit'] : '' ); ?></td>
							<td><?php echo esc_html( isset( $request['requested_limit'] ) ? $request['requested_limit'] : '' ); ?></td>
							<td><?php echo esc_html( isset( $request['reason'] ) ? $request['reason'] : '' ); ?></td>
							<td class="wwp-ccp-request-status-cell">
								<span class="wwp-ccp-badge <?php echo esc_attr( $badge_class ); ?>"><?php echo esc_html( ucfirst( $request_status ) ); ?></span>
							</td>
							<td><?php echo esc_html( isset( $request['requested_on'] ) ? $request['requested_on'] : '' ); ?></td>
							<td class="wwp-ccp-request-actions-cell">
								<?php if ( 'pending' === $request_status ) : ?>
									<div class="wwp-ccp-row-actions">
										<button type="button" class="wwp-ccp-btn wwp-ccp-btn--sm wwp-ccp-btn--success wwp-ccp-request-approve" data-index="<?php echo esc_attr( $index ); ?>">
											<span class="dashicons dashicons-yes" aria-hidden="true"></span>
											<?php esc_html_e( 'Approve', 'woocommerce-wholesale-pricing' ); ?>
										</button>
										<button type="button" class="wwp-ccp-btn wwp-ccp-btn--sm wwp-ccp-btn--danger wwp-ccp-request-decline" data-index="<?php echo esc_attr( $index ); ?>">
											<span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
											<?php esc_html_e( 'Deny', 'woocommerce-wholesale-pricing' ); ?>
										</button>
									</div>
								<?php else : ?>
									<span class="wwp-ccp-muted">—</span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php else : ?>
			<p class="wwp-ccp-empty"><?php esc_html_e( 'No credit requests yet.', 'woocommerce-wholesale-pricing' ); ?></p>
		<?php endif; ?>
	</div>
</section>
