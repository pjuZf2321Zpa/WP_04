<?php
/**
 * Company My Account portal.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int         $company_id       Company post ID.
 * @var string      $tab              Active tab.
 * @var string      $ccp_company_role Company role.
 * @var string      $company_slug     Endpoint slug.
 * @var string      $endpoint_url     Endpoint URL.
 * @var WP_User     $user             Current user.
 * @var string      $user_initials    Avatar initials.
 * @var string      $role_label       Role label.
 * @var string      $company_name     Company name.
 * @var string      $company_email    Company email.
 * @var mixed       $credit_limit     Current user credit limit.
 * @var float|int   $total_credit       Company pool total credit.
 * @var float|int   $available_credit   Current user wallet balance.
 * @var float|int   $company_available  Company pool remaining (allocatable).
 * @var float|int   $consumed_credit    Company pool consumed / allocated out.
 */

if ( ! isset( $company_available ) ) {
	$company_available = 0;
}

$manage_users = ccp_get_option_yes_default( 'ccp_manage_users' );

/**
 * Format a credit amount for portal overview.
 *
 * @param mixed $amount Amount.
 * @return string
 */
$wwp_ccp_format_credit = static function ( $amount ) {
	$amount = is_numeric( $amount ) ? (float) $amount : 0.0;
	if ( function_exists( 'wc_price' ) ) {
		return wp_kses_post( wc_price( $amount ) );
	}
	return esc_html( number_format_i18n( $amount, 2 ) );
};
?>
<div class="ccp_company_list_main wwp-ccp-company-portal">

	<div class="wwp-ccp-portal-top">
		<div class="wwp-ccp-profile-card">
			<div class="wwp-ccp-profile-card__avatar" aria-hidden="true"><?php echo esc_html( $user_initials ); ?></div>
			<div class="wwp-ccp-profile-card__body">
				<div class="wwp-ccp-profile-card__user">
					<p class="wwp-ccp-profile-card__name"><?php echo esc_html( $user->display_name ); ?></p>
					<p class="wwp-ccp-profile-card__meta"><?php echo esc_html( $user->user_email ); ?></p>
					<span class="wwp-ccp-profile-card__role"><?php echo esc_html( $role_label ); ?></span>
				</div>
				<div class="wwp-ccp-profile-card__company">
					<p class="wwp-ccp-profile-card__company-name"><?php echo esc_html( $company_name ); ?></p>
					<?php if ( ! empty( $company_email ) ) : ?>
						<p class="wwp-ccp-profile-card__meta"><?php echo esc_html( $company_email ); ?></p>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<div class="wwp-ccp-credit-overview">
			<div class="wwp-ccp-credit-overview__header">
				<span class="wwp-ccp-credit-overview__icon dashicons dashicons-chart-bar" aria-hidden="true"></span>
				<h3 class="wwp-ccp-credit-overview__title"><?php esc_html_e( 'My Credit Overview', 'woocommerce-wholesale-pricing' ); ?></h3>
			</div>
			<div class="wwp-ccp-credit-overview__stats<?php echo 'ccp_member' === $ccp_company_role ? ' wwp-ccp-credit-overview__stats--member' : ''; ?>">
				<div class="wwp-ccp-credit-overview__stat">
					<span class="wwp-ccp-credit-overview__label"><?php esc_html_e( 'My Wallet', 'woocommerce-wholesale-pricing' ); ?></span>
					<span class="wwp-ccp-credit-overview__value wwp-ccp-credit-overview__value--available"><?php echo wp_kses_post( $wwp_ccp_format_credit( $available_credit ) ); ?></span>
				</div>
				<?php if ( 'ccp_member' !== $ccp_company_role ) : ?>
					<div class="wwp-ccp-credit-overview__stat">
						<span class="wwp-ccp-credit-overview__label"><?php esc_html_e( 'Company Total', 'woocommerce-wholesale-pricing' ); ?></span>
						<span class="wwp-ccp-credit-overview__value"><?php echo wp_kses_post( $wwp_ccp_format_credit( $total_credit ) ); ?></span>
					</div>
					<div class="wwp-ccp-credit-overview__stat">
						<span class="wwp-ccp-credit-overview__label"><?php esc_html_e( 'Company Available', 'woocommerce-wholesale-pricing' ); ?></span>
						<span class="wwp-ccp-credit-overview__value"><?php echo wp_kses_post( $wwp_ccp_format_credit( $company_available ) ); ?></span>
					</div>
				<?php endif; ?>
				<div class="wwp-ccp-credit-overview__stat">
					<span class="wwp-ccp-credit-overview__label"><?php esc_html_e( 'My Credit Limit', 'woocommerce-wholesale-pricing' ); ?></span>
					<span class="wwp-ccp-credit-overview__value"><?php echo wp_kses_post( $wwp_ccp_format_credit( $credit_limit ) ); ?></span>
				</div>
				<div class="wwp-ccp-credit-overview__stat">
					<span class="wwp-ccp-credit-overview__label"><?php esc_html_e( 'Allocated / Consumed', 'woocommerce-wholesale-pricing' ); ?></span>
					<span class="wwp-ccp-credit-overview__value wwp-ccp-credit-overview__value--consumed"><?php echo wp_kses_post( $wwp_ccp_format_credit( $consumed_credit ) ); ?></span>
				</div>
			</div>
		</div>
	</div>

	<nav class="ccp_list wwp-ccp-portal-tabs" aria-label="<?php esc_attr_e( 'Company sections', 'woocommerce-wholesale-pricing' ); ?>">
		<ul>
			<?php if ( authentication_role( 'orders' ) ) : ?>
				<li class="<?php ccp_my_acount_tab_active( 'orders' ); ?>">
					<a href="<?php echo esc_url( add_query_arg( 'tab', 'orders', $endpoint_url ) ); ?>"><?php esc_html_e( 'Orders', 'woocommerce-wholesale-pricing' ); ?></a>
				</li>
			<?php endif; ?>

			<?php if ( authentication_role( 'users' ) && 'yes' === $manage_users ) : ?>
				<li class="<?php ccp_my_acount_tab_active( 'users' ); ?>">
					<a href="<?php echo esc_url( add_query_arg( 'tab', 'users', $endpoint_url ) ); ?>"><?php esc_html_e( 'Users', 'woocommerce-wholesale-pricing' ); ?></a>
				</li>
			<?php endif; ?>

			<?php if ( authentication_role( 'credit' ) ) : ?>
				<li class="<?php ccp_my_acount_tab_active( 'credit' ); ?>">
					<a href="<?php echo esc_url( add_query_arg( 'tab', 'credit', $endpoint_url ) ); ?>"><?php esc_html_e( 'Credit', 'woocommerce-wholesale-pricing' ); ?></a>
				</li>
			<?php endif; ?>

			<?php if ( authentication_role( 'credit-requests' ) ) : ?>
				<li class="<?php ccp_my_acount_tab_active( 'credit-requests' ); ?>">
					<a href="<?php echo esc_url( add_query_arg( 'tab', 'credit-requests', $endpoint_url ) ); ?>"><?php esc_html_e( 'Credit Requests', 'woocommerce-wholesale-pricing' ); ?></a>
				</li>
			<?php endif; ?>

			<?php if ( authentication_role( 'my-shared-carts' ) ) : ?>
				<li class="<?php ccp_my_acount_tab_active( 'my-shared-carts' ); ?>">
					<a href="<?php echo esc_url( add_query_arg( 'tab', 'my-shared-carts', $endpoint_url ) ); ?>"><?php esc_html_e( 'My Shared Carts', 'woocommerce-wholesale-pricing' ); ?></a>
				</li>
			<?php endif; ?>

			<?php if ( authentication_role( 'user-shared-carts' ) ) : ?>
				<li class="<?php ccp_my_acount_tab_active( 'user-shared-carts' ); ?>">
					<a href="<?php echo esc_url( add_query_arg( 'tab', 'user-shared-carts', $endpoint_url ) ); ?>"><?php esc_html_e( 'Users Shared Carts', 'woocommerce-wholesale-pricing' ); ?></a>
				</li>
			<?php endif; ?>
		</ul>
	</nav>

	<div class="container ccp_company_list wwp-ccp-portal-content">
		<?php
		switch ( $tab ) {
			case 'users':
				wwp_view(
					'frontend.company-credits.my-account.users',
					array(
						'company_id' => $company_id,
					),
					true
				);
				break;

			case 'credit':
				wwp_view(
					'frontend.company-credits.my-account.credit',
					array(
						'company_id'       => $company_id,
						'ccp_company_role' => $ccp_company_role,
					),
					true
				);
				break;

			case 'credit-requests':
				wwp_view(
					'frontend.company-credits.my-account.credit-requests',
					array(
						'company_id'       => $company_id,
						'ccp_company_role' => $ccp_company_role,
					),
					true
				);
				break;

			case 'my-shared-carts':
				wwp_view( 'frontend.company-credits.my-account.my-shared-carts', array(), true );
				break;

			case 'user-shared-carts':
				wwp_view( 'frontend.company-credits.my-account.user-shared-carts', array(), true );
				break;

			default:
				wwp_view(
					'frontend.company-credits.my-account.orders',
					array(
						'company_id'       => $company_id,
						'ccp_company_role' => $ccp_company_role,
					),
					true
				);
				break;
		}
		?>
	</div>

	<div id="ccp_myModal" class="modal wwp-ccp-modal" hidden>
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="ccp_response_heading"></h4>
				<button type="button" class="close wwp-ccp-modal__close" aria-label="<?php esc_attr_e( 'Close', 'woocommerce-wholesale-pricing' ); ?>">&times;</button>
			</div>
			<div class="loader" hidden></div>
			<div class="modal-body ccp_response_body"></div>
		</div>
	</div>
</div>
