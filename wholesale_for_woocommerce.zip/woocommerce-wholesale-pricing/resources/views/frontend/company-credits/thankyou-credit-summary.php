<?php
/**
 * Credit payment summary on the order thank-you page.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var float $credits_used         Credits spent on this order.
 * @var float $previous_balance     Wallet balance before this order.
 * @var float $available_balance    Wallet balance after this order.
 * @var bool  $is_pending_approval  Whether the order awaits company approval.
 */
$is_pending_approval = ! empty( $is_pending_approval );
?>
<section class="wwp-ccp-thankyou-credit-summary" aria-label="<?php esc_attr_e( 'Credit Payment Summary', 'woocommerce-wholesale-pricing' ); ?>">
	<h2 class="wwp-ccp-thankyou-credit-summary__title">
		<?php esc_html_e( 'Credit Payment Summary', 'woocommerce-wholesale-pricing' ); ?>
	</h2>

	<div class="wwp-ccp-thankyou-credit-summary__rows">
		
		<?php if ( $is_pending_approval ) : ?>
			<div class="wwp-ccp-thankyou-credit-summary__row">
				<span class="wwp-ccp-thankyou-credit-summary__label">
					<?php esc_html_e( 'Order Status:', 'woocommerce-wholesale-pricing' ); ?>
				</span>
				<span class="wwp-ccp-thankyou-credit-summary__value wwp-ccp-thankyou-credit-summary__value--status">
					<?php esc_html_e( 'Pending Approval', 'woocommerce-wholesale-pricing' ); ?>
				</span>
			</div>
		<?php endif; ?>

		<div class="wwp-ccp-thankyou-credit-summary__row">
			<span class="wwp-ccp-thankyou-credit-summary__label">
				<?php esc_html_e( 'Credits Used for This Order:', 'woocommerce-wholesale-pricing' ); ?>
			</span>
			<span class="wwp-ccp-thankyou-credit-summary__value wwp-ccp-thankyou-credit-summary__value--used">
				-<?php echo wp_kses_post( wc_price( $credits_used ) ); ?>
			</span>
		</div>

		<div class="wwp-ccp-thankyou-credit-summary__row">
			<span class="wwp-ccp-thankyou-credit-summary__label">
				<?php esc_html_e( 'Previous Credit Balance:', 'woocommerce-wholesale-pricing' ); ?>
			</span>
			<span class="wwp-ccp-thankyou-credit-summary__value">
				<?php echo wp_kses_post( wc_price( $previous_balance ) ); ?>
			</span>
		</div>

		<div class="wwp-ccp-thankyou-credit-summary__divider" aria-hidden="true"></div>

		<div class="wwp-ccp-thankyou-credit-summary__row wwp-ccp-thankyou-credit-summary__row--available">
			<span class="wwp-ccp-thankyou-credit-summary__label wwp-ccp-thankyou-credit-summary__label--strong">
				<?php esc_html_e( 'Available Credit Balance:', 'woocommerce-wholesale-pricing' ); ?>
			</span>
			<span class="wwp-ccp-thankyou-credit-summary__value wwp-ccp-thankyou-credit-summary__value--available">
				<?php echo wp_kses_post( wc_price( $available_balance ) ); ?>
			</span>
		</div>
	</div>
</section>
