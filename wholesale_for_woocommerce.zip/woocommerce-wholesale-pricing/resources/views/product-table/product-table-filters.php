<?php
/**

Product Table Filters *
 *
@package WooCommerce Product Table/Templates
*/
global $wpdb;
?> <div class="wc-product-table-select-filters" id="select-filter-<?php echo esc_attr($id); ?>" data-col-filter="<?php echo esc_attr($col_filters); ?>">
 <?php
 
	if ($filter_terms ) {
		?>
	 <div class="wc-product-table-select-filter">
		 <label><?php esc_html_e('Filters', 'woocommerce-wholesale-pricing'); ?></label>
		 <div class="wc-product-table-select">
			 <?php
				$product_table_link = '';
				foreach ( $filter_terms as $i => $filter_term ) {
					$product_table_taxonomy = get_taxonomy($filter_term);
					if (get_terms($filter_term) && is_object($product_table_taxonomy) ) {

						?>
					 <select name="wcpt_filter_<?php echo esc_attr($filter_term); ?>" id="<?php echo esc_attr($filter_term); ?>" class="filter-attr" data-filter-link="<?php echo esc_html(taxonomy_is_product_attribute($product_table_taxonomy->name)); ?>">
						 <option value=""><?php echo esc_html($product_table_taxonomy->label); ?></option>
						 <?php
							foreach ( get_terms($filter_term) as $term_value ) {
								if (false === taxonomy_is_product_attribute($product_table_taxonomy->name) ) {
									$product_table_link = get_term_link($term_value->term_id, $product_table_taxonomy->name);
								}
								?>
							 <option value="<?php echo esc_attr($term_value->term_id); ?>" data-tax-link="<?php echo esc_attr($product_table_link); ?>" ><?php echo esc_html($term_value->name); ?></option>
								<?php
							}
							?>
					 </select>
					<?php } elseif ( 'sort_by' == $filter_term ) { ?>
					 <select name="wcpt_filter_<?php echo esc_attr($filter_term); ?>" id="<?php echo esc_attr($filter_term); ?>" class="filter-attr" data-filter-link="<?php echo esc_html($filter_term); ?>">
						 <option value=""><?php echo esc_html__('Sort By', 'woocommerce-wholesale-pricing'); ?></option>
						 <option value="asc"><?php echo esc_html__('Low to High', 'woocommerce-wholesale-pricing'); ?></option>
						 <option value="desc"><?php echo esc_html__('High to Low', 'woocommerce-wholesale-pricing'); ?></option>
						 <option value="total_sales"><?php echo esc_html__('Popularity', 'woocommerce-wholesale-pricing'); ?></option>
						 <option value="_wc_average_rating"><?php echo esc_html__('Average rating', 'woocommerce-wholesale-pricing'); ?></option>
						 <option value="date"><?php echo esc_html__('Latest', 'woocommerce-wholesale-pricing'); ?></option>
						 <option value="total_sales"><?php echo esc_html__('Best Selling', 'woocommerce-wholesale-pricing'); ?></option>
					 </select>
					 <?php
					} elseif ( 'price' == $filter_term ) {
				 
				 

					$result = $wpdb->get_results(
						"SELECT post_id 
                      FROM {$wpdb->prefix}postmeta 
                      WHERE meta_key = '_price' 
                      ORDER BY CAST(meta_value AS DECIMAL(10,2)) DESC 
                      LIMIT 1"
					);
				 
				 
					$max = 0;
						if (!empty($result)) {
							$_product = wc_get_product($result[0]->post_id);
							if ($_product) {
								$max = $_product->get_price();
							}
						}
						?>
				 <div class="wcpt-price-range">
					 <div class="wcpt-price-range-inputs">
						 <div class="form_control_container">
							 <div class="form_control_container__time"><?php echo esc_html__('Min', 'woocommerce-wholesale-pricing'); ?></div>
							 <input class="form_control_container__time__input min-filter-attr" type="number" id="from_min" value="0" min="0" max="<?php echo esc_attr($max); ?>" />
						 </div>
						 <span class="price-range-separator">-</span>
						 <div class="form_control_container">
							 <div class="form_control_container__time"><?php echo esc_html__('Max', 'woocommerce-wholesale-pricing'); ?></div>
							 <input class="form_control_container__time__input max-filter-attr" type="number" id="to_max" value="<?php echo esc_attr($max); ?>" min="0" max="<?php echo esc_attr($max); ?>" />
						 </div>
					 </div>
					 <div class="price-range">
						 <div class="range_container">
							 <div class="sliders_control">
								 <input id="fromSlider" type="range" value="0" min="0" max="<?php echo esc_attr($max); ?>" />
								 <input id="toSlider" type="range" value="<?php echo esc_attr($max); ?>" min="0" max="<?php echo esc_attr($max) ; ?>" />
							 </div>
						 </div>
					 </div>
				 </div>
					<?php
					} elseif ( 'weight' == $filter_term ) { 
						global $wpdb;

						$weights = $wpdb->get_col("
                         SELECT DISTINCT meta_value 
                         FROM {$wpdb->prefix}postmeta 
                         WHERE meta_key = '_weight' 
                         AND meta_value != ''
                         ORDER BY CAST(meta_value AS DECIMAL(10,2)) ASC
                     ");

						?>
					 <select name="wcpt_filter_weight" id="wcpt_filter_weight" class="filter-attr" data-filter-link="weight">
						 <option value=""><?php echo esc_html__('Product Weight', 'woocommerce-wholesale-pricing'); ?></option>
						 <?php foreach ( $weights as $weight ) : ?>
							 <option value="<?php echo esc_attr($weight); ?>"><?php echo esc_html($weight); ?> <?php echo esc_html(get_option('woocommerce_weight_unit')); ?></option>
						 <?php endforeach; ?>
					 </select>
						<?php
					} elseif ( 'dem_length' == $filter_term ) {

						$lengths = $wpdb->get_col("
                         SELECT DISTINCT meta_value 
                         FROM {$wpdb->prefix}postmeta 
                         WHERE meta_key = '_length' 
                         AND meta_value != ''
                         ORDER BY CAST(meta_value AS DECIMAL(10,2)) ASC
                     ");

						?>
					 <select name="wcpt_filter_length" id="wcpt_filter_length" class="filter-attr" data-filter-link="length">
						 <option value=""><?php echo esc_html__('Dimension Length', 'woocommerce-wholesale-pricing'); ?></option>
						 <?php foreach ( $lengths as $length ) : ?>
							 <option value="<?php echo esc_attr($length); ?>"><?php echo esc_html($length); ?> <?php echo esc_html(get_option('woocommerce_dimension_unit')); ?></option>
						 <?php endforeach; ?>
					 </select>
						<?php
					} elseif ( 'dem_width' == $filter_term ) {

						$widths = $wpdb->get_col("
                         SELECT DISTINCT meta_value 
                         FROM {$wpdb->prefix}postmeta 
                         WHERE meta_key = '_width' 
                         AND meta_value != ''
                         ORDER BY CAST(meta_value AS DECIMAL(10,2)) ASC
                     ");

						?>
					 <select name="wcpt_filter_width" id="wcpt_filter_width" class="filter-attr" data-filter-link="width">
						 <option value=""><?php echo esc_html__('Dimension Width', 'woocommerce-wholesale-pricing'); ?></option>
						 <?php foreach ( $widths as $width ) : ?>
							 <option value="<?php echo esc_attr($width); ?>"><?php echo esc_html($width); ?> <?php echo esc_html(get_option('woocommerce_dimension_unit')); ?></option>
						 <?php endforeach; ?>
					 </select>
						<?php
					} elseif ( 'dem_height' == $filter_term ) {

						$heights = $wpdb->get_col("
                         SELECT DISTINCT meta_value 
                         FROM {$wpdb->prefix}postmeta 
                         WHERE meta_key = '_height' 
                         AND meta_value != ''
                         ORDER BY CAST(meta_value AS DECIMAL(10,2)) ASC
                     ");

						?>
					 <select name="wcpt_filter_height" id="wcpt_filter_height" class="filter-attr" data-filter-link="height">
						 <option value=""><?php echo esc_html__('Dimension Height', 'woocommerce-wholesale-pricing'); ?></option>
						 <?php foreach ( $heights as $height ) : ?>
							 <option value="<?php echo esc_attr($height); ?>"><?php echo esc_html($height); ?> <?php echo esc_html(get_option('woocommerce_dimension_unit')); ?></option>
						 <?php endforeach; ?>
					 </select>
						<?php
					}

				}
				?>
		 </div>
	 </div>
		<?php if ($reset_button ) { ?>
		 <a href="#" class="reset-filters"><?php esc_html_e('Reset', 'woocommerce-wholesale-pricing'); ?></a>
		 <?php
		}
	}
	?>
</div>