<?php
/**
 * Product Table Footer
 * This template can be overridden by copying it to yourtheme/wc_product_table/product-table-footer.php.
 *
 * @package WooCommerce Product Table/Templates
 */
if ( ! function_exists( 'wcpt_assign_default_footer_labels' ) ) {
	function wcpt_assign_default_footer_labels( &$headings ) {
		foreach ($headings as &$heading) {
			if (empty($heading['label'])) {
				switch ($heading['type']) {
					case 'id':
						$heading['label'] = 'ID';
						break;
					case 'title':
						$heading['label'] = 'Title';
						break;
					case 'sku':
						$heading['label'] = 'SKU';
						break;
					case 'short_desc':
						$heading['label'] = 'Short Description';
						break;
					case 'descr':
						$heading['label'] = 'Description';
						break;
					case 'date':
						$heading['label'] = 'Date';
						break;
					case 'cat':
						$heading['label'] = 'Categories';
						break;
					case 'featured_img':
						$heading['label'] = 'Featured Image';
						break;
					case 'reviews':
						$heading['label'] = 'Reviews';
						break;
					case 'stock':
						$heading['label'] = 'Stock';
						break;
					case 'dimensions':
						$heading['label'] = 'Dimensions';
						break;
					case 'price':
						$heading['label'] = 'Price';
						break;
					case 'attributes':
						$heading['label'] = 'Attributes';
						break;  
					case 'custom_fields':
						$heading['label'] = 'Custom Fields';
						break;      
					case 'tags':
						$heading['label'] = 'Tags';
						break;              
					case 'quick_view':
						$heading['label'] = 'Quick View';
						break;
					case 'taxonomy':
						$heading['label'] = 'Taxonomy';
						break;
					case 'cart_button':
						$heading['label'] = 'Add To Cart Button';
						break;
				}
			}
		}
	}
}

wcpt_assign_default_footer_labels($product_table_headings);
if ($product_table_headings ) {
	?>
	<tfoot>
		<tr>
	<?php
	foreach ( $product_table_headings as $product_table_heading ) {
		?>
			<th data-name="<?php echo esc_attr($product_table_heading['type']); ?>"><?php echo esc_attr($product_table_heading['label']); ?></th>
		<?php
	}
	?>
		</tr>
	</tfoot>
	<?php
}

