<?php

$product_id = $product ? $product->get_id() : 0;
$variations_data = array( 'variation_attribute' => '', 'variation_images' => 'row' );
$variations_structure = array();
if ($product_id ) {
	$attributes =  array_keys($product->get_variation_attributes());
	$variations_structure['columnsxz'] = isset($attributes[0]) ? $attributes[0] : '';
	$variations_structure['rows'] = isset($attributes[1]) ? $attributes[1] : '';

	$atts = array_merge($variations_data, $variations_structure);

	$atts['include'] = $product_id;

	// Fill-in missing attributes
	$r = wp_parse_args($atts, \WooCommerceWholesalePricing\App\Modules\ProductTable\ProductArgs::get_defaults());

	// Return the table as HTML
	$grid = \WooCommerceWholesalePricing\App\Modules\ProductTable\GridFactory::create($r);
	/**
	 * Filter product table output
	 * 
	 * @since 1.1.5
	**/
	$output = apply_filters('wcpt_product_output', $grid->render(), $product_id);

	// disables $theme_compat styling
	$styles  = '';
	$classes = array();

	$classes = implode(
		' ',
		array_merge(
			array( 'wcpt-table-wrapper' ),
			/**
			* Filter wcpt product classes
			* 
			* @since 1.1.5
			**/
			apply_filters(
				'wcpt_product_classes',
				$classes,
				$product_id
			)
		)
	);

	printf(
		'<div class="%2$s" %3$s>%1$s</div>',
		wp_kses($output, wwp_wc_allowed_html()),
		// $output,
		// nl2br($output),
		esc_attr($classes),
		esc_attr($styles)
	);
}
