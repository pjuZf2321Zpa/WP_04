<?php
if ( 'enable' == $enable && ! is_user_logged_in() ) {
	?>
			<div class="product-cart-wrapper">
	<a class="button" href="<?php echo esc_url(get_page_link($guest_users_redirection)); ?>"><?php echo esc_html( $wcpt_add_to_cart_label ); ?></a></div>
	<?php
} elseif ( 'link_button' === $list_group_type ) {
	?>
<div class="product-cart-wrapper">
	<a href="<?php echo esc_url(get_permalink($product->get_id())); ?>" class="button product_type_group" aria-label="<?php echo esc_html(get_the_title($product->get_id()) ); ?>" rel="nofollow"><?php esc_html_e('Select Options', 'woocommerce-wholesale-pricing'); ?>
	</a>
</div>
<?php
} else {
	?>
	<div class="product-cart-wrapper grouped_product">
		<form class="cart grouped_form" method="post" enctype='multipart/form-data'>

			<?php
			$grouped_products = array();
			if ( $product && $product->is_type('grouped') ) {
				$children = $product->get_children();
				foreach ( $children as $child_id ) {
					$child_product = wc_get_product($child_id);
					if ( $child_product && $child_product->is_purchasable() && $child_product->is_in_stock() ) {
						$grouped_products[] = array(
							'id'    => $child_id,
							'name'  => $child_product->get_name(),
							'price' => wc_price($child_product->get_price()),
						);
					}
				}
			}
			?>

			<!-- Single Dropdown -->
			<select class="grouped-product-selector">
				<option value="">Select a product</option>
				<?php foreach ( $grouped_products as $gp ) : ?>
					<option value="<?php echo esc_attr($gp['id']); ?>"
							data-name="<?php echo esc_attr($gp['name']); ?>"
							data-price="<?php echo esc_attr($gp['price']); ?>">
						<?php echo esc_html($gp['name']); ?>
					</option>
				<?php endforeach; ?>
			</select>

			<!-- Dynamic Product Blocks Will Appear Here -->
			<div class="selected-products-container" style="margin-top: 20px;"></div>
			<?php
			if ( 'add_button' === $cart_button_type || 'add_button_checkbox' == $cart_button_type ) {
				?>
			<button type="submit" class="button alt group-product-btn" disabled>
				<?php esc_html_e( 'Add to Cart', 'woocommerce' ); ?>
			</button>
			<?php
			}
			?>

			<input type="hidden" name="add-to-cart" class="group-product-add-to-cart" value="<?php echo esc_attr($product->get_id()); ?>" />
			
		   
		</form>
		<?php
		if ('add_button' !== $cart_button_type && $product->is_in_stock() ) {
			?>
			<input type="checkbox" class="product-cart-chechbox" disabled name="product_ids[]" value="<?php echo absint($product->get_id()); ?>">
			<?php
		}
		?>
	</div>
	<?php
}