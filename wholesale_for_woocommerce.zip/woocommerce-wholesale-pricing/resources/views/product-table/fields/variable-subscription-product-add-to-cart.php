<?php
/**
 * Add to Cart for variable subscription product
 *
 * @package WooCommerce Product Table/Templates
 */

?>
<div class="product-cart-chechbox-wrapper variable-product-add-cart <?php echo esc_attr($classes); ?>">
	<?php
	if ( 'enable' == $enable && ! is_user_logged_in() ) {
		?>
		<a class="button" href="<?php echo esc_url(get_page_link($guest_users_redirection)); ?>"><?php echo esc_html( $wcpt_add_to_cart_label ); ?></a>
		<?php
	} elseif ('link_button' === $list_variations_type ) {


		?>
		<div class="product-cart-wrapper">
			<a href="<?php echo esc_url(get_permalink($product->get_id())); ?>" class="button product_type_variable" aria-label="<?php echo esc_attr(get_the_title($product->get_id())); ?>" rel="nofollow"><?php esc_html_e('Select options', 'woocommerce-wholesale-pricing'); ?></a>
		</div>
		<?php
	} else {
		?>
		<div class="product-cart-wrapper">
			<form class="variations_form cart" method="post" enctype='multipart/form-data' data-product_id="<?php echo absint($product->get_id()); ?>" data-product_variations="<?php echo esc_attr(htmlspecialchars(wp_json_encode($available_variations), '', 'UTF-8')); ?>">
				<?php if (empty($available_variations) && false !== $available_variations ) : ?>
					<p class="stock out-of-stock"><?php esc_html_e('Out of Stock', 'woocommerce-wholesale-pricing'); ?></p>
				<?php else : ?>
					<div class="variations">
						<?php foreach ( $attributes as $attribute_name => $options ) : ?>
							<?php
							wc_dropdown_variation_attribute_options(
								array(
									'options'   => $options,
									'attribute' => $attribute_name,
									'product'   => $product,
								)
							);
							?>
						<?php endforeach; ?>
						<?php
					/**
					 * Filter woocommerce reset variation link
					 * 
					 * @since 1.1.6
					 **/
					echo wp_kses_post(apply_filters('woocommerce_reset_variations_link', '<a class="reset_variations" href="#">' . esc_html__('Clear', 'woocommerce-wholesale-pricing') . '</a>'));
						?>
				</div>
				<div class="single_variation_wrap">
					<?php
					/**
					 * Action product table single variations
					 * 
					 * @since 1.1.6
					 **/
					do_action('wcpt_single_variation');
					?>
				</div>
			<?php endif; ?>
		</form>
		<?php
		if ('add_button' !== $cart_button_type && $product->is_in_stock() ) {
			?>
			<input type="checkbox" class="product-cart-chechbox" name="product_ids[]" value="<?php echo absint($product->get_id()); ?>">
			<?php
		}
		?>
	</div>
	<?php


	}
	?>

</div>
