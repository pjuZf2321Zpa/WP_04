<?php

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}
if ($product->is_in_stock()  && 'simple' === $product->get_type()  ) {
	/**
	*  Action woocommerce_before_add_to_cart_form
	*                            
	*  @since 2.0.7 
	*/
	do_action('woocommerce_before_add_to_cart_form');
	/**
	*  Filter woocommerce_add_to_cart_form_action
	*                            
	*  @since 2.0.7 
	*/
	$form_action = apply_filters('woocommerce_add_to_cart_form_action', $product->get_permalink()); ?>

	<form class="cart wcpt_quick_view_cart" action="<?php echo esc_url($form_action); ?>" method="post" enctype='multipart/form-data'>
		<?php
		$box_office = false;
		if ( class_exists('WC_Box_Office') ) {
			$box_office = wc_box_office_is_product_ticket($product);
		} 
		if ( $box_office ) {
			require_once WCBO()->dir . 'includes/class-wc-box-office-ticket-form.php' ;
			$data = $_REQUEST;
			$posted_fields = ( !empty($data['ticket_fields']) && is_product() )
			? wc_clean(wp_unslash($data['ticket_fields']))
			: null;
			$ticket_form = new \WC_Box_Office_Ticket_Form(
				$product,
				$posted_fields
			);
			if (empty($ticket_form->fields)) {
				return;
			}
			?>
			<div class="wc-box-office-ticket-form">
				<?php 
				/**
				 * Action woocommerce_before_ticket_fields
				 *
				 * @since 1.0
				**/
				do_action( 'woocommerce_before_ticket_fields' ); 
				?>

				<div class="wc-box-office-ticket-fields" data-index="0" >
					<h3 class="wc-box-office-ticket-fields-title">
						<a href="#"><?php echo esc_html( wcbo_get_ticket_title_prefix() ) . '1'; ?></a>
					</h3>
					<div class="wc-box-office-ticket-fields-body">
						<?php
						$ticket_form->render( array(
							'field_name_prefix' => 'ticket_fields[0]',
							'multiple_tickets'  => true,
						) );
						?>
					</div>
				</div>
			</div>
			<?php
		}

	
	/**
	 *  Action woocommerce_before_add_to_cart_button
	 *                            
	 * @since 2.0.7 
	 */
	do_action('woocommerce_before_add_to_cart_button');
	// for product addons
		if (class_exists('WC_Product_Addons_Helper')) {
			$WC_Product_Addons_Display = new \WC_Product_Addons_Display();
			$WC_Product_Addons_Display->display($product->get_id());
		}
	/**
	 *  Action woocommerce_before_add_to_cart_quantity
	 *                            
	 *  @since 2.0.7 
	 */
	do_action('woocommerce_before_add_to_cart_quantity');

	woocommerce_quantity_input(
		array(
				/**
				 * Filter woocommerce_quantity_input_min
				 * 
				 * @since 1.0
				 **/
				'min_value'   => apply_filters('woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product),
				/**
				 * Filter woocommerce_quantity_input_max
				 * 
				 * @since 1.0
				 **/
				'max_value'   => apply_filters('woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product),
				'input_value' => $product->get_min_purchase_quantity(), // WPCS: CSRF ok, input var ok.
			)
	);
	/**
	*  Action woocommerce_before_add_to_cart_quantity
	*                            
	*  @since 2.0.7 
	*/
	do_action('woocommerce_before_add_to_cart_quantity');
	$box_office = false;
	if ( class_exists('WC_Box_Office') ) {
		$box_office = wc_box_office_is_product_ticket($product);
	} 
	if ( $box_office ) {
		?>
		<button type="submit" name="add-to-cart" data-id="<?php echo esc_attr($product->get_id()); ?>" value="<?php echo esc_attr($product->get_id()); ?>" class="wcpt_quick_add_to_cart ajax_add_to_cart single_add_to_cart_button button alt<?php echo esc_attr(wc_wp_theme_get_element_class_name('button') ? ' ' . wc_wp_theme_get_element_class_name('button') : ''); ?>"><?php echo esc_html('Buy Ticket Now', 'woocommerce-wholesale-pricing'); ?></button>
		<?php 
	} else {
		?>
		<button type="submit" name="add-to-cart" data-id="<?php echo esc_attr($product->get_id()); ?>" value="<?php echo esc_attr($product->get_id()); ?>" class="wcpt_quick_add_to_cart ajax_add_to_cart single_add_to_cart_button button alt<?php echo esc_attr(wc_wp_theme_get_element_class_name('button') ? ' ' . wc_wp_theme_get_element_class_name('button') : ''); ?>"><?php echo esc_html('Add to Cart', 'woocommerce-wholesale-pricing'); ?></button>
		<?php
	}
	
	
	/**
	 *  Action woocommerce_after_add_to_cart_button
	 *                            
	 * @since 2.0.7 
	 */
	do_action('woocommerce_after_add_to_cart_button'); 
	?>
</form>
<?php 
	/**
	 *  Action woocommerce_after_add_to_cart_form
	 *                            
	 * @since 2.0.7 
	 */
	do_action('woocommerce_after_add_to_cart_form');
}

