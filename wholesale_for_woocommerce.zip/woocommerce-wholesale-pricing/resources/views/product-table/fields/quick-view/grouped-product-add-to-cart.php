<?php
/**
 * Add to Cart for external product
 *
 * @package WooCommerce Product Table/Templates
 */

?>
<div class="product-cart-chechbox-wrapper simple-product-add-cart <?php echo esc_attr($classes); ?>">
	<div class="product-cart-wrapper">
		<?php


		// Get grouped product children
		$children = $product->get_children();

		if (empty($children) ) {
			return;
		}

		// Output each grouped product child
		foreach ( $children as $child_id ) {
			$child_product = wc_get_product($child_id);

			if (! $child_product || ! $child_product->exists() ) {
				continue;
			}

			// Display child product thumbnail, title, and price
			echo '<div class="grouped-product">';
			echo '<a href="' . esc_url($child_product->get_permalink()) . '">' . esc_html($child_product->get_image()) . '</a>';
			echo '<h4><a href="' . esc_url($child_product->get_permalink()) . '">' . esc_html($child_product->get_name()) . '</a></h4>';
			echo '<span class="price">' . esc_html($child_product->get_price_html()) . '</span>';

			// Display quantity input for the child product
			echo '<div class="quantity">';
			woocommerce_quantity_input(
				array(
				'input_name'  => 'quantity[' . $child_id . ']',
				'input_value' => '0',
				'min_value'   => '0',
				'max_value'   => '',
				)
			);
			echo '</div>';

			echo '</div>';
		}

		// Output grouped product add to cart form
		/**
		 * Action woocommerce_before_add_to_cart_form
		 * 
		 * @since 1.1.6
		**/
		do_action('woocommerce_before_add_to_cart_form'); 
		?>

		<form class="cart grouped_form" method="post" enctype='multipart/form-data'>
			<?php
			/**
			 * Action woocommerce_before_add_to_cart_button
			 * 
			 * @since 1.1.6
			 **/
			do_action('woocommerce_before_add_to_cart_button'); 
			?>

			<?php
			// Output the grouped product add to cart button
			echo '<button type="submit" class="single_add_to_cart_button button alt" name="add-to-cart" value="' . esc_attr($product->get_id()) . '">' . esc_html($product->single_add_to_cart_text()) . '</button>';
			?>

			<?php
			/**
			 * Action woocommerce_after_add_to_cart_button
			 * 
			 * @since 1.1.6
			 **/
			do_action('woocommerce_after_add_to_cart_button'); 
			?>
			<?php wp_nonce_field('woocommerce-add-to-cart', 'woocommerce-add-to-cart-nonce'); ?>
		</form>

		<?php
		/**
		 * Action woocommerce_after_add_to_cart_form
		 * 
		 * @since 1.1.6
		 **/
		do_action('woocommerce_after_add_to_cart_form'); 
		?>
		</div>
		</div>
