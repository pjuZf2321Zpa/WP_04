<?php

if (! defined('ABSPATH') ) {
	exit; // Exit if accessed directly.
}
if ($product->is_in_stock() && 'variable' === $product->get_type()) {
	/**
	*  Filter woocommerce_ajax_variation_threshold
	*                            
	*  @since 2.0.7 
	*/
	$ajax_threshold = apply_filters('woocommerce_ajax_variation_threshold', 30, $product);
	$get_variations = count($product->get_children()) <= $ajax_threshold ;
			$available_variations = $get_variations ? $product->get_available_variations() : false;
			$attributes           = $product->get_variation_attributes();
			$selected_attributes  = $product->get_default_attributes();?>
			<div class="variable_form_wrapper">
				<a href="javascript:void(0);" class="close-variable-options"></a>
				<form class="variations_form cart"  method="post" enctype='multipart/form-data' data-id="<?php echo absint($product->get_id()); ?>" data-product_variations="<?php echo esc_attr(htmlspecialchars(wp_json_encode($available_variations), ENT_QUOTES )); ?>">
					<?php if (empty($available_variations) && false !== $available_variations ) : ?>
						<p class="stock out-of-stock"><?php esc_html_e('Out of Stock', 'woocommerce-wholesale-pricing'); ?></p>
					<?php else : ?>
						<div class="variations">
						<?php foreach ( $attributes as $attribute_name => $options ) : ?>
							<?php
							wc_dropdown_variation_attribute_options(
								array(
								'options'   => $options,
								'attribute' => $attribute_name,
								'product'   => $product,
								)
							);
							?>
							<?php 
						endforeach;
						/**
						 * Filter woocommerce reset variation link
						 * 
						 * @since 1.1.6
						**/
						echo wp_kses_post(apply_filters('woocommerce_reset_variations_link', '<a class="reset_variations" href="#">' . esc_html__('Clear', 'woocommerce-wholesale-pricing') . '</a>')); 
						?>
						</div>
						<?php
						 $box_office_product = null;
						if ( class_exists('WC_Box_Office') ) {
							$box_office_product = wc_box_office_is_product_ticket($product);
						}  
						if ($box_office_product) {
							require_once WCBO()->dir . 'includes/class-wc-box-office-ticket-form.php' ; 
							$data = $_REQUEST;
							$posted_fields = ( !empty($data['ticket_fields']) && is_product() )
								? wc_clean(wp_unslash($data['ticket_fields']))
								: null;
							$ticket_form = new \WC_Box_Office_Ticket_Form(
								$product,
								$posted_fields
							);
							if (empty($ticket_form->fields)) {
								return;
							}
							?>
								<div class="wc-box-office-ticket-form">
								<?php 
								/**
								 * Action woocommerce_before_ticket_fields
								 *
								 * @since 1.0
								**/
								do_action( 'woocommerce_before_ticket_fields' ); 
								?>

									<div class="wc-box-office-ticket-fields" data-index="0" >
										<h3 class="wc-box-office-ticket-fields-title">
											<a href="#"><?php echo esc_html( wcbo_get_ticket_title_prefix() ) . '1'; ?></a>
										</h3>
										<div class="wc-box-office-ticket-fields-body">
										<?php
										$ticket_form->render( array(
											'field_name_prefix' => 'ticket_fields[0]',
											'multiple_tickets'  => true,
										) );
										?>
										</div>
									</div>
								</div>
								<?php
						}
						?>
						<div class="single_variation_wrap">
						<?php
						/**
						 * Hook: woocommerce_before_single_variation.
						 * 
						 * @since 2.4.0
						 */
						do_action('woocommerce_before_single_variation');
						
						// for product addons 
						if (class_exists('WC_Product_Addons_Helper')) {
							$WC_Product_Addons_Display = new \WC_Product_Addons_Display();
							$WC_Product_Addons_Display->display($product->get_id());
						}

						/**
						 * Hook: woocommerce_single_variation. Used to output the cart button and placeholder for variation data.
						 *
						 * @since  2.4.0
						 * @hooked woocommerce_single_variation - 10 Empty div for variation data.
						 * @hooked woocommerce_single_variation_add_to_cart_button - 20 Qty and cart button.
						 */
						do_action('woocommerce_single_variation');

						/**
						* Hook: woocommerce_after_single_variation.
						* 
						* @since 2.4.0
						*/
						do_action('woocommerce_after_single_variation'); 
						?>
						</div>
					<?php endif; ?>
				</form>
			</div>
		<?php
}