<?php
/**
 * Product Table Weight Field
 *
 * @package WooCommerce Product Table/Templates
 */

$dimension_unit = '';
if ( ! empty( $product_weight ) ) {
	$dimension_unit = get_option('woocommerce_weight_unit');
}
?>
<span><?php echo esc_html( $product_weight . ' ' . $dimension_unit ); ?></span> 
