<?php

/**
 * WooCommerce product table Quick view
 */

if (! defined('ABSPATH') ) {
	exit; // Exit if accessed directly.
}

$box_office  = '';
$box_office_product ='';

$_REQUEST['product_id'] = $product->get_id();

?>
<div class="wcpt_modal_header">
	<button class="close-wcpt-modal">&#x2715</button>
</div>


<div class="wcpt_product_container">
	<?php
	$featured_image_url = get_the_post_thumbnail_url($product->get_id(), 'full');
	$placeholder_img = wc_placeholder_img_src();
	?>

<div class="wcpt_img_container">
<?php if (!empty($featured_image_url)) : ?>
		<img src="<?php echo esc_url($featured_image_url); ?>" alt="Featured Image">
	<?php else : ?>
		<img src="<?php echo esc_url($placeholder_img); ?>" alt="Placeholder Image">
	<?php endif; ?>

</div>
	<div class="wcpt_product_info">
		<div class="wcpt_product_header">    
			<h3 class="product-name"><?php echo esc_html($product->get_name()); ?></h3>
			<?php
			if ($product->get_type() !== 'bundle_product'  ) {
				?>
				<p class="product-price"> 
				<?php
				echo wp_kses_post($product->get_price_html());     
			} 
			?>
				</p>
			 
			 
		</div>

		<span class="wcpt_rating">
			<?php
			$rating_count = $product->get_rating_count();
			$review_count = $product->get_review_count();
			$average_rating    = $product->get_average_rating();

			if ($rating_count > 0 ) : 
				?>
				<div class="woocommerce-product-rating">
				<?php echo wp_kses_post(wc_get_rating_html($average_rating, $rating_count)); // WPCS: XSS ok. ?>
				<?php if (is_single() && comments_open() ) : ?>
					<a href="#reviews" class="woocommerce-review-link" rel="nofollow"><?php echo esc_attr($review_count); ?></a>
				<?php endif ?>
				</div>
			<?php endif; ?> 
		</span>
		<?php
		$short_description = $product->get_short_description();
		if (!empty($short_description)) {
			echo '<div class="woocommerce-product-details__short-description">';
			echo '<h3> Description </h3>';
			echo '<p>' . wp_kses_post($short_description) . '</p>';
			echo '</div>';
		}
		// for bundle product
		if ($product && $product->is_type('bundle_product') ) {
			if (! $product->is_purchasable() ) {
				return;
			}
			echo wp_kses_post(wc_get_stock_html($product));

			wwp_view('product-table.fields.quick-view.quick-bundle-product-add-to-cart', compact('product'));
		}

		// for bundle product
		if ($product && $product->is_type('grouped') ) {

			wwp_view('product-table.fields.quick-view.quick-grouped-product-add-to-cart', compact('product'));
		}

		// for bundle product
		if (class_exists('WC_Bundles') ) {
			if ($product && $product->is_type('bundle')  ) {
				if (! $product->is_purchasable() ) {
					  return;
				}
				echo wp_kses_post(wc_get_stock_html($product));
				if ($product->is_in_stock() ) {
					/**
					 * Action woocommerce_before_add_to_cart_form
					 * 
					 * @since 1.0
					**/
					do_action('woocommerce_before_add_to_cart_form'); 
					wc_pb_template_add_to_cart();
					
				}
			
			}
		}
		// for simple products
		if ( class_exists('WC_Box_Office') ) {
			$box_office_product = wc_box_office_is_product_ticket($product);
		}  
		if ($product && ( $product->is_type('simple') || $product->is_type('simple-subscription') || $box_office_product )  ) {

			if (! $product->is_purchasable() ) {
				return;
			}
			echo wp_kses_post(wc_get_stock_html($product));

			wwp_view('product-table.fields.quick-view.quick-simple-product-add-to-cart', compact('product'));
		}
		// for variable products    
		if ('variable' === $product->get_type() || $box_office_product  || 'variable-subscription' === $product->get_type() ) {
			if (! $product->is_purchasable() ) {
				return;
			}
			wwp_view('product-table.fields.quick-view.quick-variable-product-add-to-cart', compact('product'));
		} 
		if ('variation' === $product->get_type() || $box_office_product  ) {
			if (! $product->is_purchasable() ) {
				return;
			}
			wwp_view('product-table.fields.quick-view.quick-variation-product-add-to-cart', compact('product'));  
		}
		?>

		<!-- Get Sku -->
		 
		<p class="wcpt_sku">
			<?php
			if ($product->get_sku() ) {
				echo 'SKU: ' . esc_attr($product->get_sku());
			} 
			?>
		</p>

		<!-- Get Categories -->
		<?php
		$categories = get_terms(
			array(
				'taxonomy' => 'product_cat',
				'include'  => $product->get_category_ids(),
			) 
		);
		foreach ( $categories as $category ) {
			$category_name = $category->name;
			$category_link = get_term_link($category);
		} 
		?>
		<p class="wcpt_categories">
			<?php
			echo 'Category: <a href="' . esc_url($category_link) . '">' . esc_html($category->name) . '</a>';
			?>
		</p>

		 <!-- Get Tag list -->
		<?php
	 
		$tag_list = wc_get_product_tag_list($product->get_id(), ', ', '<span class="tagged_as">' . _n('Tag:', 'Tags:', count($product->get_tag_ids()), 'woocommerce') . ' ', '</span>');
		if ($product->get_tag_ids() ) { 
			?>
				 
			<?php
			if ($tag_list && !is_wp_error($tag_list)) {
				echo wp_kses_post($tag_list); 
			}
		}     
		?>
			 
	</div>
</div>

