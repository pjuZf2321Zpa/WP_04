<?php
/**
 * Product Table Add Selected Cart Button
 *
 * This template can be overridden by copying it to yourtheme/wc_product_table/product-table-end.php.
 *
 * @package WooCommerce Product Table/Templates
 */

?>
</table>
<div class="modal-overlay"></div>
<div id="popup_quickview" class="wcpt_popup_quickview_content_wrapper">
</div>


