<?php 
$quote_rules = get_post_meta($post->ID, 'wc_quote_rules', true);
$user_roles = isset($quote_rules['user_roles']['toggle']) ? $quote_rules['user_roles']['toggle'] : 'all';
$select_roles = isset($quote_rules['user_roles'][$user_roles]) ? $quote_rules['user_roles'][$user_roles] : array( 0 => 0 );
$include_products = isset($quote_rules['include_products']['toggle']) ? $quote_rules['include_products']['toggle'] : 'all';
$include_product_ids = isset($quote_rules['include_' . $include_products]) ? $quote_rules['include_' . $include_products] : array( 0 => 0 );
$exclude_products = isset($quote_rules['exclude_products']['toggle']) ? $quote_rules['exclude_products']['toggle'] : 'product';
$excluded_product_ids = isset($quote_rules['exclude_' . $exclude_products]) ? $quote_rules['exclude_' . $exclude_products] : array( 0 => 0 );
$hide_price = isset($quote_rules['hide_price']) ? $quote_rules['hide_price'] : '0';
$hide_price_msg = isset($quote_rules['hide_price_msg']) ? $quote_rules['hide_price_msg'] : '' ;
$show_single = isset($quote_rules['show_single']) ? $quote_rules['show_single'] : '0' ;
$show_shop = isset($quote_rules['show_shop']) ? $quote_rules['show_shop'] : '0' ;
$hide_cart_single = isset($quote_rules['hide_cart_single']) ? $quote_rules['hide_cart_single'] : '0' ;
$hide_cart_shop = isset($quote_rules['hide_cart_shop']) ? $quote_rules['hide_cart_shop'] : '0' ;
$hide_cart_all = isset($quote_rules['hide_cart_all']) ? $quote_rules['hide_cart_all'] : '0' ;
$wc_custom_quote_status = isset($quote_rules['wc_custom_quote_status']) ? $quote_rules['wc_custom_quote_status'] : 'quote_new' ;

/**
* Action wc_quote_rules_metabox_start
* 
* @since 1.0
**/
do_action('wc_quote_rules_metabox_start', $post, $quote_rules);
?>
<table class="form-table">
	<tbody>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<?php echo esc_html__('Enable Rule', 'woocommerce-wholesale-pricing'); ?>
			</th>
			<td class="forminp forminp-checkbox">
				<p>
					<input class="inp-cbx" style="display: none" id="enable_rule" type="checkbox" value="1" name="enable_rule" <?php echo checked(1, get_post_meta( $post->ID, 'enable_rule', true ), false); ?>>
					<label class="cbx cbx-square" for="enable_rule">
						<span>
							<svg width="12px" height="9px" viewbox="0 0 12 9">
								<polyline points="1 5 4 8 11 1"></polyline>
							</svg>
						</span>
					</label>
				</p>
			</td>
		</tr>
		<tr valign="top">
			<th scope="row" class="titledesc"><?php echo esc_html__('User Roles', 'woocommerce-wholesale-pricing'); ?></th>
			<td class="forminp forminp-checkbox">
				<span>
					<input class="inp-cbx" style="display: none" id="wc_quote_rules_roles_all" type="radio" value="all" name="wc_quote_rules[user_roles][toggle]" <?php checked('all', $user_roles, true); ?>>
					<label class="cbx" for="wc_quote_rules_roles_all">
						<span>
							<svg width="12px" height="9px" viewbox="0 0 12 9">
								<polyline points="1 5 4 8 11 1"></polyline>
							</svg>
						</span>
						<span><?php echo esc_html__('All', 'woocommerce-wholesale-pricing'); ?></span>                                                
					</label>
				</span>
				<span>
					<input class="inp-cbx" style="display: none" id="wc_quote_rules_roles_specific" type="radio" value="specific" name="wc_quote_rules[user_roles][toggle]" <?php checked('specific', $user_roles, true); ?>>
					<label class="cbx" for="wc_quote_rules_roles_specific">
						<span>
							<svg width="12px" height="9px" viewbox="0 0 12 9">
								<polyline points="1 5 4 8 11 1"></polyline>
							</svg>
						</span>
						<span><?php echo esc_html__('Specific Roles', 'woocommerce-wholesale-pricing'); ?></span>                                                
					</label>
				</span>
				<span>
					<input class="inp-cbx" style="display: none" id="wc_quote_rules_users_specific" type="radio" value="specific_users" name="wc_quote_rules[user_roles][toggle]" <?php checked('specific_users', $user_roles, true); ?>>
					<label class="cbx" for="wc_quote_rules_users_specific">
						<span>
							<svg width="12px" height="9px" viewbox="0 0 12 9">
								<polyline points="1 5 4 8 11 1"></polyline>
							</svg>
						</span>
						<span><?php echo esc_html__('Specific Users', 'woocommerce-wholesale-pricing'); ?></span>                                                
					</label>
				</span>

				<!-- User roles -->
				<div class="rules-specific-container wc_quote_rules_roles_specific">
					<select name="wc_quote_rules[user_roles][specific][]" multiple class="wc-enhanced-select select2" id="quote_user_roles" data-placeholder="<?php echo esc_html__('Select the Roles', 'woocommerce-wholesale-pricing'); ?>" >
						<option value="guest"> <?php echo esc_html__('Guest', 'woocommerce-wholesale-pricing'); ?></option>
						<?php wp_dropdown_roles(); ?>
					</select>
				</div>
				<?php foreach ($select_roles as $select_role) : ?>
					<script type="text/javascript">
						jQuery('#quote_user_roles option[value=<?php echo esc_attr($select_role); ?>]').prop('selected', true)
					</script>
				<?php endforeach; ?>
				<!-- Users -->
				<div class="rules-specific-container wc_quote_rules_users_specific">
					<select  name="wc_quote_rules[user_roles][specific_users][]" multiple class="wc-customer-search" id="quote_users" data-placeholder="<?php echo esc_html__('Select the Users', 'woocommerce-wholesale-pricing'); ?>" >
					<?php
					foreach ( $select_roles as $user_id ) {
						if ( is_numeric($user_id) && $user_id > 0 ) {
							$user    = get_user_by( 'id', $user_id );
							$user_string = sprintf(
								/* translators: %1$s: display user name. */
								esc_html__( '%1$s (#%2$s &ndash; %3$s)', 'conditional-fees-for-woocommerce' ),
								$user->display_name,
								absint( $user->ID ),
								$user->user_email
							);
							?>
						<option value="<?php echo esc_attr( $user_id ); ?>" selected="selected"><?php echo wp_kses_post( $user_string ); ?></option>
							<?php
						}
					}
					?>
					</select>
				</div>
			</td>
		</tr>

		<tr valign="top">
			<th scope="row" class="titledesc"><?php echo esc_html__('Quote Status', 'woocommerce-wholesale-pricing'); ?></th>
			<td class="forminp forminp-checkbox">
				<select name="wc_quote_rules[wc_custom_quote_status]" id="wc_quote_status_dropdown" data-placeholder="<?php echo esc_html__('Select the Status', 'woocommerce-wholesale-pricing'); ?>">
					<?php
					// Fetch all quote statuses
					$quote_statuses = array(
						'quote_new'      => esc_html__('New', 'woocommerce-wholesale-pricing'),
						'quote_draft'    => esc_html__('Draft', 'woocommerce-wholesale-pricing'),
						'quote_quoted'   => esc_html__('Quoted', 'woocommerce-wholesale-pricing'),
						'quote_accepted' => esc_html__('Accepted', 'woocommerce-wholesale-pricing'),
						'quote_rejected' => esc_html__('Rejected', 'woocommerce-wholesale-pricing'),
						'quote_expired'  => esc_html__('Expired', 'woocommerce-wholesale-pricing'),
					);

					// Add custom statuses dynamically if enabled
					if ( check_quote_status() ) {
						$custom_posts = get_posts(array(
							'post_type'   => 'wc-quote-status',
							'post_status' => 'any',
							'numberposts' => -1,
							'orderby'     => array(
								'menu_order' => 'DESC', // Sort by priority (menu_order) first
								'modified'   => 'ASC', // In case of ties, sort by last modified date
							),
						));

						foreach ($custom_posts as $post_data) {
							$quote_meta_status = get_post_meta($post_data->ID, 'wc_quote_status', true);
							$quote_status_key = isset($quote_meta_status['quote_status']) ? $quote_meta_status['quote_status'] : $post_data->post_name;
							$enable_quote_status = isset($quote_meta_status['enable_quote_status']) ? $quote_meta_status['enable_quote_status'] : '';
							// Only add the status if 'enable_quote_status' is set to true
							if ( '1' === $enable_quote_status ) {
								$quote_statuses[$quote_status_key] = $post_data->post_title;
							}
						}
					}

					// Populate dropdown with statuses
					foreach ($quote_statuses as $status_key => $status_label) {
						$selected = ( $wc_custom_quote_status === $status_key ) ? 'selected="selected"' : '';
						echo '<option value="' . esc_attr($status_key) . '" ' . esc_attr($selected) . '>' . esc_html($status_label) . '</option>';
					}
					?>
				</select>
			</td>
		</tr>

		<tr valign="top">
			<th scope="row" class="titledesc"><?php echo esc_html__('Include Products', 'woocommerce-wholesale-pricing'); ?></th>
			<td class="forminp forminp-checkbox">
				<!-- all -->
				 <span>
					<input class="inp-cbx" style="display: none" id="wc_quote_rules_prod_all" type="radio" value="all" name="wc_quote_rules[include_products][toggle]" <?php checked('all', $include_products, true); ?>>
					<label class="cbx" for="wc_quote_rules_prod_all">
						<span>
							<svg width="12px" height="9px" viewbox="0 0 12 9">
								<polyline points="1 5 4 8 11 1"></polyline>
							</svg>
						</span>
						<span><?php echo esc_html__('All', 'woocommerce-wholesale-pricing'); ?></span>                                                
					</label>
				</span>
				<span>
					<input class="inp-cbx" style="display: none" id="wc_quote_rules_prod_specific" type="radio" value="product" name="wc_quote_rules[include_products][toggle]" <?php checked('product', $include_products, true); ?>>
					<label class="cbx" for="wc_quote_rules_prod_specific">
						<span>
							<svg width="12px" height="9px" viewbox="0 0 12 9">
								<polyline points="1 5 4 8 11 1"></polyline>
							</svg>
						</span>
						<span><?php echo esc_html__('Specific Products', 'woocommerce-wholesale-pricing'); ?></span>                                                
					</label>
				</span>
				<span>
					<input class="inp-cbx" style="display: none" id="wc_quote_rules_category_specific" type="radio" value="category" name="wc_quote_rules[include_products][toggle]" <?php checked('category', $include_products, true); ?>>
					<label class="cbx" for="wc_quote_rules_category_specific">
						<span>
							<svg width="12px" height="9px" viewbox="0 0 12 9">
								<polyline points="1 5 4 8 11 1"></polyline>
							</svg>
						</span>
						<span><?php echo esc_html__('Specific Products Category', 'woocommerce-wholesale-pricing'); ?></span>                                                
					</label>
				</span>
				<span>
					<input class="inp-cbx" style="display: none" id="wc_quote_rules_tag_specific" type="radio" value="tag" name="wc_quote_rules[include_products][toggle]" <?php checked('tag', $include_products, true); ?>>
					<label class="cbx" for="wc_quote_rules_tag_specific">
						<span>
							<svg width="12px" height="9px" viewbox="0 0 12 9">
								<polyline points="1 5 4 8 11 1"></polyline>
							</svg>
						</span>
						<span><?php echo esc_html__('Specific Products Tags', 'woocommerce-wholesale-pricing'); ?></span>                                                
					</label>
				</span>
				<!-- products -->
				<label for="wc_quote_rules_product_include">
					<div class="rules-specific-container">
						<select class="wc-product-search" multiple="multiple" id="wc_quote_rules_product_include" style="width:400px;" name="wc_quote_rules[include_product][]" data-placeholder="<?php esc_attr_e('Search for a product&hellip;', 'woocommerce'); ?>" data-action="woocommerce_json_search_products" data-exclude="">
							<?php 
							foreach ( $include_product_ids as $include_product_id ) {
								$product = wc_get_product($include_product_id);
								if (is_object($product) ) {
									echo '<option value="' . esc_attr($include_product_id) . '"' . selected(true, true, false) . '>' . esc_html(wp_strip_all_tags($product->get_formatted_name())) . '</option>';
								}
							}
							?>
						</select>
					</div>
				</label>
				<!-- specific_category -->
				<label for="wc_quote_rules_category_include">
					<div class="rules-specific-container">
						
						<select class="wc-category-search" multiple="multiple" id="wc_quote_rules_category_include" style="width:400px;" name="wc_quote_rules[include_category][]" data-placeholder="<?php esc_attr_e('Search for a category&hellip;', 'woocommerce'); ?>" data-action="woocommerce_json_search_category" data-exclude="">
							<?php 

							foreach ( $include_product_ids as $include_product_id ) {

								$product_cat = get_term_by('slug', $include_product_id, 'product_cat');
								if (is_object($product_cat) ) {

									echo '<option value="' . esc_attr($include_product_id) . '"' . selected(true, true, false) . '>' . esc_html($product_cat->name) . '</option>';
								}
							}
							?>
						</select>
					</div>
				</label>
				<!-- specific_tag -->
				<label for="wc_quote_rules_tag_include">
					<div class="rules-specific-container">
						<select class=" wc-tag-search select2 wc-enhanced-select wc-tag-search select2" multiple="multiple" id="wc_quote_rules_tag_include" style="width:400px;" name="wc_quote_rules[include_tag][]" data-placeholder="<?php esc_attr_e('Search for a tag&hellip;', 'woocommerce'); ?>" data-action="woocommerce_json_search_tag" data-exclude="">
							<?php
							$taxonomies = 'product_tag';
							$product_tags = get_terms($taxonomies);

							foreach ($product_tags as $values) {
								$key = $values->slug;
								$value = $values->name;
								$selected = is_array($include_product_ids) &&  in_array($key, $include_product_ids) ? 'selected' : '';

								echo '<option value="' . esc_attr($key) . '" ' . esc_attr($selected) . '>' . esc_html($value) . '</option>';
							}
							?>
						</select>
					</div>
				</label>
			</td>
		</tr>

		<tr valign="top">
			<th scope="row" class="titledesc"><?php echo esc_html__('Exclude Products', 'woocommerce-wholesale-pricing'); ?></th>
			<td class="forminp forminp-checkbox">
				<span>
					<input class="inp-cbx" style="display: none" id="wc_quote_rules_prod_specific_exclude" type="radio" value="product" name="wc_quote_rules[exclude_products][toggle]" <?php checked('product', $exclude_products, true); ?>>
					<label class="cbx" for="wc_quote_rules_prod_specific_exclude">
						<span>
							<svg width="12px" height="9px" viewbox="0 0 12 9">
								<polyline points="1 5 4 8 11 1"></polyline>
							</svg>
						</span>
						<span><?php echo esc_html__('Specific Products', 'woocommerce-wholesale-pricing'); ?></span>                                                
					</label>
				</span>
				<span>
					<input class="inp-cbx" style="display: none" id="wc_quote_rules_category_specific_exclude" type="radio" value="category" name="wc_quote_rules[exclude_products][toggle]" <?php checked('category', $exclude_products, true); ?>>
					<label class="cbx" for="wc_quote_rules_category_specific_exclude">
						<span>
							<svg width="12px" height="9px" viewbox="0 0 12 9">
								<polyline points="1 5 4 8 11 1"></polyline>
							</svg>
						</span>
						<span><?php echo esc_html__('Specific Categories', 'woocommerce-wholesale-pricing'); ?></span>                                                
					</label>
				</span>
				<span>
					<input class="inp-cbx" style="display: none" id="wc_quote_rules_tag_specific_exclude" type="radio" value="tag" name="wc_quote_rules[exclude_products][toggle]" <?php checked('tag', $exclude_products, true); ?>>
					<label class="cbx" for="wc_quote_rules_tag_specific_exclude">
						<span>
							<svg width="12px" height="9px" viewbox="0 0 12 9">
								<polyline points="1 5 4 8 11 1"></polyline>
							</svg>
						</span>
						<span><?php echo esc_html__('Specific Categories', 'woocommerce-wholesale-pricing'); ?></span>                                                
					</label>
				</span>
				<label for="wc_quote_rules_product_exclude">
					<div class="rules-specific-container">
						<select class="wc-product-search" multiple="multiple" id="wc_quote_rules_product_exclude" name="wc_quote_rules[exclude_product][]" data-placeholder="<?php esc_attr_e('Search for a product&hellip;', 'woocommerce'); ?>" data-action="woocommerce_json_search_products" data-exclude=""> 
							<?php
							foreach ( $excluded_product_ids as $excluded_product_id ) {
								$product = wc_get_product($excluded_product_id);
								if (is_object($product) ) {
									echo '<option value="' . esc_attr($excluded_product_id) . '"' . selected(true, true, false) . '>' . esc_html(wp_strip_all_tags($product->get_formatted_name())) . '</option>';
								}
							}
							?>
						</select>
					</div>
				</label>

				<!-- specific_category -->
				<label for="wc_quote_rules_category_exclude">
					<div class="rules-specific-container">
						<select class="wc-category-search" multiple="multiple" id="wc_quote_rules_category_exclude" style="width:400px;" name="wc_quote_rules[exclude_category][]" data-placeholder="<?php esc_attr_e('Search for a category&hellip;', 'woocommerce'); ?>" data-action="woocommerce_json_search_category" data-exclude="">
							<?php 

							foreach ( $excluded_product_ids as $excluded_product_id ) {

								$product_cat = get_term_by('slug', $excluded_product_id, 'product_cat');
								if (is_object($product_cat) ) {

									echo '<option value="' . esc_attr($excluded_product_id) . '"' . selected(true, true, false) . '>' . esc_html($product_cat->name) . '</option>';
								}
							}
							?>
						</select>
					</div>
				</label>
				<!-- specific_tag -->
				<label for="wc_quote_rules_tag_exclude">
					<div class="rules-specific-container">
						<select class=" wc-tag-search select2 wc-enhanced-select wc-tag-search select2" multiple="multiple" id="wc_quote_rules_tag_exclude" style="width:400px;" name="wc_quote_rules[exclude_tag][]" data-placeholder="<?php esc_attr_e('Search for a tag&hellip;', 'woocommerce'); ?>" data-action="woocommerce_json_search_tag" data-exclude="">
							<?php
							$taxonomies = 'product_tag';
							$product_tags = get_terms($taxonomies);

							foreach ($product_tags as $values) {
								$key = $values->slug;
								$value = $values->name;
								$selected = is_array($excluded_product_ids) &&  in_array($key, $excluded_product_ids) ? 'selected' : '';

								echo '<option value="' . esc_attr($key) . '" ' . esc_attr($selected) . '>' . esc_html($value) . '</option>';
							}
							?>
						</select>
					</div>
				</label>
			</td>
		</tr>
	</tbody>
</table>
<?php 
/**
 * Action wc_quote_rules_metabox_end
 * 
 * @since 1.0
 **/
do_action('wc_quote_rules_metabox_end', $post, $quote_rules);
