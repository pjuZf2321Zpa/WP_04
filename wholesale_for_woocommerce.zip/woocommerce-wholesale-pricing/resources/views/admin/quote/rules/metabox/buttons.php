<?php
	$quote_rules = get_post_meta($post->ID, 'wc_quote_rules', true);
	$show_shop = isset($quote_rules['show_shop']) ? $quote_rules['show_shop'] : '0' ;
	$show_single = isset($quote_rules['show_single']) ? $quote_rules['show_single'] : '0' ;
	$show_shop = isset($quote_rules['show_shop']) ? $quote_rules['show_shop'] : '0' ;
?>

<table class="form-table">
	<tbody>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<?php echo esc_html__('Show on Single Product Page', 'woocommerce-wholesale-pricing'); ?>
			</th>
			<td class="forminp forminp-checkbox">
				<p>
					<input class="inp-cbx" style="display: none" id="wc_quote_rules_show_single" type="checkbox" value="1" name="wc_quote_rules[show_single]" <?php echo checked(1, $show_single, false); ?>>
					<label class="cbx cbx-square" for="wc_quote_rules_show_single">
						<span>
							<svg width="12px" height="9px" viewbox="0 0 12 9">
								<polyline points="1 5 4 8 11 1"></polyline>
							</svg>
						</span>
						<span><?php esc_html_e('Enable to show add to quote button on single product page.', 'woocommerce-wholesale-pricing'); ?></span>
					</label>
				</p>
			</td>
		</tr>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<?php echo esc_html__('Show on Shop Page', 'woocommerce-wholesale-pricing'); ?>
			</th>
			<td class="forminp forminp-checkbox">
				<p>
					<input class="inp-cbx" style="display: none" id="wc_quote_rules_show_shop" type="checkbox" value="1" name="wc_quote_rules[show_shop]" <?php echo checked(1, $show_shop, false); ?>>
					<label class="cbx cbx-square" for="wc_quote_rules_show_shop">
						<span>
							<svg width="12px" height="9px" viewbox="0 0 12 9">
								<polyline points="1 5 4 8 11 1"></polyline>
							</svg>
						</span>
						<span><?php esc_html_e('Enable to show add to quote button on shop page.', 'woocommerce-wholesale-pricing'); ?></span>
					</label>
				</p>
			</td>
		</tr>
	</tbody>
</table>