<ul id="blkTabs" class="nav nav-tabs">
	<li role="presentation">
		<a href="<?php echo esc_url( admin_url('edit.php?post_type=wc-quote-rules') ); ?>" class="<?php echo in_array( $current_screen->id, array( 'edit-wc-quote-rules', 'wc-quote-rules' ) ) ? 'active' : ''; ?>"><?php esc_html_e( 'Quote Rules', 'woocommerce-wholesale-pricing' ); ?></a>
	</li>
	<li role="presentation">
		<a href="<?php echo esc_url( admin_url('edit.php?post_type=wc-quote') ); ?>" class="<?php echo in_array( $current_screen->id, array( 'edit-wc-quote', 'wc-quote' ) ) ? 'active' : ''; ?>"><?php esc_html_e( 'Quote List', 'woocommerce-wholesale-pricing' ); ?></a>
	</li>
</ul>