<?php
defined('ABSPATH') || exit;

$post_data = get_post($quote_id);
$user      = get_user_by('id', $post_data->post_author);
$user_name = $user ? $user->display_name . ' (' . $user->user_email . ')' : '';
$post_data = get_post($quote_id);
$user      = get_user_by('id', $post_data->post_author);
$user_name = $user ? $user->display_name . ' (' . $user->user_email . ')' : '';
$form_config = wwp_get_quote_form_builder_config();
$form_config = wwp_get_quote_form_builder_config();
$data        = json_decode(json_encode(get_post_meta($quote_id, 'quote_fields', true)), true);

if (!is_array($data)) {
	$data = array();
}

if (!is_array($data)) {
	$data = array();
}

if (!empty($data['file']) && is_string($data['file'])) {
	$decoded = json_decode($data['file'], true);
	$data['file'] = !empty($decoded) ? $decoded : stripslashes($data['file']);
}
$has_form_components = is_array($form_config)
	&& !empty($form_config['components'])
	&& is_array($form_config['components']);
?>

<table class="form-table">
	<tbody>
		<?php if (!empty($quote_id)) : ?>
			<tr>
				<th><?php esc_html_e('Quote #:', 'woocommerce-wholesale-pricing'); ?></th>
				<td><label><?php echo esc_html(absint($quote_id)); ?></label></td>
			</tr>
		<?php endif; ?>
		<tr>
			<th><?php esc_html_e('Quote User:', 'woocommerce-wholesale-pricing'); ?></th>
			<td><input type="text" value="<?php echo esc_attr($user_name); ?>" disabled style="width:100%;"></td>
		</tr>
	</tbody>
	<tbody>
		<?php if (!empty($quote_id)) : ?>
			<tr>
				<th><?php esc_html_e('Quote #:', 'woocommerce-wholesale-pricing'); ?></th>
				<td><label><?php echo esc_html(absint($quote_id)); ?></label></td>
			</tr>
		<?php endif; ?>
		<tr>
			<th><?php esc_html_e('Quote User:', 'woocommerce-wholesale-pricing'); ?></th>
			<td><input type="text" value="<?php echo esc_attr($user_name); ?>" disabled style="width:100%;"></td>
		</tr>
	</tbody>
</table>
<?php if ($has_form_components) : ?>
<div class="wc-quote-bootstrap-scope">
	<div id="quote-fields" class="forminp forminp-fields"></div>
</div>
<script type="text/javascript">
(function() {
	function initQuoteOrderFormio() {
		if (typeof Formio === 'undefined') {
			return;
		}
		var container = document.getElementById('quote-fields');
		if (!container) {
			return;
		}
		var components = <?php echo wp_json_encode( $form_config, JSON_HEX_TAG | JSON_UNESCAPED_SLASHES ); ?>;
		var submissionData = <?php echo wp_json_encode( $data, JSON_HEX_TAG | JSON_UNESCAPED_SLASHES ); ?>;
		Formio.createForm(container, components, {
			readOnly: true
		}).then(function(form) {
			form.nosubmit = true;
			form.submission = {
				data: submissionData
			};
		});
	}
	if (document.readyState === 'complete') {
		initQuoteOrderFormio();
	} else {
		window.addEventListener('load', initQuoteOrderFormio);
	}
})();
</script>
<?php
endif;