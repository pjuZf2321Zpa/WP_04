<?php

echo '<select name="wc_quote_pdf_admin_detail_user"  style="width:85%;">';
foreach ($users as $user_id) {
	$user_info = get_userdata($user_id);
	$user_name = $user_info ? $user_info->display_name : 'Unknown User';
	echo '<option value="' . esc_attr($user_id) . '" ' . selected($selected_user, $user_id, false) . '>' . esc_html__($user_name, 'wc-quote-custom-pdf') . '</option>';
}
echo '</select>';

// Set Nonce For All Templates (bronze,darkblue,lightblue)
wp_nonce_field('wc_quote_pdf_user_action_nonce', 'wc_quote_pdf_user_action_nonce');
