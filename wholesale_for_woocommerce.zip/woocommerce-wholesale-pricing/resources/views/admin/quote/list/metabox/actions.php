<div class="wc-quote-actions-box" id="submitpost">

	<div id="minor-publishing">
		<?php 
		// Define default statuses
		$statuses = array(
			'quote_draft'      => __('Draft', 'woocommerce-wholesale-pricing'),
			'quote_new'        => __('New', 'woocommerce-wholesale-pricing'),
			'quote_quoted'     => __('Quoted', 'woocommerce-wholesale-pricing'),
			'quote_accepted'   => __('Accepted', 'woocommerce-wholesale-pricing'),
			'quote_converted'  => __('Converted To Order', 'woocommerce-wholesale-pricing'),
			'quote_rejected'   => __('Rejected', 'woocommerce-wholesale-pricing'),
			'quote_expired'    => __('Expired', 'woocommerce-wholesale-pricing'),
		);

		if ( check_quote_status() ) {
			// Get custom statuses from 'wc-quote-status' post type
			$custom_posts = get_posts(array(
				'post_type'   => 'wc-quote-status',
				'post_status' => 'any',
				'numberposts' => -1,
				'orderby'     => array(
					'menu_order' => 'DESC', // Sort by priority (menu_order) first
					'modified'   => 'ASC', // In case of ties, sort by last modified date
				),
			));

			// Merge custom post titles into the statuses array
			foreach ($custom_posts as $post_data) {
				$quote_meta_status = get_post_meta($post_data->ID, 'wc_quote_status', true);
				$enable_quote_status = isset($quote_meta_status['enable_quote_status']) ? $quote_meta_status['enable_quote_status'] : '';
				$quote_status = isset($quote_meta_status['quote_status']) ? $quote_meta_status['quote_status'] : $post_data->post_name;

				// Only add the status if 'enable_quote_status' is set to true
				if ( '1' === $enable_quote_status ) {
					$statuses[$quote_status] = $post_data->post_title;
				}
			}
		}

		/**
		 * Filter wc_quote_statuses_array
		 * 
		 * @since 1.0
		**/
		$statuses = apply_filters('wc_quote_statuses_array', $statuses);

		// Get current post status
		$quote_status = get_post_status(get_the_ID());
		?>
		<div id="misc-publishing-actions">
			<div class="misc-pub-section misc-pub-post-status">
				<?php echo esc_html__('Status', 'woocommerce-wholesale-pricing'); ?>:
				<select name="post_status" id="post_status">
					<?php 
					// Loop through statuses and render options
					foreach ($statuses as $key => $value) { 
						printf(
							'<option value="%s" %s>%s</option>',
							esc_attr($key),
							selected($quote_status, $key, false),
							esc_html($value)
						);
					}
					?>
				</select>
			</div>
		</div>
		<div class="clear"></div>
	</div>

	<div id="major-publishing-actions">
		<div id="delete-action">
			<a class="submitdelete deletion" href="<?php echo esc_url(get_delete_post_link(get_the_ID())); ?>">
				<?php echo esc_html__('Move to Trash', 'woocommerce-wholesale-pricing'); ?>
			</a>
		</div>

		<div id="publishing-action">
			<span class="spinner"></span>
			<input name="original_publish" type="hidden" id="original_publish" value="<?php echo esc_html__('Save', 'woocommerce-wholesale-pricing'); ?>">
			<input type="submit" name="save" id="publish" class="button button-primary button-large" value="<?php echo esc_html__('Save', 'woocommerce-wholesale-pricing'); ?>">
		</div>
		<div class="clear"></div>
	</div>

</div>
