<?php
/**
 * Quote details in Meta box.
 *
 * It shows the details of quotes items in meta box.
 */
defined('ABSPATH') || exit;

$quote_status   = get_post_status($post);

?>
<div class="woocommerce_order_items_wrapper wc-order-items-editable">
	<?php
	/**
	 * Action wc_quote_details_before_quote_table
	 * 
	 * @since 1.0
	 **/
	do_action('wc_quote_details_before_quote_table', $post);

	wwp_view( 'admin.quote.list.metabox.meta-list-items', compact( 'post' ), true );
	
	/**
	* Action wc_quote_details_after_quote_table
	* 
	* @since 1.0
	**/
	do_action('wc_quote_details_after_quote_table', $post);
	?>
</div>
<div class="wc-order-data-row wc-order-add-item wc-order-data-row-toggle" >
	<?php if ( isset( $quote_general['custom_tax_shipping'] ) && '1' == $quote_general['custom_tax_shipping'] && ! in_array($quote_status, array( 'quote_converted', 'quote_expired', 'quote_rejected' )) ) : ?>
		<button type="button" id="wc_quote_add_tax_shipping" class="button add-order-item"><?php esc_html_e('Add Tax and Shipping', 'woocommerce-wholesale-pricing'); ?></button>
	<?php endif; ?>
	<button type="button" id="add-quote-item" class="button add-order-item"><?php esc_html_e('Add product(s)', 'woocommerce-wholesale-pricing'); ?></button>
	<?php if (!in_array($quote_status, array( 'quote_converted', 'quote_expired' )) ) : ?>
		<div class="pull-left">
			<button type="submit" name="wc_quote_convert_to_order" class="button button-primary button-large" >
		<?php echo esc_html__('Convert to Order', 'woocommerce-wholesale-pricing'); ?>
			</button>
		</div>
	<?php endif; ?>
</div>
<div class="wc-backbone-modal">
	<div class="wc-backbone-modal-content">
		<section class="wc-backbone-modal-main" role="main">
			<header class="wc-backbone-modal-header">
				<h1><?php esc_html_e('Add products', 'woocommerce-wholesale-pricing'); ?></h1>
				<button class="modal-close modal-close-link dashicons dashicons-no-alt">
					<span class="screen-reader-text"><?php echo esc_html__('Close modal panel', 'woocommerce-wholesale-pricing'); ?></span>
				</button>
			</header>
			<article>
				<form method="post">
					<table class="widefat">
						<thead>
							<tr>
								<th><?php esc_html_e('Product', 'woocommerce-wholesale-pricing'); ?></th>
								<th><?php esc_html_e('Quantity', 'woocommerce-wholesale-pricing'); ?></th>
							</tr>
						</thead>
						<?php
						$row = '<td><select class="wc-product-search wc-quote-add-product" name="item_id" data-allow_clear="true" data-display_stock="true" data-exclude_type="variable" data-placeholder="' . esc_attr__('Search for a product&hellip;', 'woocommerce-wholesale-pricing') . '"></select></td>
								<td><input type="number" step="1" min="0" max="9999" autocomplete="off" name="item_qty" placeholder="1" size="4" class="quantity" /></td>';
						?>
						<tbody data-row="<?php echo esc_attr($row); ?>">
							<tr>
								<td><select class="wc-product-search wc-quote-add-product" name="item_id" data-allow_clear="true" data-display_stock="true" data-exclude_type="variable" data-placeholder="<?php echo esc_attr__('Search for a product&hellip;', 'woocommerce-wholesale-pricing'); ?>"></select></td>
								<td><input type="number" step="1" min="0" max="9999" autocomplete="off" name="item_qty" placeholder="1" size="4" class="quantity" /></td>
							</tr>
						</tbody>
					</table>
				</form>
			</article>
			<footer>
				<div class="inner">
					<button id="btn-ok" class="button button-primary button-large"><?php esc_html_e('Add', 'woocommerce-wholesale-pricing'); ?></button>
				</div>
			</footer>
		</section>
	</div>
</div>
<?php
if ( isset( $quote_general['custom_tax_shipping'] ) && '1' == $quote_general['custom_tax_shipping'] && ! in_array($quote_status, array( 'quote_converted', 'quote_expired', 'quote_rejected' )) ) :
	$shipping_value = get_post_meta( $post->ID, 'quote_content_shipping', true );
	$tax_value      = get_post_meta( $post->ID, 'quote_content_shipping_tax', true );

	$shipping_value = ( is_numeric( $shipping_value ) && $shipping_value >= 0 ) ? (string) $shipping_value : ''; 
	$tax_value      = ( is_numeric( $tax_value ) && $tax_value >= 0 ) ? (string) $tax_value : '';
	?>

	<div id="wc-quote-tax-shipping-backdrop" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:#000; opacity:0.7; z-index:99900;"></div>
		<div id="wc-quote-tax-shipping-modal" style="display:none; position:fixed; top:50%; left:50%; transform:translate(-50%,-50%); z-index:99901; background:#fff; border-radius:4px; min-width:500px; max-width:95vw; box-shadow:0 4px 20px rgba(0,0,0,0.2);">
			<div style="padding:12px 16px; border-bottom:1px solid #ddd; display:flex; align-items:center; justify-content:space-between;">
				<div>
					<strong><?php echo esc_html__( 'Tax and Shipping', 'woocommerce-wholesale-pricing' ); ?></strong>
				</div>
				<button type="button" class="wc-quote-tax-shipping-close button" style="margin:0; padding:0 8px;"><?php echo esc_html__( '×', 'woocommerce-wholesale-pricing' ); ?></button>
			</div>
			<div style="padding:16px;">
				<p style="margin-top:0; margin-bottom:16px;"><?php echo esc_html( 'The updated tax and shipping will be updated in the quote and in the order once converted to order.', 'woocommerce-wholesale-pricing' ); ?></p>

				<p style="margin:0 0 12px;">
					<label for="wc-quote-tax-shipping-input-shipping" style="display:block; font-weight:600; margin-bottom:6px;">
						<?php esc_html_e( 'Shipping value', 'woocommerce-wholesale-pricing' ); ?>
					</label>
					<input
						type="number"
						id="wc-quote-tax-shipping-input-shipping"
						min="0"
						step="any"
						value="<?php echo esc_attr( $shipping_value ); ?>"
						style="width:100%; max-width:400px;"
					/>
				</p>

				<p style="margin:0;">
					<label for="wc-quote-tax-shipping-input-tax" style="display:block; font-weight:600; margin-bottom:6px;">
						<?php esc_html_e( 'Tax value', 'woocommerce-wholesale-pricing' ); ?>
					</label>
					<input
						type="number"
						id="wc-quote-tax-shipping-input-tax"
						min="0"
						step="any"
						value="<?php echo esc_attr( $tax_value ); ?>"
						style="width:100%; max-width:400px;"
					/>
				</p>

				<div id="wc-quote-tax-shipping-message" style="margin-top:14px;"></div>
			</div>
			<div style="padding:14px 16px; border-top:1px solid #ddd; text-align:right;">
				<button type="button" class="button" id="wc-quote-tax-shipping-cancel">
					<?php echo esc_html__( 'Cancel', 'woocommerce-wholesale-pricing' ); ?>
				</button>
				<button type="button" class="button button-primary button-large" id="wc-quote-tax-shipping-update" style="margin-left:10px;">
					<?php echo esc_html__( 'Update', 'woocommerce-wholesale-pricing' ); ?>
				</button>
			</div>
		</div>
<?php endif; ?>
<div class="wc-backbone-modal-backdrop modal-close"></div>
<?php
