<?php
/**
 * Quote list items
 *
 * It shows the details of quotes items in meta box.
 */
use WooCommerceWholesalePricing\App\Modules\Quote\QuoteProcess;

defined('ABSPATH') || exit;
$quote_contents = get_post_meta($post->ID, 'quote_contents', true);
$wc_quote       = new QuoteProcess($quote_contents);
$quote_totals = $wc_quote->get_calculated_totals((array) $quote_contents, $post->ID);
?>
<div id="wc_quote_items_container">
	<table cellpadding="0" cellspacing="0" id="wc_quote_items_table" class="woocommerce_order_items wc_quote_items">

		<thead>
			<tr>
				<th class="thumb sortable" data-sort="string-ins"><?php esc_html_e('Thumbnail', 'woocommerce-wholesale-pricing'); ?></th>
				<th class="item sortable" data-sort="string-ins"><?php esc_html_e('Item', 'woocommerce-wholesale-pricing'); ?></th>
				<th class="item_cost sortable" data-sort="float"><?php esc_html_e('Cost', 'woocommerce-wholesale-pricing'); ?></th>
				<th class="item_cost sortable" data-sort="float"><?php esc_html_e('Offered Price', 'woocommerce-wholesale-pricing'); ?></th>
				<th class="quantity sortable" data-sort="int"><?php esc_html_e('Qty', 'woocommerce-wholesale-pricing'); ?></th>
				<th class="line_cost sortable" data-sort="float"><?php esc_html_e('Subtotal', 'woocommerce-wholesale-pricing'); ?></th>
				<th class="line_cost sortable" data-sort="float"><?php esc_html_e('Offered Subtotal', 'woocommerce-wholesale-pricing'); ?></th>
				<th class="line_actions" ></th>
			</tr>
		</thead>

		<tbody id="order_line_items">
			<?php
			/**
			 * Action wc_quote_details_before_quote_table_items
			 * 
			 * @since 1.0
			 **/
			do_action('wc_quote_details_before_quote_table_items', $post);

			$offered_price_subtotal = 0;
			foreach ( (array) $quote_contents as $item_id => $item ) {

				if (isset($item['data']) ) {

					$product = $item['data'];

				} else {

					continue;
				}

				if (! is_object($product) ) {
					continue;
				}

				if ( get_class( $product ) === '__PHP_Incomplete_Class' ) {
					$vars = get_object_vars( $product );
					if ( isset( $vars['__PHP_Incomplete_Class_Name'] ) && 'WC_Product_Booking' === $vars['__PHP_Incomplete_Class_Name'] ) {
						continue;
					}
				}

				$price = empty($item['addons_price']) ? (int) $product->get_price() : $item['addons_price'];
				
				$offered_signup = 0;
				$signup_fee = 0;
				if ( class_exists('Wwp_Wholesale_Pricing') && class_exists('WWP_Easy_Wholesale_Multiuser') ) {
					$Wholesale_Price_class = new \WWP_Easy_Wholesale_Multiuser();
					$check_wwp = $Wholesale_Price_class->is_wholesale($product->get_id());
					$Wprice = !$check_wwp ? $Wholesale_Price_class->wwp_regular_price_change($price, $product) : $Wholesale_Price_class->wwp_regular_price_change(get_post_meta($product->get_id(), '_regular_price', true), $product);
					$price = empty($item['addons_price']) ? $Wprice : $item['addons_price'];
				}
				if ($product->is_type('booking') && !empty($item['booking']['_resource_id'])) {
					$resource_id = absint($item['booking']['_resource_id']);
					
					if ($resource_id > 0) {
						// This will calculate the price based on the complete booking array (date, time, persons, resource etc.)
						
						$get_price = \WC_Bookings_Cost_Calculation::calculate_booking_cost($item['booking'], $product);

						if (!is_wp_error($get_price)) {
							$price = $get_price;
						}

					}
				}

				if ($product->get_type() === 'subscription' || $product->get_type() === 'variable-subscription' ) :
					$signup_fee = \WC_Subscriptions_Product::get_sign_up_fee($product);
					$offered_signup = empty($item['offered_signup']) ? $signup_fee : $item['offered_signup'];
				endif;
				$qty_display   = $item['quantity'];
				$offered_price = isset($item['offered_price']) ? floatval($item['offered_price']) : $price;
				$product_link  = $product ? admin_url('post.php?post=' . $product->get_id() . '&action=edit') : '';
				/**
				* Filter wc_quote_item_thumbnail
				* 
				* @since 1.0
				**/
				$thumbnail     = $product ? apply_filters('wc_quote_item_thumbnail', $product->get_image('thumbnail', array( 'title' => '' ), false), $item_id, $item) : '';

				$offered_price_subtotal += floatval(esc_attr($offered_price) + esc_attr($offered_signup)) * intval(esc_attr($qty_display));

				?>
				<tr class="item" data-order_item_id="<?php echo esc_attr($item_id); ?>">
					<td class="thumb">
				<?php echo '<div class="wc-order-item-thumbnail">' . wp_kses_post($thumbnail) . '</div>'; ?>
					</td>

					<td class="name" data-sort-value="<?php echo esc_attr($product->get_name()); ?>">
				<?php
				$is_visible        = $product && $product->is_visible();
				/**
				 * Filter wc_quote_item_permalink
				 * 
				 * @since 1.0
				**/
				$product_permalink = apply_filters('wc_quote_item_permalink', $is_visible ? $product->get_permalink($item) : '', $item, $post);
				/**
				 * Filter wc_quote_item_name
				 * 
				 * @since 1.0
				**/
				echo wp_kses_post(apply_filters('wc_quote_item_name', $product_permalink ? sprintf('<a href="%s">%s</a>', $product_permalink, $product->get_name()) : $product->get_name(), $item, $is_visible));
				?>
						  
				<?php
				echo wp_kses_post('<div class="wc-quote-item-sku"><strong>' . esc_html__('SKU:', 'woocommerce-wholesale-pricing') . '</strong> ' . esc_html($product->get_sku()) . '</div>');
				/**
				* Action wc_quote_item_meta_start
				* 
				* @since 1.0
				**/
				do_action('wc_quote_item_meta_start', $item_id, $item, $post, false);

				if (isset($item['booking']) && is_array($item['booking'])) {
					echo '<div class="quote-booking-details">';

					// Show Booking Date
					if (!empty($item['booking']['_year']) &&
						!empty($item['booking']['_month']) &&
						!empty($item['booking']['_day'])) {

						$y = $item['booking']['_year'];
						$month = str_pad($item['booking']['_month'], 2, '0', STR_PAD_LEFT);
						$d = str_pad($item['booking']['_day'], 2, '0', STR_PAD_LEFT);
						$formatted_date = date_i18n('F j, Y', strtotime("$y-$month-$d"));

						echo '<p><strong>Booking Date:</strong><br>' . esc_html($formatted_date) . '</p>';
					}

					// Show Duration if available
					if (!empty($item['booking']['duration'])) {
						echo '<p><strong>Duration:</strong><br>' . esc_html($item['booking']['duration']) . '</p>';
					} elseif (!empty($item['booking']['_duration']) && !empty($item['booking']['_duration_unit'])) {
						$duration = $item['booking']['_duration'];
						$unit = $item['booking']['_duration_unit'];

						// Pluralize unit if duration > 1
						$unit_label = $duration > 1 ? $unit . 's' : $unit;

						echo '<p><strong>Duration:</strong><br>' . esc_html($duration . ' ' . $unit_label) . '</p>';
					}

					// Show Booking Time
					if (!empty($item['booking']['_time'])) {
						$timestamp = strtotime($item['booking']['_time']);
						if ($timestamp) {
							echo '<p><strong>Booking Time:</strong><br>' . esc_html(date_i18n('g:i a', $timestamp)) . '</p>';
						}
					} elseif (!empty($item['booking']['time'])) {
						echo '<p><strong>Booking Time:</strong><br>' . esc_html($item['booking']['time']) . '</p>';
					}

					// Show Booking Type (resource)
					if (!empty($item['booking']['_resource_id'])) {
						$resource_post = get_post($item['booking']['_resource_id']);
						if ($resource_post && !is_wp_error($resource_post)) {
							echo '<p><strong>Booking Type:</strong><br>' . esc_html($resource_post->post_title) . '</p>';
						}
					} elseif (!empty($item['booking']['type'])) {
						echo '<p><strong>Booking Type:</strong><br>' . esc_html($item['booking']['type']) . '</p>';
					}

					echo '</div>';
				} else {
					// Fallback for other data
					echo wp_kses_post(wc_get_formatted_cart_item_data($item));
				}

				
				/**
				* Action wc_quote_item_meta_end
				* 
				* @since 1.0
				**/
				do_action('wc_quote_item_meta_end', $item_id, $item, $post, false);
				?>
					</td>
					<td class="item_cost" data-sort-value="<?php echo esc_attr($price); ?>">
						<div class="edit">
				<?php 
				if ($product->get_type() === 'subscription' || ( $product->get_type() === 'variable-subscription' && $signup_fee > 0 ) ) : 
					echo wp_kses_post(\WC_Subscriptions_Product::get_price_string($product, array( 'price' => wc_price($price), 'sign_up_fee' => $signup_fee )));
			 else :
				 echo wp_kses_post(wc_price($price));
			 endif; 
				?>
						</div>
					</td>
					<td class="item-offered-price">
						<input type="number" min="0" class="input-text offered-price-input text" step="any" placeholder="<?php echo esc_html__('Offered Price', 'woocommerce-wholesale-pricing'); ?>" name="offered_price[<?php echo esc_attr($item_id); ?>]" value="<?php echo esc_attr($offered_price); ?>">
				<?php if ($product->get_type() === 'subscription' || ( $product->get_type() === 'variable-subscription' && $offered_signup > 0 ) ) : ?>
							<span> / </span> <input type="number" class="input-text offered-price-input text" step="any" name="offered_signup[<?php echo esc_attr($item_id); ?>]" placeholder="<?php echo esc_html__('Offered Signup', 'woocommerce-wholesale-pricing'); ?>" value="<?php echo esc_attr($offered_signup); ?>">
				<?php endif; ?>
					</td>
					<td class="quantity" width="1%">
						<div class="edit">
							<input type="number" class="input-text quote-qty-input text" min="1" name="quote_qty[<?php echo esc_attr($item_id); ?>]" value="<?php echo esc_attr($item['quantity']); ?>">
						</div>
					</td>

					<td class="line_cost" data-sort-value="<?php echo esc_attr($price * $qty_display); ?>">
						<div class="view">
				<?php echo wp_kses_post(wc_price(( $price + $signup_fee ) * $qty_display)); ?>
						</div>
					</td>

					<td class="offered_line_cost" data-sort-value="<?php echo esc_attr($offered_price * $qty_display); ?>">
				<?php echo wp_kses_post(wc_price(( $offered_price + $offered_signup ) * $qty_display)); ?>
					</td>
					<td class="wc-order-edit-line-item">
						<div class="wc-order-edit-line-item-actions">
							<a class="delete-order-item tips" title="Delete <?php echo esc_html($product->get_name()); ?>"  data-quote_item_id="<?php echo esc_attr($item_id); ?>"></a>
						</div>
					</td>

				</tr>
				<?php
			}
			/**
			* Action wc_quote_details_after_quote_table_items
			* 
			* @since 1.0
			**/
			do_action('wc_quote_details_after_quote_table_items', $post);
			?>
		</tbody>
	</table>
	<div class="wc-order-data-row wc-order-totals-items wc-order-items-editable">
		<table cellpadding="0" cellspacing="0" id="wc_quote_total_table" class="wc-order-totals wc_quote_items_total">
				<?php

				$tax_label = $quote_totals['_tax_label'] ? $quote_totals['_tax_label'] : 'Tax(standard)' ;
				$calculated_total_offered =  $quote_totals['cal_offered_total'];
				// Define the desired order manually
				$sequencedArr = array(
					'_subtotal' => $quote_totals['_subtotal'] ? $quote_totals['_subtotal'] : null,
					'_offered_total' => $quote_totals['_offered_total'] ? $quote_totals['_offered_total'] : null,
					'_tax_total' => $quote_totals['_tax_total'] ? $quote_totals['_tax_total'] : null,
					'_tax_total_offered' => $quote_totals['_tax_total_offered'] ? $quote_totals['_tax_total_offered'] : null,
					'_shipping' => $quote_totals['_shipping'] ? $quote_totals['_shipping'] : null,
					'_total' => $quote_totals['_total'] ? $quote_totals['_total'] : null,
				);

				$quote_totals = $sequencedArr;
				/**
				 * Filter wc_quote_totals_before_render
				 * 
				 * @since 1.0
				**/
				$quote_totals = apply_filters('wc_quote_totals_before_render', $quote_totals);


				foreach ( $quote_totals as $key => $total ) {

					$label = '';
					switch ( $key ) {
						case '_subtotal':
							$label = esc_html__('Subtotal(standard)', 'woocommerce-wholesale-pricing');
							break;
						case '_tax_total':
							$label = esc_html__($tax_label, 'woocommerce-wholesale-pricing');
							break;
						case '_tax_total_offered':
							$label = esc_html__('Tax(offered)', 'woocommerce-wholesale-pricing');
							break;
						case '_shipping':
							$label = esc_html__('Shipping', 'woocommerce-wholesale-pricing');
							break;
						case '_total':
							$label = esc_html__('Total(standard)', 'woocommerce-wholesale-pricing');
							break;
						case '_offered_total':
							$label = esc_html__('Subtotal(offered)', 'woocommerce-wholesale-pricing');
							$total = /*$offered_price_subtotal */  $quote_totals['_offered_total'];
							break;
						default:
							$label = '';
							break;
					}

					if (empty($label) ) {
						continue;
					}

					?>
						<tr>
							<td scope="row"><?php echo esc_html($label); ?></td>
							<th colspan="2"><?php echo wp_kses_post(wc_price($total)); ?></th>
						</tr>
					<?php
				}
				?>
				<tr>
					<td scope="row"><?php echo esc_html__('Total(offered)', 'woocommerce-wholesale-pricing'); ?></td>
					<!-- <th colspan="2"><?php //echo wp_kses_post(wc_price($offered_price_subtotal + $quote_totals['_shipping'] +  $quote_totals['_tax_total'] )); ?></th> -->
					<th colspan="2"><?php echo wp_kses_post(wc_price($calculated_total_offered)); ?></th>
				</tr>
				<tr>
					<td colspan="3"><?php echo esc_html__('Note: Tax/Vat will be calculated on quote conversion to cart but it is visible to customers.', 'woocommerce-wholesale-pricing'); ?></td>
				</tr>
				  
		</table>
	</div>
</div>
