<?php
/**
 * Disable payment methods + optional location / order-total conditions.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var bool $is_edit  Whether this is the edit-term screen.
 * @var int  $term_id  Term ID when editing.
 */

if ( ! isset( $is_edit ) ) {
	$term_id = absint( filter_input( INPUT_GET, 'tag_ID', FILTER_SANITIZE_NUMBER_INT ) );
	$is_edit = $term_id > 0;
} else {
	$is_edit = (bool) $is_edit;
	$term_id = isset( $term_id ) ? absint( $term_id ) : 0;
}

$wwp_countries = function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_countries() : array();
if ( ! is_array( $wwp_countries ) ) {
	$wwp_countries = array();
}

$restricted_methods = $is_edit ? (array) get_term_meta( $term_id, 'wwp_restricted_pmethods_wholesaler', true ) : array();
$restricted_methods = array_map( 'strval', array_filter( $restricted_methods, 'strlen' ) );

$conditions_enabled = $is_edit ? (string) get_term_meta( $term_id, 'wwp_conditions_enabled', true ) : '';
$condition_location = $is_edit ? (string) get_term_meta( $term_id, 'wwp_condition_location', true ) : 'shipping';
if ( ! in_array( $condition_location, array( 'billing', 'shipping' ), true ) ) {
	$condition_location = 'shipping';
}
$condition_countries = $is_edit ? (array) get_term_meta( $term_id, 'wwp_condition_countries', true ) : array();
$condition_countries = array_map( 'strval', array_filter( $condition_countries, 'strlen' ) );
$condition_states = $is_edit ? (array) get_term_meta( $term_id, 'wwp_condition_states', true ) : array();
$condition_states = array_map( 'strval', array_filter( $condition_states, 'strlen' ) );
$condition_min_order = $is_edit ? (string) get_term_meta( $term_id, 'wwp_condition_min_order', true ) : '';
$condition_max_order = $is_edit ? (string) get_term_meta( $term_id, 'wwp_condition_max_order', true ) : '';
?>
<div class="wwp-role-conditions">
	<div class="form-field term-gateways-wrap">
		<?php if ( ! $is_edit ) : ?>
			<label for="wwp_restricted_pmethods_wholesaler"><strong><?php esc_html_e( 'Disable Payment Methods', 'woocommerce-wholesale-pricing' ); ?></strong></label>
		<?php endif; ?>
		<?php $available_gateways = WC()->payment_gateways->payment_gateways(); ?>
		<select name="wwp_restricted_pmethods_wholesaler[]" id="wwp_restricted_pmethods_wholesaler" class="regular-text wc-enhanced-select" multiple data-placeholder="<?php esc_attr_e( 'Select payment methods', 'woocommerce-wholesale-pricing' ); ?>">
			<?php
			if ( ! empty( $available_gateways ) ) {
				foreach ( $available_gateways as $key => $method ) {
					$selected = ( $is_edit && in_array( (string) $key, $restricted_methods, true ) ) ? 'selected="selected"' : '';
					echo '<option value="' . esc_attr( $key ) . '" ' . esc_attr( $selected ) . '>' . esc_attr( $method->get_method_title() ) . '</option>';
				}
			}
			?>
		</select>
		<p><?php esc_html_e( 'Select payment methods to restrict for wholesale users.', 'woocommerce-wholesale-pricing' ); ?></p>
	</div>
	<label class="wwp-role-conditions-header" for="wwp_conditions_enabled">
		<input type="checkbox" name="wwp_conditions_enabled" id="wwp_conditions_enabled" class="wwp-role-conditions-toggle" value="yes" <?php checked( 'yes', $conditions_enabled ); ?>>
		<span class="dashicons dashicons-admin-generic" aria-hidden="true"></span>
		<strong><?php esc_html_e( 'Conditions', 'woocommerce-wholesale-pricing' ); ?></strong>
		<span class="wwp-role-conditions-optional"><?php esc_html_e( '(optional)', 'woocommerce-wholesale-pricing' ); ?></span>
	</label>

	<div class="wwp-role-conditions-body" <?php echo 'yes' === $conditions_enabled ? '' : 'hidden'; ?>>
		<p class="wwp-role-conditions-field">
			<label for="wwp_condition_location"><?php esc_html_e( 'Apply location condition to', 'woocommerce-wholesale-pricing' ); ?></label>
			<select name="wwp_condition_location" id="wwp_condition_location">
				<option value="shipping" <?php selected( $condition_location, 'shipping' ); ?>><?php esc_html_e( 'Shipping address', 'woocommerce-wholesale-pricing' ); ?></option>
				<option value="billing" <?php selected( $condition_location, 'billing' ); ?>><?php esc_html_e( 'Billing address', 'woocommerce-wholesale-pricing' ); ?></option>
			</select>
			<span class="description"><?php esc_html_e( 'Which address to check against the countries/states below.', 'woocommerce-wholesale-pricing' ); ?></span>
		</p>

		<div class="wwp-role-conditions-grid">
			<p class="wwp-role-conditions-field">
				<label for="wwp_condition_countries"><?php esc_html_e( 'Countries', 'woocommerce-wholesale-pricing' ); ?></label>
				<select name="wwp_condition_countries[]" id="wwp_condition_countries" class="wc-enhanced-select wwp-role-conditions-countries" multiple="multiple" data-placeholder="<?php esc_attr_e( 'Select countries', 'woocommerce-wholesale-pricing' ); ?>" style="width:100%;">
					<?php foreach ( $wwp_countries as $country_code => $country_name ) : ?>
						<option value="<?php echo esc_attr( $country_code ); ?>" <?php selected( in_array( (string) $country_code, $condition_countries, true ) ); ?>><?php echo esc_html( $country_name ); ?></option>
					<?php endforeach; ?>
				</select>
			</p>
			<p class="wwp-role-conditions-field">
				<label for="wwp_condition_states"><?php esc_html_e( 'States / regions', 'woocommerce-wholesale-pricing' ); ?></label>
				<select name="wwp_condition_states[]" id="wwp_condition_states" class="wc-enhanced-select wwp-role-conditions-states" multiple="multiple" data-placeholder="<?php esc_attr_e( 'Select states / regions', 'woocommerce-wholesale-pricing' ); ?>" data-selected="<?php echo esc_attr( wp_json_encode( array_values( $condition_states ) ) ); ?>" style="width:100%;">
				</select>
				<span class="description wwp-role-conditions-states-help"><?php esc_html_e( 'Leave empty to apply to the whole country.', 'woocommerce-wholesale-pricing' ); ?></span>
			</p>
		</div>

		<div class="wwp-role-conditions-grid">
			<p class="wwp-role-conditions-field">
				<label for="wwp_condition_min_order"><?php esc_html_e( 'Min order total', 'woocommerce-wholesale-pricing' ); ?></label>
				<input type="number" name="wwp_condition_min_order" id="wwp_condition_min_order" min="1" step="0.01" placeholder="<?php esc_attr_e( 'No minimum', 'woocommerce-wholesale-pricing' ); ?>" value="<?php echo esc_attr( $condition_min_order ); ?>">
			</p>
			<p class="wwp-role-conditions-field">
				<label for="wwp_condition_max_order"><?php esc_html_e( 'Max order total', 'woocommerce-wholesale-pricing' ); ?></label>
				<input type="number" name="wwp_condition_max_order" id="wwp_condition_max_order" min="1" step="0.01" placeholder="<?php esc_attr_e( 'No maximum', 'woocommerce-wholesale-pricing' ); ?>" value="<?php echo esc_attr( $condition_max_order ); ?>">
			</p>
		</div>

		<p class="description wwp-role-conditions-summary"></p>
	</div>
</div>
