<?php
/**
 * Vars
 * 
 * WP_Term $term
 */
use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

	$term_id                           = $term->term_id;
	$term_tax                               = get_term_meta($term_id, 'wwp_tax_exmept_wholesaler', true);
	$wwp_wholesale_payment_method_name = get_term_meta($term_id, 'wwp_wholesale_payment_method_name', true);
	$wwp_wholesaler_tax_classes        = get_term_meta($term_id, 'wwp_wholesaler_tax_classes', true);
	$coupons                           = get_term_meta($term_id, 'wwp_wholesale_disable_coupons', true);
	$settings                          = WholesaleSettingsHelper::get_pricing_settings();
	$variable_subscription_id          = ! empty($settings['wholesale_subscription']) ? $settings['wholesale_subscription'] : '';
	$selected_variation                = get_term_meta($term_id, 'wwp_wholesaler_subscription', true);
	wp_nonce_field('wwp_tax_exempt_nonce', 'wwp_tax_exempt_nonce');
?>

<tr class="form-field term-tax-wrap">
	<th> 
		<label for="wwp_tax_exmept_wholesaler"> 
			<?php esc_html_e('Tax Exempt', 'woocommerce-wholesale-pricing'); ?>
		</label>
	</th>
	<td scope="row">
		<input type="checkbox" name="wwp_tax_exmept_wholesaler" value="yes" <?php checked('yes', $term_tax); ?>>
		<span><?php esc_html_e('Tax exempt for wholesale user role.', 'woocommerce-wholesale-pricing'); ?></span>
	</td>
</tr>
<tr class="form-field classes-tax-wrap">
	<th> 
		<label for="wwp_tax_classes_wholesaler"> 
			<?php esc_html_e('Tax Class', 'woocommerce-wholesale-pricing'); ?>
		</label>
	</th>
	<td scope="row">
	<select name="wwp_wholesaler_tax_classes" id="wwp_wholesaler_tax_classes" class="">
	<option value=""><?php esc_html_e('Select Tax Class', 'woocommerce-wholesale-pricing'); ?></option>
		<?php 
		$tax_classes = WC_Tax::get_tax_rate_classes();

		if (!empty($tax_classes) ) {
			foreach ( $tax_classes as $tax_class ) {
				$selected ='';
				if ($wwp_wholesaler_tax_classes ==  $tax_class->slug  ) {
					$selected ='selected';
				}
				echo '<option value="' . esc_attr($tax_class->slug) . '" ' . esc_attr($selected) . '>' . esc_attr($tax_class->name) . '</option>';
			}
		}
		?>
		</select>
		<span><?php esc_html_e('Tax class for wholesale user role.', 'woocommerce-wholesale-pricing'); ?></span>
	</td>
</tr>
<tr class="form-field term-coupons-wrap">
	<th>
		<label for="wwp_wholesale_disable_coupons">
			<?php esc_html_e('Disable Coupons', 'woocommerce-wholesale-pricing'); ?>
		</label>
	</th>
	<td scope="row">
		<input type="checkbox" name="wwp_wholesale_disable_coupons" value="yes" <?php checked('yes', $coupons); ?>>
		<span><?php esc_html_e('Disable Coupons for wholesale user role.', 'woocommerce-wholesale-pricing'); ?></span>
	</td>
</tr>
<?php if ( isset( $settings['payment_method_name'], $settings['enable_custom_payment_method'] ) && 'yes' === $settings['enable_custom_payment_method'] && ! empty( $settings['payment_method_name'] ) ) : ?>

<tr class="form-field term-coupons-wrap">
	<th>
		<label for="wwp_wholesale_disable_coupons">
			<?php esc_html_e('Payment Method', 'woocommerce-wholesale-pricing'); ?>
		</label>
	</th>
	<td scope="row">
	<?php 
	foreach ( (array) @$settings['payment_method_name'] as $key => $value) { 
		$checked ='';
		if (array_key_exists($key, (array) $wwp_wholesale_payment_method_name) ) {
			$checked ='checked';
		}
		?>
		<div class="form-field payment_method_role_settings" style="padding:3px;">
			<input type="checkbox" name="wwp_wholesale_payment_method_name[<?php echo esc_attr($key); ?>]" <?php echo esc_attr($checked); ?> value="yes">
			<span><?php esc_html_e($key, 'woocommerce-wholesale-pricing'); ?></span>
		</div>
		<?php 
	} 
	?>
	</td>
</tr>
<?php endif; ?>
<tr class="form-field term-gateways-wrap wwp-role-conditions-row">
	<th><label for="wwp_restricted_pmethods_wholesaler">
		<?php esc_html_e('Disable Payment Methods', 'woocommerce-wholesale-pricing'); ?></label>
	</th>
	<td colspan="2">
		<?php wwp_view( 'admin.user-role.payment-method-conditions', array( 'is_edit' => true, 'term_id' => $term_id ), true ); ?>
	</td>
</tr>
<tr class="form-field wwp-po-gateway-row-wrap">

<th><label for="wwp_restricted_pmethods_wholesaler">
		<?php esc_html_e('Purchase Order Gateway', 'woocommerce-wholesale-pricing'); ?></label>
	</th>
	<td colspan="2">
		<?php wwp_view( 'admin.user-role.purchase-order-gateway', array( 'is_edit' => true, 'term_id' => $term_id ), true ); ?>
	</td>
</tr>

<tr class="form-field term-shipping-wrap">
	<th>
		<label for="wwp_restricted_smethods_wholesaler">
			<?php esc_html_e( 'Disable Shipping Methods', 'woocommerce-wholesale-pricing' ); ?>
		</label>
	</th>
	<td>
		<?php
		// Get saved restricted methods (array of instance IDs)
		$value = (array) get_term_meta( $term_id, 'wwp_restricted_smethods_wholesaler', true );
		$value = array_map( 'strval', array_filter( $value, 'strlen' ) );

		// Get all zones and their shipping methods
		$shipping_zones = WC_Shipping_Zones::get_zones();

		// Add "Rest of the world" zone too
		$shipping_zones[0] = array(
			'zone_name'        => __( 'Rest of the world', 'woocommerce' ),
			'shipping_methods' => WC_Shipping_Zones::get_zone( 0 )->get_shipping_methods(),
		);
		?>

		<select name="wwp_restricted_smethods_wholesaler[]" id="wwp_restricted_smethods_wholesaler" data-placeholder="<?php esc_html_e('Select Shipping Methods', 'woocommerce-wholesale-pricing'); ?>" class="regular-text wc-enhanced-select" multiple>

			<?php
			if ( ! empty( $shipping_zones ) ) {
				foreach ( $shipping_zones as $zone_id => $zone_data ) {
					$zone_name = $zone_data['zone_name'];
					$methods   = $zone_data['shipping_methods'];

					if ( ! empty( $methods ) ) {
						echo '<optgroup label="' . esc_html( $zone_name ) . '">';

						foreach ( $methods as $method ) {
							$instance_id  = $method->instance_id;
							$method_title = $method->get_title();
							$method_label = sprintf( '%s (%s)', $method_title, $method->method_title );

							$selected = in_array( (string) $instance_id, $value, true ) ? 'selected="selected"' : '';

							echo '<option value="' . esc_attr( $instance_id ) . '" ' . $selected . '>' . esc_html( $method_label ) . '</option>'; //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						}

						echo '</optgroup>';
					}
				}
			} else {
				echo '<option disabled>' . esc_html__( 'No shipping methods found.', 'woocommerce-wholesale-pricing' ) . '</option>';
			}
			?>
		</select>

		<p><?php esc_html_e( 'Select shipping methods to restrict for wholesale users.', 'woocommerce-wholesale-pricing' ); ?></p>
	</td>
</tr>

<?php
	$password = get_term_meta($term_id, 'password', true);
?>
<tr class="form-field role_password-wrap">
	<th>
		<label for="role_password">
			<?php esc_html_e('Password', 'woocommerce-wholesale-pricing'); ?>
		</label>
	</th>
	<td>
	<input name="password" id="role_password" type="password" value="<?php echo esc_html_e($password, 'woocommerce-wholesale-pricing'); ?>" size="40" aria-required="true" class="" placeholder="**********">
	<button type="button" id="role_password_btn" class="button wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="Show password">
	<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
	<span class="text"><?php esc_html_e('Show', 'woocommerce-wholesale-pricing'); ?></span>
	</button>
	<button type="button" id="genratepassword" class="button" onclick="generatePassword()">
	<span class="text"><?php esc_html_e('Generate Password', 'woocommerce-wholesale-pricing'); ?></span>
	</button>
	<p class="description"><?php esc_html_e('Password to access wholesale store.', 'woocommerce-wholesale-pricing'); ?></p>
	</td>
</tr>
<?php
$registrations           = WholesaleSettingsHelper::get_registration_settings();
$role_approval_enabled   = isset( $registrations['extra_role_fields'] ) && 'yes' === $registrations['extra_role_fields'];
$role_approval_style     = $role_approval_enabled ? '' : 'opacity:0.6;pointer-events:none;';
$user_request_approval   = get_term_meta( $term_id, 'wwp_user_request_approval', true );
if ( ! in_array( $user_request_approval, array( 'auto', 'manual' ), true ) ) {
	$user_request_approval = 'manual';
}
?>
<tr class="form-field term-user-request-approval-wrap" <?php echo $role_approval_style ? 'style="' . esc_attr( $role_approval_style ) . '"' : ''; ?>>
	<th>
		<label><?php esc_html_e( 'User Request Approval', 'woocommerce-wholesale-pricing' ); ?></label>
	</th>
	<td>
		<p>
			<label>
				<input type="radio" name="wwp_user_request_approval" value="auto" <?php checked( $user_request_approval, 'auto' ); ?> <?php disabled( ! $role_approval_enabled ); ?>>
				<?php esc_html_e( 'Auto', 'woocommerce-wholesale-pricing' ); ?>
			</label>
			<br>
			<label>
				<input type="radio" name="wwp_user_request_approval" value="manual" <?php checked( $user_request_approval, 'manual' ); ?> <?php disabled( ! $role_approval_enabled ); ?>>
				<?php esc_html_e( 'Manual', 'woocommerce-wholesale-pricing' ); ?>
			</label>
		</p>
		<p class="description"><?php esc_html_e( 'Choose whether users are approved automatically or require admin approval.', 'woocommerce-wholesale-pricing' ); ?></p>
		<?php if ( ! $role_approval_enabled ) : ?>
			<p class="description">
				<?php esc_html_e( 'These settings work when Enable User Role is checked in Wholesale → Registration Settings → Other Fields.', 'woocommerce-wholesale-pricing' ); ?>
			</p>
		<?php endif; ?>
	</td>
</tr>
<?php
if (! empty($variable_subscription_id) && 'publish' == get_post_status($variable_subscription_id) ) {
	$product = wc_get_product($variable_subscription_id);
	if (!$product->is_type('simple')) {
		$variations = $product->get_available_variations();
		$variations = wwp_exclude_variations($variations, $selected_variation);
		?>
		<tr class="form-field term-subscription-wrap">
			<th><label for="wwp_wholesaler_subscription"><?php esc_html_e('Select Subscription Variation', 'woocommerce-wholesale-pricing'); ?></label></th>
			<td>
				<select name="wwp_wholesaler_subscription" id="wwp_wholesaler_subscription">
					<option value=""><?php esc_html_e('Select Subscription Variation', 'woocommerce-wholesale-pricing'); ?></option>
					<?php foreach ( $variations as $key => $variation ) { ?> 
						<option value="<?php echo esc_attr($variation['variation_id']); ?>" <?php echo selected($selected_variation, $variation['variation_id'], false); ?>><?php echo esc_attr(implode(',', $variation['attributes'])); ?></option>
					<?php } ?>
				</select>
				<p><?php esc_html_e('On the purchase of the selected variation the users will be assigned this role.', 'woocommerce-wholesale-pricing'); ?></p>
			</td>
		</tr>
		<?php
	}
}
