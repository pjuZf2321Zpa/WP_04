<?php
/**
 * Purchase Order Gateway settings for a wholesale role.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var bool $is_edit Whether this is the edit-term screen.
 * @var int  $term_id Term ID when editing.
 */

if ( ! isset( $is_edit ) ) {
	$term_id = absint( filter_input( INPUT_GET, 'tag_ID', FILTER_SANITIZE_NUMBER_INT ) );
	$is_edit = $term_id > 0;
} else {
	$is_edit = (bool) $is_edit;
	$term_id = isset( $term_id ) ? absint( $term_id ) : 0;
}

$po_enabled         = $is_edit ? (string) get_term_meta( $term_id, 'wwp_po_enabled', true ) : '';
$po_require_number  = $is_edit ? (string) get_term_meta( $term_id, 'wwp_po_require_number', true ) : '';
$po_allow_upload    = $is_edit ? (string) get_term_meta( $term_id, 'wwp_po_allow_upload', true ) : '';
$po_require_upload  = $is_edit ? (string) get_term_meta( $term_id, 'wwp_po_require_upload', true ) : '';
if ( 'yes' !== $po_allow_upload ) {
	$po_require_upload = 'no';
}
$po_file_types      = $is_edit ? get_term_meta( $term_id, 'wwp_po_file_types', true ) : array();
$po_file_types      = is_array( $po_file_types ) ? array_values( array_filter( array_map( 'strval', $po_file_types ) ) ) : array();
$po_max_file_size   = $is_edit ? (string) get_term_meta( $term_id, 'wwp_po_max_file_size', true ) : '5';

if ( empty( $po_file_types ) ) {
	$po_file_types = array( 'pdf', 'jpg', 'png' );
}
if ( '' === $po_max_file_size ) {
	$po_max_file_size = '5';
}

$file_type_options = array( 'pdf', 'jpg', 'jpeg', 'png', 'csv', 'doc', 'docx', 'xls', 'xlsx', 'txt', 'rtf', 'zip' );
?>
<div class="wwp-po-gateway" id="wwp-po-gateway">
	<div class="wwp-po-gateway-header">
		<span class="dashicons dashicons-media-document" aria-hidden="true"></span>
		<strong><?php esc_html_e( 'PURCHASE ORDER GATEWAY', 'woocommerce-wholesale-pricing' ); ?></strong>
	</div>

	<div class="wwp-po-gateway-row">
		<div class="wwp-po-gateway-copy">
			<label for="wwp_po_enabled"><?php esc_html_e( 'Enable purchase order at checkout', 'woocommerce-wholesale-pricing' ); ?></label>
			<p class="description"><?php esc_html_e( 'Adds Purchase order as a payment option for eligible B2B buyers.', 'woocommerce-wholesale-pricing' ); ?></p>
		</div>
		<label class="wwp-po-switch">
			<input type="checkbox" name="wwp_po_enabled" id="wwp_po_enabled" value="yes" <?php checked( 'yes', $po_enabled ); ?>>
			<span class="wwp-po-switch-ui"></span>
		</label>
	</div>

	<div class="wwp-po-gateway-extra" <?php echo 'yes' === $po_enabled ? '' : 'hidden'; ?>>
		<div class="wwp-po-gateway-row">
			<div class="wwp-po-gateway-copy">
				<label for="wwp_po_require_number"><?php esc_html_e( 'Require PO number', 'woocommerce-wholesale-pricing' ); ?></label>
				<p class="description"><?php esc_html_e( 'Buyers must enter a PO number to place the order.', 'woocommerce-wholesale-pricing' ); ?></p>
			</div>
			<label class="wwp-po-switch">
				<input type="checkbox" name="wwp_po_require_number" id="wwp_po_require_number" value="yes" <?php checked( 'yes', $po_require_number ); ?>>
				<span class="wwp-po-switch-ui"></span>
			</label>
		</div>

		<div class="wwp-po-gateway-row">
			<div class="wwp-po-gateway-copy">
				<label for="wwp_po_allow_upload"><?php esc_html_e( 'Allow PO document upload', 'woocommerce-wholesale-pricing' ); ?></label>
				<p class="description"><?php esc_html_e( 'Let buyers attach a scanned purchase order at checkout.', 'woocommerce-wholesale-pricing' ); ?></p>
			</div>
			<label class="wwp-po-switch">
				<input type="checkbox" name="wwp_po_allow_upload" id="wwp_po_allow_upload" value="yes" <?php checked( 'yes', $po_allow_upload ); ?>>
				<span class="wwp-po-switch-ui"></span>
			</label>
		</div>

		<div class="wwp-po-gateway-row wwp-po-require-upload-row<?php echo 'yes' === $po_allow_upload ? '' : ' is-disabled'; ?>">
			<div class="wwp-po-gateway-copy">
				<label for="wwp_po_require_upload"><?php esc_html_e( 'Require document upload', 'woocommerce-wholesale-pricing' ); ?></label>
				<p class="description"><?php esc_html_e( 'Order can\'t be placed without an attached file.', 'woocommerce-wholesale-pricing' ); ?></p>
			</div>
			<label class="wwp-po-switch">
				<input type="checkbox" name="wwp_po_require_upload" id="wwp_po_require_upload" value="yes" <?php checked( 'yes', $po_require_upload ); ?> <?php disabled( 'yes' !== $po_allow_upload ); ?>>
				<span class="wwp-po-switch-ui"></span>
			</label>
		</div>

		<div class="wwp-po-upload-settings" <?php echo 'yes' === $po_allow_upload ? '' : 'hidden'; ?>>
			<div class="wwp-po-gateway-block">
				<label><?php esc_html_e( 'Allowed file types', 'woocommerce-wholesale-pricing' ); ?></label>
				<p class="description"><?php esc_html_e( 'Select the file extensions buyers may attach.', 'woocommerce-wholesale-pricing' ); ?></p>
				<div class="wwp-po-file-types">
					<?php foreach ( $file_type_options as $ext ) : ?>
						<label class="wwp-po-file-type">
							<input type="checkbox" name="wwp_po_file_types[]" value="<?php echo esc_attr( $ext ); ?>" <?php checked( in_array( $ext, $po_file_types, true ) ); ?>>
							<span>.<?php echo esc_html( $ext ); ?></span>
						</label>
					<?php endforeach; ?>
				</div>
			</div>

			<div class="wwp-po-gateway-block">
				<label for="wwp_po_max_file_size"><?php esc_html_e( 'Max file size', 'woocommerce-wholesale-pricing' ); ?></label>
				<p class="wwp-po-max-size">
					<input type="number" name="wwp_po_max_file_size" id="wwp_po_max_file_size" min="1" step="1" value="<?php echo esc_attr( $po_max_file_size ); ?>">
					<span><?php esc_html_e( 'MB per file', 'woocommerce-wholesale-pricing' ); ?></span>
				</p>
			</div>
		</div>
	</div>
</div>
