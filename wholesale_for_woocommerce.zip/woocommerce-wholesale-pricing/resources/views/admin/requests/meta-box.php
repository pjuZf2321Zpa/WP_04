<?php
use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

global $post;
$settings      = WholesaleSettingsHelper::get_pricing_settings();
$request_status        = get_post_meta($post->ID, '_user_status', true);
$user_id       = get_post_meta($post->ID, '_user_id', true);
$rejected_note = get_user_meta($user_id, 'rejected_note', true);
$user_role_set = get_post_meta($post->ID, 'user_role_set', true);
wp_nonce_field('request_user_role_nonce', 'request_user_role_nonce');
?>
<div class="wholesale_user_confirmation">
<?php
if (! empty($user_id) ) {
	$user_info = get_userdata($user_id);
	if ($user_info ) {
		?>
		<div class="user_info">
			<table class="form-table">
				<tbody>
				<?php
				$all_roles = wp_roles();
				$wp_roles_user_info = 'None';
				if (! empty($user_info->roles[0]) ) {
					$wp_roles_user_info = $all_roles->role_names[ $user_info->roles[0] ];
				}

				if (isset($settings['wholesale_role']) && 'single' == $settings['wholesale_role'] ) {

					echo '<tr class=""><td><strong>' . esc_html__('Wholesale roles to be assign: ', 'woocommerce-wholesale-pricing') . '</strong></td><td>' . esc_html('default_wholesaler') . '</td></tr>';

				} else {

					?>
					
					<tr scope="row" class="">
				
						<td><strong><label for="default_multipe_wholesale_roles"><?php esc_html_e('Wholesale roles to be assign:', 'woocommerce-wholesale-pricing'); ?></label></strong></td>
						<td>
							<?php

							$allterms = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));

							$update_role = '';

							foreach ( $allterms as $allterm ) {
								if (isset($user_info->roles[0]) ) {
									if ($allterm->slug == $user_info->roles[0] ) {
										$update_role = 'yes';
									}
								}
							}
							?>
							<select id="default_multipe_wholesale_roles" class="regular-text" name="user_role_set" >
								<option value="" disabled><?php esc_html_e('Select Wholesale Role', 'woocommerce-wholesale-pricing'); ?></option>
								<?php
								foreach ( $allterms as $allterm ) {

									$selected = '';

									if ('yes' == $update_role ) {

										if ($user_info->roles[0] == $allterm->slug ) {
											$selected = 'selected';
										}
									} elseif (isset($settings['default_multipe_wholesale_roles']) && $settings['default_multipe_wholesale_roles'] == $allterm->slug && empty($user_role_set) ) {

										$selected = 'selected';
									} elseif ($user_role_set == $allterm->slug ) {
										$selected = 'selected';
									}
									?>
									<option value="<?php echo esc_attr($allterm->slug); ?>" <?php echo esc_html($selected); ?>><?php echo esc_html($allterm->name); ?></option>
								<?php } ?> 
							</select>        
						</td>
					</tr>
					<?php
				}
				echo '<tr><td><strong>' . esc_html__('User ID: ', 'woocommerce-wholesale-pricing') . '</strong></td><td>' . esc_html($user_info->ID) . '</td></tr>';
				echo '<tr><td><strong>' . esc_html__('User Email: ', 'woocommerce-wholesale-pricing') . '</strong></td><td>' . esc_html($user_info->user_email) . '</td></tr>';
				echo '<tr><td><strong>' . esc_html__('Name: ', 'woocommerce-wholesale-pricing') . '</strong></td><td>' . esc_html($user_info->display_name) . '</td></tr>';
				echo '<tr><td><strong>' . esc_html__('Username: ', 'woocommerce-wholesale-pricing') . '</strong></td><td>' . esc_html($user_info->user_login) . '</td></tr>';
				echo '<tr><td><strong>' . esc_html__('Current user role: ', 'woocommerce-wholesale-pricing') . '</strong></td><td>' . esc_html($wp_roles_user_info) . '</td></tr>';
				echo '<tr><td><a style="font-size:12px" href="' . esc_url(admin_url("user-edit.php?user_id=$user_id")) . '" >' . esc_html__('View Customer details', 'woocommerce-wholesale-pricing') . '</a></td></tr>';
				?>
				</tbody>
			</table>
		</div>
		<?php
	} else {
		echo esc_html__('User does not exist', 'woocommerce-wholesale-pricing');
	}
} else {
	echo esc_html__('User does not exist', 'woocommerce-wholesale-pricing');
}
?>
	<table>
		<tbody>
			<tr>
				<td>
					<strong><?php esc_html_e('Request status', 'woocommerce-wholesale-pricing'); ?></strong>
				</td>
				<td>
					<div class="wwp-request-wrapper">
						<input class="inp-cbx" style="display: none" id="active" type="radio" name="user_status" value="active" <?php echo ( 'active' == $request_status ) ? 'checked' : ''; ?> >
						<label class="cbx" for="active">
							<span>
								<svg width="12px" height="9px" viewbox="0 0 12 9">
									<polyline points="1 5 4 8 11 1"></polyline>
								</svg>
							</span>
							<span><?php esc_html_e('Approve', 'woocommerce-wholesale-pricing'); ?></span>
						</label>

						<input class="inp-cbx" style="display: none" id="rejected" type="radio" name="user_status" value="rejected" <?php echo ( 'rejected' == $request_status ) ? 'checked' : ''; ?> >
						<label class="cbx" for="rejected">
							<span>
								<svg width="12px" height="9px" viewbox="0 0 12 9">
									<polyline points="1 5 4 8 11 1"></polyline>
								</svg>
							</span>
							<span><?php esc_html_e('Reject', 'woocommerce-wholesale-pricing'); ?></span>
						</label>
					</div>
				</td>
			</tr>
		</tbody>
	</table>
</div>
<div id="rejected_note" style="padding-bottom: 11px;padding-top: 11px;">
	<textarea name="rejected_note" class="widefat-100" rows="4" cols="120"  placeholder="Reject Note"><?php echo esc_html_e($rejected_note, 'woocommerce-wholesale-pricing'); ?></textarea>
</div>
<input name="save" type="submit" class="wwp-button-primary" id="requestPublish" value="<?php esc_html_e('Update', 'woocommerce-wholesale-pricing'); ?>">
<style type="">
	.post-type-wwp_requests .page-title-action {
		display: none;
	}
</style>
<?php
