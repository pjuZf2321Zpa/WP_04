<?php
/**
 * Vars
 * 
 * WP_Post $post
 */
$announcements = get_post_meta($post->ID, '_wholesale_group_announcements', true);
$announcement_author = get_option('admin_email');

wp_nonce_field('wwp_announcement', 'wwp_announcement');
?>
<div class="inside">
	<!-- Display current announcements -->
	<div class="announcement-content">
		<?php if (! empty($announcements) && is_array($announcements) ) : ?>
			<?php foreach ( $announcements as $key => $announcement ) : ?>
				<div class="single-announcement" data-key="<?php echo esc_attr($key); ?>">
					<strong><?php echo esc_html($announcement['subject']); ?></strong>
					<p><?php echo esc_html($announcement['content']); ?></p>
					<p class="description">
						<?php echo esc_html(date_i18n(get_option('date_format'), strtotime($announcement['date']))); ?>
						<?php esc_html_e('by', 'woocommerce-wholesale-pricing'); ?> <?php echo esc_html($announcement_author); ?>
						| <a href="#" data-id="<?php echo esc_attr($post->ID); ?>" data-key="<?php echo esc_attr($key); ?>" class="delete-announcement"><?php esc_html_e('Delete Announcement', 'woocommerce-wholesale-pricing'); ?></a>
					</p>
				</div>
				<div class="wwp-remove-dashes"> --------------------------------- </div>
			<?php endforeach; ?>
		<?php else : ?>
			<p><?php esc_html_e('No announcements yet.', 'woocommerce-wholesale-pricing'); ?></p>
		<?php endif; ?>
	</div>

	<!-- Add new announcement -->
	<div class="add-announcement">
		<label for="add_announcement"><?php esc_html_e('Add Announcement', 'woocommerce-wholesale-pricing'); ?></label>
		<textarea name="add_announcement" id="add_announcement" rows="3" style="width:100%;"></textarea>
		<label for="add_announcement_subject"><?php esc_html_e('Add Subject', 'woocommerce-wholesale-pricing'); ?></label>
		<input type="text" name="announcement_subject" id="add_announcement_subject" style="width:100%;" />
		<button style="margin-top:10px;" data-id="<?php echo esc_attr($post->ID); ?>" id="add_announcement_button" class="button"><?php esc_html_e('Add', 'woocommerce-wholesale-pricing'); ?></button>
	</div>
</div>
<?php
