<?php
/**
 * Vars
 * 
 * WP_Post $post
 */
$group_desc = get_post_meta($post->ID, '_wwp_group_description', true); 
?>
<div>
	<?php 
	$content   = $group_desc;
	$editor_id = 'wwp_group_description';
	$settings = array(
		'textarea_rows' => 5, // Set to 5 rows for smaller size
		'media_buttons' => false,
	);
	wp_editor($content, $editor_id, $settings); 
	?>
</div>
