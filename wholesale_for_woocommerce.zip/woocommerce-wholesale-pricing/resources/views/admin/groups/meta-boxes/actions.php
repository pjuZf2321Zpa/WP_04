<?php
/**
 * Vars
 * 
 * WP_Post $post
 */
?>
<div class="action-wrap" style="display: flex; justify-content: space-between; align-items: center;">
	<label for="wholesale_group_status"><?php esc_html_e('Status', 'woocommerce-wholesale-pricing'); ?></label>
	<select class="wc-enhanced-select" name="wholesale_group_status" id="wholesale_group_status">
		<option value="active" <?php selected(get_post_meta($post->ID, '_wholesale_group_status', true), 'active'); ?>><?php esc_html_e('Active', 'woocommerce-wholesale-pricing'); ?></option>
		<option value="inactive" <?php selected(get_post_meta($post->ID, '_wholesale_group_status', true), 'inactive'); ?>><?php esc_html_e('InActive', 'woocommerce-wholesale-pricing'); ?></option>
	</select>
</div>
