<?php
/**
 * Credit limit metabox.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int     $post_id Post ID.
 * @var WP_Post $post    Post object.
 */

$bulk_limit     = get_post_meta( $post_id, 'ccp_bulk_credit_limit', true );
$user_limits    = get_post_meta( $post_id, 'ccp_user_credit_limits', true );
$owner_ids      = get_post_meta( $post_id, 'ccp_company_users_owner', true );
$manager_ids    = get_post_meta( $post_id, 'ccp_company_users_manager', true );
$member_ids     = get_post_meta( $post_id, 'ccp_company_users_member', true );

if ( ! is_array( $user_limits ) ) {
	$user_limits = array();
}

$all_user_ids = array();
foreach ( array( $owner_ids, $manager_ids, $member_ids ) as $ids ) {
	if ( is_array( $ids ) ) {
		$all_user_ids = array_merge( $all_user_ids, array_map( 'absint', $ids ) );
	}
}
$all_user_ids = array_unique( array_filter( $all_user_ids ) );
?>
<div class="wwp-ccp-metabox wwp-ccp-credit-limit">
	<p class="wwp-ccp-field">
		<label for="ccp_bulk_credit_limit"><?php esc_html_e( 'Bulk Credit Limit (applies to all users)', 'woocommerce-wholesale-pricing' ); ?></label>
		<input type="number" step="any" min="0" class="regular-text" id="ccp_bulk_credit_limit" name="ccp_bulk_credit_limit" value="<?php echo esc_attr( $bulk_limit ); ?>">
	</p>
	<p class="wwp-ccp-checkbox-row">
		<label>
			<input type="checkbox" id="ccp_apply_bulk_credit_limit" name="ccp_apply_bulk_credit_limit" value="1">
			<?php esc_html_e( 'Apply credit limit to all users', 'woocommerce-wholesale-pricing' ); ?>
		</label>
	</p>
	<p class="description"><?php esc_html_e( 'Check this box to set every member\'s credit limit and balance to the bulk amount on save. Leave it unchecked to keep existing member limits and remaining balances.', 'woocommerce-wholesale-pricing' ); ?></p>

	<?php if ( ! empty( $all_user_ids ) ) : ?>
		<table class="widefat striped wwp-ccp-user-limits-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'User', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Email', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'User Role', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Company Role', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Credit Limit', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Balance', 'woocommerce-wholesale-pricing' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $all_user_ids as $user_id ) : ?>
					<?php
					$user = get_user_by( 'id', $user_id );
					if ( ! $user ) {
						continue;
					}
					$override    = ccp_get_stored_user_credit_limit( $user_limits, $user_id );
					$has_override = ( null !== $override );
					$limit       = $has_override ? $override : $bulk_limit;
					$balance     = ccp_get_user_wallet_balance( $post_id, $user_id );
					?>
					<tr
						data-user-id="<?php echo esc_attr( $user_id ); ?>"
						data-original-limit="<?php echo esc_attr( $limit ); ?>"
						data-original-balance="<?php echo esc_attr( wc_format_decimal( $balance, 2 ) ); ?>"
					>
						<td><a href="<?php echo esc_url( get_edit_user_link( $user_id ) ); ?>" target="_blank"><?php echo esc_html( $user->display_name ); ?></a></td>
						<td><?php echo esc_html( $user->user_email ); ?></td>
						<td><?php echo isset( $user->roles[0] ) ? esc_html( ucwords( str_replace( '_', ' ', $user->roles[0] ) ) ) : '-'; ?></td>
						<td><?php echo esc_html( ucfirst( str_replace('ccp_', '', get_user_meta( $user_id, 'ccp_company_role', true ) ) ) ); ?></td>
						<td>
							<div class="wwp-ccp-user-limit-control">
								<input
									type="number"
									step="any"
									min="0"
									name="ccp_user_credit_limits[<?php echo esc_attr( $user_id ); ?>]"
									value="<?php echo esc_attr( $limit ); ?>"
									class="small-text wwp-ccp-user-limit-input"
									data-sync-bulk="<?php echo $has_override ? '0' : '1'; ?>"
									disabled
								>
								<button
									type="button"
									class="button-link wwp-ccp-edit-user-limit"
									aria-label="<?php esc_attr_e( 'Edit credit limit', 'woocommerce-wholesale-pricing' ); ?>"
									title="<?php esc_attr_e( 'Edit credit limit', 'woocommerce-wholesale-pricing' ); ?>"
								>
									<span class="dashicons dashicons-edit" aria-hidden="true"></span>
								</button>
							</div>
						</td>
						<td class="wwp-ccp-user-wallet-balance"><?php echo esc_html( wc_format_decimal( $balance, 2 ) ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php else : ?>
		<p class="description"><?php esc_html_e( 'Assign company users to configure individual credit limits.', 'woocommerce-wholesale-pricing' ); ?></p>
	<?php endif; ?>
</div>
