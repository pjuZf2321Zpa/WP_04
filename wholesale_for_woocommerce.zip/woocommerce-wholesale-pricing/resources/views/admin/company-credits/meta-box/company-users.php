<?php
/**
 * Company users metabox.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int     $post_id Post ID.
 * @var WP_Post $post    Post object.
 */

$ccp_company_users_owner   = get_post_meta( $post_id, 'ccp_company_users_owner', true );
$ccp_company_users_manager = get_post_meta( $post_id, 'ccp_company_users_manager', true );
$ccp_company_users_member  = get_post_meta( $post_id, 'ccp_company_users_member', true );
$ccp_company_approved      = get_post_meta( $post_id, 'ccp_company_approved_orders', true );
$ccp_manager_approval      = get_post_meta( $post_id, 'ccp_manager_approval', true );

if ( ! is_array( $ccp_company_users_owner ) ) {
	$ccp_company_users_owner = array();
}
if ( ! is_array( $ccp_company_users_manager ) ) {
	$ccp_company_users_manager = array();
}
if ( ! is_array( $ccp_company_users_member ) ) {
	$ccp_company_users_member = array();
}
?>
<div class="wwp-ccp-metabox wwp-ccp-users">
	<p class="wwp-ccp-field">
		<label for="ccp_company_users_owner"><?php esc_html_e( 'Add Owner', 'woocommerce-wholesale-pricing' ); ?></label>
		<select multiple="multiple" data-placeholder="<?php esc_attr_e( 'Add Owner', 'woocommerce-wholesale-pricing' ); ?>" data-role="customer" class="wc-customer-search-custom wwp-ccp-user-select" id="ccp_company_users_owner" name="ccp_company_users_owner[]" style="width:100%;">
			<?php wwp_ccp_render_user_select_options( $ccp_company_users_owner ); ?>
		</select>
	</p>

	<p class="wwp-ccp-field">
		<label for="ccp_company_users_manager"><?php esc_html_e( 'Add Manager', 'woocommerce-wholesale-pricing' ); ?></label>
		<select multiple="multiple" data-placeholder="<?php esc_attr_e( 'Add Manager', 'woocommerce-wholesale-pricing' ); ?>" data-role="customer" class="wc-customer-search-custom wwp-ccp-user-select" id="ccp_company_users_manager" name="ccp_company_users_manager[]" style="width:100%;">
			<?php wwp_ccp_render_user_select_options( $ccp_company_users_manager ); ?>
		</select>
	</p>

	<p class="wwp-ccp-field">
		<label for="ccp_company_users_member"><?php esc_html_e( 'Add Members', 'woocommerce-wholesale-pricing' ); ?></label>
		<select multiple="multiple" data-placeholder="<?php esc_attr_e( 'Add Members', 'woocommerce-wholesale-pricing' ); ?>" data-role="customer" class="wc-customer-search-custom wwp-ccp-user-select" id="ccp_company_users_member" name="ccp_company_users_member[]" style="width:100%;">
			<?php wwp_ccp_render_user_select_options( $ccp_company_users_member ); ?>
		</select>
	</p>

	<hr>

	<p class="wwp-ccp-checkbox-row">
		<label>
			<input type="checkbox" id="ccp_company_approved_orders" name="ccp_company_approved_orders" value="yes" <?php checked( 'yes', $ccp_company_approved ); ?>>
			<?php esc_html_e( 'Company Approved Orders', 'woocommerce-wholesale-pricing' ); ?>
		</label>
	</p>
	<p class="wwp-ccp-company-approved-desc description" style=" margin-left: 25px;margin-top: -12px;"><?php esc_html_e( 'Orders paid with Company Credit require approval from an Owner or Manager before being created.', 'woocommerce-wholesale-pricing' ); ?></p>

	<div id="ccp_manager_approval_wrap" class="wwp-ccp-manager-approval-wrap"<?php echo 'yes' !== $ccp_company_approved ? ' hidden' : ''; ?>>
		<p class="wwp-ccp-checkbox-row wwp-ccp-checkbox-row--indent">
			<label>
				<input type="checkbox" name="ccp_manager_approval" value="yes" <?php checked( 'yes', $ccp_manager_approval ); ?>>
				<?php esc_html_e( 'Manager Approval', 'woocommerce-wholesale-pricing' ); ?>
			</label>
		</p>
		<p class="description" style="margin-left: 45px;margin-top: -12px;"><?php esc_html_e( 'Allows managers to approve orders. Orders paid with Company Credit can be approved by managers before being created.', 'woocommerce-wholesale-pricing' ); ?></p>
	</div>
</div>
