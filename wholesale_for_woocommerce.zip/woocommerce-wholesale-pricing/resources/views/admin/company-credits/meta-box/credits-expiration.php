<?php
/**
 * Credits expiration metabox.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int     $post_id Post ID.
 * @var WP_Post $post    Post object.
 */

$enabled  = get_post_meta( $post_id, 'ccp_credit_expiration_enabled', true );
$enabled  = ( 'yes' === $enabled ) ? 'yes' : 'no';
$recurring_mode      = get_post_meta( $post_id, 'ccp_credit_expiration_mode', true );
$recurring_mode      = in_array( $recurring_mode, array( 'monthly', 'yearly' ), true ) ? $recurring_mode : 'monthly';
$month     = absint( get_post_meta( $post_id, 'ccp_credit_expiration_month', true ) );
$month     = $month >= 1 && $month <= 12 ? $month : 1;
$day       = absint( get_post_meta( $post_id, 'ccp_credit_expiration_day', true ) );
$day       = $day >= 1 && $day <= 31 ? $day : 1;
$start_bal = get_post_meta( $post_id, 'ccp_credit_expiration_starting_balance', true );
$start_bal = is_numeric( $start_bal ) ? (float) $start_bal : 0.0;
$last_run  = get_post_meta( $post_id, 'ccp_credit_expiration_last_run', true );
?>

<div class="wwp-ccp-metabox wwp-ccp-credit-expiration">
	<p class="wwp-ccp-checkbox-row">
		<label>
			<input
				type="checkbox"
				id="ccp_credit_expiration_enabled"
				name="ccp_credit_expiration_enabled"
				value="yes"
				<?php checked( 'yes', $enabled ); ?>
			>
			<?php esc_html_e( 'Enable Credits Expiration', 'woocommerce-wholesale-pricing' ); ?>
		</label>
	</p>

	<div class="wwp-ccp-credit-expiration__fields"<?php echo 'yes' === $enabled ? '' : ' hidden'; ?>>
		<p class="wwp-ccp-field">
			<label for="ccp_credit_expiration_mode"><?php esc_html_e( 'Recurrence', 'woocommerce-wholesale-pricing' ); ?></label>
			<select id="ccp_credit_expiration_mode" name="ccp_credit_expiration_mode">
				<option value="monthly" <?php selected( 'monthly', $recurring_mode ); ?>><?php esc_html_e( 'Monthly', 'woocommerce-wholesale-pricing' ); ?></option>
				<option value="yearly" <?php selected( 'yearly', $recurring_mode ); ?>><?php esc_html_e( 'Yearly', 'woocommerce-wholesale-pricing' ); ?></option>
			</select>
		</p>

		<div id="ccp_credit_expiration_month_wrap" class="wwp-ccp-credit-expiration-month-wrap"<?php echo 'yearly' === $recurring_mode ? '' : ' hidden'; ?>>
			<p class="wwp-ccp-field">
				<label for="ccp_credit_expiration_month"><?php esc_html_e( 'Month', 'woocommerce-wholesale-pricing' ); ?></label>
				<select id="ccp_credit_expiration_month" name="ccp_credit_expiration_month">
					<?php for ( $loop = 1; $loop <= 12; $loop++ ) : ?>
						<?php
						$month_name = date_i18n( 'F', mktime( 0, 0, 0, $loop, 1, gmdate( 'Y' ) ) );
						?>
						<option value="<?php echo esc_attr( $loop ); ?>" <?php selected( $loop, $month ); ?>><?php echo esc_html( $month_name ); ?></option>
					<?php endfor; ?>
				</select>
			</p>
		</div>

		<p class="wwp-ccp-field">
			<label for="ccp_credit_expiration_day"><?php esc_html_e( 'Day of month', 'woocommerce-wholesale-pricing' ); ?></label>
			<select id="ccp_credit_expiration_day" name="ccp_credit_expiration_day">
				<?php for ( $d = 1; $d <= 31; $d++ ) : ?>
					<option value="<?php echo esc_attr( $d ); ?>" <?php selected( $d, $day ); ?>><?php echo esc_html( (string) $d ); ?></option>
				<?php endfor; ?>
			</select>
		</p>

		<p class="wwp-ccp-field">
			<label for="ccp_credit_expiration_starting_balance"><?php esc_html_e( 'Starting balance per member after expiration', 'woocommerce-wholesale-pricing' ); ?></label>
			<input
				type="number"
				step="any"
				min="0"
				id="ccp_credit_expiration_starting_balance"
				name="ccp_credit_expiration_starting_balance"
				value="<?php echo esc_attr( $start_bal ); ?>"
			>
		</p>

		<p class="description">
			<?php esc_html_e( 'When the expiration date is reached, credits are reseeded for assigned users (owner/manager/member). Credit logs are preserved for audit. If the selected day does not exist in a month, it runs on the last day of that month.', 'woocommerce-wholesale-pricing' ); ?>
		</p>

		<?php if ( ! empty( $last_run ) ) : ?>
			<p class="description">
				<?php esc_html_e( 'Last run:', 'woocommerce-wholesale-pricing' ); ?>
				<?php echo esc_html( $last_run ); ?>
			</p>
		<?php endif; ?>
	</div>
</div>

