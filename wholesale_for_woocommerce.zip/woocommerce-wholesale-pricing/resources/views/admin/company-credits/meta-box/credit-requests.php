<?php
/**
 * Credit requests metabox — owner → admin queue.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int     $post_id Post ID.
 * @var WP_Post $post    Post object.
 */

$all_requests = ccp_get_credit_requests( $post_id );
$requests     = ccp_filter_credit_requests( $all_requests, 'admin' );

$pending_count = 0;
foreach ( $requests as $request ) {
	if ( isset( $request['status'] ) && 'pending' === $request['status'] ) {
		$pending_count++;
	}
}
?>
<div class="wwp-ccp-metabox wwp-ccp-credit-requests" data-company-id="<?php echo esc_attr( $post_id ); ?>">
	<div class="wwp-ccp-credit-requests__header">
		<p class="description"><?php esc_html_e( 'Credit requests from company owners. Approving adds credits to the company pool.', 'woocommerce-wholesale-pricing' ); ?></p>
		<?php if ( $pending_count > 0 ) : ?>
			<span class="wwp-ccp-badge wwp-ccp-badge--pending">
				<?php
				printf(
					/* translators: %d: number of pending requests */
					esc_html( _n( '%d pending', '%d pending', $pending_count, 'woocommerce-wholesale-pricing' ) ),
					(int) $pending_count
				);
				?>
			</span>
		<?php endif; ?>
	</div>

	<?php if ( ! empty( $requests ) ) : ?>
		<table class="widefat striped wwp-ccp-requests-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'User', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Current Wallet', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Requested', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Reason', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Status', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Requested On', 'woocommerce-wholesale-pricing' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $requests as $index => $request ) : ?>
					<?php
					$request_status      = isset( $request['status'] ) ? $request['status'] : 'pending';
					$badge_class = 'pending' === $request_status ? 'wwp-ccp-badge--pending' : ( 'approved' === $request_status ? 'wwp-ccp-badge--approved' : 'wwp-ccp-badge--declined' );
					?>
					<tr data-request-index="<?php echo esc_attr( $index ); ?>">
						<td>
							<strong><?php echo esc_html( isset( $request['name'] ) ? $request['name'] : '' ); ?></strong><br>
							<small><?php echo esc_html( isset( $request['email'] ) ? $request['email'] : '' ); ?></small>
						</td>
						<td><?php echo esc_html( isset( $request['current_limit'] ) ? $request['current_limit'] : '' ); ?></td>
						<td><?php echo esc_html( isset( $request['requested_limit'] ) ? $request['requested_limit'] : '' ); ?></td>
						<td><?php echo esc_html( isset( $request['reason'] ) ? $request['reason'] : '' ); ?></td>
						<td class="wwp-ccp-request-status-cell">
							<span class="wwp-ccp-badge <?php echo esc_attr( $badge_class ); ?>"><?php echo esc_html( ucfirst( $request_status ) ); ?></span>
						</td>
						<td class="wwp-ccp-request-actions-cell">
							<?php if ( 'pending' === $request_status ) : ?>
								<div class="wwp-ccp-row-actions">
									<button type="button" class="button button-small button-primary wwp-ccp-request-approve" data-index="<?php echo esc_attr( $index ); ?>" title="<?php esc_attr_e( 'Approve', 'woocommerce-wholesale-pricing' ); ?>">
										<?php esc_html_e( 'Approve', 'woocommerce-wholesale-pricing' ); ?>
									</button>
									<button type="button" class="button button-small wwp-ccp-request-decline" data-index="<?php echo esc_attr( $index ); ?>" title="<?php esc_attr_e( 'Deny', 'woocommerce-wholesale-pricing' ); ?>">
										<?php esc_html_e( 'Deny', 'woocommerce-wholesale-pricing' ); ?>
									</button>
								</div>
							<?php else : ?>
								—
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( isset( $request['requested_on'] ) ? $request['requested_on'] : '' ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php else : ?>
		<p><?php esc_html_e( 'No owner credit requests yet.', 'woocommerce-wholesale-pricing' ); ?></p>
	<?php endif; ?>
</div>
