<?php
/**
 * Company credit option metabox.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int     $post_id Post ID.
 * @var WP_Post $post    Post object.
 */

wp_nonce_field( 'global_notice_nonce', 'global_notice_nonce' );

$give_credit_to_company   = get_post_meta( $post_id, 'give_credit_to_company', true );
$recently_assigned_credit = recently_assigned_credit( $post_id );
$consumed                 = ccp_company_credits( $post_id );
$logs_url                 = admin_url( 'edit.php?post_type=ccp_credit_logs&company_id=' . $post_id );
?>
<div class="wwp-ccp-metabox wwp-ccp-credit-option">
	<p class="wwp-ccp-checkbox-row">
		<label>
			<input type="checkbox" value="yes" name="give_credit_to_company" id="give_credit_to_company">
			<?php esc_html_e( 'Give Credit to Company', 'woocommerce-wholesale-pricing' ); ?>
		</label>
	</p>

	<p class="wwp-ccp-credit-add-row<?php echo 'yes' === $give_credit_to_company ? ' is-visible' : ''; ?>">
		<input type="number" step="any" placeholder="<?php esc_attr_e( 'Enter credit amount', 'woocommerce-wholesale-pricing' ); ?>" name="ccp_credit_assign" class="ccp_credit_assign regular-text" value="">
		<button type="submit" name="save" id="ccp_add_credit" class="button button-primary"><?php esc_html_e( 'Add', 'woocommerce-wholesale-pricing' ); ?></button>
	</p>

	<div class="wwp-ccp-credit-stats">
		<div class="wwp-ccp-credit-stat">
			<span class="wwp-ccp-credit-stat__label"><?php esc_html_e( 'Recently Assigned', 'woocommerce-wholesale-pricing' ); ?></span>
			<span class="wwp-ccp-credit-stat__value wwp-ccp-credit-stat__value--assigned"><?php echo esc_html( $recently_assigned_credit ); ?></span>
		</div>
		<div class="wwp-ccp-credit-stat">
			<span class="wwp-ccp-credit-stat__label"><?php esc_html_e( 'Consumed', 'woocommerce-wholesale-pricing' ); ?></span>
			<span class="wwp-ccp-credit-stat__value wwp-ccp-credit-stat__value--consumed"><?php echo esc_html( abs( $consumed['consumed'] ) ); ?></span>
		</div>
		<div class="wwp-ccp-credit-stat">
			<span class="wwp-ccp-credit-stat__label"><?php esc_html_e( 'Available', 'woocommerce-wholesale-pricing' ); ?></span>
			<span class="wwp-ccp-credit-stat__value wwp-ccp-credit-stat__value--available"><?php echo esc_html( $consumed['remaining'] ); ?></span>
		</div>
		<div class="wwp-ccp-credit-stat">
			<span class="wwp-ccp-credit-stat__label"><?php esc_html_e( 'Total', 'woocommerce-wholesale-pricing' ); ?></span>
			<span class="wwp-ccp-credit-stat__value wwp-ccp-credit-stat__value--total"><?php echo esc_html( $consumed['credit'] ); ?></span>
		</div>
	</div>

	<p class="wwp-ccp-credit-logs-row">
		<a href="<?php echo esc_url( $logs_url ); ?>" target="_blank" class="button"><?php esc_html_e( 'View Logs', 'woocommerce-wholesale-pricing' ); ?></a>
	</p>
</div>
