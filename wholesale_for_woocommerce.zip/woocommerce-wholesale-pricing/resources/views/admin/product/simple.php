<?php
/**
 * Template vars
 * 
 * @var array $roles
 * @var array $data
 * @var string $wholesale_type
 * @var double $wholesale_price
 * @var array $settings
 * @var array $product_tier_pricing
 */
?>
<div id="accordion">
	<?php
	foreach ($roles as $key => $term_role) :
		$min      = 1;
		$price    = $wholesale_price;
		$discount = $wholesale_type;
		$step     = 1;
		
		if (isset($data[$term_role->term_id])) {
			$min      = isset($data[$term_role->term_id]['min_quatity']) ? $data[$term_role->term_id]['min_quatity'] : 1;
			$price    = isset($data[$term_role->term_id]['wholesale_price']) ? $data[$term_role->term_id]['wholesale_price'] : $wholesale_price;
			$discount = isset($data[$term_role->term_id]['discount_type']) ? $data[$term_role->term_id]['discount_type'] : $wholesale_type;
			$step     = isset($data[$term_role->term_id]['step_quantity']) ? $data[$term_role->term_id]['step_quantity'] : 1;
		}

		if (isset($settings['wholesale_role']) && 'single' == $settings['wholesale_role'] && 'default_wholesaler' != $term_role->slug) {
			continue;
		}
		?>
		<div class="card">
			<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_<?php esc_attr_e($term_role->term_id); ?>" aria-expanded="false" aria-controls="collapse_<?php esc_attr_e($term_role->term_id); ?>">
				<?php esc_html_e($term_role->name); ?>
				<div class="wwp_signal">
					<?php
					$wwp_on_active  = '';
					$wwp_off_active = '';
					if (isset($data[$term_role->term_id]) && ! empty($data[$term_role->term_id])) {
						$wwp_on_active = 'active';
					} else {
						$wwp_off_active = 'active';
					}

					?>
					<div class="wwp_circle wwp_circle_off <?php echo esc_attr(@$wwp_off_active); ?> ">&nbsp;</div>
					<div class="wwp_circle wwp_circle_on <?php echo esc_attr(@$wwp_on_active); ?> ">&nbsp;</div>
				</div>
			</button>
			<div id="collapse_<?php esc_attr_e($term_role->term_id); ?>" class="collapse" aria-labelledby="heading_<?php esc_attr_e($term_role->term_id); ?>" data-parent="#accordion" style="">
				<div class="card-body">
					<table class="form-table wwp-main-settings">
						<tbody>
							<tr scope="row">
								<th>
									<label for=""><?php esc_html_e('Role Activation', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td>
									<input class="inp-cbx  wwp-checbox" style="display: none" id="role_<?php esc_attr_e($term_role->term_id); ?>" type="checkbox" value="<?php esc_attr_e($term_role->slug); ?>" name="role_<?php esc_attr_e($term_role->term_id); ?>" <?php echo isset($data[$term_role->term_id]) ? 'checked' : ''; ?>>
									<label class="cbx cbx-square" for="role_<?php esc_attr_e($term_role->term_id); ?>">
										<span>
											<svg width="12px" height="9px" viewbox="0 0 12 9">
												<polyline points="1 5 4 8 11 1"></polyline>
											</svg>
										</span>
										<span><?php esc_html_e('Enable Role', 'woocommerce-wholesale-pricing'); ?></span>
									</label>
								</td>
							</tr>

							<tr scope="row">
								<th>
									<label for=""><?php esc_html_e('Discount Type', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td>
									<select class="widefat" name="discount_type_<?php esc_attr_e($term_role->term_id); ?>" value="<?php esc_attr_e($wholesale_type); ?>">
										<option value="percent" <?php selected($discount, 'percent'); ?>> <?php esc_html_e('Percent', 'woocommerce-wholesale-pricing'); ?> </option>
										<option value="fixed" <?php selected($discount, 'fixed'); ?>> <?php esc_html_e('Fixed', 'woocommerce-wholesale-pricing'); ?> </option>
									</select>
									<span data-tip="Price type for wholesale products" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
								</td>
							</tr>

							<tr scope="row">
								<th>
									<label for=""><?php esc_html_e('Wholesale Price', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td>
									<input class="widefat wwp-price " type="text" name="wholesale_price_<?php esc_attr_e($term_role->term_id); ?>" value="<?php esc_attr_e( wwp_format_price_for_input( $price ) ); ?>">
									<span data-tip="Enter the value you would like to change the Wholesale User" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
								</td>
							</tr>

							<tr scope="row">
								<th>
									<label for=""><?php esc_html_e('Min Quantity', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td>
									<input class="widefat" type="number" name="min_quatity_<?php esc_attr_e($term_role->term_id); ?>" min="1" value="<?php esc_attr_e($min); ?>">
									<span data-tip="Enter Wholesale minimum quantity to apply discount" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
								</td>
							</tr>
							<tr scope="row">
								<th>
									<label for=""><?php esc_html_e('Step Quantity', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td>
									<input class="widefat" type="text" name="step_quantity_<?php esc_attr_e($term_role->term_id); ?>" min="1" value="<?php esc_attr_e($step); ?>">
									<span data-tip="Enter Wholesale step quantity" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
								</td>
							</tr>
							<tr scope="row">
								<th>
									<label for=""><?php esc_html_e('Product Tier Pricing', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td>
									<button data-toggle="modal" data-target="#product_tier_pricing<?php esc_attr_e($term_role->term_id); ?>" class="wwp-button-primary" type="button"><?php esc_html_e('Add Tier Pricing', 'woocommerce-wholesale-pricing'); ?></button>
									<span class="wwwp_help_text"><?php esc_html_e('Product Tier Pricing', 'woocommerce-wholesale-pricing'); ?></span>
									<?php
									$name = 'product_tier_pricing[tier_pricing]';
									echo wp_kses_post('<div>' . tier_pricing_modal_popup('Product Tier Pricing', 'product_tier_pricing' . $term_role->term_id, $term_role->term_id, $product_tier_pricing, $name, $product_id) . '</div>');
									?>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	<?php endforeach; ?>
</div>
