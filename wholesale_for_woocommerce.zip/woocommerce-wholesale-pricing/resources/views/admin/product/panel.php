<?php
/**
 * Vars
 * 
 * WP_Post $post
 */
use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;
$product_id = $post->ID;
$roles      = array();
$taxroles   = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
if (! empty($taxroles) ) {
	foreach ( $taxroles as $key => $term_role ) {
		$roles[ $term_role->slug ] = $term_role->name;
	}
}
?>
<div id="wwp_wholesale_product_data" class="panel woocommerce_options_panel">
<?php
wp_nonce_field('wwp_product_wholesale_nonce', 'wwp_product_wholesale_nonce');
$wwp_icon_url  = get_post_meta($product_id, 'wwp_icon_url', true);
$wwp_image_url = get_post_meta($product_id, 'wwp_image_url', true);
woocommerce_wp_checkbox(
	array(
		'id'            => '_wwp_hide_for_customer',
		'wrapper_class' => '_wwp_hide_for_customer',
		'label'         => esc_html__('Hide Product For Customer Role', 'woocommerce-wholesale-pricing'),
		'description'   => esc_html__('Hide this product from users having customer role', 'woocommerce-wholesale-pricing'),
	)
);

woocommerce_wp_checkbox(
	array(
		'id'            => '_wwp_hide_for_visitor',
		'wrapper_class' => '_wwp_hide_for_visitor',
		'label'         => esc_html__('Hide Product For Guest Users', 'woocommerce-wholesale-pricing'),
		'description'   => esc_html__('Hide this product from visitors', 'woocommerce-wholesale-pricing'),
	)
);

$value = get_post_meta($product_id, 'wholesale_product_visibility_multi', true);
woocommerce_wp_select(
	array(
		'id'                => 'wholesale_product_visibility_multi[]',
		'label'             => esc_html__('Hide Product for Wholesaler Roles', 'woocommerce-wholesale-pricing'),
		'type'              => 'select',
		'class'             => 'wc-enhanced-select',
		'style'             => 'min-width: 50%;',
		'desc_tip'          => 'true',
		'description'       => esc_html__('Choose specific user roles to hide the product.', 'woocommerce-wholesale-pricing'),
		'options'           => $roles,
		'value'             => $value,
		'custom_attributes' => array(
			'multiple' => 'multiple',
		),
	)
); // ends version 1.3.0

$settings = WholesaleSettingsHelper::get_pricing_settings();
if (isset($settings['variation_table_enable']) && 'yes' == $settings['variation_table_enable']) {
	$product = wc_get_product($product_id);
	if ($product->get_type() == 'variable' ) {
		
		woocommerce_wp_checkbox(
			array(
				'id'            => 'wwp_variation_explode_eneble',
				'wrapper_class' => 'wwp_variation_explode_eneble',
				'label'         => esc_html__('Enable', 'woocommerce-wholesale-pricing'),
				'description'   => esc_html__('Enable Attributes Quantity', 'woocommerce-wholesale-pricing'),
			)
		);
		
		$available_attributes = $product->get_attributes();
		$formatted_attributes = array();
		$attributes           = $product->get_attributes();
		foreach ($attributes as $attr => $attr_deets) {
			$attribute_label = wc_attribute_label($attr);
			if (isset($attributes[ $attr ]) || isset($attributes[ 'pa_' . $attr ]) ) {
				$attribute = isset($attributes[ $attr ]) ? $attributes[ $attr ] : $attributes[ 'pa_' . $attr ];
				if ($attribute['is_taxonomy'] ) {
					$formatted_attributes[$attr] = $attribute_label;
				} else {
					$attribute_name                                = $attr_deets->get_data();
					$formatted_attributes[$attribute_name['name']] = $attribute_name['name'];
				}
			}
		}
		
		woocommerce_wp_select(
			array(
				'id'                => 'wwp_variation_attribute_with_qty',
				'label'             => esc_html__('Select Primray Attribute', 'woocommerce-wholesale-pricing'),
				'type'              => 'select',
				'class'             => 'wc-enhanced-select',
				'style'             => 'min-width: 50%;',
				'desc_tip'          => 'true',
				'description'       => esc_html__('Select the attribute to dispaly along side the quantity counter', 'woocommerce-wholesale-pricing'),
				'options'           => $formatted_attributes,
				'value'             => get_post_meta($product_id, 'wwp_variation_attribute_with_qty', true),
			)
		);
	}
}

if (isset($settings['request_for_sample_enable']) && 'yes' == $settings['request_for_sample_enable']) {
	$product = wc_get_product($product_id);
	woocommerce_wp_checkbox(
		array(
			'id'            => 'request_for_sample_enable',
			'wrapper_class' => 'request_for_sample_enable',
			'label'         => esc_html__('Sample Product', 'woocommerce-wholesale-pricing'),
			'description'   => esc_html__('Enable sample for this product', 'woocommerce-wholesale-pricing'),
		)
	);
	
	$sample_product_id        = get_post_meta($product_id, 'sample_product_id', true);
	$sample_product_id_hidden = get_post_meta($product_id, 'sample_product_id_hidden', true);
	
	
	if (! empty($sample_product_id) ) {
		$register_redirect_title = get_the_title($sample_product_id_hidden) . ' - (' . $sample_product_id_hidden . ')';
	} else {
		$register_redirect_title  = '';
		$sample_product_id_hidden = '';
	}

	$value = get_post_meta($product_id, 'sample_product_id', true);
	woocommerce_wp_text_input(
		array(
			'id'            => 'sample_product_id',
			'value'         => $register_redirect_title,
			'label'         => __('Select Sample Product', 'woocommerce-wholesale-pricing'),
			'desc_tip'      => 'true',
			'description'   => esc_html__('Select sample for this product', 'woocommerce-wholesale-pricing'),
			'wrapper_class' => 'sample_product_id',
		)
	);

	woocommerce_wp_hidden_input(
		array(
			'id'    => 'sample_product_id_hidden', 
			'value' => $sample_product_id_hidden,
		)
	);
}

?>
	<div id="wwp_wholesale_product_data" class="panel woocommerce_options_panel">
		<div id="variable_product_options" class=" wc-metaboxes-wrapper" style="display: block;">
			<div id="variable_product_options_inner">
				<div id="message" class="inline notice woocommerce-message">
					<p><?php printf('%1$s <strong>%2$s</strong> %3$s', esc_html__('For', 'woocommerce-wholesale-pricing'), esc_html__('Multi-user wholesale roles', 'woocommerce-wholesale-pricing'), esc_html__('manage price from wholesale metabox', 'woocommerce-wholesale-pricing')); ?></p>
					<p><a class="button-primary" id="wholesale-pricing-pro-multiuser-move"><?php esc_html_e('Move', 'woocommerce-wholesale-pricing'); ?></a></p>
				</div>
			</div>
		</div>
	</div>
<h2 class=""><b><?php esc_html_e('Select Attachment File', 'woocommerce-wholesale-pricing'); ?></b></h2>    
<p class="form-field">
<label for="wwp_icon_url"><?php esc_html_e('Upload Icon', 'woocommerce-wholesale-pricing'); ?></label>
<input type="text" name="wwp_icon_url" id="wwp_icon_url" value="<?php echo esc_attr($wwp_icon_url); ?>" class="short regular-text">
<span class="wwp_media_selection">
	<input type="button" name="www_upload_icon" id="www_upload_icon" class="button-secondary" value="<?php esc_html_e('Upload', 'woocommerce-wholesale-pricing'); ?>">
	<input type="button" id="www_remove_icon" class="button-secondary" value="Remove">
</span>
</p>
<p class="form-field">
<label for="wwp_image_url"><?php esc_html_e('Upload Attachment', 'woocommerce-wholesale-pricing'); ?></label>
<input type="text" name="wwp_image_url" id="wwp_image_url" value="<?php echo esc_attr($wwp_image_url); ?>"  class="short regular-text">
<span class="wwp_media_selection">
	<input type="button" name="www_upload_attachment" id="www_upload_attachment" class="button-secondary" value="<?php esc_html_e('Upload', 'woocommerce-wholesale-pricing'); ?>">
	<input type="button" id="www_remove_attachment" class="button-secondary" value="Remove">
</span>
</p>
<?php 
	woocommerce_wp_text_input(
		array(
			'id' => 'wwp_attachment_title',
			'placeholder' => __('Set Custom Title', 'woocommerce-wholesale-pricing'),
			'label' => __('Set Custom Title', 'woocommerce-wholesale-pricing'),
			'type' => 'text',
			'custom_attributes' => array(
				'step' => 'any',
				'min' => '0',
			),
		)
	);
	woocommerce_wp_text_input(
		array(
			'id' => 'wwp_attachment_text_link',
			'placeholder' => __('Text For Download Link', 'woocommerce-wholesale-pricing'),
			'label' => __('Text For Download Link', 'woocommerce-wholesale-pricing'),
			'type' => 'text',
			'custom_attributes' => array(
				'step' => 'any',
				'min' => '0',
			),
		)
	); 
	?>
<h2 class=""><b><?php esc_html_e('Current Attachment', 'woocommerce-wholesale-pricing'); ?> = <a onclick="wwp_open_attachment()" url="<?php echo esc_attr($wwp_image_url); ?>" class="wwp_download_link" target="_blank" ><?php esc_html_e('Download Here', 'woocommerce-wholesale-pricing'); ?></a></b></h2>        
</br></br>
<script type="text/javascript">
function wwp_open_attachment () {
	url = jQuery('.wwp_download_link').attr('url');
	
	if (url != '' && url  != undefined) {
		window.open(url);
	}
	return false;
	
	}
	jQuery(document).ready(function($) {
		$('#www_upload_icon').click(function(e) {
		e.preventDefault();
		var image = wp.media({ 
			title: 'Upload Icon',
			multiple: false
		}).open().on('select', function(e) {
			var uploaded_image = image.state().get('selection').first();
			var image_url = uploaded_image.toJSON().url;
			$('#wwp_icon_url').val(image_url);
		});
	});

	$('#www_upload_attachment').click(function(e) {
		e.preventDefault();
		var image = wp.media({ 
			title: 'Upload Attachment',
			multiple: false
		}).open().on('select', function(e) {
			var uploaded_image = image.state().get('selection').first();
			var image_url = uploaded_image.toJSON().url;
			$('#wwp_image_url').val(image_url);
			$('wwp_download_link').val(image_url);
			$('.wwp_download_link').attr( 'url', image_url );
			console.log(uploaded_image);
		});
	});

	$('#www_remove_attachment').click(function(e) {
		$('#wwp_image_url').val('');
		$('.wwp_download_link').attr( 'url', '' );
	});
	$('#www_remove_icon').click(function(e) {
		$('#wwp_icon_url').val('');
	});    
	$('#wwp_image_url').on('input',function(e){
		if ( this.value  ) {
			$('.wwp_download_link').attr( 'url', this.value );
		} else {
			$('.wwp_download_link').attr( 'url', '' );
		}
	});
});
</script>
</div>
