<?php
/**
 * Template vars
 * 
 * @var array $roles
 * @var array $data
 * @var array $settings
 * @var string $wholesale_type
 * @var array $variables
 * @var int $product_id
 * @var array $product_tier_pricing
 */
?>
<div id="accordion">
<?php
foreach ( $roles as $key => $term_role ) {
	$discount = '';
	
	if (isset($data[ $term_role->term_id ]['discount_type']) ) {
		$discount = $data[ $term_role->term_id ]['discount_type'];
	}
	if (isset($settings['wholesale_role']) && 'single' == $settings['wholesale_role'] && 'default_wholesaler' != $term_role->slug ) {
		continue;
	}
	?>
	<div class="card">
		<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_<?php esc_attr_e($term_role->term_id); ?>" aria-expanded="false" aria-controls="collapse_<?php esc_attr_e($term_role->term_id); ?>">
			<?php esc_html_e($term_role->name); ?>
			<div class="wwp_signal">
				<?php
				$wwp_on_active  = '';
				$wwp_off_active = '';
				if (isset($data[ $term_role->term_id ]) && ! empty($data[ $term_role->term_id ]) ) {
					$wwp_on_active = 'active';
				} else {
					$wwp_off_active = 'active';
				}

				?>
				<div class="wwp_circle wwp_circle_off <?php echo esc_attr(@$wwp_off_active); ?> ">&nbsp;</div>
				<div class="wwp_circle wwp_circle_on <?php echo esc_attr(@$wwp_on_active); ?> ">&nbsp;</div>                                        
			</div>
		</button>
		<div id="collapse_<?php esc_attr_e($term_role->term_id); ?>" class="collapse" aria-labelledby="heading_<?php esc_attr_e($term_role->term_id); ?>" data-parent="#accordion" style="">
			<div class="card-body">
				<table class="form-table wwp-main-settings">
					<tbody>
						<tr scope="row">
							<th>
								<label for=""><?php esc_html_e('Role Activation', 'woocommerce-wholesale-pricing'); ?></label>
							</th>
							<td>
								<input class="inp-cbx" style="display: none" id="role_<?php esc_attr_e($term_role->term_id); ?>" type="checkbox" value="<?php esc_attr_e($term_role->slug); ?>" name="role_<?php esc_attr_e($term_role->term_id); ?>" <?php echo isset($data[ $term_role->term_id ]) ? 'checked' : ''; ?> >
								<label class="cbx cbx-square" for="role_<?php esc_attr_e($term_role->term_id); ?>">
									<span>
										<svg width="12px" height="9px" viewbox="0 0 12 9">
											<polyline points="1 5 4 8 11 1"></polyline>
										</svg>
									</span>
									<span><?php esc_html_e('Enable Role', 'woocommerce-wholesale-pricing'); ?></span>
								</label>
							</td>
						</tr>

						<tr scope="row">
							<th>
								<label for=""><?php esc_html_e('Discount Type', 'woocommerce-wholesale-pricing'); ?></label>
							</th>
							<td>                                                            
								<select class="widefat" name="discount_type_<?php esc_attr_e(@$term_role->term_id); ?>" value="<?php esc_attr_e(@$wholesale_type); ?>">
									<option value="percent" <?php selected(@$discount, 'percent'); ?> > <?php esc_html_e('Percent', 'woocommerce-wholesale-pricing'); ?> </option>
									<option value="fixed"  <?php selected(@$discount, 'fixed'); ?> > <?php esc_html_e('Fixed', 'woocommerce-wholesale-pricing'); ?> </option>
								</select>
								<span data-tip="<?php esc_html_e('Price type for wholesale products', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
							</td>
						</tr>
					</tbody>
				</table>
						
				<?php
				foreach ( $variables as $key ) {
					$variation_id = $key;
					$variation = wc_get_product($variation_id);
					// $formatted_name = preg_replace( '/<span[^>]*>.*?<\/span>/is', '', $variation->get_formatted_name() );
					// $formatted_name = str_replace( 'Product - ', '', $formatted_name );
					$formatted_name = '#' . $variation_id . ' ( ' . wc_get_formatted_variation($variation, true, false, false) . ' )';
					$step = 1;
					if (isset($data[ $term_role->term_id ][ $variation_id ]) ) {
						$wholesale_price = $data[ $term_role->term_id ][ $variation_id ]['wholesaleprice'];
						$qty             = $data[ $term_role->term_id ][ $variation_id ]['qty'];
						$step            = $data[ $term_role->term_id ][ $variation_id ]['step'];
					} else {
						$wholesale_price = get_post_meta($key, '_regular_price', true);
						$qty             = 1;
					}
					$regular_price        = get_post_meta($key, '_regular_price', true);
					$wholesale_field_name = 'wholesaleprice_' . esc_attr($term_role->term_id) . '_' . esc_attr($key);
					$qty_field_name       = 'qty_' . esc_attr($term_role->term_id) . '_' . esc_attr($key);
					$step_field_name      = 'step_' . esc_attr($term_role->term_id) . '_' . esc_attr($key);
					$quanity_label        = esc_html__('Quantity: ', 'woocommerce-wholesale-pricing');
					?>
					<table class="form-table variable-item-table">
						<tbody>
							<tr scope="row">
								<th colspan="2" class="row-heading">
									<label for=""><?php esc_html_e('Wholesale Price & Min Qty ' . $formatted_name, 'woocommerce-wholesale-pricing'); ?></label>
								</th>
							</tr>
							<tr class="variable-item">
								<th>
									<label><?php esc_html_e('Regular Price', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td>
									<input type="text" readonly name="reg-price" value="<?php esc_attr_e($regular_price); ?>"/>
								</td>
							</tr>

							<tr>
								<th>
									<label><?php esc_html_e('Wholesale Price', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td>
									<input type="text" name="<?php esc_attr_e($wholesale_field_name); ?>" value="<?php esc_attr_e( wwp_format_price_for_input( $wholesale_price ) ); ?>"/>
									<span data-tip="<?php esc_html_e('Enter the value you would like to change the Wholesale User', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
								</td>
							</tr>

							<tr>
								<th>
									<label><?php esc_html_e($quanity_label, 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td>
									<input type="text" class="qty" name="<?php esc_attr_e($qty_field_name); ?>" value="<?php esc_attr_e($qty); ?>"/>
									<span data-tip="<?php esc_html_e('Enter Wholesale minimum quantity to apply discount', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
								</td>                                                        
								<input type="hidden" name="product_type_<?php esc_attr_e($product_id); ?>" value="variable">
								<input type="hidden" name="prod_id_<?php esc_attr_e($product_id); ?>" value="<?php esc_attr_e($product_id); ?>">
							</tr>
							<tr>
								<th>
									<label><?php esc_html_e('Step Quantity', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td>
									<input type="text" class="step" name="<?php esc_attr_e($step_field_name); ?>" value="<?php esc_attr_e(@$step); ?>"/>
									<span data-tip="<?php esc_html_e('Enter Wholesale step quantity', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
								</td>                                                        
								
							</tr>
							<tr scope="row">
							<th>
							<label for=""><?php esc_html_e('Product Tier Pricing', 'woocommerce-wholesale-pricing'); ?></label>
							</th>
							<td>
							<button data-toggle="modal" data-target="#product_tier_pricing<?php esc_attr_e($term_role->term_id) . esc_attr_e($variation_id); ?>" class="wwp-button-primary" type="button"><?php esc_html_e('Add Tier Pricing', 'woocommerce-wholesale-pricing'); ?></button>
							<span class="wwwp_help_text"><?php esc_html_e('Product Tier Pricing', 'woocommerce-wholesale-pricing'); ?></span><br><br>
							<?php
							$name = 'product_tier_pricing[tier_pricing]';
							$tier_popup = tier_pricing_modal_popup('Product Tier Pricing #' . $variation_id, 'product_tier_pricing' . $term_role->term_id . $variation_id, $term_role->term_id, $product_tier_pricing, $name, $variation_id);
							echo $tier_popup ? wp_kses_post($tier_popup) : '';
							?>
							</td>
							</tr>
							
						</tbody>
					</table>
					<?php
				}
				?>
				</tbody>
				</table>
			</div>
		</div>
	</div>
	<?php
}
?>
</div>
<input type="hidden" name="wholesale_product_type" value="<?php echo esc_attr($ptype); ?>">
