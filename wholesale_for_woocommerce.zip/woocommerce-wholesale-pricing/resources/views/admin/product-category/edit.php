<?php
/**
 * Vars
 * 
 * WP_Term $term
 */
use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

wp_nonce_field('wwp_wholeset_ruleset_nonce', 'wwp_wholeset_ruleset_nonce');
$settings = WholesaleSettingsHelper::get_pricing_settings();
$roles    = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
if (! empty($roles) ) :
	$data              = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
	$cate_tier_pricing = get_term_meta($term->term_id, 'category_tier_pricing', true);
	$roles_selected = get_term_meta($term->term_id, 'wholesale_product_visibility_multi', true);
	$non_wholesaler = get_term_meta($term->term_id, 'wholesale_product_visibility_multi_customer', true);
	?>
<tr class="form-field term-visibility-wrap">
	<th>
		<label for="wholesale_product_visibility_multi">
			<?php esc_html_e('Hide Category for Wholesaler Roles', 'woocommerce-wholesale-pricing'); ?>
		</label>
	</th>
	<td scope="row">
		<select name="wholesale_product_visibility_multi[]" id="wholesale_product_visibility_multi" class="regular-text wc-enhanced-select" multiple>
		<?php
		foreach ( $roles as $key => $group_role ) {
			$selected = ( ! empty($roles_selected) && in_array($group_role->slug, $roles_selected) ) ? 'selected' : '';
			echo '<option value="' . esc_attr($group_role->slug) . '" ' . esc_attr($selected) . '>' . esc_html($group_role->name) . '</option>';
		}
		?>
		</select>
		<p><?php esc_html_e('Select specific user roles to hide the products of this category.', 'woocommerce-wholesale-pricing'); ?></p>
	</td>
</tr>
<tr>
	<th>
		<label for="wholesale_product_visibility_multi_customer">
			<?php esc_html_e('Hide Category for Non-Wholesale User', 'woocommerce-wholesale-pricing'); ?>
		</label>
	</th>
	<td scope="row">
		<input name="wholesale_product_visibility_multi_customer" id="wholesale_product_visibility_multi_customer" type="checkbox" value="yes" <?php echo isset($non_wholesaler[0]) && 'yes' == $non_wholesaler[0] ? 'checked' : ''; ?> >
		<p style="display:inline;"><?php esc_html_e('Check this option to hide this category from non wholesale user.', 'woocommerce-wholesale-pricing'); ?></p>
	</td>
</tr>
<tr>
	<td colspan="2">
	<h1>Wholesale Role</h1>
		<div id="accordion">
			<?php
			foreach ( $roles as $key => $term_role ) {
				$min      = 1;
				$price    = '';
				$discount = '';
				$step      = '';
				if (isset($settings['wholesale_role']) && 'single' == $settings['wholesale_role'] && 'default_wholesaler' != $term_role->slug ) {
					continue;
				}
				if (isset($data[ $term_role->term_id ]) ) {
					$min      = $data[ $term_role->term_id ]['min_quatity'];
					$price    = $data[ $term_role->term_id ]['wholesale_price'];
					$discount = isset($data[ $term_role->term_id ]['discount_type']) ? $data[ $term_role->term_id ]['discount_type'] : '';
					if (isset($data[ $term_role->term_id ]['step_quantity'])) {
						$step = $data[ $term_role->term_id ]['step_quantity'];
					}
				}
				?>
				<div class="card">
					<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_<?php esc_attr_e($term_role->term_id); ?>" aria-expanded="false" aria-controls="collapse_<?php esc_attr_e($term_role->term_id); ?>">
						<?php esc_html_e($term_role->name); ?>
						<div class="wwp_signal">
							<?php
							$wwp_on_active  = '';
							$wwp_off_active = '';
							if (isset($data[ $term_role->term_id ]) && ! empty($data[ $term_role->term_id ]) ) {
								$wwp_on_active = 'active';
							} else {
								$wwp_off_active = 'active';
							}

							?>
							<div class="wwp_circle wwp_circle_off <?php echo esc_attr(@$wwp_off_active); ?> ">&nbsp;</div>
							<div class="wwp_circle wwp_circle_on <?php echo esc_attr(@$wwp_on_active); ?> ">&nbsp;</div>
						</div>
					</button>
					<div id="collapse_<?php esc_attr_e($term_role->term_id); ?>" class="collapse" aria-labelledby="heading_<?php esc_attr_e($term_role->term_id); ?>" data-parent="#accordion" style="">
						<div class="card-body">
							<table class="form-table wwp-main-settings">
								<tbody>
									<tr scope="row">
										<th>
											<label for=""><?php esc_html_e('Role Activation', 'woocommerce-wholesale-pricing'); ?></label>
										</th>
										<td>
											<input class="inp-cbx  wwp-checbox" style="display: none" type="checkbox" value="<?php esc_attr_e($term_role->slug); ?>" id="role_<?php esc_attr_e($term_role->term_id); ?>" name="role_<?php esc_attr_e($term_role->term_id); ?>" <?php echo isset($data[ $term_role->term_id ]) ? 'checked' : ''; ?> >
											<label class="cbx cbx-square" for="role_<?php esc_attr_e($term_role->term_id); ?>">
												<span>
													<svg width="12px" height="9px" viewbox="0 0 12 9">
														<polyline points="1 5 4 8 11 1"></polyline>
													</svg>
												</span>
												<span><?php esc_html_e('Enable Role', 'woocommerce-wholesale-pricing'); ?></span>
											</label>
										</td>
									</tr>

									<tr scope="row">
										<th>
											<label for=""><?php esc_html_e('Discount Type', 'woocommerce-wholesale-pricing'); ?></label>
										</th>
										<td>
											<select class="regular-text" name="discount_type_<?php esc_attr_e($term_role->term_id); ?>" value="">
												<option value="percent" <?php selected($discount, 'percent'); ?> > <?php esc_html_e('Percent', 'woocommerce-wholesale-pricing'); ?> </option>
												<option value="fixed"  <?php selected($discount, 'fixed'); ?> > <?php esc_html_e('Fixed', 'woocommerce-wholesale-pricing'); ?> </option>
											</select>
											<span class="wwwp_help_text"><?php esc_html_e('Price type for wholesale products', 'woocommerce-wholesale-pricing'); ?></span>
										</td>
									</tr>

									<tr scope="row">
										<th>
											<label for=""><?php esc_html_e('Wholesale Price', 'woocommerce-wholesale-pricing'); ?></label>
										</th>
										<td>
											<input class="regular-text wwp-price " type="text" name="wholesale_price_<?php esc_attr_e($term_role->term_id); ?>" value="<?php esc_attr_e( wwp_format_price_for_input( $price ) ); ?>">
											<span class="wwwp_help_text"><?php esc_html_e('Enter the value you would like to change the Wholesale User', 'woocommerce-wholesale-pricing'); ?> </span>
										</td>
									</tr>

									<tr scope="row">
										<th>
											<label for=""><?php esc_html_e('Min Quantity', 'woocommerce-wholesale-pricing'); ?></label>
										</th>
										<td>
											<input class="regular-text " type="number" name="min_quatity_<?php esc_attr_e($term_role->term_id); ?>" value="<?php esc_attr_e($min); ?>">
											<span class="wwwp_help_text"><?php esc_html_e('Enter Wholesale minimum quantity to apply discount', 'woocommerce-wholesale-pricing'); ?></span>
										</td>
									</tr>
									<tr scope="row">
										<th>
											<label for=""><?php esc_html_e('Step Quantity', 'woocommerce-wholesale-pricing'); ?></label>
										</th>
										<td>
											<input class="regular-text " type="text" name="step_quantity_<?php esc_attr_e($term_role->term_id); ?>" value="<?php esc_attr_e($step); ?>">
											<span class="wwwp_help_text"><?php esc_html_e('Enter Wholesale step quantity', 'woocommerce-wholesale-pricing'); ?></span>
										</td>
									</tr>                                                
									<tr scope="row">
										<th>
											<label for=""><?php esc_html_e('Category Tier Pricing', 'woocommerce-wholesale-pricing'); ?></label>
										</th>
										<td>
											<button data-toggle="modal" data-target="#category_tier_pricing_Modal<?php esc_attr_e($term_role->term_id); ?>" class="wwp-button-primary" type="button">Add Tier Pricing</button>
											<?php
											$name = 'category_tier_pricing[tier_pricing]';
											if (isset($cate_tier_pricing['tier_pricing']) ) {
												$cate_tier_pricing = $cate_tier_pricing['tier_pricing'];
											}
											echo wp_kses_post('<div>' . tier_pricing_modal_popup('Category Tier Pricing', 'category_tier_pricing_Modal' . $term_role->term_id, $term_role->term_id, $cate_tier_pricing, $name, '') . '</div>');
											?>
											<span class="wwwp_help_text"><?php esc_html_e('Category Tier Pricing', 'woocommerce-wholesale-pricing'); ?></span>
										</td>
									</tr>
									
								</tbody>
							</table>
						</div>
					</div>
				</div>                
			<?php } ?>
		</div>
	</td>
</tr>
<?php endif; ?>
