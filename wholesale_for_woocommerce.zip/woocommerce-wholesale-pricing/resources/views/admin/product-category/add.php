<?php
use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

wp_nonce_field('wwp_wholeset_ruleset_nonce', 'wwp_wholeset_ruleset_nonce');
$settings = WholesaleSettingsHelper::get_pricing_settings();
;
$roles    = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
if (! empty($roles) ) { ?>
<div class="form-field term-visibility-wrap">
	<label for="wholesale_product_visibility_multi"><?php esc_html_e('Hide Category for Wholesaler Roles', 'woocommerce-wholesale-pricing'); ?></label>
	<select name="wholesale_product_visibility_multi[]" id="wholesale_product_visibility_multi" class="widefat wc-enhanced-select" multiple>
	<?php
	foreach ( $roles as $key => $term_role ) {
		echo '<option value="' . esc_attr($term_role->slug) . '">' . esc_html($term_role->name) . '</option>';
	}
	?>
	</select>
	<p><?php esc_html_e('Select specific user roles to hide the products of this category.', 'woocommerce-wholesale-pricing'); ?></p>
</div>
<h1><?php esc_html_e('Wholesale Role', 'woocommerce-wholesale-pricing'); ?></h1>
<div id="accordion">
	<?php
	foreach ( $roles as $key => $term_role ) {
		$min      = 1;
		$step      = 1;
		$price    = '';
		$discount = '';
		if (isset($settings['wholesale_role']) && 'single' == $settings['wholesale_role'] && 'default_wholesaler' != $term_role->slug ) {
			continue;
		}
		?>
		<div class="card">
			<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_<?php esc_attr_e($term_role->term_id); ?>" aria-expanded="false" aria-controls="collapse_<?php esc_attr_e($term_role->term_id); ?>">
				<?php esc_html_e($term_role->name); ?>
			</button>
			<div id="collapse_<?php esc_attr_e($term_role->term_id); ?>" class="collapse" aria-labelledby="heading_<?php esc_attr_e($term_role->term_id); ?>" data-parent="#accordion" style="">
				<div class="card-body">
					<table class="form-table wwp-main-settings">
						<tbody>
							<tr scope="row">
								<td colspan="2">
									<input class="inp-cbx wwp-checbox" style="display: none" type="checkbox" value="<?php esc_attr_e($term_role->slug); ?>" id="role_<?php esc_attr_e($term_role->term_id); ?>" name="role_<?php esc_attr_e($term_role->term_id); ?>" <?php echo isset($data[ $term_role->term_id ]) ? 'checked' : ''; ?> >
									<label class="cbx cbx-square" for="role_<?php esc_attr_e($term_role->term_id); ?>">
										<span>
											<svg width="12px" height="9px" viewbox="0 0 12 9">
												<polyline points="1 5 4 8 11 1"></polyline>
											</svg>
										</span>
										<span><?php esc_html_e('Enable Role', 'woocommerce-wholesale-pricing'); ?></span>
									</label>
								</td>
							</tr>

							<tr scope="row">
								<td colspan="2">
									<label for=""><?php esc_html_e('Discount Type', 'woocommerce-wholesale-pricing'); ?></label><br>
									<select class="regular-text" name="discount_type_<?php esc_attr_e($term_role->term_id); ?>" value="">
										<option value="percent" <?php selected($discount, 'percent'); ?> > <?php esc_html_e('Percent', 'woocommerce-wholesale-pricing'); ?> </option>
										<option value="fixed"  <?php selected($discount, 'fixed'); ?> > <?php esc_html_e('Fixed', 'woocommerce-wholesale-pricing'); ?> </option>
									</select>
									<span class="wwwp_help_text"><?php esc_html_e('Price type for wholesale products', 'woocommerce-wholesale-pricing'); ?></span>
								</td>
							</tr>

							<tr scope="row">
								<td colspan="2">
									<label for=""><?php esc_html_e('Wholesale Price', 'woocommerce-wholesale-pricing'); ?></label><br>
									<input class="regular-text wwp-price" type="text" name="wholesale_price_<?php esc_attr_e($term_role->term_id); ?>" value="<?php esc_attr_e( wwp_format_price_for_input( $price ) ); ?>">
									<span class="wwwp_help_text"><?php esc_html_e('Enter the value you would like to change the Wholesale User', 'woocommerce-wholesale-pricing'); ?></span>
								</td>
							</tr>

							<tr scope="row">
								<td colspan="2">
									<label for=""><?php esc_html_e('Min Quantity', 'woocommerce-wholesale-pricing'); ?></label><br>
									<input class="regular-text " type="number" name="min_quatity_<?php esc_attr_e($term_role->term_id); ?>" value="<?php esc_attr_e($min); ?>">
									<span class="wwwp_help_text"><?php esc_html_e('Enter Wholesale minimum quantity to apply discount', 'woocommerce-wholesale-pricing'); ?></span>
								</td>
							</tr>
							<tr scope="row">
								<td colspan="2">
									<label for=""><?php esc_html_e('Step Quantity', 'woocommerce-wholesale-pricing'); ?></label><br>
									<input class="regular-text " type="text" name="step_quantity_<?php esc_attr_e($term_role->term_id); ?>" value="<?php esc_attr_e($step); ?>">
									<span class="wwwp_help_text"><?php esc_html_e('Enter Wholesale step quantity', 'woocommerce-wholesale-pricing'); ?></span>
								</td>
							</tr>
							<tr scope="row">

								<td>
									<button data-toggle="modal" data-target="#category_tier_pricing_Modal<?php esc_attr_e($term_role->term_id); ?>" class="wwp-button-primary" type="button">Add Tier Pricing</button>
									<?php
									$name = nl2br('category_tier_pricing[tier_pricing]');
									echo wp_kses_post(tier_pricing_modal_popup('Category Tier Pricing', 'category_tier_pricing_Modal' . $term_role->term_id, $term_role->term_id, '', $name, ''));
									?>
									<span class="wwwp_help_text"><?php esc_html_e('Category Tier Pricing', 'woocommerce-wholesale-pricing'); ?></span>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	<?php } ?>
</div>
<?php
}
