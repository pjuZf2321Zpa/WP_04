<?php

use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

$settings       = WholesaleSettingsHelper::get_pricing_settings();
$registrations  = WholesaleSettingsHelper::get_registration_settings();
$quote_general  = WholesaleSettingsHelper::get_quote_general_settings();
$quote_notifications  = WholesaleSettingsHelper::get_quote_notifications_settings();
$quote_customization  = WholesaleSettingsHelper::get_quote_customization_settings();
$quote_pdf  = WholesaleSettingsHelper::get_quote_pdf_settings();

if (isset($_POST['save-wwp_wholesale']) ) {
	if (isset($_POST['wwp_wholesale_register_nonce']) && wp_verify_nonce(wc_clean($_POST['wwp_wholesale_register_nonce']), 'wwp_wholesale_register_nonce') ) {
		$posted                                   = $_POST;
		$settings                                 = isset($_POST['options']) ? wc_clean($_POST['options']) : '';
		$settings['enable_registration_page']     = isset($settings['enable_registration_page']) ? 'yes' : 'no';
		$settings['wholesaler_allow_minimum_qty'] = isset($settings['wholesaler_allow_minimum_qty']) ? 'yes' : 'no';
		$settings['restrict_store_access']        = isset($settings['restrict_store_access']) ? 'yes' : 'no';
		$settings['over_right_wholesale_form']    = isset($settings['over_right_wholesale_form']) ? 'yes' : 'no';
		$settings['wholesaler_prodcut_only']      = isset($settings['wholesaler_prodcut_only']) ? 'yes' : 'no';
		$settings['enable_upgrade']               = isset($settings['enable_upgrade']) ? 'yes' : 'no';
		$settings['disable_auto_role']            = isset($settings['disable_auto_role']) ? 'yes' : 'no';
		$settings['retailer_disabled']            = isset($settings['retailer_disabled']) ? 'yes' : 'no';
		$settings['save_price_disabled']          = isset($settings['save_price_disabled']) ? 'yes' : 'no';
		$settings['enable_admin_new_order_item']  = isset($settings['enable_admin_new_order_item']) ? 'yes' : 'no';
		// 2.6
		// hide add to cart button
		$settings['wwp_hide_add_to_cart']         = isset($settings['wwp_hide_add_to_cart']) ? 'yes' : 'no';
		$settings['wwp_hide_add_to_cart_on']      = isset($settings['wwp_hide_add_to_cart_on']) ? $settings['wwp_hide_add_to_cart_on'] : '';
		$settings['wwp_specific_product'] = isset($settings['wwp_specific_product']) ? $settings['wwp_specific_product'] : array();
		
		$settings['advance_registration_form']     = isset($settings['advance_registration_form']) ? 'yes' : 'no';

		$settings['wwp_specific_cat'] = isset($settings['wwp_specific_cat']) ? $settings['wwp_specific_cat'] : array();
		
		$settings['wwp_specific_user_role'] = isset($settings['wwp_specific_user_role']) ? $settings['wwp_specific_user_role'] : array();
		$settings['wwp_specific_user_role'] = wwp_normalize_settings_user_roles( $settings['wwp_specific_user_role'] );

		$settings['custom_message_for_cart']      = isset($posted['options']['custom_message_for_cart']) ? wp_kses_post( $posted['options']['custom_message_for_cart'] ) : '`';

		if (( 'specific_product' == $settings['wwp_hide_add_to_cart_on'] && empty($settings['wwp_specific_product']) ) || ( 'specific_product_cat' == $settings['wwp_hide_add_to_cart_on'] && empty($settings['wwp_specific_cat']) ) || ( 'specific_user_roles' == $settings['wwp_hide_add_to_cart_on'] && empty($settings['wwp_specific_user_role']) ) ) {
			$settings['wwp_hide_add_to_cart_on'] = '';
			$settings['wwp_hide_add_to_cart'] = 'no';
			$settings['wwp_specific_cat'] = array();
			$settings['wwp_specific_user_role'] = array();
			$settings['wwp_specific_product'] = array();
		}

		if (( 'specific_product' == $settings['wwp_hide_add_to_cart_on'] && !empty($settings['wwp_specific_product']) )  ) {
			$settings['wwp_specific_cat'] = array();
			$settings['wwp_specific_user_role'] = array();
		} elseif (( 'specific_product_cat' == $settings['wwp_hide_add_to_cart_on'] && !empty($settings['wwp_specific_cat']) )  ) {
			$settings['wwp_specific_product'] = array();
			$settings['wwp_specific_user_role'] = array();
		} elseif (( 'specific_user_roles' == $settings['wwp_hide_add_to_cart_on'] && !empty($settings['wwp_specific_user_role']) )  ) {
			$settings['wwp_specific_product'] = array();
			$settings['wwp_specific_cat'] = array();
		}

		// end hide to cart
		// hide price
		$settings['wwp_hide_price']           = isset($settings['wwp_hide_price']) ? 'yes' : 'no';
		$settings['wwp_hide_price_on']        = isset($settings['wwp_hide_price_on']) ? $settings['wwp_hide_price_on'] : '';
		$settings['wwp_specific_product_price'] = isset($settings['wwp_specific_product_price']) ? $settings['wwp_specific_product_price'] : array();
		$settings['wwp_specific_cat_price'] = isset($settings['wwp_specific_cat_price']) ? $settings['wwp_specific_cat_price'] : array();
		$settings['wwp_specific_user_role_price'] = isset($settings['wwp_specific_user_role_price']) ? $settings['wwp_specific_user_role_price'] : array();
		$settings['wwp_specific_user_role_price'] = wwp_normalize_settings_user_roles( $settings['wwp_specific_user_role_price'] );
		$settings['custom_message_for_price']     = isset($posted['options']['custom_message_for_price']) ? wp_kses_post($posted['options']['custom_message_for_price']) : '';

		if (( 'specific_product' == $settings['wwp_hide_price_on'] && empty($settings['wwp_specific_product_price']) ) || ( 'specific_product_cat' == $settings['wwp_hide_price_on'] && empty($settings['wwp_specific_cat_price']) ) || ( 'specific_user_roles' == $settings['wwp_hide_price_on'] && empty($settings['wwp_specific_user_role_price']) ) ) {
			$settings['wwp_hide_price_on'] = '';
			$settings['wwp_hide_price'] = 'no';
			$settings['wwp_specific_product_price'] = array();
			$settings['wwp_specific_cat_price'] = array();
			$settings['wwp_specific_user_role_price'] = array();
		}

		if (( 'specific_product' == $settings['wwp_hide_price_on'] && !empty($settings['wwp_specific_product_price']) ) ) {
			$settings['wwp_specific_cat_price'] = array();
			$settings['wwp_specific_user_role_price'] = array();
		} elseif (( 'specific_product_cat' == $settings['wwp_hide_price_on'] && !empty($settings['wwp_specific_cat_price']) ) ) {
			$settings['wwp_specific_product_price'] = array();
			$settings['wwp_specific_user_role_price'] = array();
		} elseif (( 'specific_user_roles' == $settings['wwp_hide_price_on'] && !empty($settings['wwp_specific_user_role_price']) ) ) {
			$settings['wwp_specific_product_price'] = array();
			$settings['wwp_specific_cat_price'] = array();
		}
		// end hide price
		// end 2.6
		$settings['enable_strike_through_price']  = isset($settings['enable_strike_through_price']) ? 'yes' : 'no';
		$settings['enable_groups']                = isset($settings['enable_groups']) ? 'yes' : 'no';
		$settings['enable_quote']                 = isset($settings['enable_quote']) ? 'yes' : 'no';
		$settings['payment_method_name']          = array();
		if (isset($_POST['options']['payment_method_name']) ) {
			$request = $_POST;
			foreach ( ( array ) $request['options']['payment_method_name'] as $key => $value ) {
				if ($value) {
					$settings['payment_method_name'][$value] = 'no';
				}
			}
		}

		$settings['wwp_custom_message_non_logged_in'] = isset($posted['options']['wwp_custom_message_non_logged_in']) ? esc_html($posted['options']['wwp_custom_message_non_logged_in']) : '';

		WholesaleSettingsHelper::update_pricing_settings($settings);
		
		$roles         = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
		$data          = array();
		$cart_discount = array();
		if (! empty($roles) ) {
			foreach ( $roles as $key => $term_role ) {
				if (isset($_POST[ 'role_' . $term_role->term_id ]) ) {

					if (isset($_POST[ 'role_' . $term_role->term_id ]) ) {
						$data[ $term_role->term_id ]['slug'] = $term_role->slug;
					}
					if (isset($_POST[ 'discount_type_' . $term_role->term_id ]) ) {
						$data[ $term_role->term_id ]['discount_type'] = wc_clean($_POST[ 'discount_type_' . $term_role->term_id ]);
					}
					if (isset($_POST[ 'wholesale_price_' . $term_role->term_id ]) ) {
						$data[ $term_role->term_id ]['wholesale_price'] = is_numeric(wc_clean($_POST[ 'wholesale_price_' . $term_role->term_id ])) ? wc_clean($_POST[ 'wholesale_price_' . $term_role->term_id ]) : '';
					}
					if (isset($_POST[ 'min_quatity_' . $term_role->term_id ]) ) {
						$data[ $term_role->term_id ]['min_quatity'] = is_numeric(wc_clean($_POST[ 'min_quatity_' . $term_role->term_id ])) ? wc_clean($_POST[ 'min_quatity_' . $term_role->term_id ]) : 1;
					}
					if (isset($_POST[ 'min_subtotal_' . $term_role->term_id ]) ) {
						$data[ $term_role->term_id ]['min_subtotal'] = is_numeric(wc_clean($_POST[ 'min_subtotal_' . $term_role->term_id ])) ? wc_clean($_POST[ 'min_subtotal_' . $term_role->term_id ]) : '';
					}

					if (isset($_POST[ 'exclude_categories_' . $term_role->term_id ]) ) {
						$data[ $term_role->term_id ]['exclude_categories'] = ! empty($_POST[ 'exclude_categories_' . $term_role->term_id ]) ? array_map('intval', $_POST['exclude_categories_' . $term_role->term_id ]) : array();
					}
				}
				if (isset($_POST[ 'role_' . $term_role->term_id . '_cart' ]) ) {
					if (isset($_POST[ 'role_' . $term_role->term_id . '_cart' ]) ) {
						$cart_discount[ $term_role->term_id ]['slug'] = $term_role->slug;
					}
					if (isset($_POST['discount_type_' . $term_role->term_id . '_cart']) ) {
						$cart_discount[$term_role->term_id]['discount_type'] = wc_clean($_POST['discount_type_' . $term_role->term_id . '_cart']);
					}

					// 2.7 
					if (isset($_POST['cart_price_' . $term_role->term_id ]) ) {
						$cart_discount[$term_role->term_id]['cart_price'] = wc_clean($_POST['cart_price_' . $term_role->term_id]);
					}
					if (isset($_POST['discount_on_' . $term_role->term_id . '_cart']) ) {
						$cart_discount[$term_role->term_id]['discount_on'] = wc_clean($_POST['discount_on_' . $term_role->term_id . '_cart']);
					}
					if (isset($_POST['min_subtotal_' . $term_role->term_id . '_cart']) ) {
						$cart_discount[$term_role->term_id]['cart_min_subtotal'] = wc_clean($_POST['min_subtotal_' . $term_role->term_id . '_cart']);
					}
				}
			}
		}
		if (isset($_POST['wholesale_multi_user_cart_discount']) ) {
			$request         = wwp_get_post_data('');
			$tier_pricing = $request['wholesale_multi_user_cart_discount'];
			update_option('cart_tire_preces', $tier_pricing);
		}
		WholesaleSettingsHelper::update_multiuser_pricing_settings($data);
		update_option('wholesale_multi_user_cart_discount', $cart_discount);

		$registration_posted = isset($_POST['registrations']) ? wc_clean($_POST['registrations']) : '';
		foreach ( array( 'custommer_billing_address', 'custommer_shipping_address', 'display_fields_registration', 'display_fields_myaccount', 'display_fields_checkout' ) as $key ) {
			if ( isset($registration_posted[ $key ]) ) {
				$value = 'yes';
			} else {
				$value = 'no';
			}
			$registrations[$key] = $value;
		}
		WholesaleSettingsHelper::update_registration_settings($registrations);

		maybe_set_registration_page(isset($settings['registration_page']) ? $settings['registration_page'] : '');

		if ( isset( $_POST['wc_quote_general'] ) ) {
			$settings = isset($_POST['wc_quote_general']) ? wc_clean($_POST['wc_quote_general']) : array();
			WholesaleSettingsHelper::update_quote_general_settings($settings);
		}

		if ( isset( $_POST['wc_quote_notifications'] ) ) {
			$settings = isset($_POST['wc_quote_notifications']) ? wc_clean($_POST['wc_quote_notifications']) : array();
			WholesaleSettingsHelper::update_quote_notifications_settings($settings);
		}

		if ( isset( $_POST['wc_quote_pdf'] ) ) {
			$settings = isset($_POST['wc_quote_pdf']) ? wc_clean($_POST['wc_quote_pdf']) : array();
			WholesaleSettingsHelper::update_quote_pdf_settings($settings);
		}

		if ( isset( $_POST['wc_quote_customization'] ) ) {
			$settings = isset($_POST['wc_quote_customization']) ? wc_clean($_POST['wc_quote_customization']) : array();
			WholesaleSettingsHelper::update_quote_customization_settings($settings);
		}

	} else {
		wp_die(esc_html__('Security check', 'wholesale-for-woocommerce'));
	}

	$redirect_url = wp_get_referer();
	if (empty($redirect_url) ) {
		$redirect_url = admin_url('admin.php?page=wwp_wholesale_settings');
	}
	$redirect_url = remove_query_arg('success', $redirect_url);
	wp_safe_redirect($redirect_url);
	exit;
}

wp_enqueue_script('wc-enhanced-select');
wp_enqueue_style('wwp-select2');

$pdf_logo_id = isset($quote_pdf['pdf_logo_id']) ? $quote_pdf['pdf_logo_id'] : '';
$pdf_logo_url = isset($pdf_logo_id) && !empty($pdf_logo_id) ? wp_get_attachment_url($pdf_logo_id) : wc_placeholder_img_src();
?>
<form action="" id="wwp-global-settings" method="post">
	<hr>
	<?php wp_nonce_field('wwp_wholesale_register_nonce', 'wwp_wholesale_register_nonce'); ?>
	
	<div class="tab" role="tabpanel">
		<!-- Nav tabs -->
	<div class="row">
		<div class="col-md-3 col-sm-12">
				<?php 
				/**
				 * Hooks
				 *
				 * @since 3.0
				 */
				$wwp_settings_tab_lists = apply_filters(
					'wwp_settings_tab_lists', 
					array(
						'section1' => esc_html__('General', 'wwp-wholesale'),
						'section2' => esc_html__('WooCommerce Subscription', 'wwp-wholesale'),
						'section3' => esc_html__('Global Wholesale Pricing ', 'wwp-wholesale'),
						'section4' => esc_html__('Cart Total Discounts', 'wwp-wholesale'),
						'section5' => esc_html__('Registration Settings', 'wwp-wholesale'),
						'section6' => esc_html__('Labels & Customization', 'wwp-wholesale'),
						'section7' => esc_html__('Quote', 'wwp-wholesale'),
						'section8' => esc_html__('Quote PDF', 'wwp-wholesale'),
						'section9' => esc_html__('Login Restrictions', 'wwp-wholesale'),
						'section10' => esc_html__('Product Visibility', 'wwp-wholesale'),
						'section11' => esc_html__('Upgrade Wholesale Role', 'wwp-wholesale'),
						'section12' => esc_html__('Payment Methods', 'wwp-wholesale'),
						'section13' => esc_html__('Additional CSS', 'wwp-wholesale'),
						'section14' => esc_html__( 'MultiLipi', 'wwp-wholesale' ),
						'section15' => esc_html__( 'Product Table', 'wwp-wholesale' ),
						'section16' => esc_html__( 'Sales Agent', 'wwp-wholesale' ),
						'section17' => esc_html__( 'Company Credits', 'wwp-wholesale' ),
						)
				);
				?>
		<ul class="nav nav-tabs" role="tablist">
			<?php
			foreach ( $wwp_settings_tab_lists as $section_id => $section_name ) {
				?>
				<li role="presentation">
					<a href="#<?php echo esc_attr($section_id); ?>" role="tab" data-toggle="tab"><?php echo esc_html($section_name); ?></a>
				</li>
				<?php
			}
			?>
		</ul>
		</div>
		<div class="col-md-9 col-sm-12">    
			<div class="tab-content tabs">
				<div role="tabpanel" class="tab-pane fade" id="section1">
					<table class="form-table wwp-main-settings">
						<tbody>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Wholesale Pricing Mode', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="single_wholesaler_role" type="radio" value="single" name="options[wholesale_role]" <?php echo ( ! isset( $settings['wholesale_role'] ) || 'single' === $settings['wholesale_role'] ) ? 'checked' : ''; ?>>
										<label class="cbx" for="single_wholesaler_role">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Single Wholesale Role', 'woocommerce-wholesale-pricing'); ?></span>                                                
										</label>
										<span data-tip="<?php esc_html_e('Default settings for single user role.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>                                            
									</p>
									<p>
										<input class="inp-cbx" style="display: none" id="multiple_wholesaler_role" type="radio" value="multiple" name="options[wholesale_role]" <?php echo ( isset($settings['wholesale_role']) && 'multiple' == $settings['wholesale_role'] ) ? 'checked' : ''; ?>>
										<label class="cbx" for="multiple_wholesaler_role">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>                                                    
											<span><?php esc_html_e(' Multiple Wholesale Roles', 'woocommerce-wholesale-pricing'); ?></span>                                                    
										</label>
										<span data-tip="<?php esc_html_e('Manage prices according to multiple wholesaler user roles.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
									</p>
								</td>
							</tr>
							
							<tr scope="row" id="multiroledropdown">
							
								<th><label for="default_multipe_wholesale_roles"><?php esc_html_e('Default Multi Wholesale Roles', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<?php
									$allterms = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
									?>
									<select id="default_multipe_wholesale_roles" class="regular-text" name="options[default_multipe_wholesale_roles]" >
										<option value=""><?php esc_html_e('Select Wholesale Role', 'woocommerce-wholesale-pricing'); ?></option>
										<?php
										foreach ( $allterms as $allterm ) {
											$selected = '';
											if (isset($settings['default_multipe_wholesale_roles']) && $settings['default_multipe_wholesale_roles'] == $allterm->slug ) {
													$selected = 'selected';
											}
											?>
											<option value="<?php echo esc_attr($allterm->slug); ?>" <?php echo esc_html($selected); ?>><?php echo esc_html($allterm->name); ?></option>
										<?php } ?> 
									</select>     
									<span data-tip="<?php esc_html_e('Define the default wholesaler role for your user.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
								</td>
							</tr>
							<tr scope="row">
								<th>
									<label for=""><?php esc_html_e('Apply Wholesale Price on', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="wholeasle_price_application_regular" type="radio" value="_regular_price" name="options[wholesale_price_application]" <?php echo ( ! isset($settings['wholesale_price_application']) || ( isset($settings['wholesale_price_application']) && '_regular_price' == $settings['wholesale_price_application'] ) ) ? 'checked' : ''; ?>>
										<label class="cbx" for="wholeasle_price_application_regular">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Regular Price', 'woocommerce-wholesale-pricing'); ?></span>                                                
										</label>
										<span data-tip="<?php esc_html_e('Wholesale Prices will be applicable on regular prices.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>                                            
									</p>
									<p>
										<input class="inp-cbx" style="display: none" id="wholeasle_price_application_sale" type="radio" value="_price" name="options[wholesale_price_application]" <?php echo ( isset($settings['wholesale_price_application']) && '_price' == $settings['wholesale_price_application'] ) ? 'checked' : ''; ?>>
										<label class="cbx" for="wholeasle_price_application_sale">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>                                                    
											<span><?php esc_html_e(' Sale Price', 'woocommerce-wholesale-pricing'); ?></span>                                                    
										</label>
										<span data-tip="<?php esc_html_e('Wholesale Prices will be applicable on sale prices. If sale price is not configured, the regular price will be used.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
									</p>
								</td>
							</tr>
							<tr scope="row">
								<th>
									<label for=""><?php esc_html_e('Disable Auto Approval', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="disable_auto_role" type="checkbox" value="yes" name="options[disable_auto_role]" <?php echo ( isset($settings['disable_auto_role']) && 'yes' == $settings['disable_auto_role'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="disable_auto_role">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Check this option to disable auto approval for wholesale user role registration requests', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>

							<tr scope="row" id="attachment_location">
								<th><label for=""><?php esc_html_e('Select Attachment location', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<?php
									$attachment_location_value = array(
										'woocommerce_before_add_to_cart_button' => 'Woocommerce before add to cart button',
										'woocommerce_after_add_to_cart_button' => 'Woocommerce after add to cart button',
										'woocommerce_after_single_product_summary' => 'Woocommerce after single product summary',
									);
									?>
									<select id="attachment_location_value" class="regular-text" name="options[wwp_attachment_location]" >
										<option value=""><?php esc_html_e('Select Attachment location', 'woocommerce-wholesale-pricing'); ?></option>
										<?php
										foreach ( $attachment_location_value as $key => $value ) {
											$selected = '';
											if (isset($settings['wwp_attachment_location']) && $settings['wwp_attachment_location'] == $key ) {
												$selected = 'selected';
											}
											?>
											<option value="<?php echo esc_attr($key); ?>" <?php echo esc_html($selected); ?>><?php echo esc_html($value); ?></option>
										<?php } ?> 
									</select>  
									<span data-tip="<?php esc_html_e('Select a product attachment location.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>                                
								</td>
							</tr>
							
							
							
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Order Notification Email', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
								
								<p>
										<input class="inp-cbx" style="display: none" id="emailuserrole" type="radio" value="order_email_user_role" name="options[emailuserrole]" <?php echo ( isset($settings['emailuserrole']) && 'order_email_user_role' == $settings['emailuserrole'] ) ? 'checked' : ''; ?>>
										<label class="cbx" for="emailuserrole">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('User Role', 'woocommerce-wholesale-pricing'); ?></span>                                                
										</label>
										
										<input class="inp-cbx" style="display: none" id="order_email_custom" type="radio" value="order_email_custom" name="options[emailuserrole]"<?php echo ( ! isset( $settings['emailuserrole'] ) || ( isset($settings['emailuserrole']) && 'order_email_custom' == $settings['emailuserrole'] ) ) ? 'checked' : ''; ?>>
										<label class="cbx" for="order_email_custom">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Custom Email', 'woocommerce-wholesale-pricing'); ?></span>                                                
										</label>
										<span data-tip="<?php esc_html_e('Select option to send wholesale order notification email.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>                                            
								</p>
								
								</td>
							</tr>
							<tr scope="row" id="select_role_wrap">
								<th><label for=""><?php esc_html_e('Select Role', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<select id="email_user_role_value" class="regular-text" name="options[email_user_role_value]" >
										<option value=""><?php esc_html_e('Select Role', 'woocommerce-wholesale-pricing'); ?></option>
										<?php
										foreach ( get_editable_roles() as $role_name => $role_info ) {
											$selected = '';
											if (isset($settings['email_user_role_value']) && $settings['email_user_role_value'] == $role_name ) {
												$selected = 'selected';
											}
											?>
											<option value="<?php echo esc_attr($role_name); ?>" <?php echo esc_html($selected); ?>><?php echo esc_html($role_info['name']); ?></option>
										<?php } ?> 
									</select>  
									<span data-tip="<?php esc_html_e('Select a role of email notifications.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>                                
								</td>
							</tr>

							<?php 
							if (!isset($settings['order_custom_email_value']) ) { 
								$settings['order_custom_email_value'] = '';
							} 
							?>
							<tr scope="row" id="select_email_custom_wrap">
								<th><label for=""><?php esc_html_e('Recipient(s)', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
								<input id="order_custom_email_value"  name="options[order_custom_email_value]"  type="text" class="regular-text" value="<?php echo esc_attr($settings['order_custom_email_value']); ?>" placeholder="admin@website.com,user@website.com">
								<span data-tip="<?php esc_html_e('Enter recipients (comma separated)', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>                                
								</td>
							</tr>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Manual Wholesale Order', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="enable_admin_new_order_item" type="checkbox" value="yes" name="options[enable_admin_new_order_item]" <?php echo ( isset($settings['enable_admin_new_order_item']) && 'yes' == $settings['enable_admin_new_order_item'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="enable_admin_new_order_item">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Allow admin to add wholesale orders', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>

							<!-- 2.6 -->
							<!-- hide add to cart button -->
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Hide Add To Cart Button', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="wwp-hide-add-to-cart" type="checkbox" value="yes" name="options[wwp_hide_add_to_cart]" <?php echo ( isset($settings['wwp_hide_add_to_cart']) && 'yes' == $settings['wwp_hide_add_to_cart'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="wwp-hide-add-to-cart">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php //esc_html_e( ' Allow admin to add wholesale orders', 'woocommerce-wholesale-pricing' ); ?></span>
										</label>
									</p>
								</td>
							</tr>

							<?php 
							if (isset($settings['wwp_hide_add_to_cart']) && 'yes' == $settings['wwp_hide_add_to_cart'] ) {
								$style = 'display:table-row;';
							} else {
								$style = 'display:none;';
							} 
							?>
							<tr scope="row" class="wwp-hide-cart-on" style="<?php esc_attr_e($style); ?>">
								<th><label for=""><?php esc_html_e('Hide Add To Cart Button on', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="wwp-on-specific-product" type="radio" value="specific_product" name="options[wwp_hide_add_to_cart_on]" <?php echo ( isset($settings['wwp_hide_add_to_cart_on']) && 'specific_product' == $settings['wwp_hide_add_to_cart_on'] ) ? 'checked' : ''; ?>>
										<label class="cbx" for="wwp-on-specific-product">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Specific Products', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
										<input class="inp-cbx" style="display: none" id="wwp-on-specific-product-cat" type="radio" value="specific_product_cat" name="options[wwp_hide_add_to_cart_on]" <?php echo ( isset($settings['wwp_hide_add_to_cart_on']) && 'specific_product_cat' == $settings['wwp_hide_add_to_cart_on'] ) ? 'checked' : ''; ?>>
										<label class="cbx" for="wwp-on-specific-product-cat">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Specific Products Category', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
										<input class="inp-cbx" style="display: none" id="wwp-on-specific-user-role" type="radio" value="specific_user_roles" name="options[wwp_hide_add_to_cart_on]" <?php echo ( isset($settings['wwp_hide_add_to_cart_on']) && 'specific_user_roles' == $settings['wwp_hide_add_to_cart_on'] ) ? 'checked' : ''; ?>>
										<label class="cbx" for="wwp-on-specific-user-role">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Specific User Roles', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
									<p class="get-checked-value-for-select">    
									</p>
									<?php
									// Load selected product IDs from settings (if any)
									$selected_products = isset($settings['wwp_specific_product']) ? $settings['wwp_specific_product'] : array();
									?>

										<p class="hide-select-product" style="display: none;">
											<select style="width: 100%;"
													class="wc-product-search"
													multiple="multiple"
													name="options[wwp_specific_product][]"
													id="specific_product"
													data-placeholder="<?php esc_attr_e('Search for a product…', 'woocommerce'); ?>"
													data-action="woocommerce_json_search_products_and_variations">

												<?php
												// Show selected products in the list
												if (! empty($selected_products) ) {
													foreach ( $selected_products as $product_id ) {
														$product = wc_get_product($product_id);
														if ($product ) {
															echo '<option value="' . esc_attr($product_id) . '" selected="selected">' . esc_html($product->get_formatted_name()) . '</option>';
														}
													}
												}
												?>
											</select>
										</p>
										<?php 
										$categories = get_terms(
											array(
											'taxonomy' => 'product_cat',
											'orderby'  => 'name',
											'hide_empty' => false,
											) 
										);
										?>
										<p class="hide-select-category" style="display: none;">
											<select style="width: 100%;" class="wc-enhanced-select" multiple  name="options[wwp_specific_cat][]" id="specific_product_cat">
												<option value="">Select Product Category</option>
												<?php
												foreach ( $categories as $category ) : 
													$selected = '';
													if (isset($settings['wwp_specific_cat']) && in_array($category->term_id, $settings['wwp_specific_cat']) ) {
														$selected = 'selected="selected"';
													}
													?>
													<option <?php esc_attr_e($selected); ?> value="<?php echo esc_attr($category->term_id); ?>">
														<?php echo esc_html($category->name); ?>
													</option>
												<?php endforeach; ?>
											</select>
										</p>
										<?php
										$roles            = get_editable_roles();
										$saved_user_roles = wwp_normalize_settings_user_roles( isset( $settings['wwp_specific_user_role'] ) ? $settings['wwp_specific_user_role'] : array() );
										?>
										<p class="hide-select-user_role" style="display: none;">
											<select style="width: 100%;" class="wc-enhanced-select" multiple name="options[wwp_specific_user_role][]" id="specific_user_roles" data-placeholder="<?php esc_attr_e( 'Select User Role', 'woocommerce-wholesale-pricing' ); ?>">
												<option value="guest" <?php selected( in_array( 'guest', $saved_user_roles, true ) ); ?>>
													<?php esc_html_e( 'Guest', 'woocommerce-wholesale-pricing' ); ?>
												</option>
												<?php
												foreach ( $roles as $role_key => $term_role ) :
													?>
													<option value="<?php echo esc_attr( $role_key ); ?>" <?php selected( in_array( $role_key, $saved_user_roles, true ) ); ?>>
														<?php echo esc_html( $term_role['name'] ); ?>
													</option>
												<?php endforeach; ?>
											</select>
										</p>
								</td>
							</tr>
							
							<?php 
							if (! isset($settings['custom_message_for_cart']) ) { 
								$settings['custom_message_for_cart'] = '';
							}
							?>

							<tr scope="row" class="wwp-hide-cart-custom_msg" style="<?php esc_attr_e($style); ?>">
								<th><label for=""><?php esc_html_e('Custom Message For Hide Add To Cart Button', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<?php
										$content = isset($settings['custom_message_for_cart']) ? $settings['custom_message_for_cart'] : '';
										wp_editor(
											$content,
											'wwp-custom-message-for-cart',
											array( 'textarea_rows' => 3, 'textarea_name' => 'options[custom_message_for_cart]', 'media_buttons' => false )
										);
										?>
									<p class="description"><?php esc_html_e('Enter custom message instead of add to cart button', 'woocommerce-wholesale-pricing'); ?></p>                            
								</td>
							</tr>
							<!-- end for add to cart button -->
							<!-- hide price -->
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Hide Price', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="wwp-hide-price" type="checkbox" value="yes" name="options[wwp_hide_price]" <?php echo ( isset($settings['wwp_hide_price']) && 'yes' == $settings['wwp_hide_price'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="wwp-hide-price">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php //esc_html_e( ' Allow admin to hide wholesale price', 'woocommerce-wholesale-pricing' ); ?></span>
										</label>
									</p>
								</td>
							</tr>

							<?php 
							if (isset($settings['wwp_hide_price']) && 'yes' == $settings['wwp_hide_price'] ) {
								$style = 'display:table-row;';
							} else {
								$style = 'display:none;';
							} 
							?>
							<tr scope="row" class="wwp-hide-price-on" style="<?php esc_attr_e($style); ?>">
								<th><label for=""><?php esc_html_e('Hide Price on', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="wwp-on-specific-product-price" type="radio" value="specific_product" name="options[wwp_hide_price_on]" <?php echo ( isset($settings['wwp_hide_price_on']) && 'specific_product' == $settings['wwp_hide_price_on'] ) ? 'checked' : ''; ?>>
										<label class="cbx" for="wwp-on-specific-product-price">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Specific Products', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
										<input class="inp-cbx" style="display: none" id="wwp-on-specific-product-cat-price" type="radio" value="specific_product_cat" name="options[wwp_hide_price_on]" <?php echo ( isset($settings['wwp_hide_price_on']) && 'specific_product_cat' == $settings['wwp_hide_price_on'] ) ? 'checked' : ''; ?>>
										<label class="cbx" for="wwp-on-specific-product-cat-price">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Specific Product Category', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
										<input class="inp-cbx" style="display: none" id="wwp-on-specific-user-role-price" type="radio" value="specific_user_roles" name="options[wwp_hide_price_on]" <?php echo ( isset($settings['wwp_hide_price_on']) && 'specific_user_roles' == $settings['wwp_hide_price_on'] ) ? 'checked' : ''; ?>>
										<label class="cbx" for="wwp-on-specific-user-role-price">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Specific User Roles', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
									<p class="get-checked-value-for-select-price">    
									</p>
									<?php
									// Load selected product IDs from settings
									$selected_products = isset($settings['wwp_specific_product_price']) ? $settings['wwp_specific_product_price'] : array();
									?>

									<p class="hide-select-price-product" style="display: none;">
										<select style="width: 100%;" class="wc-product-search"
												multiple="multiple"
												name="options[wwp_specific_product_price][]"
												id="specific_product_price"
												data-placeholder="<?php esc_attr_e('Search for a product…', 'woocommerce'); ?>"
												data-action="woocommerce_json_search_products_and_variations">

											<?php
											// Show pre-selected products
											if (! empty($selected_products) ) {
												foreach ( $selected_products as $product_id ) {
													$product = wc_get_product($product_id);
													if ($product ) {
														echo '<option value="' . esc_attr($product_id) . '" selected="selected">' . esc_html($product->get_formatted_name()) . '</option>';
													}
												}
											}
											?>
										</select>
									</p>
										<?php 
										$categories = get_terms(
											array(
											'taxonomy' => 'product_cat',
											'orderby'  => 'name',
											'hide_empty' => false,
											) 
										);
										?>
										<p class="hide-select-price-category" style="display: none;">
											<select style="width: 100%;" class="wc-enhanced-select" multiple  name="options[wwp_specific_cat_price][]" id="specific_product_cat_price">
												<option value="">Select Product Category</option>
												<?php
												foreach ( $categories as $category ) : 
													$selected = '';
													if (isset($settings['wwp_specific_cat_price']) && in_array($category->term_id, $settings['wwp_specific_cat_price']) ) {
														$selected = 'selected="selected"';
													}
													?>
													<option <?php esc_attr_e($selected); ?> value="<?php echo esc_attr($category->term_id); ?>">
														<?php echo esc_html($category->name); ?>
													</option>
												<?php endforeach; ?>
											</select>
										</p>
										<?php
										$roles                  = get_editable_roles();
										$saved_user_roles_price = wwp_normalize_settings_user_roles( isset( $settings['wwp_specific_user_role_price'] ) ? $settings['wwp_specific_user_role_price'] : array() );
										?>
										<p class="hide-select-price-user-role" style="display: none;">
											<select style="width: 100%;" class="wc-enhanced-select" multiple name="options[wwp_specific_user_role_price][]" id="specific_user_roles_price" data-placeholder="<?php esc_attr_e( 'Select User Role', 'woocommerce-wholesale-pricing' ); ?>">
												<option value="guest" <?php selected( in_array( 'guest', $saved_user_roles_price, true ) ); ?>>
													<?php esc_html_e( 'Guest', 'woocommerce-wholesale-pricing' ); ?>
												</option>
												<?php
												foreach ( $roles as $role_key => $term_role ) :
													?>
													<option value="<?php echo esc_attr( $role_key ); ?>" <?php selected( in_array( $role_key, $saved_user_roles_price, true ) ); ?>>
														<?php echo esc_html( $term_role['name'] ); ?>
													</option>
												<?php endforeach; ?>
											</select>
										</p>
								</td>
							</tr>

							<?php 
							if (! isset($settings['custom_message_for_price']) ) { 
								$settings['custom_message_for_price'] = '';
							}
							?>

							<tr scope="row" class="wwp-hide-price-custom_msg" style="<?php esc_attr_e($style); ?>">
								<th><label for=""><?php esc_html_e('Custom Message For Hide Price', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<?php
										$content = isset($settings['custom_message_for_price']) ? $settings['custom_message_for_price'] : '';
										wp_editor(
											$content,
											'wwp-custom-message-for-price',
											array( 'textarea_rows' => 3, 'textarea_name' => 'options[custom_message_for_price]', 'media_buttons' => false )
										);
										?>
									<p class="description"><?php esc_html_e('Enter custom message when price is hidden', 'woocommerce-wholesale-pricing'); ?></p> 
								</td>
							</tr>
							<!-- end for hide price -->

							<tr scope="row">
								<th><label for=""><?php esc_html_e('Enable Coupon', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="enable_coupon" type="checkbox" value="yes" name="options[enable_coupon]" <?php echo ( isset($settings['enable_coupon']) && 'yes' == $settings['enable_coupon'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="enable_coupon">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable Wholesale Coupon', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Requisition List', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="requisition_list" type="checkbox" value="yes" name="options[requisition_list]" <?php echo ( isset($settings['requisition_list']) && 'yes' == $settings['requisition_list'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="requisition_list">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable Requisition List for customers', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Requisition List on cart page', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="requisition_list_cart_page" type="checkbox" value="yes" name="options[requisition_list_cart_page]" <?php echo ( isset($settings['requisition_list_cart_page']) && 'yes' == $settings['requisition_list_cart_page'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="requisition_list_cart_page">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable Requisition List button on cart page', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Variation Table', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="variation_table_enable" type="checkbox" value="yes" name="options[variation_table_enable]" <?php echo ( isset($settings['variation_table_enable']) && 'yes' == $settings['variation_table_enable'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="variation_table_enable">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable Variation table on the variation product page', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Request for Sample', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="request_for_sample_enable" type="checkbox" value="yes" name="options[request_for_sample_enable]" <?php echo ( isset($settings['request_for_sample_enable']) && 'yes' == $settings['request_for_sample_enable'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="request_for_sample_enable">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable to allow users to request for sample product', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Request for Sample Label', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
								<input id="request_for_sample_label"  name="options[request_for_sample_label]"  type="text" class="regular-text" value="<?php echo ( isset($settings['request_for_sample_label']) && ! empty( $settings['request_for_sample_label'] ) ) ? esc_attr($settings['request_for_sample_label']) : 'Get Sample'; ?>" placeholder="<?php esc_html_e('Get Sample', 'woocommerce-wholesle-pricing'); ?>">
								<span data-tip="<?php esc_html_e('Enter request for sample button label', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>                                
								</td>
							</tr>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Enable Group', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="enable-groups" type="checkbox" value="yes" name="options[enable_groups]" <?php echo ( isset($settings['enable_groups']) && 'yes' == $settings['enable_groups'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="enable-groups">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable to allow creating groups for customers', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
						</tbody>
					</table>
					<!-- non-logged in settings -->
					<h5><?php esc_html_e('Non Logged In Settings', 'woocommerce-wholesale-pricing'); ?></h5>
					<table class="form-table wwp-main-settings">
						<tbody>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Display Wholesaler price for non logged in', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="enable_wholesale_price" type="checkbox" value="yes" name="options[enable_wholesale_price]" <?php echo ( isset($settings['enable_wholesale_price']) && 'yes' == $settings['enable_wholesale_price'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="enable_wholesale_price">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Enable Wholesale price', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr scope="row" id="non_logged_in_role" class="wwp_guest_settings">
								<th><label for=""><?php esc_html_e('Select wholesale role', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<?php
										$wwp_roles = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
									?>
									<select id="wwp_select_wholesale_role_for_non_logged_in" class="regular-text" name="options[wwp_select_wholesale_role_for_non_logged_in]" >
										<option value="-1"><?php esc_html_e('Select wholesale role', 'woocommerce-wholesale-pricing'); ?></option>
											<?php foreach ( $wwp_roles as $wwp_role ) : ?>
												<option value="<?php esc_attr_e($wwp_role->term_id); ?>" <?php selected(( isset($settings['wwp_select_wholesale_role_for_non_logged_in']) ? $settings['wwp_select_wholesale_role_for_non_logged_in'] : '' ), $wwp_role->term_id, true); ?> ><?php esc_attr_e($wwp_role->name); ?></option>
											<?php endforeach; ?>
									</select>  
								</td>
							</tr>
							<tr scope="row"  class="wwp_guest_settings">
								<th><label><?php esc_html_e('Display Settings', 'woocommerce-wholesale-pricing'); ?><label></th>
								<td>&nbsp;</td>
							</tr>
							<tr scope="row"  class="wwp_guest_settings">
								<th><label for=""><?php esc_html_e('Shop Page', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="enable_non_logged_shop_page_wholesale_price" type="checkbox" value="yes" name="options[enable_non_logged_shop_page_wholesale_price]" <?php echo ( isset($settings['enable_non_logged_shop_page_wholesale_price']) && 'yes' == $settings['enable_non_logged_shop_page_wholesale_price'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="enable_non_logged_shop_page_wholesale_price">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Enable to display on shop page', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr scope="row"  class="wwp_guest_settings">
								<th><label for=""><?php esc_html_e('Single Product Page', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="enable_non_logged_product_page_wholesale_price" type="checkbox" value="yes" name="options[enable_non_logged_product_page_wholesale_price]" <?php echo ( isset($settings['enable_non_logged_product_page_wholesale_price']) && 'yes' == $settings['enable_non_logged_product_page_wholesale_price'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="enable_non_logged_product_page_wholesale_price">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Enable to display on single product page', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr scope="row" id="custom_message_non_logged_in"  class="wwp_guest_settings">
								<th><label for=""><?php esc_html_e('Custom Message', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<?php
										$content = isset($settings['wwp_custom_message_non_logged_in']) ? $settings['wwp_custom_message_non_logged_in'] : '';
										wp_editor(
											$content,
											'wwp_custom_message_non_logged_in',
											array( 'textarea_rows' => 3, 'textarea_name' => 'options[wwp_custom_message_non_logged_in]', 'media_buttons' => false )
										);
										?>
									<p class="description">Tags: {saved_amount}, {saved_percentage}</p>                            
								</td>
							</tr>
						</tbody>
					</table>                        
				</div>

				<div role="tabpanel" class="tab-pane fade" id="section2">
					<table class="form-table wwp-main-settings">
						<tbody>
							<?php
							/**
							 * Hooks
							 *
							 * @since 3.0
							 */
							if (wwp_is_subscription_active() && isset($settings['wholesale_role']) ) {
								?>
								<tr scope="row">
									<th><label for=""><?php esc_html_e('Enable Wholesale For Subscription', 'woocommerce-wholesale-pricing'); ?></label></th>
									<td>
										<input class="inp-cbx" style="display: none" id="enable_subscription" type="checkbox" value="yes" name="options[enable_subscription]" <?php echo ( isset($settings['enable_subscription']) && 'yes' == $settings['enable_subscription'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="enable_subscription">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('If checked Wholesaler role will be assigned on the respective wholesale subscription.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</td>
								</tr>
								<?php
								$args     = array(
									'post_type'     => array( 'product' ),
									'post_status' => 'publish',
									'posts_per_page' => -1,
									'tax_query' => array(
										array(
											'taxonomy' => 'product_type',
											'field'    => 'slug',
											'terms'    => 'variable-subscription',
										),
									),
								);
								$products = get_posts($args);
								?>
								<tr scope="row">
									<th><label for=""><?php esc_html_e('Select Variable Subscription', 'woocommerce-wholesale-pricing'); ?></label></th>
									<td>
										<label for="wholesale_subscription">
											<select id="wholesale_subscription" class="" name="options[wholesale_subscription]">
											<option value="" checked><?php esc_html_e('Select variable product', 'woocommerce-wholesale-pricing'); ?></option> 
											<?php
											if (! empty($products) ) {
												foreach ( $products as $key => $product ) {
													$selected = ( isset($settings['wholesale_subscription']) && $product->ID == $settings['wholesale_subscription'] ) ? 'selected' : '';
													echo '<option value="' . esc_attr($product->ID) . '" ' . esc_attr($selected) . ' >' . esc_html($product->post_title) . '</option>';
												}
											}
											?>
											</select>
											<p><?php esc_html_e('Select the variable subscription product.', 'woocommerce-wholesale-pricing'); ?></p>
										</label>
									</td>
								</tr>
								<?php
							} else {
								echo esc_html__('You need to enable Woocommerce Subscription plugin.', 'woocommerce-wholesale-pricing');
							}
							?>
						</tbody>
					</table>
				</div>

				<div role="tabpanel" class="tab-pane fade" id="section3">
					<?php
					$roles = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
					if (! empty($roles) ) {
						?>
						<div id="accordion">
							<?php
							$data = WholesaleSettingsHelper::get_multiuser_pricing_settings();
							foreach ( $roles as $key => $term_role ) :
								$min            = 1;
								$min_subtotal   = '';
								$price          = '';
								$discount       = '';
								$excluded_categories  = array();
								if (isset($settings['wholesale_role']) && 'single' == $settings['wholesale_role'] && 'default_wholesaler' != $term_role->slug ) {
									continue;
								}
								if (isset($data[ $term_role->term_id ]) ) {
									$min      = $data[ $term_role->term_id ]['min_quatity'];
									$min_subtotal   = isset($data[ $term_role->term_id ]['min_subtotal']) ? $data[ $term_role->term_id ]['min_subtotal'] : '';
									$price    = $data[ $term_role->term_id ]['wholesale_price'];
									$discount = $data[ $term_role->term_id ]['discount_type'];
									$excluded_categories  = isset($data[ $term_role->term_id ]['exclude_categories']) ? $data[ $term_role->term_id ]['exclude_categories'] : array();

								}
								?>
								<div class="card">
									<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_<?php esc_attr_e($term_role->term_id); ?>" aria-expanded="false" aria-controls="collapse_<?php esc_attr_e($term_role->term_id); ?>">
										<?php esc_html_e($term_role->name); ?>
										<div class="wwp_signal">
											<?php
											$wwp_on_active  = '';
											$wwp_off_active = '';
											if (isset($data[ $term_role->term_id ]) && ! empty($data[ $term_role->term_id ]) ) {
												$wwp_on_active = 'active';
											} else {
												$wwp_off_active = 'active';
											}

											?>
											<div class="wwp_circle wwp_circle_off <?php echo esc_attr(@$wwp_off_active); ?> ">&nbsp;</div>
											<div class="wwp_circle wwp_circle_on <?php echo esc_attr(@$wwp_on_active); ?> ">&nbsp;</div>
										</div>
									</button>
									<div id="collapse_<?php esc_attr_e($term_role->term_id); ?>" class="collapse" aria-labelledby="heading_<?php esc_attr_e($term_role->term_id); ?>" data-parent="#accordion" style="">
										<div class="card-body">
											<table class="form-table wwp-main-settings">
												<tbody>
													<tr scope="row">
														<th>
															<label for=""><?php esc_html_e('Role Activation', 'woocommerce-wholesale-pricing'); ?></label>
														</th>
														<td>
															<input class="inp-cbx wwp-checbox" style="display: none" type="checkbox" value="<?php esc_attr_e($term_role->slug); ?>" id="role_<?php esc_attr_e($term_role->term_id); ?>" name="role_<?php esc_attr_e($term_role->term_id); ?>" <?php echo isset($data[ $term_role->term_id ]) ? 'checked' : ''; ?> >
															<label class="cbx cbx-square" for="role_<?php esc_attr_e($term_role->term_id); ?>">
																<span>
																	<svg width="12px" height="9px" viewbox="0 0 12 9">
																		<polyline points="1 5 4 8 11 1"></polyline>
																	</svg>
																</span>
																<span><?php esc_html_e('Enable Role', 'woocommerce-wholesale-pricing'); ?></span>
															</label>
														</td>
													</tr>

													<tr scope="row">
														<th>
															<label for=""><?php esc_html_e('Discount Type', 'woocommerce-wholesale-pricing'); ?></label>
														</th>
														<td>
															<select class="regular-text" name="discount_type_<?php esc_attr_e($term_role->term_id); ?>" value="">
																<option value="percent" <?php selected($discount, 'percent'); ?> > <?php esc_html_e('Percent', 'woocommerce-wholesale-pricing'); ?> </option>
																<option value="fixed"  <?php selected($discount, 'fixed'); ?> > <?php esc_html_e('Fixed', 'woocommerce-wholesale-pricing'); ?> </option>
															</select>
															<span data-tip="<?php esc_html_e('Price type for wholesale products', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
														</td>
													</tr>

													<tr scope="row">
														<th>
															<label for=""><?php esc_html_e('Wholesale Value', 'woocommerce-wholesale-pricing'); ?></label>
														</th>
														<td>
															<input class="regular-text wwp-price" type="number" min=".01" step=".01" name="wholesale_price_<?php esc_attr_e($term_role->term_id); ?>" value="<?php esc_attr_e($price); ?>">
															<span data-tip="<?php esc_html_e('Enter the value you would like to change the Wholesale User', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
														</td>
													</tr>

													<tr scope="row">
														<th>
															<label for=""><?php esc_html_e('Min Quantity', 'woocommerce-wholesale-pricing'); ?></label>
														</th>
														<td>
															<input class="regular-text " type="number" min="1" step="1"  name="min_quatity_<?php esc_attr_e($term_role->term_id); ?>" value="<?php esc_attr_e($min); ?>">
															<span data-tip="<?php esc_html_e('Enter Wholesale minimum per product quantity to apply discount', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
														</td>
													</tr>
													<tr scope="row">
														<th>
															<label for=""><?php esc_html_e('Min Subtotal', 'woocommerce-wholesale-pricing'); ?></label>
														</th>
														<td>
															<input class="regular-text " type="number" min=".01" step=".01" name="min_subtotal_<?php esc_attr_e($term_role->term_id); ?>" value="<?php esc_attr_e($min_subtotal); ?>">
															<span data-tip="<?php esc_html_e('Enter Wholesale minimum cart subtotal to apply discount', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
														</td>
													</tr>
													<tr scope="row">
														<th>
															<label for=""><?php esc_html_e('Exclude Category', 'woocommerce-wholesale-pricing'); ?></label>
														</th>
														<td>
															<select name="exclude_categories_<?php echo esc_attr($term_role->term_id); ?>[]" multiple class="wc-enhanced-select" style="width: 300px;">
																<?php
																$categories = get_terms(
																	array(
																	'taxonomy'   => 'product_cat',
																	'hide_empty' => false,
																	) 
																);

																if (! empty($categories) && ! is_wp_error($categories) ) {
																	foreach ( $categories as $category ) {
																		$selected = in_array($category->term_id, (array) $excluded_categories) ? 'selected' : '';
																		echo '<option value="' . esc_attr($category->term_id) . '" ' . esc_attr($selected) . '>' . esc_html($category->name) . '</option>';
																	}
																}
																?>
															</select>
															<span data-tip="<?php esc_html_e('Select the Catagory you want to exclude.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
														</td>
													</tr>
													<tr scope="row">
														<th>
															<label for=""><?php esc_html_e('Global Tier Pricing', 'woocommerce-wholesale-pricing'); ?></label>
														</th>
														<td>
															<button name="save-wwp_wholesale" data-toggle="modal" data-target="#global_tier_pricing_Modal<?php esc_attr_e($term_role->term_id); ?>" class="wwp-button-primary" type="button" value="Save changes">Add Tier Pricing</button>
															<span data-tip="<?php esc_html_e('Global Tier Pricing', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
															<?php
															if (!isset($settings['tier_pricing'])) {
																$settings['tier_pricing'] = '';
															}
															
															$name = 'options[tier_pricing]';
															echo wp_kses_post('<div>' . tier_pricing_modal_popup('Global Tier Pricing', 'global_tier_pricing_Modal' . esc_attr($term_role->term_id), esc_attr($term_role->term_id), $settings['tier_pricing'], esc_attr($name), '') . '</div>');

															?>
														</td>
													</tr>
												</tbody>
											</table>
										</div>
									</div>
								</div>
								<?php
							endforeach;
							?>
						</div>
						<?php
					}
					?>
				</div>

				<div role="tabpanel" class="tab-pane fade" id="section4">
					<?php
						$roles = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
					if (! empty($roles) ) {
						?>
								<div id="accordion">
							<?php
							$data             = get_option('wholesale_multi_user_cart_discount');
							$cart_tire_preces = get_option('cart_tire_preces');
							foreach ( $roles as $key => $term_role ) :

								$min_wholesale_amount = '';
								$wholesale_amount     = '';
								$wholesale_label      = '';
								$discount             = '';
								// 2.7
								$discount_on          = '';
								$cart_discount_value  = '';
								$min_subtotal_value   = '';
								if (isset($settings['wholesale_role']) && 'single' == $settings['wholesale_role'] && 'default_wholesaler' != $term_role->slug ) {
									continue;
								}
								if (isset($data[ $term_role->term_id ]) ) {
									if (isset($data[ $term_role->term_id ]['wholesale_price']) ) {
										$price = $data[ $term_role->term_id ]['wholesale_price'];
									}
									if (isset($data[ $term_role->term_id ]['discount_type']) ) {
										$discount = $data[ $term_role->term_id ]['discount_type'];
									}
									// 2.7
									if (isset($data[ $term_role->term_id ]['discount_on']) ) {
										$discount_on = $data[ $term_role->term_id ]['discount_on'];
									}
									if (isset($data[ $term_role->term_id ]['cart_price']) && ! empty($data[ $term_role->term_id ]['cart_price']) ) {
										$cart_discount_value = $data[ $term_role->term_id ]['cart_price'];
									}
									if (isset($data[ $term_role->term_id ]['cart_min_subtotal']) && ! empty($data[ $term_role->term_id ]['cart_min_subtotal']) ) {
										$min_subtotal_value = $data[ $term_role->term_id ]['cart_min_subtotal'];
									}
									
								}
								?>
										<div class="card">
											<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_<?php esc_attr_e($term_role->term_id); ?>_cart" aria-expanded="false" aria-controls="collapse_<?php esc_attr_e($term_role->term_id); ?>_cart">
										<?php esc_html_e($term_role->name); ?>
												<div class="wwp_signal">
											<?php
											$wwp_on_active  = '';
											$wwp_off_active = '';
											if (isset($data[ $term_role->term_id ]) && ! empty($data[ $term_role->term_id ]) ) {
												$wwp_on_active = 'active';
											} else {
												$wwp_off_active = 'active';
											}
											?>
													<div class="wwp_circle wwp_circle_off <?php echo esc_attr(@$wwp_off_active); ?> ">&nbsp;</div>
													<div class="wwp_circle wwp_circle_on <?php echo esc_attr(@$wwp_on_active); ?> ">&nbsp;</div>
												</div>
											</button>
											<div id="collapse_<?php esc_attr_e($term_role->term_id); ?>_cart" class="collapse" aria-labelledby="heading_<?php esc_attr_e($term_role->term_id); ?>" data-parent="#accordion" style="">
												<div class="card-body">
												<table class="form-table wwp-main-settings">
														<tbody>
															<tr scope="row">
																<th>
																	<label for=""><?php esc_html_e('Role Activation', 'woocommerce-wholesale-pricing'); ?></label>
																</th>
																<td>
																	<input class="inp-cbx wwp-checbox" style="display: none" type="checkbox" value="<?php esc_attr_e($term_role->slug); ?>" id="role_<?php esc_attr_e($term_role->term_id); ?>_cart" name="role_<?php esc_attr_e($term_role->term_id); ?>_cart" <?php echo isset($data[ $term_role->term_id ]) ? 'checked' : ''; ?> >
																	<label class="cbx cbx-square" for="role_<?php esc_attr_e($term_role->term_id); ?>_cart">
																		<span>
																			<svg width="12px" height="9px" viewbox="0 0 12 9">
																				<polyline points="1 5 4 8 11 1"></polyline>
																			</svg>
																		</span>
																		<span><?php esc_html_e('Enable Role', 'woocommerce-wholesale-pricing'); ?></span>
																	</label>
																</td>
															</tr>

															<tr scope="row">
																<th>
																	<label for=""><?php esc_html_e('Discount Type', 'woocommerce-wholesale-pricing'); ?></label>
																</th>
																<td>
																	<select class="regular-text" name="discount_type_<?php esc_attr_e($term_role->term_id); ?>_cart" value="">
																		<option value="percent" <?php selected($discount, 'percent'); ?> > <?php esc_html_e('Percent', 'woocommerce-wholesale-pricing'); ?> </option>
																		<option value="fixed"  <?php selected($discount, 'fixed'); ?> > <?php esc_html_e('Fixed', 'woocommerce-wholesale-pricing'); ?> </option>
																	</select>
																	<span data-tip="<?php esc_html_e('Price type for cart discount', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
																</td>
															</tr>

														<?php // 2.7 ?> 
															<tr scope="row">
																<th>
																	<label for=""><?php esc_html_e('Discount Value', 'woocommerce-wholesale-pricing'); ?></label>
																</th>
																<td>
																	<input class="regular-text wwp-price" type="number" min=".01" step=".01" name="cart_price_<?php esc_attr_e($term_role->term_id); ?>" value="<?php echo esc_attr($cart_discount_value); ?>">
																	<span data-tip="<?php esc_html_e('Enter the discount value', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
																</td>
															</tr>

															<tr scope="row">
																<th>
																	<label for=""><?php esc_html_e('Tier Discount On', 'woocommerce-wholesale-pricing'); ?></label>
																</th>
																<td>
																	<select class="regular-text cart-discount-on cart-discount-on_<?php esc_attr_e($term_role->term_id); ?>" name="discount_on_<?php esc_attr_e($term_role->term_id); ?>_cart" value="">
																		<option value="cart_discount_amount" <?php selected($discount_on, 'cart_discount_amount'); ?> > <?php esc_html_e('Amount', 'woocommerce-wholesale-pricing'); ?> </option>
																		<option value="cart_discount_quantity"  <?php selected($discount_on, 'cart_discount_quantity'); ?> > <?php esc_html_e('Quantity', 'woocommerce-wholesale-pricing'); ?> </option>
																	</select>
																	<span data-tip="<?php esc_html_e('Select type on behalf of which you want to create tier', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
																</td>
															</tr>
														<?php 
														if (! empty($discount_on) && 'cart_discount_quantity' == $discount_on ) {
															$minlabel = 'Minimum Cart Quantity';
															$discountlabel = 'Cart Quantity Discount Range';
														} else {
															$minlabel = 'Minimum Cart Subtotal';
															$discountlabel = 'Cart Total Discount Range';
														}
														?>
															<tr scope="row">
																<th>
																	<label id="wwp-min-cart-label" for=""><?php esc_html_e($minlabel, 'woocommerce-wholesale-pricing'); ?></label>
																</th>
																<td>
																	<input class="regular-text wwp-price" type="number" min=".01" step=".01" name="min_subtotal_<?php esc_attr_e($term_role->term_id); ?>_cart" value="<?php echo esc_attr($min_subtotal_value); ?>">
																	<span data-tip="<?php esc_html_e('Enter The Minimum Cart Subtotal', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top cart-subtotal"><span class="woocommerce-help-tip"></span></span>
																</td>
															</tr>

															<tr scope="row">
																<th>
																	<label id="wwp-cart-discount-label" for=""><?php esc_html_e($discountlabel, 'woocommerce-wholesale-pricing'); ?></label>
																</th>
																<td>
																	<button name="cart_total_discount_range" data-toggle="modal" data-id="<?php esc_attr_e($term_role->term_id); ?>" data-target="#cart_total_discount_range<?php esc_attr_e($term_role->term_id); ?>" class="wwp-button-primary" type="button" value="Save changes"><?php esc_html_e('Add Discount', 'woocommerce-wholesale-pricing'); ?></button>
																	<span data-tip="<?php esc_attr_e($discountlabel); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
																	<div class="cart_total_discount_range_wrap">
																<?php
																	
																$name = 'wholesale_multi_user_cart_discount[tier_pricing]';
																if (!isset($cart_tire_preces['tier_pricing']) ) {
																	$cart_tire_preces['tier_pricing'] = '';
																}
																echo wp_kses_post('<div>' . tier_pricing_modal_popup($discountlabel, 'cart_total_discount_range' . $term_role->term_id, $term_role->term_id, $cart_tire_preces['tier_pricing'], $name, '') . '</div>');
																?>
																	
																	</div>
																</td>
															</tr>
														</tbody>
													</table>
												
												</div>
											</div>
										</div>
										<?php
								endforeach;
							?>
								</div>
							<?php
					}
					?>
				</div>

				<div role="tabpanel" class="tab-pane fade" id="section5">
					<table class="form-table wwp-main-settings">
						<tbody>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Enable Registration Link', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="enable_registration_page" type="checkbox" value="yes" name="options[enable_registration_page]" <?php echo ( isset($settings['enable_registration_page']) && 'yes' == $settings['enable_registration_page'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="enable_registration_page">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Enable wholesale registration link on my account page (You must enable registration form on myaccount page to work this functionality)', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr scope="row">
								<th><label for="registration_page_for_wholesale"><?php esc_html_e('Registration Page', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<?php
									wp_dropdown_pages( 
										array(
											'show_option_none' => esc_html__('Select Page', 'woocommerce-wholesale-pricing'),
											'class' => 'regular-text',
											'name'  => 'options[registration_page]',
											'id'    => 'registration_page_for_wholesale',
											'selected' => isset($settings['registration_page']) ? esc_attr( $settings['registration_page'] ) : '',
										) 
									);
									?>
									<span data-tip="<?php esc_html_e('Select the page on which you want to display your wholesale registration form.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>                                
								</td>
							</tr>

							<?php if (class_exists('WC_USER_REGISTRATION') ) : ?>
								<tr scope="row">
									<th><label for="advance_registration_form"><?php esc_html_e('Advance Registration Form', 'woocommerce-wholesale-pricing'); ?></label></th>
									<td>
										<label class="switch">
											<input id="advance_registration_form" type="checkbox" value="yes" name="options[advance_registration_form]" <?php echo ( isset($settings['advance_registration_form']) && 'yes' == $settings['advance_registration_form'] ) ? 'checked' : ''; ?>>
											<span class="advance_registration_form slider round"></span>
										</label>
										<p class="advance_registration_form_note"><?php esc_html_e('Note: This feature requires User Registration for WooCommerce by WPExperts.', 'woocommerce-wholesale-pricing'); ?></p>
									</td>
								</tr>  

								<div id="advanceRegistrationPopup" style="display: none;" class="popup-modal">
								<div class="popup-content">
									<div style="text-align:center;">
									<svg width="90" height="50" viewBox="0 0 90 90" fill="none" xmlns="http://www.w3.org/2000/svg">
									<circle cx="45" cy="45" r="42.5" fill="white" stroke="#FF0000" stroke-width="5"/>
									<rect x="40" y="20" width="9" height="37" rx="4.5" fill="#FF0000"/>
									<circle cx="44.5" cy="64.5" r="4.5" fill="#FF0000"/>
									</svg>
									<h5 style="margin: 15px;"><?php esc_html_e('Enable Advance User Registration', 'woocommerce-wholesale-pricing'); ?></h5>
									<p class="advance_user_registration_note"><strong><?php esc_html_e('Note: ', 'woocommerce-wholesale-pricing'); ?></strong><?php esc_html_e('Using advance user registration will disable default Wholesale Registration, Notifications and Request section. All the registration form settings, requests and emails will be handled using the User Registration. Please check pending wholesaler requests before enabling.', 'woocommerce-wholesale-pricing'); ?></p>
									<button class="popup-allow"><?php esc_html_e('Allow', 'woocommerce-wholesale-pricing'); ?></button>
									<button class="popup-decline"><?php esc_html_e('Decline', 'woocommerce-wholesale-pricing'); ?></button>
									</div>
								</div>
								</div>
								
							<?php endif; ?>  
							<tr scope="row">
								<th><label for="registration_page_for_wholesale"><?php esc_html_e('Registration Page Redirect', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<?php
									wp_dropdown_pages( 
										array(
											'show_option_none' => esc_html__('No Redirect', 'woocommerce-wholesale-pricing'),
											'class' => 'regular-text',
											'name'  => 'options[register_redirect]',
											'id'    => 'register_redirect_autocomplete',
											'selected' => isset($settings['register_redirect']) ? esc_attr( $settings['register_redirect'] ) : '',
										) 
									);
									?>
									<span data-tip="<?php esc_html_e('Please select a page or product to redirect after a successful registration.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
								</td>
							</tr>

							<tr scope="row">
								<th><label for=""><?php esc_html_e('Override My Account Registration Form', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>                                    
									<input class="inp-cbx" style="display: none" id="over_right_wholesale_form" type="checkbox" value="yes" name="options[over_right_wholesale_form]" <?php echo ( isset($settings['over_right_wholesale_form']) && 'yes' == $settings['over_right_wholesale_form'] ) ? 'checked' : ''; ?>>
									<label class="cbx cbx-square" for="over_right_wholesale_form">
										<span>
											<svg width="12px" height="9px" viewbox="0 0 12 9">
												<polyline points="1 5 4 8 11 1"></polyline>
											</svg>
										</span>
										<span><?php esc_html_e('Override Default WooCommerce My Account registration form to Wholesale Registration form', 'woocommerce-wholesale-pricing'); ?></span>
									</label>
								</td>
							</tr>

							<tr scope="row">
								<th><label for=""><?php esc_html_e('Enable Billing Address form Default Fields', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="custommer_billing_address" type="checkbox" value="yes" name="registrations[custommer_billing_address]" <?php checked( ( empty( $registrations ) || ( isset($registrations['custommer_billing_address']) && 'yes' == $registrations['custommer_billing_address'] ) ), true, true ); ?>>
										<label class="cbx cbx-square" for="custommer_billing_address">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enabling this option will allow default WooCommerce billing address field to appear on the front-end form.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr scope="row">
								<th><label><?php esc_html_e('Enable Shipping Address form Default Fields', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="custommer_shipping_address" type="checkbox" value="yes" name="registrations[custommer_shipping_address]" <?php checked( ( empty( $registrations ) || ( isset($registrations['custommer_shipping_address']) && 'yes' == $registrations['custommer_shipping_address'] ) ), true, true ); ?>>
										<label class="cbx cbx-square" for="custommer_shipping_address">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enabling this option will allow default WooCommerce shipping address field to appear on the front-end form.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr scope="row">
								<th><label><?php esc_html_e('Display Extra Fields on Registration', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="display_fields_registration" type="checkbox" value="yes" name="registrations[display_fields_registration]" <?php checked( ( empty( $registrations ) || ( isset($registrations['display_fields_registration']) && 'yes' == $registrations['display_fields_registration'] ) ), true, true ); ?>>
										<label class="cbx cbx-square" for="display_fields_registration">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable this option to allow the dynamic form builder to display extra fields on the registration page.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr scope="row">
								<th><label><?php esc_html_e('Display Extra Fields on  My account', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="display_fields_myaccount" type="checkbox" value="yes" name="registrations[display_fields_myaccount]" <?php checked( ( empty( $registrations ) || ( isset($registrations['display_fields_myaccount']) && 'yes' == $registrations['display_fields_myaccount'] ) ), true, true ); ?>>
										<label class="cbx cbx-square" for="display_fields_myaccount">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable this option to allow the dynamic form builder to display extra fields on the my account page.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr scope="row">
								<th><label><?php esc_html_e('Display Extra Fields on Checkout', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="display_fields_checkout" type="checkbox" value="yes" name="registrations[display_fields_checkout]" <?php checked( ( empty( $registrations ) || ( isset($registrations['display_fields_checkout']) && 'yes' == $registrations['display_fields_checkout'] ) ), true, true ); ?>>
										<label class="cbx cbx-square" for="display_fields_checkout">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable this option to allow the dynamic form builder to display extra fields on the checkout page.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<div role="tabpanel" class="tab-pane fade" id="section6">
					<h5><?php esc_html_e('Wholesale Pricing Labels', 'woocommerce-wholesale-pricing'); ?></h5>
					<table class="form-table wwp-main-settings">
						<tbody>
							<tr scope="row">
								<th><label for="retailer_label"><?php esc_html_e('Retailer Price Label', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<input type="text" class="regular-text" name="options[retailer_label]" id="retailer_label" value="<?php echo ( isset($settings['retailer_label']) && ! empty($settings['retailer_label']) ) ? esc_html($settings['retailer_label']) : 'Actual'; ?>" placeholder="<?php esc_html_e( 'Actual', 'woocommerce-wholesale-pricing' ); ?>"> 
									
									<span>
										<input class="inp-cbx" style="display: none" id="retailer_disabled" type="checkbox" value="yes" name="options[retailer_disabled]" <?php echo ( isset($settings['retailer_disabled']) && 'yes' == $settings['retailer_disabled'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="retailer_disabled">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span for="retailer_disabled"><?php esc_html_e('Hide Label', 'woocommerce-wholesale-pricing'); ?></span>                                                
										</label>
										<span data-tip="<?php esc_html_e('Hide Retail price Label in the wholesale view.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
									</span>
									<span style="margin-left: 40px;">
										<input class="inp-cbx" style="display: none" id="retailer_price_disabled" type="checkbox" value="yes" name="options[retailer_price_disabled]" <?php echo ( isset($settings['retailer_price_disabled']) && 'yes' == $settings['retailer_price_disabled'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="retailer_price_disabled">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span for="retailer_price_disabled"><?php esc_html_e('Hide Price', 'woocommerce-wholesale-pricing'); ?></span>                                                
										</label>
										<span data-tip="<?php esc_html_e('Hide Retail price in the wholesale view.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
									</span>
								</td>
							</tr>
							<tr scope="row">
								<th><label for="wholesaler_price_label"><?php esc_html_e('Wholesaler Price Label', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<input type="text" class="regular-text" name="options[wholesaler_label]" id="wholesaler_price_label" value="<?php echo ( isset($settings['wholesaler_label']) && ! empty($settings['wholesaler_label']) ) ? esc_html($settings['wholesaler_label']) : 'New'; ?>" placeholder="<?php esc_html_e( 'New', 'woocommerce-wholesale-pricing' ); ?>">
									<span>
										<input class="inp-cbx" style="display: none" id="wholesaler_disabled" type="checkbox" value="yes" name="options[wholesaler_disabled]" <?php echo ( isset($settings['wholesaler_disabled']) && 'yes' == $settings['wholesaler_disabled'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="wholesaler_disabled">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span for="retailer_disabled"><?php esc_html_e('Hide Label', 'woocommerce-wholesale-pricing'); ?></span>                                                
										</label>
										<span data-tip="<?php esc_html_e('Hide Wholesale price Label in the wholesale view.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
									</span>
									<span style="margin-left: 40px;">
										<input class="inp-cbx" style="display: none" id="wholesaler_price_disabled" type="checkbox" value="yes" name="options[wholesaler_price_disabled]" <?php echo ( isset($settings['wholesaler_price_disabled']) && 'yes' == $settings['wholesaler_price_disabled'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="wholesaler_price_disabled">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span for="wholesaler_price_disabled"><?php esc_html_e('Hide Price', 'woocommerce-wholesale-pricing'); ?></span>                                                
										</label>
										<span data-tip="<?php esc_html_e('Hide Retail price in the wholesale view.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
									</span>
								</td>
							</tr>
							<tr scope="row">
								<th><label for="save_price_label"><?php esc_html_e('Save Price Label', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<input type="text" class="regular-text" name="options[save_label]" id="save_price_label" value="<?php echo ( isset($settings['save_label']) && ! empty($settings['save_label']) ) ? esc_html($settings['save_label']) : 'Save'; ?>" placeholder="<?php esc_html_e( 'Save', 'woocommerce-wholesale-pricing' ); ?>">

									<span>
										<input class="inp-cbx" style="display: none" id="save_price_label_disabled" type="checkbox" value="yes" name="options[save_price_label_disabled]" <?php echo ( isset($settings['save_price_label_disabled']) && 'yes' == $settings['save_price_label_disabled'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="save_price_label_disabled">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span for="save_price_disabled"><?php esc_html_e('Hide Label', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
										<span data-tip="<?php esc_html_e('Hide Save price Label in the wholesale view.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span></label>
									</span>
									<span style="margin-left: 40px;">
										<input class="inp-cbx" style="display: none" id="save_price_disabled" type="checkbox" value="yes" name="options[save_price_disabled]" <?php echo ( isset($settings['save_price_disabled']) && 'yes' == $settings['save_price_disabled'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="save_price_disabled">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span for="save_price_disabled"><?php esc_html_e('Hide Price', 'woocommerce-wholesale-pricing'); ?></span>                                                
										</label>
										<span data-tip="<?php esc_html_e('Hide Save price/percentage in the wholesale view.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
									</span>
								</td>
							</tr>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Strike Through Price', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="enable_strike_through_price" type="checkbox" value="yes" name="options[enable_strike_through_price]" <?php checked(( isset($settings['enable_strike_through_price']) ? $settings['enable_strike_through_price'] : 'yes' ), 'yes', true); ?>>
										<label class="cbx cbx-square" for="enable_strike_through_price">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Display strike through regular price', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
						</tbody>
					</table>
					<h5><?php esc_html_e('Quotes', 'woocommerce-wholesale-pricing'); ?></h5>
					<table class="form-table wwp-main-settings">
						<tbody>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<label for="wc_quote_build_quote_text">
										<?php echo esc_html__('Build a Quote Button Text', 'woocommerce-wholesale-pricing'); ?>
									</label>
								</th>
								<td class="forminp forminp-text">
									<input name="wc_quote_customization[build_quote_text]" id="wc_quote_build_quote_text" type="text" placeholder="<?php echo esc_html__('Build a quote text', 'woocommerce-wholesale-pricing'); ?>" value="<?php echo esc_attr( isset( $quote_customization['build_quote_text'] ) ? $quote_customization['build_quote_text'] : '' ); ?>">
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<label for="wc_quote_convert_cart_text">
										<?php echo esc_html__('Convert to Cart Button Text', 'woocommerce-wholesale-pricing'); ?>
									</label>
								</th>
								<td class="forminp forminp-text">
									<input name="wc_quote_customization[convert_cart_text]" id="wc_quote_convert_cart_text" type="text" placeholder="<?php echo esc_html__('Convert to cart text', 'woocommerce-wholesale-pricing'); ?>" value="<?php echo esc_attr( isset( $quote_customization['convert_cart_text'] ) ? $quote_customization['convert_cart_text'] : '' ); ?>">
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<label for="wc_quote_send_quote_text">
										<?php echo esc_html__('Send Quote Button Text', 'woocommerce-wholesale-pricing'); ?>
									</label>
								</th>
								<td class="forminp forminp-text">
									<input name="wc_quote_customization[send_quote_text]" id="wc_quote_send_quote_text" type="text" placeholder="<?php echo esc_html__('Send quote text', 'woocommerce-wholesale-pricing'); ?>" value="<?php echo esc_attr( isset( $quote_customization['send_quote_text'] ) ? $quote_customization['send_quote_text'] : '' ); ?>">
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<label for="wc_quote_add_quote_text">
										<?php echo esc_html__('Add to Quote Button Text', 'woocommerce-wholesale-pricing'); ?>
									</label>
								</th>
								<td class="forminp forminp-text">
									<input name="wc_quote_customization[add_quote_text]" id="wc_quote_add_quote_text" type="text" placeholder="<?php echo esc_html__('Add to quote button text', 'woocommerce-wholesale-pricing'); ?>" value="<?php echo esc_attr( isset( $quote_customization['add_quote_text'] ) ? $quote_customization['add_quote_text'] : '' ); ?>">
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<label for="wc_quote_browse_list">
										<?php echo esc_html__('Browse the List Button Text', 'woocommerce-wholesale-pricing'); ?>
									</label>
								</th>
								<td class="forminp forminp-text">
									<input name="wc_quote_customization[browse_list_text]" id="wc_quote_browse_list" type="text" placeholder="<?php echo esc_html__('Browse the List', 'woocommerce-wholesale-pricing'); ?>" value="<?php echo esc_attr( isset( $quote_customization['browse_list_text'] ) ? $quote_customization['browse_list_text'] : '' ); ?>">
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<label for="wc_quote_return_shop_text">
										<?php echo esc_html__('Return to Shop Button Text', 'woocommerce-wholesale-pricing'); ?>
									</label>
								</th>
								<td class="forminp forminp-text">
									<input name="wc_quote_customization[return_shop_text]" id="wc_quote_return_shop_text" type="text" placeholder="<?php echo esc_html__('Return to shop text', 'woocommerce-wholesale-pricing'); ?>" value="<?php echo esc_attr( isset( $quote_customization['return_shop_text'] ) ? $quote_customization['return_shop_text'] : '' ); ?>">
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<label for="wc_quote_counter_text">
										<?php echo esc_html__('Quote Counter Text', 'woocommerce-wholesale-pricing'); ?>
									</label>
								</th>
								<td class="forminp forminp-text">
									<input name="wc_quote_customization[quote_counter_text]" id="wc_quote_counter_text" type="text" placeholder="<?php echo esc_html__('Quote Counter', 'woocommerce-wholesale-pricing'); ?>" value="<?php echo esc_attr( isset( $quote_customization['quote_counter_text'] ) ? $quote_customization['quote_counter_text'] : '' ); ?>">
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<label for="wc_quote_button_position"><?php echo esc_html__('Add To Quote Button Positioning', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td class="forminp forminp-radio">
									<p>
										<input class="inp-cbx" style="display: none" id="quote_btn_positioning_inline" type="radio" value="inline" name="wc_quote_customization[quote_btn_positioning]" <?php checked( ( ( ! isset( $quote_customization['quote_btn_positioning'] ) ) || ( isset( $quote_customization['quote_btn_positioning'] ) && 'inline' == $quote_customization['quote_btn_positioning'] ) ), true, true); ?>>
										<label class="cbx" for="quote_btn_positioning_inline">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Inline with "Add to Cart" button', 'woocommerce-wholesale-pricing'); ?></span>                                                
										</label>
									</p>
									<p>
										<input class="inp-cbx" style="display: none" id="quote_btn_positioning_underneath" type="radio" value="underneath" name="wc_quote_customization[quote_btn_positioning]" <?php checked( isset( $quote_customization['quote_btn_positioning'] ) && 'underneath' == $quote_customization['quote_btn_positioning'], true, true ); ?>>
										<label class="cbx" for="quote_btn_positioning_underneath">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>                                                    
											<span><?php esc_html_e('Underneath with "Add to Cart" button', 'woocommerce-wholesale-pricing'); ?></span>                                                    
										</label>
									</p>
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<label for="wc_quote_add_btn_color"><?php echo esc_html__('Add to Quote Button Color', 'woocommerce-wholesale-pricing'); ?> </label>
								</th>
								<td class="forminp forminp-color">
									<input name="wc_quote_customization[add_quote_btn_color]" id="wc_quote_add_btn_color" type="color" value="<?php echo esc_attr( isset( $quote_customization['add_quote_btn_color'] ) ? $quote_customization['add_quote_btn_color'] : '#eeeeee' ); ?>" class="colorpick">
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<label for="wc_quote_add_txt_color"><?php echo esc_html__('Add to Quote Button Text Color', 'woocommerce-wholesale-pricing'); ?> </label>
								</th>
								<td class="forminp forminp-color">
									<input name="wc_quote_customization[add_quote_text_color]" id="wc_quote_add_txt_color" type="color" value="<?php echo esc_attr( isset( $quote_customization['add_quote_text_color'] ) ? $quote_customization['add_quote_text_color'] : '#333333' ); ?>" class="colorpick">
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<label for="wc_quote_send_btn_color"><?php echo esc_html__('Send Quote Button Color', 'woocommerce-wholesale-pricing'); ?> </label>
								</th>
								<td class="forminp forminp-color">
									<input name="wc_quote_customization[send_quote_btn_color]" id="wc_quote_send_btn_color" type="color" value="<?php echo esc_attr( isset( $quote_customization['send_quote_btn_color'] ) ? $quote_customization['send_quote_btn_color'] : '#eeeeee' ); ?>" class="colorpick">
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<label for="wc_quote_send_txt_color"><?php echo esc_html__('Send Quote Button Text Color', 'woocommerce-wholesale-pricing'); ?> </label>
								</th>
								<td class="forminp forminp-color">
									<input name="wc_quote_customization[send_quote_text_color]" id="wc_quote_send_txt_color" type="color" value="<?php echo esc_attr( isset( $quote_customization['send_quote_text_color'] ) ? $quote_customization['send_quote_text_color'] : '#333333' ); ?>" class="colorpick">
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<label for="wc_quote_counter_text_color"><?php echo esc_html__('Quote Counter Text Color', 'woocommerce-wholesale-pricing'); ?> </label>
								</th>
								<td class="forminp forminp-color">
									<input name="wc_quote_customization[quote_counter_text_color]" id="wc_quote_counter_text_color" type="color" value="<?php echo esc_attr( isset( $quote_customization['quote_counter_text_color'] ) ? $quote_customization['quote_counter_text_color'] : '' ); ?>" class="colorpick">
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<div role="tabpanel" class="tab-pane fade" id="section7">
					<table class="form-table wwp-main-settings">
						<tbody>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Enable Quote', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<input type="hidden" name="wc_quote_general[enable_quote]" value="<?php echo ( isset($settings['enable_quote']) && 'yes' == $settings['enable_quote'] ) ? 'checked' : ''; ?>">
										<input class="inp-cbx" style="display: none" id="enable_quote" type="checkbox" value="yes" name="options[enable_quote]" <?php echo ( isset($settings['enable_quote']) && 'yes' == $settings['enable_quote'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="enable_quote">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Enable this option to allow customers to request and manage quotes.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Quote List Page', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<p>
										<?php if ( isset( $quote_general['quote_page'] ) && ! empty( $quote_general['quote_page'] ) && get_post($quote_general['quote_page']) && 'trash' != get_post_status($quote_general['quote_page']) ) : ?>
											<?php esc_html_e('Quote Page: ', 'woocommerce-wholesale-pricing'); ?> <a href="<?php echo esc_url( get_edit_post_link($quote_general['quote_page']) ); ?>" target="_blank"><?php echo esc_html( get_the_title($quote_general['quote_page']) ); ?></a>
											<small style="display: block;"><?php esc_html_e('Quote Page Shortcode: [wc-quote-request-page]', 'woocommerce-wholesale-pricing'); ?></small>
											<a
												href="<?php echo esc_url( admin_url('admin-ajax.php?action=wc_quote_page_delete&nonce=' . wp_create_nonce('quote_page_delete')) ); ?>"
												class="button"
												id="delete_quote_page"
												style="margin-top: 8px; display: inline-block; color: #b32d2e; border-color: #b32d2e;"
												onclick="return confirm('<?php echo esc_js( __( 'Delete the quote list page permanently? This will also remove it from settings.', 'woocommerce-wholesale-pricing' ) ); ?>');"
											><?php esc_html_e('Delete Quote Page', 'woocommerce-wholesale-pricing'); ?></a>
										<?php else : ?>
											<a href="<?php echo esc_url( admin_url('admin-ajax.php?action=wc_quote_page_generate&nonce=' . wp_create_nonce('quote_page_generate')) ); ?>" class="wwp-button-primary" id="generate_quote_page"><?php esc_html_e('Generate Quote Page', 'woocommerce-wholesale-pricing'); ?></a>
											<small style="display: block;"><?php esc_html_e('Click on the button to generate a quote list page, or you can use Shortcode: [wc-quote-request-page]', 'woocommerce-wholesale-pricing'); ?></small>
										<?php endif; ?>
										
									</p>
									<?php if ( isset($quote_general['quote_page']) && ! empty( $quote_general['quote_page'] ) ) : ?>
										<input type="hidden" name="wc_quote_general[quote_page]" value="<?php echo esc_attr( $quote_general['quote_page'] ); ?>">
									<?php endif; ?>
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Empty Quote After Email', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_empty_email" type="checkbox" value="1" name="wc_quote_general[empty_email]" <?php checked(1, isset( $quote_general['empty_email'] ) && $quote_general['empty_email'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_empty_email">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable to empty quote after email.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Re-Quote', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_requote" type="checkbox" value="1" name="wc_quote_general[wc_requote]" <?php checked(1, isset( $quote_general['wc_requote'] ) && $quote_general['wc_requote'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_requote">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable will allow customer to re-quote again.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Convert Quote to Cart', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_convert_cart" type="checkbox" value="1" name="wc_quote_general[enable_convert_cart]" <?php checked(1, isset( $quote_general['enable_convert_cart'] ) && $quote_general['enable_convert_cart'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_convert_cart">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable to show "add to cart" option on quote page', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Show Build Quote', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_build_quote" type="checkbox" value="1" name="wc_quote_general[enable_build_quote]" <?php checked(1, isset( $quote_general['enable_build_quote'] ) && $quote_general['enable_build_quote'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_build_quote">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable to show build a quote option on cart page.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>

							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Empty Cart', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_empty_cart" type="checkbox" value="1" name="wc_quote_general[empty_cart]" <?php checked(1, isset( $quote_general['empty_cart'] ) && $quote_general['empty_cart'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_empty_cart">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable to empty cart after products moved to quote.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>

							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Show Quote Details in Order', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_show_quote_details" type="checkbox" value="1" name="wc_quote_general[enable_show_quote_details]" <?php checked(1, isset( $quote_general['enable_show_quote_details'] ) && $quote_general['enable_show_quote_details'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_show_quote_details">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable to show quote details in order.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Quote Basket', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_mini_cart" type="checkbox" value="1" name="wc_quote_general[mini_cart]" <?php checked(1, isset( $quote_general['mini_cart'] ) && $quote_general['mini_cart'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_mini_cart">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable to display quote basket.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr valign="top" class="wc_quote_basket_menu">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Quote Basket Menu', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<?php
										if (empty(get_terms('nav_menu')) ) {
											$url = admin_url('nav-menus.php');
											/* translators: %s: Url admin menu create. */
											printf('No menu(s) have been created yet. <a href="%s" target="_blank">Create some</a>.', esc_url($url));
										} else {
											foreach ( (array) get_terms('nav_menu') as $nav_menu ) : 
												?>
											<label for="wc_quote_basket_menu_<?php echo intval($nav_menu->term_id); ?>">
												<input name="wc_quote_general[quote_basket_menu][]" id="wc_quote_basket_menu_<?php echo intval($nav_menu->term_id); ?>" type="checkbox" class="wc-quote-basket-menu" value="<?php echo intval($nav_menu->term_id); ?>" <?php echo in_array($nav_menu->term_id, (array) @$quote_general['quote_basket_menu']) ? 'checked' : ''; ?>><?php echo esc_html($nav_menu->name); ?>
											</label></br>
											<?php endforeach; ?>
											<p class="description"><?php echo esc_html__('Show quote basket in selected menu(s)', 'woocommerce-wholesale-pricing'); ?></p>
										<?php } ?>
									</p>
								</td>
							</tr>
							<tr valign="top" class="wc_quote_disable_basket_roles">
								<th scope="row" class="titledesc">
									<label for="wc_quote_disable_basket_roles">
										<?php echo esc_html__('Disable Quote Basket for user roles', 'woocommerce-wholesale-pricing'); ?>
									</label>
								</th>
								<td class="forminp forminp-text">    
									<select name="wc_quote_general[disable_basket_roles][]" multiple class="wc-enhanced-select select2" id="wc_quote_disable_basket_roles" data-placeholder="<?php echo esc_html__('Select the Roles', 'woocommerce-wholesale-pricing'); ?>" style="min-width: 400px;">
										<option value="guest"> <?php echo esc_html__('Guest', 'woocommerce-wholesale-pricing'); ?></option>
										<?php wp_dropdown_roles(); ?>
									</select>
									<?php if ( isset( $quote_general['disable_basket_roles'] ) && ! empty( $quote_general['disable_basket_roles'] ) ) : ?>
										<?php foreach ($quote_general['disable_basket_roles'] as $disable_basket_role) : ?>
											<script type="text/javascript">
												jQuery('#wc_quote_disable_basket_roles option[value=<?php echo esc_attr($disable_basket_role); ?>]').prop('selected', true)
												</script>
										<?php endforeach; ?>
									<?php endif; ?>
									<p class="description"><?php echo esc_html__('Disable quote basket for user roles. Enable for all user roles by default.', 'woocommerce-wholesale-pricing'); ?></p>
								</td>
							</tr>
							<tr valign="top" class="wc_quote_basket_style">
								<th scope="row" class="titledesc">
									<label for="wc_quote_basket_style"><?php echo esc_html__('Quote Basket Style', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td class="forminp forminp-radio">
									<p>
										<input class="inp-cbx" style="display: none" id="quote_basket_dropdown" type="radio" value="dropdown" name="wc_quote_general[quote_basket_style]" <?php checked(1, ( ( ! isset( $quote_general['quote_basket_style'] ) ) || ( isset( $quote_general['quote_basket_style'] ) && 'dropdown' == $quote_general['quote_basket_style'] ) ), true); ?>>
										<label class="cbx" for="quote_basket_dropdown">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Quote Basket with Dropdown', 'woocommerce-wholesale-pricing'); ?></span>                                                
										</label>
									</p>
									<p>
										<input class="inp-cbx" style="display: none" id="quote_basket_icon" type="radio" value="icon" name="wc_quote_general[quote_basket_style]" <?php checked(1, isset( $quote_general['quote_basket_style'] ) && 'icon' == $quote_general['quote_basket_style'], true); ?>>
										<label class="cbx" for="quote_basket_icon">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>                                                    
											<span><?php esc_html_e(' Quote Basket Icon', 'woocommerce-wholesale-pricing'); ?></span>                                                    
										</label>
									</p>
									<span><?php esc_html_e('Select to show dropdown or icon.', 'woocommerce-wholesale-pricing'); ?></span>
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Offered Price', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_enable_offered" type="checkbox" value="1" name="wc_quote_general[enable_offered]" <?php checked(1, isset( $quote_general['enable_offered'] ) && $quote_general['enable_offered'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_enable_offered">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable to display offered price and subtotal offered price on quote page.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr valign="top" class="condition_offered_price">
								<th scope="row" class="titledesc">
									<label for="wc_quote_inc_dec_offered_price"><?php echo esc_html__('Increase/Decrease Offered Price', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td class="forminp forminp-radio">
									<p>
										<input class="inp-cbx" style="display: none" id="inc_offered_price" type="radio" value="inc" name="wc_quote_general[inc_dec_offered_price]" <?php checked(1, ( ( ! isset( $quote_general['inc_dec_offered_price'] ) ) || ( isset( $quote_general['inc_dec_offered_price'] ) && 'inc' == $quote_general['inc_dec_offered_price'] ) ), true); ?>>
										<label class="cbx" for="inc_offered_price">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e(' Increase Offered Price', 'woocommerce-wholesale-pricing'); ?></span>                                                
										</label>
									</p>
									<p>
										<input class="inp-cbx" style="display: none" id="dec_offered_price" type="radio" value="dec" name="wc_quote_general[inc_dec_offered_price]" <?php checked(1, isset( $quote_general['inc_dec_offered_price'] ) && 'dec' == $quote_general['inc_dec_offered_price'], true); ?>>
										<label class="cbx" for="dec_offered_price">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>                                                    
											<span><?php esc_html_e(' Decrease Offered Price', 'woocommerce-wholesale-pricing'); ?></span>                                                    
										</label>
									</p>
								</td>
							</tr>
							<tr scope="row" class="condition_offered_price">
								<th><label for="wc_quote_increased_offered_price"><?php esc_html_e('Increase Offered Price', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<input id="wc_quote_increased_offered_price"  name="wc_quote_general[increase_offered_price]" type="number" min=".01" step=".01" max="100" class="regular-text" value="<?php echo isset( $quote_general['increase_offered_price'] ) ? esc_attr($quote_general['increase_offered_price']) : ''; ?>" placeholder="10">
									<span data-tip="Enter percentage to increase the offered price from regular price of product. Leave empty for regular price." class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
								</td>
							</tr>
							<tr scope="row" class="condition_offered_price">
								<th><label for="wc_quote_decreased_offered_price"><?php esc_html_e('Decrease Offered Price', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<input id="wc_quote_decreased_offered_price"  name="wc_quote_general[decrease_offered_price]" type="number" min=".01" step=".01" max="100" class="regular-text" value="<?php echo isset( $quote_general['decrease_offered_price'] ) ? esc_attr($quote_general['decrease_offered_price']) : ''; ?>" placeholder="10">
									<span data-tip="Enter percentage to decrease the offered price from regular price of product. Leave empty for regular price." class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
								</td>
							</tr>

							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Display Tax', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_display_tax" type="checkbox" value="1" name="wc_quote_general[display_tax]" <?php checked(1, isset( $quote_general['display_tax'] ) && $quote_general['display_tax'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_display_tax">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable to display tax calculation on quote page.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Standard Price', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_enable_standard" type="checkbox" value="1" name="wc_quote_general[enable_standard]" <?php checked(1, isset( $quote_general['enable_standard'] ) && $quote_general['enable_standard'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_enable_standard">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable to display standard price and subtotal standard price on quote page.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>

							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Return to Shop', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_return_shop" type="checkbox" value="1" name="wc_quote_general[return_shop]" <?php checked(1, isset( $quote_general['return_shop'] ) && $quote_general['return_shop'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_return_shop">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable to display return to shop button when quote page is empty.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>

							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Convert to Order', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_convert_to_order" type="checkbox" value="1" name="wc_quote_general[convert_to_order]" <?php checked(1, isset( $quote_general['convert_to_order'] ) && $quote_general['convert_to_order'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_convert_to_order">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable convert to order for customers. (Quote status should be "Quote" or "Accepted").', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>

							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Convert to Checkout', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_convert_to_checkout" type="checkbox" value="1" name="wc_quote_general[send_to_checkout]" <?php checked(1, isset( $quote_general['send_to_checkout'] ) && $quote_general['send_to_checkout'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_convert_to_checkout">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable convert to checkout for customers. (Quote status should be "Quote" or "Accepted").', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>

							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Display Quote Converter', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_display_quote_converter" type="checkbox" value="1" name="wc_quote_general[display_quote_converter]" <?php checked(1, isset( $quote_general['display_quote_converter'] ) && $quote_general['display_quote_converter'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_display_quote_converter">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable display of quote converted status in my account quote details.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
  
							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Quote Counter', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_display_quote_counter" type="checkbox" value="1" name="wc_quote_general[display_quote_counter]" <?php checked(1, isset( $quote_general['display_quote_counter'] ) && $quote_general['display_quote_counter'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_display_quote_counter">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable to display quote counter.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>

							<tr valign="top" class="wc_quote_counter_menu">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Show Quote Counter', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_counter_shop" type="checkbox" value="1" name="wc_quote_general[counter_shop]" <?php checked(1, isset( $quote_general['counter_shop'] ) && $quote_general['counter_shop'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_counter_shop">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Shop Page.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_counter_single_product" type="checkbox" value="1" name="wc_quote_general[counter_single_product]" <?php checked(1, isset( $quote_general['counter_single_product'] ) && $quote_general['counter_single_product'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_counter_single_product">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Single Product Page.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
									<p class="description"><?php echo esc_html__('Select the page to show the quote counter.', 'woocommerce-wholesale-pricing'); ?></p>
								</td>
							</tr>
					
							<tr valign="top" class="wc_quote_counter_reset_data">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Reset Data', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<label for="wc_quote_reset_quote_counter">
										<a id="wc_quote_reset_quote_counter" class="button-primary reset-btn" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-ajax.php?action=wc_reset_quote_counter'), 'wc-reset-quote-counter')); ?>"><?php esc_html_e('Reset Data', 'woocommerce-wholesale-pricing'); ?></a>
									</label>
									<p class="description"><?php echo esc_html__('Reset the Quote Counter Data.', 'woocommerce-wholesale-pricing'); ?></p>
								</td>
							</tr>
							
							<tr valign="top">
								<th scope="row" class="titledesc">
									<label for="wc_quote_show_on_stock"><?php echo esc_html__('Product Stock Level', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td class="forminp forminp-radio">
									<p>
										<input class="inp-cbx" style="display: none" id="show_on_stock" type="radio" value="show" name="wc_quote_general[show_on_stock]" <?php checked(1, isset( $quote_general['show_on_stock'] ) && 'show' == $quote_general['show_on_stock'], true); ?>>
										<label class="cbx" for="show_on_stock">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Show add to quote on out of stock products', 'woocommerce-wholesale-pricing'); ?></span>                                                
										</label>
									</p>
									<p>
										<input class="inp-cbx" style="display: none" id="hide_on_stock" type="radio" value="hide" name="wc_quote_general[show_on_stock]" <?php checked(1, ( ( ! isset( $quote_general['show_on_stock'] ) ) || ( isset( $quote_general['show_on_stock'] ) && 'hide' == $quote_general['show_on_stock'] ) ), true); ?>>
										<label class="cbx" for="hide_on_stock">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>                                                    
											<span><?php esc_html_e('Hide add to quote on out of stock products', 'woocommerce-wholesale-pricing'); ?></span>                                                    
										</label>
									</p>
								</td>
							</tr>

							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('View Quote Cart List', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_display_browse_list" type="checkbox" value="1" name="wc_quote_general[display_browse_list]" <?php checked(1, isset( $quote_general['display_browse_list'] ) && $quote_general['display_browse_list'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_display_browse_list">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable display of View Quote Cart list after products moved to quote.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>

							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Custom Tax & Shipping in Quote', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_custom_tax_shipping" type="checkbox" value="1" name="wc_quote_general[custom_tax_shipping]" <?php checked(1, isset( $quote_general['custom_tax_shipping'] ) && $quote_general['custom_tax_shipping'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_custom_tax_shipping">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Enable to allow administrator to add custom tax and shipping amount in a quote.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
						</tbody>
					</table>
					<h5><?php esc_html_e('Quote Messages', 'woocommerce-wholesale-pricing'); ?></h5>
					<table class="form-table">
						<tbody>
							<tbody>
								<tr valign="top">
									<th scope="row" class="titledesc">
										<label for="wc_quote_email_success_msg">
											<?php echo esc_html__('Message Email Quote on Success', 'woocommerce-wholesale-pricing'); ?>
										</label>
									</th>
									<td class="forminp forminp-text">
										<input name="wc_quote_notifications[email_success_msg]" id="wc_quote_email_success_msg" type="text" placeholder="<?php echo esc_html__('Email Success Message', 'woocommerce-wholesale-pricing'); ?>" value="<?php echo esc_attr( isset( $quote_notifications['email_success_msg'] ) ? $quote_notifications['email_success_msg'] : '' ); ?>">
										<p class="description"><?php echo esc_html__('This Text will show as notice when user successfully email quotes', 'woocommerce-wholesale-pricing'); ?></p>
									</td>
								</tr>
								<tr valign="top">
									<th scope="row" class="titledesc">
										<label for="wc_quote_email_error_msg">
											<?php echo esc_html__('Message Email Quote on Error', 'woocommerce-wholesale-pricing'); ?>
										</label>
									</th>
									<td class="forminp forminp-text">
										<input name="wc_quote_notifications[email_error_msg]" id="wc_quote_email_error_msg" type="text" placeholder="<?php echo esc_html__('Email Error Message', 'woocommerce-wholesale-pricing'); ?>" value="<?php echo esc_attr( isset( $quote_notifications['email_error_msg'] ) ? $quote_notifications['email_error_msg'] : '' ); ?>">
										<p class="description"><?php echo esc_html__('This Text will show as notice when user get error on email quotes', 'woocommerce-wholesale-pricing'); ?></p>
									</td>
								</tr>
								<tr valign="top">
									<th scope="row" class="titledesc">
										<label for="wc_quote_email_valid_msg">
											<?php echo esc_html__('Message Email Wrong Error', 'woocommerce-wholesale-pricing'); ?>
										</label>
									</th>
									<td class="forminp forminp-text">
										<input name="wc_quote_notifications[email_valid_msg]" id="wc_quote_email_valid_msg" type="text" placeholder="<?php echo esc_html__('Email Validation Message', 'woocommerce-wholesale-pricing'); ?>" value="<?php echo esc_attr( isset( $quote_notifications['email_valid_msg'] ) ? $quote_notifications['email_valid_msg'] : '' ); ?>">
										<p class="description"><?php echo esc_html__('This Text will show as notice when user input wrong email address', 'woocommerce-wholesale-pricing'); ?></p>
									</td>
								</tr>
								<tr valign="top">
									<th scope="row" class="titledesc">
										<?php echo esc_html__('Add To Quote Redirect', 'woocommerce-wholesale-pricing'); ?>
									</th>
									<td class="forminp forminp-checkbox">
										<p>
											<input class="inp-cbx" style="display: none" id="wc_quote_add_quote_redirect" type="checkbox" value="1" name="wc_quote_notifications[add_quote_redirect]" <?php checked(1, isset( $quote_notifications['add_quote_redirect'] ) && $quote_notifications['add_quote_redirect'], true); ?>>
											<label class="cbx cbx-square" for="wc_quote_add_quote_redirect">
												<span>
													<svg width="12px" height="9px" viewbox="0 0 12 9">
														<polyline points="1 5 4 8 11 1"></polyline>
													</svg>
												</span>
												<span><?php esc_html_e('Redirect page on add to quote success.', 'woocommerce-wholesale-pricing'); ?></span>
											</label>
										</p>
									</td>
								</tr>
								<tr valign="top">
									<th scope="row" class="titledesc">
										<label for="wc_quote_add_redirect_url"><?php echo esc_html__('Add To Quote Redirect URL', 'woocommerce-wholesale-pricing'); ?> </label>
									</th>
									<td class="forminp forminp-url">
										<input name="wc_quote_notifications[add_quote_redirect_url]" id="wc_quote_add_redirect_url" type="url" value="<?php echo esc_attr( isset( $quote_notifications['add_quote_redirect_url'] ) ? $quote_notifications['add_quote_redirect_url'] : '' ); ?>" placeholder="<?php echo esc_html__('https://www.example.com', 'woocommerce-wholesale-pricing'); ?>">
										<p class="description"><?php echo esc_html__('Enter url to redirect after add to quote success', 'woocommerce-wholesale-pricing'); ?></p>
									</td>
								</tr>
								<tr valign="top">
									<th scope="row" class="titledesc">
										<?php echo esc_html__('Send Quote Redirect', 'woocommerce-wholesale-pricing'); ?>
									</th>
									<td class="forminp forminp-checkbox">
										<p>
											<input class="inp-cbx" style="display: none" id="wc_quote_send_quote_redirect" type="checkbox" value="1" name="wc_quote_notifications[send_quote_redirect]" <?php checked(1, isset( $quote_notifications['send_quote_redirect'] ) && $quote_notifications['send_quote_redirect'], true); ?>>
											<label class="cbx cbx-square" for="wc_quote_send_quote_redirect">
												<span>
													<svg width="12px" height="9px" viewbox="0 0 12 9">
														<polyline points="1 5 4 8 11 1"></polyline>
													</svg>
												</span>
												<span><?php esc_html_e('Enable to redirect page on send quote success.', 'woocommerce-wholesale-pricing'); ?></span>
											</label>
										</p>

									</td>
								</tr>
								<tr valign="top">
									<th scope="row" class="titledesc">
										<label for="wc_quote_send_redirect_url"><?php echo esc_html__('Send Quote Redirect URL', 'woocommerce-wholesale-pricing'); ?> </label>
									</th>
									<td class="forminp forminp-url">
										<input name="wc_quote_notifications[send_quote_redirect_url]" id="wc_quote_send_redirect_url" type="url" value="<?php echo esc_attr( isset( $quote_notifications['send_quote_redirect_url'] ) ? $quote_notifications['send_quote_redirect_url'] : '' ); ?>" placeholder="<?php echo esc_html__('https://www.example.com', 'woocommerce-wholesale-pricing'); ?>">
										<p class="description"><?php echo esc_html__('Enter url to redirect after sending quote to admin success', 'woocommerce-wholesale-pricing'); ?></p>
									</td>
								</tr>
							</tbody>
						</tbody>
					</table>
				</div>
				
				<div role="tabpanel" class="tab-pane fade" id="section8">
					<table class="form-table wwp-main-settings">
						<tbody>
							<tr valign="top">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Enable PDF', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_enable_pdf" type="checkbox" value="1" name="wc_quote_pdf[enable_pdf]" <?php checked(1, isset( $quote_pdf['enable_pdf'] ) && $quote_pdf['enable_pdf'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_enable_pdf">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php echo esc_html__('Enable PDF feature', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
								
							<tr valign="top" class="enable_pdf_feature">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Enable PDF Download', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_enable_pdf_download" type="checkbox" value="1" name="wc_quote_pdf[enable_pdf_download]" <?php checked(1, isset( $quote_pdf['enable_pdf_download'] ) && $quote_pdf['enable_pdf_download'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_enable_pdf_download">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php echo esc_html__('Enable this option to allow users to download quote PDF from my account', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr valign="top" class="enable_pdf_feature">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Attach PDF in Email', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_enable_pdf_attach" type="checkbox" value="1" name="wc_quote_pdf[enable_pdf_attach]" <?php checked(1, isset( $quote_pdf['enable_pdf_attach'] ) && $quote_pdf['enable_pdf_attach'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_enable_pdf_attach">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php echo esc_html__('Enable this option to attach PDF in the quote email.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr valign="top" class="enable_pdf_feature" class="wc_quote_hide_product_list">
								<th scope="row" >
									<?php echo esc_html__('Hide Product List from Email', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_hide_product_list" type="checkbox" value="1" name="wc_quote_pdf[hide_product_list]" <?php checked(1, isset( $quote_pdf['hide_product_list'] ) && $quote_pdf['hide_product_list'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_hide_product_list">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php echo esc_html__('Hide Product list in the email content, if the PDF is attached to the email.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr valign="top" class="enable_pdf_feature">
								<th scope="row" class="titledesc">
									<label for="wc_settings_pdf_logo_email">
										<?php echo esc_html__('Upload Logo for PDF', 'woocommerce-wholesale-pricing'); ?>
									</label>
								</th>
								<td class="forminp forminp-pdf_upload">
									<fieldset>
										<legend class="screen-reader-text">
											<span><?php echo esc_html__('Upload logo to add in PDF Head', 'woocommerce-wholesale-pricing'); ?></span>
										</legend>
										<label for="wc_quote_pdf_logo">
											<img src="<?php echo esc_url( $pdf_logo_url ); ?>" width="60px" height="60px" id="wc_quote_pdf_logo">
										</label>
										<label for="wc_quote_pdf_logo_btn">
											<input type="hidden" id="wc_quote_pdf_logo_id" name="wc_quote_pdf[pdf_logo_id]" value="<?php echo esc_attr( isset( $quote_pdf['pdf_logo_id'] ) ? $quote_pdf['pdf_logo_id'] : '' ); ?>">
											<button type="button" class="upload_image_button wwp-button-primary button" style="margin-left: 5px;">
												<?php echo esc_html__('Upload/Add image', 'woocommerce-wholesale-pricing'); ?>
											</button>
											<button type="button" class="remove_image_button wwp-button-primary button">
												<?php echo esc_html__('Remove image', 'woocommerce-wholesale-pricing'); ?>
											</button>
										</label>
										<p class="description"><?php echo esc_html__('Upload logo to add in PDF Head', 'woocommerce-wholesale-pricing'); ?></p>
									</fieldset>
								</td>
							</tr>
							<script type="text/javascript">

								// Only show the "remove image" button when needed
								if ( ! jQuery( '#wc_quote_pdf_logo_id' ).val() ) {
									jQuery( '.remove_image_button' ).hide();
								}

								// Uploading files
								var file_frame;

								jQuery( document ).on( 'click', '.upload_image_button', function( event ) {

									event.preventDefault();

									// If the media frame already exists, reopen it.
									if ( file_frame ) {
										file_frame.open();
										return;
									}

									// Create the media frame.
									file_frame = wp.media.frames.downloadable_file = wp.media({
										title: 'Choose an image',
										button: {
											text: 'Use image'
										},
										multiple: false
									});

									// When an image is selected, run a callback.
									file_frame.on( 'select', function() {
										var attachment           = file_frame.state().get( 'selection' ).first().toJSON();
										var attachment_thumbnail = attachment.sizes.thumbnail || attachment.sizes.full;

										jQuery( '#wc_quote_pdf_logo_id' ).val( attachment.id );
										jQuery( '#wc_quote_pdf_logo' ).attr( 'src', attachment_thumbnail.url );
										jQuery( '.remove_image_button' ).show();
									});

									// Finally, open the modal.
									file_frame.open();
								});

								jQuery( document ).on( 'click', '.remove_image_button', function() {
									jQuery( '#wc_quote_pdf_logo' ).attr( 'src', '<?php echo esc_url(wc_placeholder_img_src()); ?>' );
									jQuery( '#wc_quote_pdf_logo_id' ).val( '' );
									jQuery( '.remove_image_button' ).hide();
									return false;
								});
							</script>
							<tr valign="top" class="enable_pdf_feature">
								<th scope="row" class="titledesc">
									<?php echo esc_html__('Show Link Accept & Checkout', 'woocommerce-wholesale-pricing'); ?>
								</th>
								<td class="forminp forminp-checkbox">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_pdf_show_link" type="checkbox" value="1" name="wc_quote_pdf[pdf_show_link]" <?php checked(1, isset( $quote_pdf['pdf_show_link'] ) && $quote_pdf['pdf_show_link'], true); ?>>
										<label class="cbx cbx-square" for="wc_quote_pdf_show_link">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php echo esc_html__('Enable this option show Accept & Checkout Link in PDF.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>

							<tr valign="top" class="enable_pdf_feature">
								<th scope="row" class="titledesc">
									<label for="wc_quote_pdf_template"><?php echo esc_html__('PDF Template', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td class="forminp forminp-radio">
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_default_pdf" type="radio" value="default" name="wc_quote_pdf[quote_pdf]" <?php checked( ( ( ! isset( $quote_pdf['quote_pdf'] ) ) || ( isset( $quote_pdf['quote_pdf'] ) && 'default' == $quote_pdf['quote_pdf'] ) ), true, true); ?>>
										<label class="cbx" for="wc_quote_default_pdf">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Default Template', 'woocommerce-wholesale-pricing'); ?></span>                                                
										</label>
									</p>
									<p>
										<input class="inp-cbx" style="display: none" id="wc_quote_custom_pdf" type="radio" value="custom" name="wc_quote_pdf[quote_pdf]" <?php checked( isset( $quote_pdf['quote_pdf'] ) && 'custom' == $quote_pdf['quote_pdf'], true, true); ?>>
										<label class="cbx" for="wc_quote_custom_pdf">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>                                                    
											<span><?php esc_html_e('Custom Template', 'woocommerce-wholesale-pricing'); ?></span>                                                    
										</label>
									</p>
									<p><?php esc_html_e('Select the Default Template or the Custom Template.', 'woocommerce-wholesale-pricing'); ?></p>
								</td>
							</tr>

							<tr valign="top" class="wc_quote_show_pdf enable_pdf_feature">
								<th scope="row" class="titledesc"></th>
								<td class="forminp forminp-radio">
										<?php
										$image_url = WWP_PUBLIC_URL . '/images/quote/pdf/';
										$img_src = array(
										'bronze' => $image_url . 'bronze.png',
										'darkblue' => $image_url . 'darkblue.png',
										'lightblue' => $image_url . 'lightblue.png',
										);
										// Start working here AQ
										foreach ( $img_src as $key => $value ) {    
											// Fetch the custom_pdf post with the matching pdf_color meta field
											$custom_pdf = get_posts(
												array(
												'post_type' => 'custom_pdf',
												'meta_key' => 'pdf_template_name',
												'meta_value' => $key, // Match the color key (e.g., bronze, darkblue, etc.)
												'posts_per_page' => 1,
												'fields' => 'ids', // Retrieve only the post ID
												)
											);
											// Check if a post was found
											$_post_id = isset($custom_pdf[0]) ? $custom_pdf[0] : null; 

											if ($_post_id) {

												if ( ! isset( $quote_pdf['custom'] ) ) {
													$quote_pdf['custom'] = 'bronze';
												}
												
												?>
											
											<label for="wc_quote_pdf_select_<?php echo esc_attr($key); ?>" class="wc_quote_pdf_wrapper"> 

											<img src="<?php echo esc_attr($value); ?>"  class="pdf_image_src">

											<input name="wc_quote_pdf[custom]" id="wc_quote_pdf_select_<?php echo esc_attr($key); ?>" type="radio" class="wc-quote-pdf-select" value="<?php echo esc_attr($key); ?>" <?php checked( $quote_pdf['custom'] == $key, true, true); ?>>

											<a href="<?php echo esc_attr($value); ?>" class="pdf_image_btn preview_image_btn" ><?php echo esc_html__('Preview', 'woocommerce-wholesale-pricing'); ?></a>
											
											<!-- Edit Button -->
											<a href="<?php echo esc_url(admin_url("post.php?post=$_post_id&action=edit")); ?>" class="pdf_image_btn edit_button" target="_blank"><?php echo esc_html__('Edit'/*, 'woocommerce-wholesale-pricing'*/); ?></a>
											</label>
											
												<?php
											}
										}
										?>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<div role="tabpanel" class="tab-pane fade" id="section9">
					<table class="form-table wwp-main-settings">
						<tbody>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Hide price', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<input class="inp-cbx" style="display: none" id="price_hide" type="checkbox" value="yes" name="options[price_hide]" <?php echo ( isset($settings['price_hide']) && 'yes' == $settings['price_hide'] ) ? 'checked' : ''; ?>>
									<label class="cbx cbx-square" for="price_hide">
										<span>
											<svg width="12px" height="9px" viewbox="0 0 12 9">
												<polyline points="1 5 4 8 11 1"></polyline>
											</svg>
										</span>
										<span><?php esc_html_e('Hide retail prices until user gets logged in', 'woocommerce-wholesale-pricing'); ?></span>                                                
									</label>
								</td>
							</tr>
							<tr scope="row" class="enhanced-multi-select">
								<th><label for=""><?php esc_html_e('Select Role', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<select name="options[price_hide_role][]" id="price_hide_role" class="wc-enhanced-select" multiple data-placeholder="<?php esc_html_e('Select roles to hide the price', 'woocommerce-wholesale-pricing'); ?>">
										<option value="guest" <?php selected( isset( $settings['price_hide_role'] ) && in_array( 'guest', (array) $settings['price_hide_role'], true ), true, true); ?>><?php esc_html_e('Guest', 'woocommerce-wholesale-pricing'); ?></option>
										<?php foreach ( wp_get_roles_except_wholesale() as $role_key => $role_name ) : ?>
											<option value="<?php echo esc_attr($role_key); ?>" <?php selected( isset( $settings['price_hide_role'] ) && in_array( $role_key, (array) $settings['price_hide_role'] ), true, true); ?>><?php echo esc_html($role_name); ?></option>
										<?php endforeach; ?>
									</select>
									<span data-tip="<?php esc_html_e('Select Multiple Roles to Hide the Price.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>

								</td>
							</tr>
							<tr scope="row">
								<th><label for="display_link_text"><?php esc_html_e('Label for login link', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td><input type="text" class="regular-text" name="options[display_link_text]" id="display_link_text" value="<?php echo ( isset($settings['display_link_text']) && ! empty( $settings['display_link_text'] ) ) ? esc_html($settings['display_link_text']) : 'Login to see price'; ?>" placeholder="<?php esc_html_e( 'Login to see price', 'woocommerce-wholesale-pricing' ); ?>">
								<span data-tip="<?php esc_html_e('This login link will appear on every product if Hide price option is checked', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
								</td>
							</tr>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Restrict wholesale store access', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<input class="inp-cbx" style="display: none" id="wholesaler_login_restriction" type="checkbox" value="yes" name="options[wholesaler_login_restriction]" <?php echo ( isset($settings['wholesaler_login_restriction']) && 'yes' == $settings['wholesaler_login_restriction'] ) ? 'checked' : ''; ?>>
									<label class="cbx cbx-square" for="wholesaler_login_restriction">
										<span>
											<svg width="12px" height="9px" viewbox="0 0 12 9">
												<polyline points="1 5 4 8 11 1"></polyline>
											</svg>
										</span>
										<span><?php esc_html_e('Enabling this option will allow only approved wholesale users to login.', 'woocommerce-wholesale-pricing'); ?></span>
									</label>
								</td>
							</tr>
							<tr scope="row">
								<th><label for="login_message_waiting_user"><?php esc_html_e('Custom message for pending request', 'woocommerce-wholesale-pricing'); ?></label></th>
								<?php
								if (empty($settings['login_message_waiting_user']) ) {
									$settings['login_message_waiting_user'] = __('You can not access this store, Your request status is in Pending', 'woocommerce-wholesale-pricing');
								}
								?>
								<td><input type="text" class="regular-text" name="options[login_message_waiting_user]" id="login_message_waiting_user" value="<?php echo isset($settings['login_message_waiting_user']) ? esc_html($settings['login_message_waiting_user']) : ''; ?>">
								<span data-tip="<?php esc_html_e('Enter message to display for pending request', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
								</td>
							</tr>
							<tr scope="row">
								<th><label for="login_message_rejected_user"><?php esc_html_e('Custom message for rejected request', 'woocommerce-wholesale-pricing'); ?></label></th>
								<?php
								if (empty($settings['login_message_rejected_user']) ) {
									$settings['login_message_rejected_user'] = __('You can not access this store, Your request is Rejected by admin', 'woocommerce-wholesale-pricing');
								}
								?>
								<td><input type="text" class="regular-text" name="options[login_message_rejected_user]" id="login_message_rejected_user" value="<?php echo isset($settings['login_message_rejected_user']) ? esc_html($settings['login_message_rejected_user']) : ''; ?>">
								<span data-tip="<?php esc_html_e('Enter message to display for rejected request', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
								</td>
							</tr>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Restrict Full Store Access', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<input class="inp-cbx" style="display: none" id="restrict_store_access" type="checkbox" value="yes" name="options[restrict_store_access]" <?php echo ( isset($settings['restrict_store_access']) && 'yes' == $settings['restrict_store_access'] ) ? 'checked' : ''; ?>>
									<label class="cbx cbx-square" for="restrict_store_access">
										<span>
											<svg width="12px" height="9px" viewbox="0 0 12 9">
												<polyline points="1 5 4 8 11 1"></polyline>
											</svg>
										</span>
										<span><?php esc_html_e('Restrict or Hide your store with Password', 'woocommerce-wholesale-pricing'); ?></span>
									</label>
								</td>
							</tr>
							<tr>
								<th>
									<label for="enable_store_access_cookie"><?php esc_html_e('Enable Cookie', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td>
									<input class="inp-cbx" style="display: none" id="enable_store_access_cookie" type="checkbox" value="yes" name="options[enable_store_access_cookie]" <?php echo ( isset($settings['enable_store_access_cookie']) && 'yes' == $settings['enable_store_access_cookie'] ) ? 'checked' : ''; ?>>
									<label class="cbx cbx-square" for="enable_store_access_cookie">
										<span>
											<svg width="12px" height="9px" viewbox="0 0 12 9">
												<polyline points="1 5 4 8 11 1"></polyline>
											</svg>
										</span>
										<span><?php esc_html_e('Enable your store cookie with a password', 'woocommerce-wholesale-pricing'); ?></span>
									</label>
								</td>
							</tr>
							<?php
								$style = 'display: none';
							if (isset($settings['enable_store_access_cookie']) && 'yes' == $settings['enable_store_access_cookie'] ) {
								$style = 'display: table-row';
							} 
							?>
							<tr class="wwp-cookie-interval" style="<?php echo esc_attr($style); ?>" >
								<th>
									<label for="wwp_cookie_interval"><?php esc_html_e('Cookie Interval', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td>
									<input type="number" min="1" class="regular-text" name="options[wwp_cookie_interval]" placeholder="<?php esc_html_e('Enter number of days', 'woocommerce-wholesale-pricing'); ?>" id="wwp_cookie_interval" value="<?php echo isset($settings['wwp_cookie_interval']) ? esc_html($settings['wwp_cookie_interval']) : '1'; ?>">
									<span data-tip="<?php esc_html_e('The store\'s cookie with a password will be deleted after the specified time interval.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
								</td>
							</tr>
							
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Restrict Store Access Message', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
								<?php $settings['restrict_store_access_message'] = isset($settings['restrict_store_access_message']) ? $settings['restrict_store_access_message'] : ''; ?>
								<textarea id="restrict_store_access_message" rows="7" name="options[restrict_store_access_message]" class="textarea"><?php echo wp_kses_post(wp_unslash($settings['restrict_store_access_message'])); ?></textarea> 
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<div role="tabpanel" class="tab-pane fade" id="section10">
					<table class="form-table wwp-main-settings">
						<tbody>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Restrict wholesale products visibility', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<input class="inp-cbx" style="display: none" id="wholesaler_prodcut_only" type="checkbox" value="yes" name="options[wholesaler_prodcut_only]" <?php echo ( isset($settings['wholesaler_prodcut_only']) && 'yes' == $settings['wholesaler_prodcut_only'] ) ? 'checked' : ''; ?>>
									<label class="cbx cbx-square" for="wholesaler_prodcut_only">
										<span>
											<svg width="12px" height="9px" viewbox="0 0 12 9">
												<polyline points="1 5 4 8 11 1"></polyline>
											</svg>
										</span>
										<span><?php esc_html_e('By enabling this option wholesale only products will be visible to wholesaler user roles only.', 'woocommerce-wholesale-pricing'); ?></span>
									</label>
								</td>
							</tr>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Restrict wholesale products globally from non-wholesaler customer.', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<input class="inp-cbx" style="display: none" id="non_wholesale_product_hide" type="checkbox" value="yes" name="options[non_wholesale_product_hide]" <?php echo ( isset($settings['non_wholesale_product_hide']) && 'yes' == $settings['non_wholesale_product_hide'] ) ? 'checked' : ''; ?>>
									<label class="cbx cbx-square" for="non_wholesale_product_hide">
										<span>
											<svg width="12px" height="9px" viewbox="0 0 12 9">
												<polyline points="1 5 4 8 11 1"></polyline>
											</svg>
										</span>
										<span><?php esc_html_e('Enable this option to hide wholesale products from retailers and non-logged in user.', 'woocommerce-wholesale-pricing'); ?></span>
									</label>
								</td>
							</tr>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Enforce minimum quantity rules', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<input class="inp-cbx" style="display: none" id="wholesaler_allow_minimum_qty" type="checkbox" value="yes" name="options[wholesaler_allow_minimum_qty]" <?php echo ( isset($settings['wholesaler_allow_minimum_qty']) && 'yes' == $settings['wholesaler_allow_minimum_qty'] ) ? 'checked' : ''; ?>>
									<label class="cbx cbx-square" for="wholesaler_allow_minimum_qty">
										<span>
											<svg width="12px" height="9px" viewbox="0 0 12 9">
												<polyline points="1 5 4 8 11 1"></polyline>
											</svg>
										</span>
										<span><?php esc_html_e('Enforce the wholesale customer to purchase with minimum quantity rules', 'woocommerce-wholesale-pricing'); ?></span>
									</label>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<div role="tabpanel" class="tab-pane fade" id="section11">
					<table class="form-table wwp-main-settings">
						<tbody>                                    
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Enable Upgrade Tab', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<input class="inp-cbx" style="display: none" id="enable_upgrade" type="checkbox" value="yes" name="options[enable_upgrade]" <?php echo ( isset($settings['enable_upgrade']) && 'yes' == $settings['enable_upgrade'] ) ? 'checked' : ''; ?>>
									<label class="cbx cbx-square" for="enable_upgrade">
										<span>
											<svg width="12px" height="9px" viewbox="0 0 12 9">
												<polyline points="1 5 4 8 11 1"></polyline>
											</svg>
										</span>
										<span><?php esc_html_e('Enable wholesale upgrade tab on my account page for non wholesale users', 'woocommerce-wholesale-pricing'); ?></span>
									</label>
								</td>
							</tr>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Request Again Submit', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<input class="inp-cbx" style="display: none" id="request_again_submit" type="checkbox" value="yes" name="options[request_again_submit]" <?php echo ( isset($settings['request_again_submit']) && 'yes' == $settings['request_again_submit'] ) ? 'checked' : ''; ?>>
									<label class="cbx cbx-square" for="request_again_submit">
										<span>
											<svg width="12px" height="9px" viewbox="0 0 12 9">
												<polyline points="1 5 4 8 11 1"></polyline>
											</svg>
										</span>
										<span><?php esc_html_e('Ability to enable submitting request again after rejection.', 'woocommerce-wholesale-pricing'); ?></span>
									</label>
								</td>
							</tr>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Upgrade Tab Text', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<label for="upgrade_tab_text">
										<input type="text" class="regular-text" name="options[upgrade_tab_text]" id="upgrade_tab_text" value="<?php echo isset($settings['upgrade_tab_text']) ? esc_html($settings['upgrade_tab_text']) : ''; ?>" Placeholder="Label for Upgrade to Wholesaler tab">
									</label>
									<span data-tip='<?php esc_html_e('Display any text you want on the "Upgrade to Wholesaler" tab.', 'woocommerce-wholesale-pricing'); ?>' class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
				
				<div role="tabpanel" class="tab-pane fade" id="section12">
					<table class="form-table wwp-main-settings">
						<tbody>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Payment Method', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
									<input class="inp-cbx" style="display: none" id="enable_custom_payment_method" type="checkbox" value="yes" name="options[enable_custom_payment_method]" <?php echo ( isset($settings['enable_custom_payment_method']) && 'yes' == $settings['enable_custom_payment_method'] ) ? 'checked' : ''; ?>>
									<label class="cbx cbx-square" for="enable_custom_payment_method">
										<span>
											<svg width="12px" height="9px" viewbox="0 0 12 9">
												<polyline points="1 5 4 8 11 1"></polyline>
											</svg>
										</span>
										<span><?php esc_html_e('Enable Custom Payment Method', 'woocommerce-wholesale-pricing'); ?></span>
									</label>
								</td>
							</tr>
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Payment Method Name', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td >
								<div id="payment_method_data">
									<?php 
									if (isset($settings['payment_method_name']) && !empty($settings['payment_method_name'])) {
										foreach ( (array) $settings['payment_method_name'] as $key => $payment_method_name_value) { 
											if (!empty($payment_method_name_value) ) { 
												?>
													<div class="panel_payment_method_name">
														<label for="payment_method_name">
															<input type="text" class="regular-text payment_method_name" readonly name="options[payment_method_name][<?php esc_attr_e($key); ?>]" 
															value="<?php esc_attr_e($key); ?>" 
															Placeholder="<?php esc_html_e('Enter Payment Method Name', 'woocommerce-wholesale-pricing'); ?>">
														</label>
														<span><a class="button removebtn"><?php esc_html_e('Remove', 'woocommerce-wholesale-pricing'); ?></a></span>
														<span><a class="button editbtn wwpeditbtn"><?php esc_html_e('Edit', 'woocommerce-wholesale-pricing'); ?></a></span>
													</div>
												<?php
											}
										} 
									}
									?>
								</div>     
									<div> <a class="button add_row_payment_method_name" ><?php esc_html_e('Add Method', 'woocommerce-wholesale-pricing'); ?></a> </div>
								</td>
							</tr>
						</tbody>
					</table>
					<script>
					
						jQuery(document).ready(function(){
							jQuery(".add_row_payment_method_name").click(function() {
								template  =    '<div class="panel_payment_method_name " ><label for="payment_method_name">';
								template  += '<input type="text" class="regular-text payment_method_name"  name="options[payment_method_name][]" value="" Placeholder="Enter Payment Method Name">';
								template  += '</label> <span><a class="button removebtn">Remove</a></span></div>';
								console.log(template);
								jQuery("#payment_method_data").append(template);
							});
							jQuery(document).on( 'click','.button.removebtn', function (e) {
								jQuery(this).closest(".panel_payment_method_name").remove();
							});
							
							jQuery(document).on( 'click','.button.wwpeditbtn', function (e) { 
								alert('Editing the title of the gateway will result in disconnection of wholesale roles from this gateway.');
								console.log(jQuery(this).closest(".panel_payment_method_name").find('.payment_method_name'));
								jQuery(this).closest(".panel_payment_method_name").find('.payment_method_name').removeAttr('readonly');
							});
						});
					</script>
				</div>

				<div role="tabpanel" class="tab-pane fade" id="section13">
					<table class="form-table wwp-main-settings">
						<tbody>
							<?php 
							/**
							 * Hooks
							 *
							 * @since 3.0
							 */
							do_action('registration_page_css_after', $settings); 
							?>
							<tr scope="row">
								<th colspan="2"><h2><?php esc_html_e('Additional CSS', 'woocommerce-wholesale-pricing'); ?></h2></th>
							</tr>
							
							<?php
							if (empty($settings['wholesale_css']) ) {
								$settings['wholesale_css'] = '/* Enter Your Custom CSS Here */';
							}
							?>
							
							<tr scope="row">
								<th><label for=""><?php esc_html_e('Registration Page CSS', 'woocommerce-wholesale-pricing'); ?></label></th>
								<td>
								<textarea id="code_editor_page_css" rows="15" name="options[wholesale_css]" class="widefat-100 textarea"><?php echo wp_kses_post(wp_unslash($settings['wholesale_css'])); ?></textarea>
								<p class="wwwp_help_text"><?php esc_html_e('Enter css without <style> tag.', 'woocommerce-wholesale-pricing'); ?></p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
				<div role="tabpanel" class="tab-pane fade" id="section14">
					<?php 
					/**
					 * Render multilipi UI
					 * 
					 * @since 3.1.0
					 */
					do_action( 'wwp_render_multilipi_ui' ); 
					?>
				</div>
				<div role="tabpanel" class="tab-pane fade" id="section15">
					<table class="form-table wwp-main-settings">
						<tbody>
							<tr scope="row">
								<th>
									<label for=""><?php esc_html_e('Enable Bulk Order Product Table', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="product_table" type="checkbox" value="yes" name="options[product_table]" <?php echo ( isset($settings['product_table']) && 'yes' == $settings['product_table'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="product_table">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Check this option to enable bulk order form product table.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr scope="row" class="wwp-quick-order-form-row"<?php echo ( ! isset( $settings['product_table'] ) || 'yes' !== $settings['product_table'] ) ? ' style="display:none;"' : ''; ?>>
								<th>
									<label for=""><?php esc_html_e('Enable Quick Order Form', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="quick_order_form" type="checkbox" value="yes" name="options[quick_order_form]" <?php echo ( isset($settings['quick_order_form']) && 'yes' == $settings['quick_order_form'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="quick_order_form">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Check this option to enable the quick order form.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
				<div role="tabpanel" class="tab-pane fade" id="section16">
					<table class="form-table wwp-main-settings">
						<tbody>
						<tr scope="row">
								<th>
									<label for=""><?php esc_html_e('Enable Sales Agent', 'woocommerce-wholesale-pricing'); ?></label>
									<span data-tip="<?php esc_html_e('Activate the Sales Agent module to assign sales agents who earn commissions on wholesale orders', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
								</th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="sales_agent" type="checkbox" value="yes" name="options[sales_agent]" <?php echo ( isset($settings['sales_agent']) && 'yes' == $settings['sales_agent'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="sales_agent">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('When enabled, admins can assign sales agents who earn commissions on wholesale orders'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr scope="row" class="sales_agent_enabled">
								<th>
									<label for=""><?php esc_html_e('Enable PayPal for Payouts', 'woocommerce-wholesale-pricing'); ?></label>
									<span data-tip="<?php esc_html_e('Allow sales agents to receive their commissions via PayPal', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
									<p><small><?php esc_html_e('Agents will be prompted to add their PayPal email address in their profile.', 'woocommerce-wholesale-pricing'); ?></small></p>
								</th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="sales_agent_paypal_payout" type="checkbox" value="yes" name="options[sales_agent_paypal_payout]" <?php echo ( isset($settings['sales_agent_paypal_payout']) && 'yes' == $settings['sales_agent_paypal_payout'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="sales_agent_paypal_payout">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Allow sales agents to receive commissions via PayPal.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr scope="row" class="sales_agent_enabled">
								<th>
									<label style="width:160px;" for=""><?php esc_html_e('Enable Bank Transfer for Payouts.', 'woocommerce-wholesale-pricing'); ?></label>
									<span data-tip="<?php esc_html_e('Allow sales agents to receive their commissions via bank transfer', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
									<p><small><?php esc_html_e('Agents will be prompted to add their bank details in their profile.', 'woocommerce-wholesale-pricing'); ?></small></p>
								</th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="sales_agent_bacs_payout" type="checkbox" value="yes" name="options[sales_agent_bacs_payout]" <?php echo ( isset($settings['sales_agent_bacs_payout']) && 'yes' == $settings['sales_agent_bacs_payout'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="sales_agent_bacs_payout">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Allow sales agents to receive commissions via bank transfer (BACS).', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
							<tr scope="row" id="sales_agent_default_agent" class="sales_agent_enabled">
								<th>
									<label for=""><?php esc_html_e('Default Sales Agent', 'woocommerce-wholesale-pricing'); ?></label>
									<span data-tip="<?php esc_html_e('New wholesale customers will be automatically assigned to this agent.', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>
									<p><small><?php esc_html_e('Can be overridden per-customer from the customer edit screen.', 'woocommerce-wholesale-pricing'); ?></small></p>
								</th>
								<td>
									<select id="sales_agent_default_agent_value" class="regular-text" name="options[sales_agent_default_agent]">
										<option value=""><?php esc_html_e('- Select Default Agent -', 'woocommerce-wholesale-pricing'); ?></option>
										<?php 
										$all_agents = get_posts(
											array(
												'post_type'   => 'agent',
												'numberposts' => -1,
											)
										);
										?>
										
										<?php foreach ( (array) $all_agents as $agent ) : ?>
											<option value="<?php echo esc_attr($agent->ID); ?>" <?php selected(( isset( $settings['sales_agent_default_agent'] ) && $settings['sales_agent_default_agent'] == $agent->ID ), true, true); ?>><?php echo esc_html($agent->post_title); ?></option>
										<?php endforeach; ?>
									</select>  
									
								</td>
							</tr>
						</tbody>
					</table>
				</div>
				<div role="tabpanel" class="tab-pane fade" id="section17">
					<table class="form-table wwp-main-settings">
						<tbody>
							<tr scope="row">
								<th>
									<label for=""><?php esc_html_e('Enable B2B Company Credits', 'woocommerce-wholesale-pricing'); ?></label>
								</th>
								<td>
									<p>
										<input class="inp-cbx" style="display: none" id="b2b_company_credits" type="checkbox" value="yes" name="options[b2b_company_credits]" <?php echo ( isset($settings['b2b_company_credits']) && 'yes' == $settings['b2b_company_credits'] ) ? 'checked' : ''; ?>>
										<label class="cbx cbx-square" for="b2b_company_credits">
											<span>
												<svg width="12px" height="9px" viewbox="0 0 12 9">
													<polyline points="1 5 4 8 11 1"></polyline>
												</svg>
											</span>
											<span><?php esc_html_e('Check this option to enable B2B Company Credit for Wholesale user role.', 'woocommerce-wholesale-pricing'); ?></span>
										</label>
									</p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

			</div>
	<div class="sep20px">&nbsp;</div>
	<div class="main-save-settings">
	<button name="save-wwp_wholesale" class="wwp-button-primary save-general-setting" type="submit" value="Save changes"><?php esc_html_e('Save changes', 'woocommerce-wholesale-pricing'); ?></button>
	</div>
	<div class="sep20px">&nbsp;</div>
		</div>

	</div>    
	</div>
	

</form>
