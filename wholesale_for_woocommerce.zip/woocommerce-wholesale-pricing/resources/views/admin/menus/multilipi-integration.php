<div class="wwp-multilipi-connect" style="padding: 24px 0; max-width: 680px;">

	<h3 style="margin-top: 0; display: flex; align-items: center; gap: 10px;">
		<span class="dashicons dashicons-translation" style="font-size: 24px; color: #5b8af7;"></span>
		<?php esc_html_e( 'MultiLipi — AI Multilingual SEO', 'woocommerce-wholesale-pricing' ); ?>
	</h3>

	<p style="color: #555;">
		<?php esc_html_e( 'Translate your wholesale store into multiple languages automatically. MultiLipi integrates directly here — no extra admin menu needed.', 'woocommerce-wholesale-pricing' ); ?>
	</p>

	<?php if ( isset( $_GET['wwp_mlms_error'] ) ) : ?>
		<div class="notice notice-error inline">
			<p><?php esc_html_e( 'Could not activate MultiLipi. Please try again or activate it from the Plugins screen.', 'woocommerce-wholesale-pricing' ); ?></p>
		</div>
	<?php endif; ?>

	<div style="margin-top: 16px;">
		<?php if ( $is_installed ) : ?>

			<?php
			// Build a nonce-protected URL that triggers wwp_handle_multilipi_activation().
			$activate_url = wp_nonce_url(
				add_query_arg(
					array(
						'action' => 'wwp_activate_multilipi',
					),
					admin_url( 'admin-post.php' )
				),
				'wwp_activate_multilipi'
			);
			?>
			<a href="<?php echo esc_url( $activate_url ); ?>" class="button button-primary">
				<?php esc_html_e( 'Activate MultiLipi', 'woocommerce-wholesale-pricing' ); ?>
			</a>
			<p class="description" style="margin-top: 8px;">
				<?php esc_html_e( 'MultiLipi is installed but not active. Click to activate it.', 'woocommerce-wholesale-pricing' ); ?>
			</p>

		<?php else : ?>

			<?php
			// Build a nonce-protected URL that triggers wwp_handle_multilipi_activation() for installation.
			$install_activate_url = wp_nonce_url(
				add_query_arg(
					array(
						'action' => 'wwp_install_activate_multilipi',
					),
					admin_url( 'admin-post.php' )
				),
				'wwp_install_activate_multilipi'
			);
			?>
			<a href="<?php echo esc_url( $install_activate_url ); ?>" class="button button-primary">
				<?php esc_html_e( 'Activate MultiLipi', 'woocommerce-wholesale-pricing' ); ?>
			</a>
			<p class="description" style="margin-top: 8px;">
				<?php esc_html_e( 'Install the free MultiLipi — AI Website Translation & Multilingual SEO plugin to get started.', 'woocommerce-wholesale-pricing' ); ?>
			</p>

		<?php endif; ?>
	</div>

</div>