<?php
/**
 * Dashboard menu template.
 *
 * @package WooCommerceWholesalePricing
 * @version 3.0.0
 */
?>
<div id="wholesale-dashboard"></div>