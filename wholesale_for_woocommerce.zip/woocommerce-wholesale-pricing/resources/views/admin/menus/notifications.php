<?php
	$quote_settings = get_option('wc_quote_email', array());
	$get_quote_email_setting = static function ( $key, $default = '' ) use ( $quote_settings ) {
		return isset($quote_settings[ $key ]) ? $quote_settings[ $key ] : $default;
	};
	$admin_email = $get_quote_email_setting('admin_email', get_bloginfo('admin_email'));
	?>
<div class="wrap">
	<form method="post" action="options.php">
		<?php settings_errors(); ?>
		<?php settings_fields('wwp_wholesale_request_notifications'); ?>
		<?php do_settings_sections('wwp_wholesale_request_notifications'); ?>

		<div class="tab" role="tabpanel">
			<!-- Nav tabs -->
			<ul id="blkTabs" class="nav nav-tabs" role="tablist">
				<li role="presentation">
					<a href="#section_notification1" role="tab" data-toggle="tab"><?php esc_html_e('Wholesale Registration Emails', 'woocommerce-wholesale-pricing'); ?></a>
				</li>
				<li role="presentation">
					<a href="#section_notification2" role="tab" data-toggle="tab"><?php esc_html_e('Subscription Upgrade', 'woocommerce-wholesale-pricing'); ?></a>
				</li>
				<li role="presentation">
					<a href="#section_notification3" role="tab" data-toggle="tab"><?php esc_html_e('Quote Emails', 'woocommerce-wholesale-pricing'); ?></a>
				</li>
			</ul>

			<!-- Tab panes -->
			<div class="tab-content tabs">
				<div role="tabpanel" class="tab-pane fade" id="section_notification1">
					<div id="accordion_notification">
						<!-- NEW REQUEST ADMIN NOTIFICATION -->
						<div class="card">
							<?php 
							$value = get_option('wwp_wholesale_admin_request_notification'); 
							$stop_notification = get_option('wwp_wholesale_stop_admin_notification');
							$to_others_notification = get_option('wwp_wholesale_send_notification_email_other');
							wp_enqueue_script('wc-enhanced-select');
							wp_enqueue_style('wwp-select2');
							?>
								<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_admin_notify" aria-expanded="false" aria-controls="collapse_admin_notify">
									<?php esc_html_e('Admin Notification (New Registration Request)', 'woocommerce-wholesale-pricing'); ?>
								<div class="wwp_signal">
								<?php
								if ('yes' === $value ) {
									?>
									<div class="wwp_circle wwp_circle_off">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on active">&nbsp;</div>
									<?php
								} else {
									?>
									<div class="wwp_circle wwp_circle_off active">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on">&nbsp;</div>
									<?php
								}
								?>
								</div>
							</button>                                        
							<div id="collapse_admin_notify" class="collapse" data-parent="#accordion_notification" >
								<div class="card-body">
									<table class="form-table wwp-main-settings">
										<tr>
											<th>
												<label for="wwp_wholesale_admin_request_notification"><?php esc_html_e('Role Request Notification', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input class="inp-cbx" style="display: none" type="checkbox" name="wwp_wholesale_admin_request_notification" value="yes" id="wwp_wholesale_admin_request_notification" <?php echo checked('yes', $value); ?>>
												<label class="cbx cbx-square" for="wwp_wholesale_admin_request_notification">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
													<span><?php esc_html_e('When checked, an Email will be sent to admin about the new requested User Role.', 'woocommerce-wholesale-pricing'); ?></span>
												</label>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wwp-wholesale-stop-admin-notification"><?php esc_html_e("Don't Send Notification Emails to Current Site Admin: ", 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input class="inp-cbx" style="display: none" type="checkbox" name="wwp_wholesale_stop_admin_notification" value="yes" id="wwp-wholesale-stop-admin-notification" <?php echo checked('yes', $stop_notification); ?>>
												<label class="cbx cbx-square" for="wwp-wholesale-stop-admin-notification">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
												</label>
												</br>
												<label class=""><?php esc_html_e(get_option('admin_email')); ?></label>
											</td>
										</tr>
										<!-- <tr>
											<th>
												<label for="wwp-wholesale-send-notification-email-other"><?php //esc_html_e( 'Send Email Notification To Other Than Admins:', 'woocommerce-wholesale-pricing' ); ?> </label>
											</th>
											<td>
												<input class="inp-cbx" style="display: none" type="checkbox" name="wwp_wholesale_send_notification_email_other" value="yes" id="wwp-wholesale-send-notification-email-other" <?php //echo checked( 'yes', $to_others_notification ); ?>>
												<label class="cbx cbx-square" for="wwp-wholesale-send-notification-email-other">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
												</label>
											</td>
										</tr> -->
										<?php
										$required = '';
										if ('yes' == $stop_notification ) {
											$required = 'required';
										}
										?>
										<tr scope="row" id="recipient-row">
											<th><label for=""><?php esc_html_e('Recipient(s)', 'woocommerce-wholesale-pricing'); ?></label></th>
											<td>
											<?php $value = get_option('wwp_wholesale_admin_request_recipient'); ?>
											<input <?php echo ! empty($required) ? esc_attr($required) : esc_attr($required); ?> id="wwp_wholesale_admin_request_recipient"  name="wwp_wholesale_admin_request_recipient"  type="text" class="widefat-100 regular-text" value="<?php echo esc_attr($value); ?>" >
											<span data-tip="<?php esc_html_e('Enter recipients (comma separated)', 'woocommerce-wholesale-pricing'); ?>" class="data-tip-top"><span class="woocommerce-help-tip"></span></span>                                
											</td>
										</tr>
										<tr>
											<th>
												<label for="wwp_wholesale_admin_request_subject"><?php esc_html_e('Email Subject', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php $value = get_option('wwp_wholesale_admin_request_subject'); ?>
												<input type="text" name="wwp_wholesale_admin_request_subject" id="wwp_wholesale_admin_request_subject" value="<?php echo esc_attr($value); ?>" class="widefat-100 regular-text"/>
											</td>
										</tr>
										
										<tr>
											<th>
												<label for="wwp_wholesale_admin_request_body"><?php esc_html_e('Message', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php
													$content = html_entity_decode(get_option('wwp_wholesale_admin_request_body'), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401);
													wp_editor(
														$content,
														'wwp_wholesale_admin_request_body',
														array( 'textarea_rows' => 3 )
													);
													
													?>
												<p><?php esc_html_e('Email body for the new requested user role. Use {first_name}, {last_name}, {username}, {email}, {date}, {time} tag in body to get user email.', 'woocommerce-wholesale-pricing'); ?></p>
												<?php echo wp_kses_post(email_placeholders_content()); ?>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>

						<!-- NEW USER REQUEST USER NOTIFICATION-->
						<div class="card">
							<?php $value = get_option('wwp_wholesale_user_registration_notification'); ?>
							<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_user_notify" aria-expanded="false" aria-controls="collapse_user_notify">
								<?php esc_html_e('User Notification (New Registration Request)', 'woocommerce-wholesale-pricing'); ?>
								<div class="wwp_signal">
								<?php
								if ('yes' === $value ) {
									?>
									<div class="wwp_circle wwp_circle_off">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on active">&nbsp;</div>
									<?php
								} else {
									?>
									<div class="wwp_circle wwp_circle_off active">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on">&nbsp;</div>
									<?php
								}
								?>
								</div>
							</button>                                        
							<div id="collapse_user_notify" class="collapse" data-parent="#accordion_notification" >
								<div class="card-body">
									<table class="form-table wwp-main-settings">
									<tr>
										<th>
											<label for="wwp_wholesale_user_registration_notification"><?php esc_html_e('Registration Notification', 'woocommerce-wholesale-pricing'); ?></label>
										</th>
										<td>                                                        
											<input class="inp-cbx" style="display: none" type="checkbox" name="wwp_wholesale_user_registration_notification" value="yes" id="wwp_wholesale_user_registration_notification" <?php echo checked('yes', $value); ?>>
											<label class="cbx cbx-square" for="wwp_wholesale_user_registration_notification">
												<span>
													<svg width="12px" height="9px" viewbox="0 0 12 9">
														<polyline points="1 5 4 8 11 1"></polyline>
													</svg>
												</span>
												<span><?php esc_html_e('When checked, an Email will be sent to user registration requested	.', 'woocommerce-wholesale-pricing'); ?></span>
											</label>
										</td>
									</tr>
									<tr>
										<th>
											<label for="wwp_wholesale_registration_notification_subject"><?php esc_html_e('Email Subject', 'woocommerce-wholesale-pricing'); ?></label>
										</th>
										<td>
											<?php $value = get_option('wwp_wholesale_registration_notification_subject'); ?>
											<input type="text" name="wwp_wholesale_registration_notification_subject" id="wwp_wholesale_registration_notification_subject" value="<?php echo esc_attr($value); ?>" class="widefat-100 regular-text"/>
										</td>
									</tr>
									<tr>
										<th>
											<label for="wwp_wholesale_registration_notification_body"><?php esc_html_e('Message', 'woocommerce-wholesale-pricing'); ?></label>
										</th>
										<td>
											<?php
												$content = html_entity_decode(get_option('wwp_wholesale_registration_notification_body'), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401);
												wp_editor(
													$content,
													'wwp_wholesale_registration_notification_body',
													array( 'textarea_rows' => 3 )
												);
												?>
											<p><?php esc_html_e('Email body for the new registration user role. Use {first_name}, {last_name}, {username}, {email}, {date}, {time} tag in body to get user email.', 'woocommerce-wholesale-pricing'); ?></p>
											<?php echo wp_kses_post(email_placeholders_content()); ?>
										</td>
									</tr>
									</table>
								</div>
							</div>
						</div>

						<div class="card">
							<?php $value = get_option('wwp_wholesale_user_rejection_notification'); ?>
							<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_user_notify_rejected" aria-expanded="false" aria-controls="collapse_user_notify_rejected">
								<?php esc_html_e('User Notification (Registration Request Rejection Notification)', 'woocommerce-wholesale-pricing'); ?>
								<div class="wwp_signal">
								<?php
								if ('yes' === $value ) {
									?>
									<div class="wwp_circle wwp_circle_off">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on active">&nbsp;</div>
									<?php
								} else {
									?>
									<div class="wwp_circle wwp_circle_off active">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on">&nbsp;</div>
									<?php
								}
								?>
								</div>
							</button>                                        
							<div id="collapse_user_notify_rejected" class="collapse" data-parent="#accordion_notification" >
								<div class="card-body">
									<table class="form-table wwp-main-settings">
										<tr>
											<th>
												<label for="wwp_wholesale_user_rejection_notification"><?php esc_html_e('Rejection Notification', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>                                                        
												<input class="inp-cbx" style="display: none" type="checkbox" name="wwp_wholesale_user_rejection_notification" value="yes" id="wwp_wholesale_user_rejection_notification" <?php echo checked('yes', $value); ?>>
												<label class="cbx cbx-square" for="wwp_wholesale_user_rejection_notification">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
													<span><?php esc_html_e('When checked, an Email will be sent to user Rejection requested.', 'woocommerce-wholesale-pricing'); ?></span>
												</label>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wwp_wholesale_rejection_notification_subject"><?php esc_html_e('Email Subject', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php $value = get_option('wwp_wholesale_rejection_notification_subject'); ?>
												<input type="text" name="wwp_wholesale_rejection_notification_subject" id="wwp_wholesale_rejection_notification_subject" value="<?php echo esc_attr($value); ?>" class="widefat-100 regular-text"/>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wwp_wholesale_rejection_notification_body"><?php esc_html_e('Message', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php
													$content = html_entity_decode(get_option('wwp_wholesale_rejection_notification_body'), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401);
													wp_editor(
														$content,
														'wwp_wholesale_rejection_notification_body',
														array( 'textarea_rows' => 3 )
													);
													?>
												<p><?php esc_html_e('Email body for the new rejection user role. Use {first_name}, {last_name}, {username}, {email}, {date}, {time} tag in body to get user email.', 'woocommerce-wholesale-pricing'); ?></p>
												<?php echo wp_kses_post(email_placeholders_content()); ?>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>

						<div class="card">
							<?php $value = get_option('wwp_wholesale_request_approve_notification'); ?>
							<button onclick="return false;" class="btn btn-link" data-toggle="collapse" data-target="#collapse_user_notify_approved" aria-expanded="false" aria-controls="collapse_user_notify_approved">
								<?php esc_html_e('User Notification (Registration Request Approval Notification)', 'woocommerce-wholesale-pricing'); ?>
								<div class="wwp_signal">
								<?php
								if ('yes' === $value ) {
									?>
									<div class="wwp_circle wwp_circle_off">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on active">&nbsp;</div>
									<?php
								} else {
									?>
									<div class="wwp_circle wwp_circle_off active">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on">&nbsp;</div>
									<?php
								}
								?>
								</div>
							</button>                                        
							<div id="collapse_user_notify_approved" class="collapse" data-parent="#accordion_notification" >
								<div class="card-body">
									<table class="form-table wwp-main-settings">
										<tr>
											<th>
												<label for="wwp_wholesale_request_approve_notification"><?php esc_html_e('Request Approval Email', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>                                                                                                                    
												<input class="inp-cbx" style="display: none" type="checkbox" name="wwp_wholesale_request_approve_notification" value="yes" id="wwp_wholesale_request_approve_notification" <?php echo checked('yes', $value); ?>>
												<label class="cbx cbx-square" for="wwp_wholesale_request_approve_notification">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
													<span><?php esc_html_e('When checked, an Email will be sent to user about the approval of their requested User Role.', 'woocommerce-wholesale-pricing'); ?></span>
												</label>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wwp_wholesale_email_request_subject"><?php esc_html_e('Email Subject', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php $value = get_option('wwp_wholesale_email_request_subject'); ?>
												<input type="text" name="wwp_wholesale_email_request_subject" id="wwp_wholesale_email_request_subject" value="<?php echo esc_attr($value); ?>" class="widefat-100 regular-text"/>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wwp_wholesale_email_request_body"><?php esc_html_e('Message', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php
													$content = html_entity_decode(get_option('wwp_wholesale_email_request_body'), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401);
													wp_editor(
														$content,
														'wwp_wholesale_email_request_body',
														array( 'textarea_rows' => 3 )
													);
													?>
												<p><?php esc_html_e('Email body for the approval of User Role request. Use {first_name}, {last_name}, {username}, {email}, {date}, {time} tag in body to get user email.', 'woocommerce-wholesale-pricing'); ?></p>
												<?php echo wp_kses_post(email_placeholders_content()); ?>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div role="tabpanel" class="tab-pane fade" id="section_notification2">
					<div id="accordion_notification_subscription">
						<!-- USER REJECTION NOTIFICATION -->
						<div class="card">
							<?php $value = get_option('wwp_wholesale_subscription_role_notification'); ?>
							<button onclick="return false;" class="btn btn-link" data-toggle="collapse" data-target="#collapse_subscription_notification" aria-expanded="true" aria-controls="collapse_subscription_notification">
								<?php esc_html_e('User Role Upgrade Notification', 'woocommerce-wholesale-pricing'); ?>
								<div class="wwp_signal">
								<?php
								if ('yes' === $value ) {
									?>
									<div class="wwp_circle wwp_circle_off">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on active">&nbsp;</div>
									<?php
								} else {
									?>
									<div class="wwp_circle wwp_circle_off active">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on">&nbsp;</div>
									<?php
								}
								?>
								</div>
							</button>                                        
							<div id="collapse_subscription_notification" class="collapse show" data-parent="#accordion_notification_subscription" >
								<div class="card-body">
									<table class="form-table wwp-main-settings">
										<?php
										/**
										 * Hooks
										 *
										 * @since 3.0
										 */
										if (wwp_is_subscription_active() ) {
											?>
											<tr>
												<th>
													<label for="wwp_wholesale_subscription_role_notification"><?php esc_html_e('Enable Role Upgrade Notification', 'woocommerce-wholesale-pricing'); ?></label>
												</th>
												<td>
													<input class="inp-cbx" style="display: none" type="checkbox" name="wwp_wholesale_subscription_role_notification" value="yes" id="wwp_wholesale_subscription_role_notification" <?php echo checked('yes', $value); ?>>
													<label class="cbx cbx-square" for="wwp_wholesale_subscription_role_notification">
														<span>
															<svg width="12px" height="9px" viewbox="0 0 12 9">
																<polyline points="1 5 4 8 11 1"></polyline>
															</svg>
														</span>
														<span><?php esc_html_e('When checked, an Email will be sent to user on the role upgrade after subscription.', 'woocommerce-wholesale-pricing'); ?></span>
													</label>
												</td>
											</tr>
											<tr>
												<th>
													<label for="wwp_wholesale_subscription_role_subject"><?php esc_html_e('Email Subject', 'woocommerce-wholesale-pricing'); ?></label>
												</th>
												<td>
													<?php $value = get_option('wwp_wholesale_subscription_role_subject'); ?>
													<input type="text" name="wwp_wholesale_subscription_role_subject" id="wwp_wholesale_subscription_role_subject" value="<?php echo esc_attr($value); ?>" class="widefat-100 regular-text"/>
												</td>
											</tr>
											<tr>
												<th>
													<label for="wwp_wholesale_subscription_role_body"><?php esc_html_e('Message', 'woocommerce-wholesale-pricing'); ?></label>
												</th>
												<td>
													<?php
														$content = html_entity_decode(get_option('wwp_wholesale_subscription_role_body'), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401);
														wp_editor(
															$content,
															'wwp_wholesale_subscription_role_body',
															array( 'textarea_rows' => 3 )
														);
													?>
													<p><?php esc_html_e('Email body for the role upgrade after subscription. Use {first_name}, {last_name}, {username}, {date}, {time}, {email} & {role} tag in body to get user email.', 'woocommerce-wholesale-pricing'); ?></p>
												</td>
											</tr>
											<?php
										} else {
											esc_html_e('You need to enable Woocommerce Subscription plugin.', 'woocommerce-wholesale-pricing');
										}
										?>
										<!-- ends version 1.3.0 -->
									</table>
								</div>
								
							</div>
						</div>
					</div>
				</div>

				<div role="tabpanel" class="tab-pane fade" id="section_notification3">
					<div id="accordion_notification">
						<table class="form-table">
							<tbody>
								<tr valign="top">
									<th scope="row" class="titledesc">
										<label for="wc_quote_admin_email">
											<?php echo esc_html__('Admin Email', 'woocommerce-wholesale-pricing'); ?>
										</label>
									</th>
									<td class="forminp forminp-email">
										<input name="wc_quote_email[admin_email]" id="wc_quote_admin_email" type="email" placeholder="someone@example.com" value="<?php echo esc_attr($admin_email); ?>">
										<p class="description"><?php echo esc_html__('Leave this blank to use default admin email', 'woocommerce-wholesale-pricing'); ?></p>
									</td>
								</tr>
							</tbody>
						</table>

						<!-- New Request Admin -->
						<div class="card">
								<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_new_quote_request" aria-expanded="false" aria-controls="collapse_new_quote_request">
									<?php esc_html_e('Admin (New Quote Request)', 'woocommerce-wholesale-pricing'); ?>
								<div class="wwp_signal">
								<?php
								if ('1' === $get_quote_email_setting('new_admin_email_enable') ) {
									?>
									<div class="wwp_circle wwp_circle_off">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on active">&nbsp;</div>
									<?php
								} else {
									?>
									<div class="wwp_circle wwp_circle_off active">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on">&nbsp;</div>
									<?php
								}
								?>
								</div>
							</button>                                        
							<div id="collapse_new_quote_request" class="collapse" data-parent="#accordion_notification" >
								<div class="card-body">
									<table class="form-table wwp-main-settings">
										<tr>
											<th>
												<label for="wc_quote_new_admin_email_enable"><?php esc_html_e('Enable', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input class="inp-cbx" style="display: none" type="checkbox" name="wc_quote_email[new_admin_email_enable]" value="1" id="wc_quote_new_admin_email_enable" <?php checked('1', (string) $get_quote_email_setting('new_admin_email_enable')); ?>>
												<label class="cbx cbx-square" for="wc_quote_new_admin_email_enable">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
												</label>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wc_quote_new_admin_email_subject"><?php esc_html_e('Subject', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input type="text" name="wc_quote_email[new_admin_email_subject]" id="wc_quote_new_admin_email_subject" value="<?php echo esc_attr($get_quote_email_setting('new_admin_email_subject')); ?>" class="widefat-100 regular-text"/>
											</td>
										</tr>
										
										<tr>
											<th>
												<label for="wc_quote_new_admin_email_msg"><?php esc_html_e('Message', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php
													wp_editor(
														html_entity_decode((string) $get_quote_email_setting('new_admin_email_msg'), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401),
														'wc_quote_new_admin_email_msg',
														array( 
															'textarea_name' => 'wc_quote_email[new_admin_email_msg]',
															'textarea_rows' => 5, 
														)
													);
													?>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>

						<!-- New Request Customer -->
						 <div class="card">
								<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_new_quote_request_customer" aria-expanded="false" aria-controls="collapse_new_quote_request_customer">
									<?php esc_html_e('Customer (New Quote Request)', 'woocommerce-wholesale-pricing'); ?>
								<div class="wwp_signal">
								<?php
								if ('1' === $get_quote_email_setting('new_user_email_enable') ) {
									?>
									<div class="wwp_circle wwp_circle_off">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on active">&nbsp;</div>
									<?php
								} else {
									?>
									<div class="wwp_circle wwp_circle_off active">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on">&nbsp;</div>
									<?php
								}
								?>
								</div>
							</button>                                        
							<div id="collapse_new_quote_request_customer" class="collapse" data-parent="#accordion_notification" >
								<div class="card-body">
									<table class="form-table wwp-main-settings">
										<tr>
											<th>
												<label for="wc_quote_new_user_email_enable"><?php esc_html_e('Enable', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input class="inp-cbx" style="display: none" type="checkbox" name="wc_quote_email[new_user_email_enable]" value="1" id="wc_quote_new_user_email_enable" <?php checked('1', (string) $get_quote_email_setting('new_user_email_enable')); ?>>
												<label class="cbx cbx-square" for="wc_quote_new_user_email_enable">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
												</label>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wc_quote_new_user_email_subject"><?php esc_html_e('Subject', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input type="text" name="wc_quote_email[new_user_email_subject]" id="wc_quote_new_user_email_subject" value="<?php echo esc_attr($get_quote_email_setting('new_user_email_subject')); ?>" class="widefat-100 regular-text"/>
											</td>
										</tr>
										
										<tr>
											<th>
												<label for="wc_quote_new_user_email_msg"><?php esc_html_e('Message', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php
													wp_editor(
														html_entity_decode((string) $get_quote_email_setting('new_user_email_msg'), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401),
														'wc_quote_new_user_email_msg',
														array( 
															'textarea_name' => 'wc_quote_email[new_user_email_msg]',
															'textarea_rows' => 5, 
														)
													);
													?>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>

						<!-- Pending Quoted Request Admin -->
						 <div class="card">
								<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_new_quoted_request_admin" aria-expanded="false" aria-controls="collapse_new_quoted_request_admin">
									<?php esc_html_e('Admin (Pending Quoted Request)', 'woocommerce-wholesale-pricing'); ?>
								<div class="wwp_signal">
								<?php
								if ('1' === $get_quote_email_setting('quoted_admin_email_enable')) {
									?>
									<div class="wwp_circle wwp_circle_off">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on active">&nbsp;</div>
									<?php
								} else {
									?>
									<div class="wwp_circle wwp_circle_off active">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on">&nbsp;</div>
									<?php
								}
								?>
								</div>
							</button>                                        
							<div id="collapse_new_quoted_request_admin" class="collapse" data-parent="#accordion_notification" >
								<div class="card-body">
									<table class="form-table wwp-main-settings">
										<tr>
											<th>
												<label for="wc_quote_admin_email_enable"><?php esc_html_e('Enable', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input class="inp-cbx" style="display: none" type="checkbox" name="wc_quote_email[quoted_admin_email_enable]" value="1" id="wc_quote_admin_email_enable" <?php checked('1', (string) $get_quote_email_setting('quoted_admin_email_enable')); ?>>
												<label class="cbx cbx-square" for="wc_quote_admin_email_enable">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
												</label>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wc_quoted_admin_email_subject"><?php esc_html_e('Subject', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input type="text" name="wc_quote_email[quoted_admin_email_subject]" id="wc_quoted_admin_email_subject" value="<?php echo esc_attr($get_quote_email_setting('quoted_admin_email_subject')); ?>" class="widefat-100 regular-text"/>
											</td>
										</tr>
										
										<tr>
											<th>
												<label for="wc_quote_admin_email_msg"><?php esc_html_e('Message', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php
													wp_editor(
														html_entity_decode((string) $get_quote_email_setting('quoted_admin_email_msg'), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401),
														'wc_quote_admin_email_msg',
														array( 
															'textarea_name' => 'wc_quote_email[quoted_admin_email_msg]',
															'textarea_rows' => 5, 
														)
													);
													?>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>

						<!-- Pending Quoted Request Customer -->
						 <div class="card">
								<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_new_quoted_request_customer" aria-expanded="false" aria-controls="collapse_new_quoted_request_customer">
									<?php esc_html_e('Customer (Pending Quoted Request)', 'woocommerce-wholesale-pricing'); ?>
								<div class="wwp_signal">
								<?php
								if ('1' === $get_quote_email_setting('quoted_user_email_enable') ) {
									?>
									<div class="wwp_circle wwp_circle_off">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on active">&nbsp;</div>
									<?php
								} else {
									?>
									<div class="wwp_circle wwp_circle_off active">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on">&nbsp;</div>
									<?php
								}
								?>
								</div>
							</button>                                        
							<div id="collapse_new_quoted_request_customer" class="collapse" data-parent="#accordion_notification" >
								<div class="card-body">
									<table class="form-table wwp-main-settings">
										<tr>
											<th>
												<label for="wc_quote_user_email_enable"><?php esc_html_e('Enable', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input class="inp-cbx" style="display: none" type="checkbox" name="wc_quote_email[quoted_user_email_enable]" value="1" id="wc_quote_user_email_enable" <?php checked('1', (string) $get_quote_email_setting('quoted_user_email_enable')); ?>>
												<label class="cbx cbx-square" for="wc_quote_user_email_enable">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
												</label>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wc_quote_user_email_subject"><?php esc_html_e('Subject', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input type="text" name="wc_quote_email[quoted_user_email_subject]" id="wc_quote_user_email_subject" value="<?php echo esc_attr($get_quote_email_setting('quoted_user_email_subject')); ?>" class="widefat-100 regular-text"/>
											</td>
										</tr>
										
										<tr>
											<th>
												<label for="wc_quote_user_email_msg"><?php esc_html_e('Message', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php
													wp_editor(
														html_entity_decode((string) $get_quote_email_setting('quoted_user_email_msg'), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401),
														'wc_quote_user_email_msg',
														array( 
															'textarea_name' => 'wc_quote_email[quoted_user_email_msg]',
															'textarea_rows' => 5, 
														)
													);
													?>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wc_quote_user_show_link"><?php esc_html_e('Enable accept & checkout link in customer email quoted.', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input class="inp-cbx" style="display: none" type="checkbox" name="wc_quote_email[quoted_user_show_link]" value="1" id="wc_quote_user_show_link" <?php checked('1', (string) $get_quote_email_setting('quoted_user_show_link')); ?>>
												<label class="cbx cbx-square" for="wc_quote_user_show_link">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
												</label>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>

						<!-- Accepted Quote Request Admin -->
						 <div class="card">
								<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_quoted_request_accepeted_admin" aria-expanded="false" aria-controls="collapse_quoted_request_accepeted_admin">
									<?php esc_html_e('Admin (Accepted Quote Request)', 'woocommerce-wholesale-pricing'); ?>
								<div class="wwp_signal">
								<?php
								if ('1' === $get_quote_email_setting('accepted_admin_email_enable') ) {
									?>
									<div class="wwp_circle wwp_circle_off">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on active">&nbsp;</div>
									<?php
								} else {
									?>
									<div class="wwp_circle wwp_circle_off active">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on">&nbsp;</div>
									<?php
								}
								?>
								</div>
							</button>                                        
							<div id="collapse_quoted_request_accepeted_admin" class="collapse" data-parent="#accordion_notification" >
								<div class="card-body">
									<table class="form-table wwp-main-settings">
										<tr>
											<th>
												<label for="wc_quote_accepted_admin_email_enable"><?php esc_html_e('Enable', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input class="inp-cbx" style="display: none" type="checkbox" name="wc_quote_email[accepted_admin_email_enable]" value="1" id="wc_quote_accepted_admin_email_enable" <?php checked('1', (string) $get_quote_email_setting('accepted_admin_email_enable')); ?>>
												<label class="cbx cbx-square" for="wc_quote_accepted_admin_email_enable">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
												</label>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wc_quote_accepted_admin_email_subject"><?php esc_html_e('Subject', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input type="text" name="wc_quote_email[accepted_admin_email_subject]" id="wc_quote_accepted_admin_email_subject" value="<?php echo esc_attr($get_quote_email_setting('accepted_admin_email_subject')); ?>" class="widefat-100 regular-text"/>
											</td>
										</tr>
										
										<tr>
											<th>
												<label for="wc_quote_accepted_admin_email_msg"><?php esc_html_e('Message', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php
													wp_editor(
														html_entity_decode((string) $get_quote_email_setting('accepted_admin_email_msg'), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401),
														'wc_quote_accepted_admin_email_msg',
														array( 
															'textarea_name' => 'wc_quote_email[accepted_admin_email_msg]',
															'textarea_rows' => 5, 
														)
													);
													?>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>

						<!-- Accepted Quote Request Customer -->
						 <div class="card">
								<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_quoted_request_accepeted_customer" aria-expanded="false" aria-controls="collapse_quoted_request_accepeted_customer">
									<?php esc_html_e('Customer (Accepted Quote Request)', 'woocommerce-wholesale-pricing'); ?>
								<div class="wwp_signal">
								<?php
								if ('1' === $get_quote_email_setting('accepted_user_email_enable') ) {
									?>
									<div class="wwp_circle wwp_circle_off">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on active">&nbsp;</div>
									<?php
								} else {
									?>
									<div class="wwp_circle wwp_circle_off active">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on">&nbsp;</div>
									<?php
								}
								?>
								</div>
							</button>                                        
							<div id="collapse_quoted_request_accepeted_customer" class="collapse" data-parent="#accordion_notification" >
								<div class="card-body">
									<table class="form-table wwp-main-settings">
										<tr>
											<th>
												<label for="wc_quote_accepted_user_email_enable"><?php esc_html_e('Enable', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input class="inp-cbx" style="display: none" type="checkbox" name="wc_quote_email[accepted_user_email_enable]" value="1" id="wc_quote_accepted_user_email_enable" <?php checked('1', (string) $get_quote_email_setting('accepted_user_email_enable')); ?>>
												<label class="cbx cbx-square" for="wc_quote_accepted_user_email_enable">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
												</label>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wc_quote_accepted_user_email_subject"><?php esc_html_e('Subject', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input type="text" name="wc_quote_email[accepted_user_email_subject]" id="wc_quote_accepted_user_email_subject" value="<?php echo esc_attr($get_quote_email_setting('accepted_user_email_subject')); ?>" class="widefat-100 regular-text"/>
											</td>
										</tr>
										
										<tr>
											<th>
												<label for="wc_quote_accepted_user_email_msg"><?php esc_html_e('Message', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php
													wp_editor(
														html_entity_decode((string) $get_quote_email_setting('accepted_user_email_msg'), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401),
														'wc_quote_accepted_user_email_msg',
														array( 
															'textarea_name' => 'wc_quote_email[accepted_user_email_msg]',
															'textarea_rows' => 5, 
														)
													);
													?>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>

						<!-- Rejected Quote Request Admin -->
						 <div class="card">
								<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_quoted_request_rejected_admin" aria-expanded="false" aria-controls="collapse_quoted_request_rejected_admin">
									<?php esc_html_e('Admin (Rejected Quote Request)', 'woocommerce-wholesale-pricing'); ?>
								<div class="wwp_signal">
								<?php
								if ('1' === $get_quote_email_setting('rejected_admin_email_enable') ) {
									?>
									<div class="wwp_circle wwp_circle_off">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on active">&nbsp;</div>
									<?php
								} else {
									?>
									<div class="wwp_circle wwp_circle_off active">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on">&nbsp;</div>
									<?php
								}
								?>
								</div>
							</button>                                        
							<div id="collapse_quoted_request_rejected_admin" class="collapse" data-parent="#accordion_notification" >
								<div class="card-body">
									<table class="form-table wwp-main-settings">
										<tr>
											<th>
												<label for="wc_quote_rejected_admin_email_enable"><?php esc_html_e('Enable', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input class="inp-cbx" style="display: none" type="checkbox" name="wc_quote_email[rejected_admin_email_enable]" value="1" id="wc_quote_rejected_admin_email_enable" <?php checked('1', (string) $get_quote_email_setting('rejected_admin_email_enable')); ?>>
												<label class="cbx cbx-square" for="wc_quote_rejected_admin_email_enable">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
												</label>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wc_quote_rejected_admin_email_subject"><?php esc_html_e('Subject', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input type="text" name="wc_quote_email[rejected_admin_email_subject]" id="wc_quote_rejected_admin_email_subject" value="<?php echo esc_attr($get_quote_email_setting('rejected_admin_email_subject')); ?>" class="widefat-100 regular-text"/>
											</td>
										</tr>
										
										<tr>
											<th>
												<label for="wc_quote_rejected_admin_email_msg"><?php esc_html_e('Message', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php
													wp_editor(
														html_entity_decode((string) $get_quote_email_setting('rejected_admin_email_msg'), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401),
														'wc_quote_rejected_admin_email_msg',
														array( 
															'textarea_name' => 'wc_quote_email[rejected_admin_email_msg]',
															'textarea_rows' => 5, 
														)
													);
													?>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>

						<!-- Rejected Quote Request Customer -->
						 <div class="card">
								<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_quoted_request_rejected_customer" aria-expanded="false" aria-controls="collapse_quoted_request_rejected_customer">
									<?php esc_html_e('Customer (Rejected Quote Request)', 'woocommerce-wholesale-pricing'); ?>
								<div class="wwp_signal">
								<?php
								if ('1' === $get_quote_email_setting('rejected_user_email_enable') ) {
									?>
									<div class="wwp_circle wwp_circle_off">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on active">&nbsp;</div>
									<?php
								} else {
									?>
									<div class="wwp_circle wwp_circle_off active">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on">&nbsp;</div>
									<?php
								}
								?>
								</div>
							</button>                                        
							<div id="collapse_quoted_request_rejected_customer" class="collapse" data-parent="#accordion_notification" >
								<div class="card-body">
									<table class="form-table wwp-main-settings">
										<tr>
											<th>
												<label for="wc_quote_rejected_user_email_enable"><?php esc_html_e('Enable', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input class="inp-cbx" style="display: none" type="checkbox" name="wc_quote_email[rejected_user_email_enable]" value="1" id="wc_quote_rejected_user_email_enable" <?php checked('1', (string) $get_quote_email_setting('rejected_user_email_enable')); ?>>
												<label class="cbx cbx-square" for="wc_quote_rejected_user_email_enable">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
												</label>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wc_quote_rejected_user_email_subject"><?php esc_html_e('Subject', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input type="text" name="wc_quote_email[rejected_user_email_subject]" id="wc_quote_rejected_user_email_subject" value="<?php echo esc_attr($get_quote_email_setting('rejected_user_email_subject')); ?>" class="widefat-100 regular-text"/>
											</td>
										</tr>
										
										<tr>
											<th>
												<label for="wc_quote_rejected_user_email_msg"><?php esc_html_e('Message', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php
													wp_editor(
														html_entity_decode((string) $get_quote_email_setting('rejected_user_email_msg'), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401),
														'wc_quote_rejected_user_email_msg',
														array( 
															'textarea_name' => 'wc_quote_email[rejected_user_email_msg]',
															'textarea_rows' => 5, 
														)
													);
													?>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>

						<!-- Reuqest Quote Converted Order Admin -->
						 <div class="card">
								<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_quoted_request_converted_order" aria-expanded="false" aria-controls="collapse_quoted_request_converted_order">
									<?php esc_html_e('Admin (Quote Converted to Order Request)', 'woocommerce-wholesale-pricing'); ?>
								<div class="wwp_signal">
								<?php
								if ('1' === $get_quote_email_setting('converted_admin_email_enable') ) {
									?>
									<div class="wwp_circle wwp_circle_off">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on active">&nbsp;</div>
									<?php
								} else {
									?>
									<div class="wwp_circle wwp_circle_off active">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on">&nbsp;</div>
									<?php
								}
								?>
								</div>
							</button>                                        
							<div id="collapse_quoted_request_converted_order" class="collapse" data-parent="#accordion_notification" >
								<div class="card-body">
									<table class="form-table wwp-main-settings">
										<tr>
											<th>
												<label for="wc_quote_converted_admin_email_enable"><?php esc_html_e('Enable', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input class="inp-cbx" style="display: none" type="checkbox" name="wc_quote_email[converted_admin_email_enable]" value="1" id="wc_quote_converted_admin_email_enable" <?php checked('1', (string) $get_quote_email_setting('converted_admin_email_enable')); ?>>
												<label class="cbx cbx-square" for="wc_quote_converted_admin_email_enable">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
												</label>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wc_quote_converted_admin_email_subject"><?php esc_html_e('Subject', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input type="text" name="wc_quote_email[converted_admin_email_subject]" id="wc_quote_converted_admin_email_subject" value="<?php echo esc_attr($get_quote_email_setting('converted_admin_email_subject')); ?>" class="widefat-100 regular-text"/>
											</td>
										</tr>
										
										<tr>
											<th>
												<label for="wc_quote_converted_admin_email_msg"><?php esc_html_e('Message', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php
													wp_editor(
														html_entity_decode((string) $get_quote_email_setting('converted_admin_email_msg'), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401),
														'wc_quote_converted_admin_email_msg',
														array( 
															'textarea_name' => 'wc_quote_email[converted_admin_email_msg]',
															'textarea_rows' => 5, 
														)
													);
													?>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>

						<!-- Reuqest Quote Converted Order Customer -->
						 <div class="card">
								<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_quoted_request_converted_order_customer" aria-expanded="false" aria-controls="collapse_quoted_request_converted_order_customer">
									<?php esc_html_e('Customer (Quote Converted To Order Request)', 'woocommerce-wholesale-pricing'); ?>
								<div class="wwp_signal">
								<?php
								if ('1' === $get_quote_email_setting('converted_user_email_enable') ) {
									?>
									<div class="wwp_circle wwp_circle_off">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on active">&nbsp;</div>
									<?php
								} else {
									?>
									<div class="wwp_circle wwp_circle_off active">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on">&nbsp;</div>
									<?php
								}
								?>
								</div>
							</button>                                        
							<div id="collapse_quoted_request_converted_order_customer" class="collapse" data-parent="#accordion_notification" >
								<div class="card-body">
									<table class="form-table wwp-main-settings">
										<tr>
											<th>
												<label for="wc_quote_converted_to_order_user_email_enable"><?php esc_html_e('Enable', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input class="inp-cbx" style="display: none" type="checkbox" name="wc_quote_email[converted_user_email_enable]" value="1" id="wc_quote_converted_to_order_user_email_enable" <?php checked('1', (string) $get_quote_email_setting('converted_user_email_enable')); ?>>
												<label class="cbx cbx-square" for="wc_quote_converted_to_order_user_email_enable">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
												</label>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wc_quote_converted_user_email_subject"><?php esc_html_e('Subject', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input type="text" name="wc_quote_email[converted_user_email_subject]" id="wc_quote_converted_user_email_subject" value="<?php echo esc_attr($get_quote_email_setting('converted_user_email_subject')); ?>" class="widefat-100 regular-text"/>
											</td>
										</tr>
										
										<tr>
											<th>
												<label for="wc_quote_converted_user_email_msg"><?php esc_html_e('Message', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php
													wp_editor(
														html_entity_decode((string) $get_quote_email_setting('converted_user_email_msg'), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401),
														'wc_quote_converted_user_email_msg',
														array( 
															'textarea_name' => 'wc_quote_email[converted_user_email_msg]',
															'textarea_rows' => 5, 
														)
													);
													?>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>

						<!-- Reuqest Expired Quote Admin -->
						 <div class="card">
								<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_quoted_request_expired_admin" aria-expanded="false" aria-controls="collapse_quoted_request_expired_admin">
									<?php esc_html_e('Admin (Expired Quote Request)', 'woocommerce-wholesale-pricing'); ?>
								<div class="wwp_signal">
								<?php
								if ('1' === $get_quote_email_setting('expired_admin_email_enable') ) {
									?>
									<div class="wwp_circle wwp_circle_off">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on active">&nbsp;</div>
									<?php
								} else {
									?>
									<div class="wwp_circle wwp_circle_off active">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on">&nbsp;</div>
									<?php
								}
								?>
								</div>
							</button>                                        
							<div id="collapse_quoted_request_expired_admin" class="collapse" data-parent="#accordion_notification" >
								<div class="card-body">
									<table class="form-table wwp-main-settings">
										<tr>
											<th>
												<label for="wc_quote_expired_admin_email_enable"><?php esc_html_e('Enable', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input class="inp-cbx" style="display: none" type="checkbox" name="wc_quote_email[expired_admin_email_enable]" value="1" id="wc_quote_expired_admin_email_enable" <?php checked('1', (string) $get_quote_email_setting('expired_admin_email_enable')); ?>>
												<label class="cbx cbx-square" for="wc_quote_expired_admin_email_enable">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
												</label>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wc_quote_expired_admin_email_subject"><?php esc_html_e('Subject', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input type="text" name="wc_quote_email[expired_admin_email_subject]" id="wc_quote_expired_admin_email_subject" value="<?php echo esc_attr($get_quote_email_setting('expired_admin_email_subject')); ?>" class="widefat-100 regular-text"/>
											</td>
										</tr>
										
										<tr>
											<th>
												<label for="wc_quote_expired_admin_email_msg"><?php esc_html_e('Message', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php
													wp_editor(
														html_entity_decode((string) $get_quote_email_setting('expired_admin_email_msg'), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401),
														'wc_quote_expired_admin_email_msg',
														array( 
															'textarea_name' => 'wc_quote_email[expired_admin_email_msg]',
															'textarea_rows' => 5, 
														)
													);
													?>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>

						<!-- Reuqest Expired Quote Customer -->
						 <div class="card">
								<button onclick="return false;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse_quoted_request_expired_customer" aria-expanded="false" aria-controls="collapse_quoted_request_expired_customer">
									<?php esc_html_e('Customer (Expired Quote Request)', 'woocommerce-wholesale-pricing'); ?>
								<div class="wwp_signal">
								<?php
								if ('1' === $get_quote_email_setting('expired_user_email_enable') ) {
									?>
									<div class="wwp_circle wwp_circle_off">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on active">&nbsp;</div>
									<?php
								} else {
									?>
									<div class="wwp_circle wwp_circle_off active">&nbsp;</div>
									<div class="wwp_circle wwp_circle_on">&nbsp;</div>
									<?php
								}
								?>
								</div>
							</button>                                        
							<div id="collapse_quoted_request_expired_customer" class="collapse" data-parent="#accordion_notification" >
								<div class="card-body">
									<table class="form-table wwp-main-settings">
										<tr>
											<th>
												<label for="wc_quote_convert_to_order_user_email_enable"><?php esc_html_e('Enable', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input class="inp-cbx" style="display: none" type="checkbox" name="wc_quote_email[expired_user_email_enable]" value="1" id="wc_quote_convert_to_order_user_email_enable" <?php checked('1', (string) $get_quote_email_setting('expired_user_email_enable')); ?>>
												<label class="cbx cbx-square" for="wc_quote_convert_to_order_user_email_enable">
													<span>
														<svg width="12px" height="9px" viewbox="0 0 12 9">
															<polyline points="1 5 4 8 11 1"></polyline>
														</svg>
													</span>
												</label>
											</td>
										</tr>
										<tr>
											<th>
												<label for="wc_quote_expired_user_email_subject"><?php esc_html_e('Subject', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<input type="text" name="wc_quote_email[expired_user_email_subject]" id="wc_quote_expired_user_email_subject" value="<?php echo esc_attr($get_quote_email_setting('expired_user_email_subject')); ?>" class="widefat-100 regular-text"/>
											</td>
										</tr>
										
										<tr>
											<th>
												<label for="wc_quote_expired_user_email_msg"><?php esc_html_e('Message', 'woocommerce-wholesale-pricing'); ?></label>
											</th>
											<td>
												<?php
													wp_editor(
														html_entity_decode((string) $get_quote_email_setting('expired_user_email_msg'), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401),
														'wc_quote_expired_user_email_msg',
														array( 
															'textarea_name' => 'wc_quote_email[expired_user_email_msg]',
															'textarea_rows' => 5, 
														)
													);
													?>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php /*submit_button();*/ ?>
		<div class="sep20px">&nbsp;</div>
		<input type="submit" name="submit" id="submit" class="wwp-button-primary" value="<?php esc_html_e('Save Changes', 'woocommerce-wholesale-pricing'); ?>">                    
		<div class="sep20px">&nbsp;</div>
	</form>
	</div>
