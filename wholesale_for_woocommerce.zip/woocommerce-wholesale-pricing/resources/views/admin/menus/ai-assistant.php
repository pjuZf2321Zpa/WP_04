<?php
/**
 * AI Assistant menu template.
 *
 * @package WooCommerceWholesalePricing
 * @version 3.2.0
 */
?>
<div id="wholesale-ai-assistant"></div>