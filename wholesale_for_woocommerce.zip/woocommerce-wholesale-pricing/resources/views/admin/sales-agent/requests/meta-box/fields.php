<?php
$agent_id = $post->ID;
$form_option  = str_replace( '"false"', 'false', (string) get_option( 'sales_agent_form_builder_data', '' ) );
$extra_fields = json_decode( $form_option );

if ( empty( $extra_fields ) || empty( $extra_fields->components ) ) {
	$extra_fields = (object) array(
		'components' => mendatory_fields(),
	);
}

$user_fields = get_post_meta( $agent_id, 'wc_agent_register_extra_fields', true );
if ( ! is_array( $user_fields ) ) {
	$user_fields = array();
}

if ( isset( $user_fields['cat'] ) && '' !== $user_fields['cat'] ) {
	$commission_cat_term = get_term( $user_fields['cat'] );
	if ( $commission_cat_term && ! is_wp_error( $commission_cat_term ) ) {
		$user_fields['cat'] = $commission_cat_term->name;
	}
}

$data = array();

foreach ( $extra_fields->components as $fields ) {
	$field = (array) $fields;

	if ( empty( $field['key'] ) ) {
		continue;
	}

	// Never expose password values in admin UI.
	if ( ( isset( $field['type'] ) && 'password' === $field['type'] ) || 'pass' === $field['key'] ) {
		continue;
	}

	$wc_user_field_name = $field['key'];
	/**
	 * Filter.
	 *
	 * @since 1.4
	 */
	$wc_user_field_label = apply_filters( 'wc_agent_request_labels', isset( $field['label'] ) ? $field['label'] : $wc_user_field_name );

	if ( array_key_exists( $wc_user_field_name, $user_fields ) ) {
		$data[ $wc_user_field_label ] = $user_fields[ $wc_user_field_name ];
	}
}

$html_content = '<div class="agent-details-popup">';
if ( ! empty( $data ) ) {
	foreach ( $data as $label => $value ) {
		if ( is_array( $value ) ) {
			$value = implode( ', ', array_map( 'strval', $value ) );
		}
		$html_content .= '<p><strong>' . esc_html( $label ) . ':</strong><input type="text" value="' . esc_attr( $value ) . '" readonly class="regular-text" /></p>';
	}
} else {
	$html_content .= '<p>' . esc_html__( 'No Result Found', 'woocommerce-wholesale-pricing' ) . '</p>';
}
$html_content .= '</div>';

echo $html_content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
