<div class="alignleft filter-actions " style="display: flex;">

	<?php
	$agent_id = isset( $_GET['agent_id'] ) ? sanitize_text_field( wp_unslash( $_GET['agent_id'] ) ) : '';
	?>

	<form method="get" class="payout-commission-filters-form" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" autocomplete="off">

		<input name="page" value="agent-payout-view" type="hidden">

		<input name="agent_id" class="agent_id" value="<?php echo esc_attr( $agent_id ); ?>" type="hidden">

		<select class="" id="agent_customer_filter" name="customer_id" data-placeholder="<?php esc_attr_e( 'Select a Customer', 'woocommerce-wholesale-pricing' ); ?>" data-allow_clear="true" tabindex="-1" aria-hidden="true">

			<option value=""><?php echo esc_html__( 'Select a Customer', 'woocommerce-wholesale-pricing' ); ?></option>

			<?php
			$agent_customers = get_users(
				array(
					'meta_key'   => 'sales_agent',
					'meta_value' => $agent_id,
				)
			);

			$customer_id = 0;
			if ( isset( $_REQUEST['customer_id'] ) ) {
				$customer_id = sanitize_text_field( wp_unslash( $_REQUEST['customer_id'] ) );
			}

			foreach ( $agent_customers as $agent_customer ) {
				?>
				<option value="<?php echo esc_attr( $agent_customer->ID ); ?>" <?php selected( $agent_customer->ID, $customer_id, true ); ?>><?php echo esc_html( $agent_customer->display_name ); ?></option>
				<?php
			}
			?>

		</select>

		<input type="text" id="commission_date_from" name="date_from" size="10" placeholder="<?php echo esc_attr__( 'Start Date', 'woocommerce-wholesale-pricing' ); ?>" value="<?php echo ( isset( $_REQUEST['date_from'] ) ) ? esc_attr( sanitize_text_field( wp_unslash( $_REQUEST['date_from'] ) ) ) : ''; ?>">

		<label style="padding: 6px;">:</label>

		<input type="text" id="commission_date_to" name="date_to" size="10" placeholder="<?php echo esc_attr__( 'End Date', 'woocommerce-wholesale-pricing' ); ?>" value="<?php echo ( isset( $_REQUEST['date_to'] ) ) ? esc_attr( sanitize_text_field( wp_unslash( $_REQUEST['date_to'] ) ) ) : ''; ?>">


		<?php submit_button( esc_html__( 'Filter', 'woocommerce-wholesale-pricing' ), 'primary', 'filter_commissions', false ); ?>

	</form>

	<form method="post" style="padding-left: 10px;" class="form-export">
		<?php wp_nonce_field( '_export_commissions_nonce', 'export_commissions_nonce' ); ?>
		<input type="submit" name="export_commissions" id="export_commissions" class="button button-primary" value="Export">
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=agent-payout-view&agent_id=' . esc_attr( $agent_id ) ) ); ?>" class="button agent-clear-filters"><?php esc_html_e( 'Clear', 'woocommerce-wholesale-pricing' ); ?></a>

	</form>
	<?php
	$agent_payout_detail = get_post_meta( $agent_id, 'agent_payout_detail', true );
	$is_payout_allowed   = isset( $agent_payout_detail['payout-method'] ) && (
		( 'paypal' === $agent_payout_detail['payout-method'] && 'enabled' === get_option( 'paypal_payout_toggle' ) ) ||
		( 'bank' === $agent_payout_detail['payout-method'] && 'enabled' === get_option( 'bank_transfer_payout_toggle' ) )
	);

	/**
	* Filter.
	*
	* @since 1.6
	*/
	$is_payout_allowed = apply_filters( 'allow_agent_payout', $is_payout_allowed, $agent_payout_detail );

	if ( $is_payout_allowed ) :
		wp_nonce_field( 'mark_commissions_paid_nonce', 'mark_commissions_paid_nonce_field' );
		wp_nonce_field( 'delete_commissions_nonce', 'delete_commissions_nonce_field' );
		?>
		<form method="post" style="padding-left: 10px;" class="bulk_action" >
			<input type="submit" id="mark_paid" class="button button-primary" value="<?php esc_attr_e( 'Bulk Payout', 'woocommerce-wholesale-pricing' ); ?>">
			<input type="submit" id="delete_commissions" class="button button-danger" value="<?php esc_attr_e( 'Delete Bulk', 'woocommerce-wholesale-pricing' ); ?>">
			<div style="position:relative"><div id="loader"></div></div>
		</form>
		<?php
	endif;
	?>

</div>
