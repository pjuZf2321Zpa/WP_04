<?php

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n";
echo esc_html( wp_strip_all_tags( $email_heading ) );
echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

/* translators: %1$s: CommissionCategory, %2\$s: CommissionValue */
echo esc_html__( sprintf( 'You’ve been assigned to the %1$s category. You will receive %2$s as commission amount.', $commission_category, $commission_value ), 'woocommerce-wholesale-pricing' ) . "\n\n";

if ( $additional_content ) {
	echo esc_html( wp_strip_all_tags( wptexturize( $additional_content ) ) );
}
