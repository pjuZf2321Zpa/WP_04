<div class="form-field">
	<label for="commission_type"><?php esc_html_e( 'Commission Type' ); ?></label>
	<select name="term_meta[commission_type]" id="commission_type" class="regular-text" style="width:100%;">
		<option value="percentage"><?php echo esc_html( 'Percentage' ); ?></option>
		<option value="fixed"><?php echo esc_html( 'Fixed' ); ?></option>
	</select>
	<p><?php echo esc_html__( 'Select a commission type', 'woocommerce-wholesale-pricing' ); ?></p>
</div>
<div class="form-field form-required">
	<label for="commission_value"><?php esc_html_e( 'Commission Value' ); ?></label>
	<input type="number" name="term_meta[commission_value]" id="commission_value" size="25" aria-required="true" style="width:95%;" step="0.1">
	<p ><?php echo esc_html__( 'Enter a commission value', 'woocommerce-wholesale-pricing' ); ?></p>
</div>
<div class="form-field on-order-wrapper">
	<div class="prod-cat-wrapper">
		<div class="prod-option-wrapper" style="margin-bottom:10px;">
			<input type="radio" checked id="commission_on_prod" name="term_meta[commission_prod_cat]" value="commission_on_prod" class="main_selection_radio">
			<label for="commission_on_prod" style="display:inline;"><?php esc_html_e( 'Commission On Products' ); ?></label>
		</div>
		<div class="cat-option-wrapper" style="margin-bottom:10px;">
			<input type="radio" id="commission_on_cat" name="term_meta[commission_prod_cat]" value="commission_on_cat" class="main_selection_radio">
			<label for="commission_on_cat" style="display:inline;"><?php esc_html_e( 'Commission On Category' ); ?></label>
		</div>

		<!-- Product Selection Section -->
		<div class="safw-prod-selection-section">

			<div class="form-field safw-prod-search-wrapper">
				<label for="commission-products"><?php esc_html_e( 'Select Products' ); ?></label>
				<select class="wc-product-search" multiple="true" id="commission-products_inc" name="term_meta[commission_products][]" data-placeholder="Search for a product…" data-action="woocommerce_json_search_products_and_variations" data-exclude="" value="">
				</select>
				<p><?php echo esc_html__( 'Select product on which agent will earn commission. Leave blank to apply to all products.', 'woocommerce-wholesale-pricing' ); ?></p>
			</div>
		</div>

		<!-- Category Selection Section -->
		<div class="safw-cat-selection-section safw-is-hidden">
			<div class="form-field safw-cat-search-wrapper">
				<label for="commission-category"><?php esc_html_e( 'Select Categories' ); ?></label>
				<select class="wc-category-search" multiple="true" id="commission-category_inc" name="term_meta[commission_category][]" data-placeholder="Search for a category…" data-action="woocommerce_json_search_categories" data-exclude="" value="">
				</select>
				<p><?php echo esc_html__( 'Select category on which agent will earn commission. Leave blank to apply to all categories.', 'woocommerce-wholesale-pricing' ); ?></p>
			</div>
		</div>
	</div>
	<div class="ind-prod-commission-wrapper">
		<input type="checkbox" id="term_meta[indi_prod_comm]" name="term_meta[indi_prod_comm]" value="indi_prod_comm">
		<label for="term_meta[indi_prod_comm]"><?php esc_html_e( 'Per product commission.' ); ?></label>
	</div>
	<div class="prod-subtotal-check-wrapper">
		<input type="checkbox" id="term_meta[per_quantity]" name="term_meta[per_quantity]" value="per_quantity">
		<label for="term_meta[per_quantity]"><?php esc_html_e( 'Calculate commission on product subtotal.' ); ?></label>
	</div>
</div>
<?php wp_nonce_field( '_nonce_commission_cat', 'commission_cat_nonce' ); ?>