<?php
// Check for existing taxonomy meta for the term you're editing
$term_meta         = '';
$commission_value  = '';
$commission_system = '';
if ( $term && isset( $term->term_id ) ) {
	$t_id      = $term->term_id; // Get the ID of the term you're editing
	$term_meta = get_option( "taxonomy_term_$t_id" ); // Do the check
}
?>

<tr class="form-field">
	<th scope="row" valign="top">
		<label for="commission_type"><?php esc_html_e( 'Commission Type' ); ?></label>
	</th>
	<td>
		<?php ! empty( $term_meta ) && $term_meta['commission_type'] ? $commission_value = $term_meta['commission_type'] : ''; ?>
		<select name="term_meta[commission_type]" id="commission_type" class="regular-text" style="width:100%;">
			<option value="percentage" <?php echo 'percentage' === $commission_value ? 'selected' : ''; ?>><?php echo esc_html( 'Percentage' ); ?></option>
			<option value="fixed" <?php echo 'fixed' === $commission_value ? 'selected' : '' ; ?>><?php echo esc_html( 'Fixed' ); ?></option>
		</select>
		<p><?php echo esc_html__( 'Select a commission type', 'woocommerce-wholesale-pricing' ); ?></p>
	</td>
</tr>
<tr class="form-field form-required">
	<th scope="row" valign="top">
		<label for="commission_value"><?php esc_html_e( 'Commission Value', 'woocommerce-wholesale-pricing' ); ?></label>
	</th>
	<td>
		<input type="number" name="term_meta[commission_value]" id="commission_value" size="25" aria-required="true" style="width:95%;" step="0.1" value="<?php echo ! empty( $term_meta ) && $term_meta['commission_value'] ? esc_attr( $term_meta['commission_value'] ) : ''; ?>">
		<p ><?php echo esc_html__( 'Enter a commission value', 'woocommerce-wholesale-pricing' ); ?></p>
	</td>
</tr>

<?php
	$prod_checked        = 'checked';
	$cat_checked         = '';
	$commission_prod_cat = 'commission_on_prod';
if ( ! empty( $term_meta ) && isset( $term_meta['commission_prod_cat'] ) && ! empty( $term_meta['commission_prod_cat'] ) ) {
	$commission_prod_cat = $term_meta['commission_prod_cat'];
	if ( 'commission_on_cat' === $term_meta['commission_prod_cat'] ) {
		$cat_checked  = 'checked';
		$prod_checked = '';
	} else {
		$prod_checked = 'checked';
		$cat_checked  = '';
	}
}

?>
<tr class="form-field main-selection-row">
	<th scope="row" valign="top">
		<label><?php esc_html_e( 'Commission Basis', 'woocommerce-wholesale-pricing' ); ?></label>
	</th>
	<td>
		<div style="margin-bottom:10px;">
			<input type="radio" <?php echo esc_attr( $prod_checked ); ?> id="commission_on_prod" name="term_meta[commission_prod_cat]" value="commission_on_prod" class="main_selection_radio">
			<label for="commission_on_prod" style="display:inline;"><?php esc_html_e( 'Commission On Products', 'woocommerce-wholesale-pricing' ); ?></label>
		</div>
		<div>
			<input type="radio" <?php echo esc_attr( $cat_checked ); ?> id="commission_on_cat" name="term_meta[commission_prod_cat]" value="commission_on_cat" class="main_selection_radio">
			<label for="commission_on_cat" style="display:inline;"><?php esc_html_e( 'Commission On Category', 'woocommerce-wholesale-pricing' ); ?></label>
		</div>
	</td>
</tr>
<tr class="form-field safw-prod-search-wrapper" style="<?php echo ( 'commission_on_prod' === $commission_prod_cat && 'specific' === $product_selection ) ? '' : 'display:none !important;'; ?>">
	<th scope="row" valign="top">
		<label for="commission-products"><?php esc_html_e( 'Select Product' ); ?></label>
	</th>
	<td>
		<select class="wc-product-search" multiple="true" id="commission-products_inc" name="term_meta[commission_products][]" data-placeholder="Search for a product…" data-action="woocommerce_json_search_products_and_variations" data-exclude="" value="">
			<?php 
			if ( isset( $term_meta['commission_products'] ) && ! empty( $term_meta['commission_products'] ) ) {
				$include_product_ids =  $term_meta['commission_products']; 
				foreach ( $include_product_ids as $include_product_id ) {
					$product = wc_get_product( $include_product_id );
					if ( is_object( $product ) ) {
						echo '<option value="' . esc_attr( $include_product_id ) . '"' . selected( true, true, false ) . '>' . esc_html( wp_strip_all_tags( $product->get_formatted_name() ) ) . '</option>';
					}
				}
			}           
			?>
		</select>
		<p><?php echo esc_html__( 'Select product on which agent will earn commission. Leave blank to apply to all products.', 'woocommerce-wholesale-pricing' ); ?></p>
	</td>
</tr>

<tr class="form-field safw-prod-exclude-wrapper" style="<?php echo ( 'commission_on_prod' === $commission_prod_cat && 'all' === $product_selection ) ? '' : 'display:none !important;'; ?>">
	<th scope="row" valign="top">
		<label for="exclude-products"><?php esc_html_e( 'Exclude Products', 'woocommerce-wholesale-pricing' ); ?></label>
	</th>
	<td>
		<select class="wc-product-search" multiple="true" id="exclude-products" name="term_meta[exclude_products][]" data-placeholder="Search for a product…" data-action="woocommerce_json_search_products_and_variations" data-exclude="" value="">
			<?php 
			if ( isset( $term_meta['exclude_products'] ) && ! empty( $term_meta['exclude_products'] ) ) {
				$exclude_product_ids = $term_meta['exclude_products']; 
				foreach ( $exclude_product_ids as $exclude_product_id ) {
					$product = wc_get_product( $exclude_product_id );
					if ( is_object( $product ) ) {
						echo '<option value="' . esc_attr( $exclude_product_id ) . '"' . selected( true, true, false ) . '>' . esc_html( wp_strip_all_tags( $product->get_formatted_name() ) ) . '</option>';
					}
				}
			}           
			?>
		</select>
		<p><?php echo esc_html__( 'Select products that will be excluded from the commission.', 'woocommerce-wholesale-pricing' ); ?></p>
	</td>
</tr>
<tr class="form-field safw-cat-search-wrapper" style="<?php echo ( 'commission_on_cat' === $commission_prod_cat ) ? '' : 'display:none !important;'; ?>">
	<th scope="row" valign="top">
		<label for="commission-category"><?php esc_html_e( 'Select Category' ); ?></label>
	</th>
	<td>
		<select class="wc-category-search" multiple="true" id="commission-category_inc" name="term_meta[commission_category][]" data-placeholder="Search for a category" data-action="woocommerce_json_search_categories" data-exclude="" value="">
			<?php 
			if ( isset( $term_meta['commission_category'] ) && ! empty( $term_meta['commission_category'] ) ) {
				$include_categories =   $term_meta['commission_category']; 
				foreach ( $include_categories as $slug ) {
					$current_category = $slug ? get_term_by( 'slug', $slug, 'product_cat' ) : false;
					if ( $current_category && is_object( $current_category ) ) {
						echo '<option value="' . esc_attr( $slug ) . '"' . selected( true, true, false ) . '>' . wp_kses_post( $current_category->name . ' (#' . $current_category->term_id . ')' ) . '</option>';
					}
				}
			}           
			?>
		</select>
		<p><?php echo esc_html__( 'Select category on which agent will earn commission. Leave blank to apply to all categories.', 'woocommerce-wholesale-pricing' ); ?></p>
	</td>
</tr>

<tr class="form-field safw-cat-exclude-wrapper" style="<?php echo ( 'commission_on_cat' === $commission_prod_cat ) ? '' : 'display:none !important;'; ?>">
	<th scope="row" valign="top">
		<label for="exclude-category"><?php esc_html_e( 'Exclude Category' ); ?></label>
	</th>
	<td>
		<select class="wc-category-search" multiple="true" id="exclude-category" name="term_meta[exclude_category][]" data-placeholder="Search for a category" data-action="woocommerce_json_search_categories" data-exclude="" value="">
			<?php 
			if ( isset( $term_meta['exclude_category'] ) && ! empty( $term_meta['exclude_category'] ) ) {
				$exclude_categories = $term_meta['exclude_category']; 
				foreach ( $exclude_categories as $slug ) {
					$current_category = $slug ? get_term_by( 'slug', $slug, 'product_cat' ) : false;
					if ( $current_category && is_object( $current_category ) ) {
						echo '<option value="' . esc_attr( $slug ) . '"' . selected( true, true, false ) . '>' . wp_kses_post( $current_category->name . ' (#' . $current_category->term_id . ')' ) . '</option>';
					}
				}
			}           
			?>
		</select>
		<p><?php echo esc_html__( 'Select categories to exclude from commission', 'woocommerce-wholesale-pricing' ); ?></p>
	</td>
</tr>

<script type="text/javascript">
	jQuery(document).ready(function($) {
		function safwUpdateVisibility() {
			var mainSelection = $('.main_selection_radio:checked').val();
			
			if (mainSelection === 'commission_on_prod') {
				$('.safw-prod-selection-section').show();
				$('.safw-cat-selection-section').hide();
				$('.safw-cat-search-wrapper').hide();
				$('.safw-cat-exclude-wrapper').hide();
				
				var prodSelection = $('.product_selection_radio:checked').val();
				if (prodSelection === 'all') {
					$('.safw-prod-search-wrapper').hide();
					$('.safw-prod-exclude-wrapper').show();
				} else {
					$('.safw-prod-search-wrapper').show();
					$('.safw-prod-exclude-wrapper').hide();
				}
			} else {
				$('.safw-prod-selection-section').hide();
				$('.safw-prod-search-wrapper').hide();
				$('.safw-prod-exclude-wrapper').hide();
				$('.safw-cat-selection-section').show();
				
				var catSelection = $('.category_selection_radio:checked').val();
				if (catSelection === 'all') {
					$('.safw-cat-search-wrapper').hide();
					$('.safw-cat-exclude-wrapper').show();
				} else {
					$('.safw-cat-search-wrapper').show();
					$('.safw-cat-exclude-wrapper').hide();
				}
			}
		}

		// Bind events
		$('.main_selection_radio, .product_selection_radio, .category_selection_radio').on('change', function() {
			safwUpdateVisibility();
		});

		// Initialize view on page load with a slight delay
		setTimeout(safwUpdateVisibility, 200);
	});
</script>
<?php
	$per_quan_checked      = '';
	$ind_prod_comm_checked = '';
if ( ! empty( $term_meta ) && isset( $term_meta['per_quantity'] ) && ! empty( $term_meta['per_quantity'] ) ) {
	$per_quan_checked = 'checked';
}
if ( ! empty( $term_meta ) && isset( $term_meta['indi_prod_comm'] ) && ! empty( $term_meta['indi_prod_comm'] ) ) {
	$ind_prod_comm_checked = 'checked';
}
?>
<tr class="form-field ind-prod-commission-wrapper">
	<th scope="row" valign="top">
		<label for="term_meta[indi_prod_comm]"><?php esc_html_e( 'Per product commission.' ); ?></label>
	</th>
	<td>
		<input type="checkbox" <?php echo esc_attr( $ind_prod_comm_checked ); ?> id="term_meta[indi_prod_comm]" name="term_meta[indi_prod_comm]" value="indi_prod_comm">
	</td>
</tr>
<tr class="form-field prod-subtotal-check-wrapper">	
	<th>
		<label for="term_meta[per_quantity]"><?php esc_html_e( 'Calculate commission on product subtotal.' ); ?></label>
	</th>
	<td>
		<input type="checkbox" <?php echo esc_attr( $per_quan_checked ); ?> id="term_meta[per_quantity]" name="term_meta[per_quantity]" value="per_quantity">
	</td>
</tr>

<?php wp_nonce_field( '_nonce_commission_cat', 'commission_cat_nonce' ); ?>