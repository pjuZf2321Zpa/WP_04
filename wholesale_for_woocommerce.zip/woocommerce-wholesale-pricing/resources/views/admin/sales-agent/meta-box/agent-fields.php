<?php

$first_name            = get_post_meta( $post->ID, 'first_name', true );
$last_name             = get_post_meta( $post->ID, 'last_name', true );
$customer_registration = get_post_meta( $post->ID, 'customer_registration', true );
$assign_users          = get_post_meta( $post->ID, 'assign_user', true );
$commission_category   = get_post_meta( $post->ID, 'commission_category', true );
?>
<?php wp_nonce_field( '_agent_nonce', 'agent_nonce' ); ?>
<div style="display: flex; gap: 20px;">
<p style="display: flex;flex-direction: column;">
	<label for="first_name"><?php esc_html_e( 'First Name', 'woocommerce-wholesale-pricing' ); ?></label>
	<input type="text" name="first_name" id="first_name" class="regular-text" value="<?php echo esc_attr( $first_name ); ?>" required>
</p>

<p style="display: flex;flex-direction: column;">
	<label for="last_name"><?php esc_html_e( 'Last Name', 'woocommerce-wholesale-pricing' ); ?></label>
	<input type="text" name="last_name" id="last_name" class="regular-text" value="<?php echo esc_attr( $last_name ); ?>" required>
</p>
</div>
<p>
	<label for="assign_user"><?php esc_html_e( 'Assign/Select User as Agent', 'woocommerce-wholesale-pricing' ); ?></label>
	<br>
	<select required name="assign_user" id="assign_user" class="regular-text wc-agent-select2" data-width=75%" data-placeholder="<?php esc_attr_e( 'Assigned user', 'woocommerce-wholesale-pricing' ); ?>">
		<?php
		if ( $assign_users ) {
			$user = get_user_by( 'ID', $assign_users );
			if ( $user ) {
				$last_name  = get_user_meta( $user->ID, 'last_name', true );
				$first_name = get_user_meta( $user->ID, 'first_name', true );
				/* translators: %1$s is name, %2$s is id, %3$s is email */
				$text = sprintf( esc_html__( '%1$s (# %2$s %3$s)', 'woocommerce-wholesale-pricing' ), $first_name . ' ' . $last_name, $user->ID, $user->user_email );
				?>
					<option value="<?php echo esc_attr( $user->ID ); ?>" selected ><?php echo esc_attr( $text ); ?></option>
				<?php
			}
		}
		?>
	</select>
</p>
<p>
	<label for="agent_bio"><?php esc_html_e( 'Agent Bio', 'woocommerce-wholesale-pricing' ); ?></label>
	<br>
	<textarea name="agent_bio" id="agent_bio" class="regular-text" rows="5" style="width: 52em;"><?php echo esc_textarea( get_post_meta( $post->ID, 'agent_bio', true ) ); ?></textarea>
</p>

<!-- Commission Category Section -->
<div id="commission_category_section">
	<label for="commission_category"><?php esc_html_e('Commission Category', 'woocommerce-wholesale-pricing'); ?></label><br>
	<select name="commission_category" id="commission_category" class="regular-text" style="width: 52em;" required>
		<option value=""><?php echo esc_html__('Select Commission Category', 'woocommerce-wholesale-pricing'); ?></option>
		<?php
		$args = array(
			'taxonomy'   => 'commission_cat',
			'hide_empty' => false,
		);

		$agent_categories = get_terms($args);
		if ($agent_categories) {
			foreach ($agent_categories as $cate) {
				$selected = ( $cate->term_id == $commission_category ) ? 'selected' : '';
				?>
				<option value="<?php echo esc_attr($cate->term_id); ?>" <?php echo esc_attr($selected); ?>>
					<?php echo esc_html($cate->name); ?>
				</option>
				<?php
			}
		}
		?>
	</select>
</div>

<p>
	<label for="customer_registration"><?php esc_html_e( 'Customer Registration', 'woocommerce-wholesale-pricing' ); ?></label>
	<br>
	<?php
		$selected = $customer_registration;
	?>
	<select  name="customer_registration" id="customer_registration" class="regular-text" style="width: 52em;">
		<option value="yes" <?php echo ( 'yes' == $customer_registration ) ? 'selected' : ''; ?> ><?php esc_html_e( 'Yes', 'woocommerce-wholesale-pricing' ); ?></option>
		<option value="no" <?php echo ( 'no' == $customer_registration ) ? 'selected' : ''; ?>><?php esc_html_e( 'No', 'woocommerce-wholesale-pricing' ); ?></option>
	</select>
</p>
