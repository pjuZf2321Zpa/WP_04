<?php

use WooCommerceWholesalePricing\App\Models\SalesAgent\Stats;
use WooCommerceWholesalePricing\App\Models\SalesAgent\Agent;
use WooCommerceWholesalePricing\App\Models\SalesAgent\Commission;

$total_order_count             = Stats::total_count_order_by_agent( $post->ID );
$total_order_sales             = Stats::total_order_sales_by_agent( $post->ID );
$total_customers               = count( (array) Agent::get_agent_customers( $post->ID ) );
$commission_info               = ( new Commission() )->get_agent_commission_info( $post->ID );
$total_commission              = (float) $commission_info['total_paid_commission'] + (float) $commission_info['total_pending_commission'];

?>
<div style="display: flex; flex-direction: column; gap: 15px;">
	<div style="display: flex; align-items: center; justify-content: space-between;">
		<span class="text-sm text-gray-600">Total Sales</span>
		<span class="text-sm font-bold text-gray-300"><?php echo wp_kses_post( $total_order_sales ); ?></span>
	</div>
	<div style="display: flex; align-items: center; justify-content: space-between;">
		<span class="text-sm text-gray-600">Total Orders</span>
		<span class="text-sm font-bold text-gray-300"><?php echo esc_html( $total_order_count ); ?></span>
	</div>
	<div style="display: flex; align-items: center; justify-content: space-between;">
		<span class="text-sm text-gray-600">Commission</span>
		<span class="text-sm font-bold text-gray-300"><?php echo wp_kses_post( wc_price( $total_commission ) ); ?></span>
	</div>
	<div style="display: flex; align-items: center; justify-content: space-between;">
		<span class="text-sm text-gray-600">Customers</span>
		<span class="text-sm font-bold text-gray-300"><?php echo esc_html( $total_customers ); ?></span>
	</div>
</div>