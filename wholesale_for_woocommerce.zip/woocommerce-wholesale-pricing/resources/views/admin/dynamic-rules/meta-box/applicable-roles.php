<?php
/**
 * Applicable Wholesale roles metabox.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int     $post_id Post ID.
 * @var WP_Post $post    Post object.
 * @var array   $rule    Rule meta.
 */

$apply_all_roles = isset( $rule['apply_all_roles'] ) ? $rule['apply_all_roles'] : 'yes';
$selected_roles  = isset( $rule['roles'] ) && is_array( $rule['roles'] ) ? $rule['roles'] : array();
$is_change_group = isset( $rule['rule_type'] ) && 'change-group' === $rule['rule_type'];

$wholesale_roles = get_terms(
	array(
		'taxonomy'   => 'wholesale_user_roles',
		'hide_empty' => false,
	)
);
if ( is_wp_error( $wholesale_roles ) ) {
	$wholesale_roles = array();
}
?>
<div class="wwp-dr-applicable-roles" <?php echo $is_change_group ? 'style="display:none;"' : ''; ?>>
	<p>
		<input
			class="inp-cbx wwp-dr-apply-all-roles"
			id="wwp_dr_apply_all_roles"
			type="checkbox"
			value="yes"
			name="wwp_dynamic_rule[apply_all_roles]"
			<?php checked( 'yes', $apply_all_roles ); ?>
		/>
		<label class="cbx cbx-square" for="wwp_dr_apply_all_roles">
			<span><?php esc_html_e( 'Apply to all wholesale roles', 'woocommerce-wholesale-pricing' ); ?></span>
		</label>
	</p>

	<div class="wwp-dr-roles-list" <?php echo ( 'yes' === $apply_all_roles ) ? 'style="opacity:0.5;pointer-events:none;"' : ''; ?>>
		<?php if ( empty( $wholesale_roles ) ) : ?>
			<p class="description"><?php esc_html_e( 'No wholesale roles found.', 'woocommerce-wholesale-pricing' ); ?></p>
		<?php else : ?>
			<?php foreach ( $wholesale_roles as $term_role ) : ?>
				<p>
					<input
						class="inp-cbx wwp-dr-role-checkbox"
						id="wwp_dr_role_<?php echo esc_attr( $term_role->term_id ); ?>"
						type="checkbox"
						value="<?php echo esc_attr( $term_role->slug ); ?>"
						name="wwp_dynamic_rule[roles][]"
						<?php checked( in_array( $term_role->slug, $selected_roles, true ) ); ?>
						<?php disabled( 'yes' === $apply_all_roles ); ?>
					/>
					<label class="cbx cbx-square" for="wwp_dr_role_<?php echo esc_attr( $term_role->term_id ); ?>">
						<span><?php echo esc_html( $term_role->name . ' (' . $term_role->slug . ')' ); ?></span>
					</label>
				</p>
			<?php endforeach; ?>
		<?php endif; ?>
	</div>
</div>
