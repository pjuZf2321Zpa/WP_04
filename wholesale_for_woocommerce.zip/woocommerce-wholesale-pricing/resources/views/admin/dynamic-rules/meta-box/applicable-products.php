<?php
/**
 * Effective Applicable Products metabox.
 *
 * Live preview of products this rule can apply to, based on Applies to,
 * selected groups, and (when specific roles are chosen) role excluded categories.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int     $post_id Post ID.
 * @var WP_Post $post    Post object.
 * @var array   $rule    Rule meta.
 */

$is_change_group = isset( $rule['rule_type'] ) && 'change-group' === $rule['rule_type'];
?>
<div
	class="wwp-dr-applicable-products"
	<?php echo $is_change_group ? 'style="display:none;"' : ''; ?>
>
	<style>
		.wwp-dr-ap-list-wrap {
			position: relative;
			margin-top: 8px;
			min-height: 80px;
		}
		.wwp-dr-ap-list {
			margin: 0;
			padding: 0;
			list-style: none;
			max-height: 280px;
			overflow: auto;
			border: 1px solid #dcdcde;
			background: #fff;
		}
		.wwp-dr-ap-loader {
			display: none;
			position: absolute;
			inset: 0;
			z-index: 2;
			align-items: center;
			justify-content: center;
			flex-direction: column;
			gap: 8px;
			background: rgba(255, 255, 255, 0.85);
			border: 1px solid #dcdcde;
		}
		.wwp-dr-applicable-products.is-loading .wwp-dr-ap-loader {
			display: flex;
		}
		.wwp-dr-applicable-products.is-loading .wwp-dr-ap-list {
			opacity: 0.35;
			pointer-events: none;
		}
		.wwp-dr-ap-loader .spinner {
			float: none;
			margin: 0;
			visibility: visible;
		}
		.wwp-dr-ap-loader-text {
			margin: 0;
			color: #50575e;
			font-size: 12px;
		}
		.wwp-dr-applicable-products-status {
			display: flex;
			align-items: center;
			gap: 10px;
			flex-wrap: wrap;
		}
		.wwp-dr-ap-inline-spinner {
			display: none;
			float: none;
			margin: 0;
			visibility: visible;
		}
		.wwp-dr-applicable-products.is-loading .wwp-dr-ap-inline-spinner {
			display: inline-block;
		}
	</style>

	<p class="description wwp-dr-applicable-products-intro">
		<?php esc_html_e( 'Products this rule can apply to after combining Applies to, group product settings, and selected wholesale role excluded categories.', 'woocommerce-wholesale-pricing' ); ?>
	</p>

	<div class="wwp-dr-applicable-products-status" aria-live="polite">
		<span class="wwp-dr-applicable-products-count">
			<strong class="wwp-dr-ap-total">0</strong>
			<span class="wwp-dr-ap-total-label"><?php esc_html_e( 'applicable products', 'woocommerce-wholesale-pricing' ); ?></span>
		</span>
		<span class="spinner wwp-dr-ap-inline-spinner" aria-hidden="true"></span>
		<span class="wwp-dr-ap-loading-label" style="display:none;"><?php esc_html_e( 'Updating…', 'woocommerce-wholesale-pricing' ); ?></span>
	</div>

	<p class="wwp-dr-ap-note description" style="display:none;"></p>
	<p class="wwp-dr-ap-empty description" style="display:none;"></p>
	<p class="wwp-dr-ap-error description" style="display:none;color:#b32d2e;"></p>

	<div class="wwp-dr-ap-list-wrap">
		<div class="wwp-dr-ap-loader" role="status" aria-live="polite" aria-busy="false">
			<span class="spinner is-active" aria-hidden="true"></span>
			<p class="wwp-dr-ap-loader-text"><?php esc_html_e( 'Loading applicable products…', 'woocommerce-wholesale-pricing' ); ?></p>
		</div>
		<ul class="wwp-dr-ap-list"></ul>
	</div>
</div>
