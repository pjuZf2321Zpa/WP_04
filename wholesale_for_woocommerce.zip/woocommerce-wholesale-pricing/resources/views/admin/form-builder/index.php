<?php
	$wwp_save_form = ( get_option('wwp_save_form') ) ? get_option('wwp_save_form') : '';
?>
<div id="wwp_wholesale_form_builder_container" class="wc-wholesale-form-builder-container">
	<div class="registration-form-message"><span class="dashicons dashicons-yes-alt"></span>
		<span class="message_text"> <?php echo esc_html__('Successfully Form Saved.', 'woocommerce-wholesale-pricing'); ?></span> 
		<span class="dashicons dashicons-no-alt" onclick="jQuery('.registration-form-message').fadeOut();"></span>
	</div>
	<div id="build-wrap"></div>
	<div class="row">
		<div class="wc-wholesale-form-builder-save-button col-xs-4 col-sm-3 col-md-2 formcomponents">
			<?php
			$other_attributes = array( 'id' => 'wc-wholesale-save-formbuilder' );
			submit_button(esc_html__('Save Changes', 'woocommerce-wholesale-pricing'), 'primary wwp-button-primary', 'submit', true, $other_attributes);
			?>
		</div>
	</div>
</div>