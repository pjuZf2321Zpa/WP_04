<div id="wcpt-table-type-modal" class="wcpt-table-type-modal" style="display:none;" role="dialog" aria-modal="true" aria-labelledby="wcpt-table-type-modal-title" aria-describedby="wcpt-table-type-modal-desc">
	<div class="wcpt-table-type-modal__backdrop" tabindex="-1"></div>
	<div class="wcpt-table-type-modal__dialog" role="document">
		<button type="button" class="wcpt-table-type-modal__close" aria-label="<?php esc_attr_e( 'Close', 'woocommerce-wholesale-pricing' ); ?>">
			<span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
		</button>
		<div class="wcpt-table-type-modal__header">
			<span class="wcpt-table-type-modal__badge dashicons dashicons-editor-table" aria-hidden="true"></span>
			<h2 id="wcpt-table-type-modal-title"><?php esc_html_e( 'Choose Table Type', 'woocommerce-wholesale-pricing' ); ?></h2>
			<p id="wcpt-table-type-modal-desc"><?php esc_html_e( 'Select the type of table you want to create.', 'woocommerce-wholesale-pricing' ); ?></p>
		</div>
		<div class="wcpt-table-type-modal__options">
			<a class="wcpt-table-type-card wcpt-table-type-option" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=wcpt' ) ); ?>" data-url="<?php echo esc_url( admin_url( 'post-new.php?post_type=wcpt' ) ); ?>">
				<span class="wcpt-table-type-card__icon dashicons dashicons-list-view" aria-hidden="true"></span>
				<span class="wcpt-table-type-card__body">
					<strong class="wcpt-table-type-card__title"><?php esc_html_e( 'Product Table', 'woocommerce-wholesale-pricing' ); ?></strong>
					<span class="wcpt-table-type-card__desc"><?php esc_html_e( 'Create a bulk product table with columns, filters, and cart controls.', 'woocommerce-wholesale-pricing' ); ?></span>
				</span>
				<span class="wcpt-table-type-card__arrow dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span>
			</a>
			<a class="wcpt-table-type-card wcpt-table-type-option" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=wcpt&table=quick_order_form' ) ); ?>" data-url="<?php echo esc_url( admin_url( 'post-new.php?post_type=wcpt&table=quick_order_form' ) ); ?>">
				<span class="wcpt-table-type-card__icon dashicons dashicons-cart" aria-hidden="true"></span>
				<span class="wcpt-table-type-card__body">
					<strong class="wcpt-table-type-card__title"><?php esc_html_e( 'Quick Order Form', 'woocommerce-wholesale-pricing' ); ?></strong>
					<span class="wcpt-table-type-card__desc"><?php esc_html_e( 'Build a fast search-and-order form for wholesale customers.', 'woocommerce-wholesale-pricing' ); ?></span>
				</span>
				<span class="wcpt-table-type-card__arrow dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span>
			</a>
		</div>
	</div>
</div>
