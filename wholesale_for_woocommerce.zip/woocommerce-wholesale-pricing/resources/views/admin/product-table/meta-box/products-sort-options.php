<?php
/**
 * Sorted Options
 *
 * @package Woocommerce Product Table/metaboxes views
 */
$enable_clickable_sort_col = get_post_meta($post_id, 'enable_sort_cols', true);
$product_table_fields      = get_post_meta($post_id, 'product_table_fields', true);
$selected_option           = array();
$fields                    = array();
$default_sorted            = '';

$saved_sorting_fields  = get_post_meta($post_id, 'sorted_cols', true);
$saved_sorting_default = get_post_meta($post_id, 'default_sorted_col', true);
if ($product_table_fields ) {
	$acceptable_sorting_fields = array(
		'id',
		'title',
		'date',
		'sku',
		'reviews',
		'price',
	);

	foreach ( $product_table_fields as $i => $product_table_field ) {
		if (in_array($product_table_field['woo_ids'], $acceptable_sorting_fields, true) ) {
			$fields[ $product_table_field['woo_ids'] . '_' . $i ] = $product_table_field['woo_label'];
		}
	}

	if ($saved_sorting_default ) {
		$sel = (int) substr(strrchr($saved_sorting_default, '_'), 1);
		if (is_int($sel) ) {
			$default_sorted = $product_table_fields[ $sel ]['woo_ids'] . '_' . $sel;
		} else {
			$default_sorted = '';
		}
	} else {
		$default_sorted = '';
	}

	if ($saved_sorting_fields ) {
		foreach ( $saved_sorting_fields as $saved_sorting_field ) {
			$selected[] = (int) substr(strrchr($saved_sorting_field, '_'), 1);
		}
		foreach ( $selected as $select ) {
			if (is_int($select) ) {
				$selected_option[ $product_table_fields[ $select ]['woo_ids'] . '_' . $select ] = $product_table_fields[ $select ]['woo_label'];
			}
		}
	}

	$selected_option = $selected_option + $fields;
}
?>
<div class="woocommerce_options_panel">
	<?php
	woocommerce_wp_checkbox(
		array(
		'label'       => __('Sorted Column Headings', 'woocommerce-wholesale-pricing'),
		'id'          => 'enable_sort_cols',
		'name'        => 'enable_sort_cols',
		'value'       => wc_bool_to_string($enable_clickable_sort_col),
		'desc_tip'    => true,
		'description' => __('Click on a column heading to sort by that column', 'woocommerce-wholesale-pricing'),
		)
	);

	woocommerce_wp_select(
		array(
		'label'             => __('Fields Sort By', 'woocommerce-wholesale-pricing'),
		'id'                => 'sorted_cols',
		'name'              => 'sorted_cols[]',
		'wrapper_class'     => 'sorting-clickable',
		'class'             => 'wcpt-enhanced-select',
		'options'           => $selected_option,
		'custom_attributes' => array( 'multiple' => 'multiple' ),
		)
	);

	echo '<hr>';

	woocommerce_wp_select(
		array(
		'label'       => __('Default Sort By Field', 'woocommerce-wholesale-pricing'),
		'id'          => 'default_sorted_col',
		'name'        => 'default_sorted_col',
		'class'       => 'wcpt-enhanced-select',
		'value'       => $default_sorted,
		'options'     => array_merge(array( '' => __('Select Default Sort Field', 'woocommerce-wholesale-pricing') ), $fields),
		'desc_tip'    => true,
		'description' => __('Choose which field will be used in by default in sorting', 'woocommerce-wholesale-pricing'),
		)
	);

	woocommerce_wp_select(
		array(
		'label'       => __('Default Sort Direction', 'woocommerce-wholesale-pricing'),
		'id'          => 'default_sorted_dir',
		'name'        => 'default_sorted_dir',
		'class'       => 'wcpt-enhanced-select',
		'options'     => array(
				'asc'  => __('Ascending', 'woocommerce-wholesale-pricing'),
				'desc' => __('Descending', 'woocommerce-wholesale-pricing'),
		),
		'desc_tip'    => true,
		'description' => __('The sort order option controls the direction in which the table is sorted', 'woocommerce-wholesale-pricing'),
		)
	);
	?>
</div>
