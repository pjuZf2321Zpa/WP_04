<?php

global $wp_roles; 

$selected_roles = get_post_meta( $post->ID, '_wcpt_table_user_role_restriction', true );
$selected_users = get_post_meta( $post->ID, '_wcpt_table_user_restriction', true );

$roles_array = array( 'Guest' => __('Guest', 'woocommerce-wholesale-pricing') );

foreach ( $wp_roles->roles as $role_slug => $role_details ) {
	$roles_array[ $role_slug ] = $role_details['name'];
}

if ( ! is_array( $selected_roles ) ) {
	$selected_roles = array();
}

$all_users = get_users();

foreach ( $all_users as $user ) {
	$users_array[ $user->ID ] = $user->display_name . ' (' . $user->user_email . ')';
}

if ( ! is_array( $selected_users ) ) {
	$selected_users = array();
}

?>

<div class="woocommerce_options_panel">
	<?php
	echo '<input type="hidden" name="wcpt_table_restricted_user_roles[]" value="">';
	woocommerce_wp_select(
		array(
			'id'                => 'wcpt_table_restricted_user_roles',
			'name'              => 'wcpt_table_restricted_user_roles[]',
			'class'             => 'wcpt-enhanced-select',
			'label'             => __('User Roles', 'woocommerce-wholesale-pricing'),
			'desc_tip'    => true,
			'description' => __('When no user role is selected, the product table is shown to all roles by default', 'woocommerce-wholesale-pricing'),
			'options'           => $roles_array,
			'custom_attributes' => array( 'multiple' => 'multiple' ),
			'value'             => is_array($selected_roles) && !empty($selected_roles) ? $selected_roles : array(),
		)
	);
	?>
</div>

<div class="woocommerce_options_panel">
	<?php
	echo '<input type="hidden" name="wcpt_table_restricted_users[]" value="">';
	woocommerce_wp_select(
		array(
			'id'                => 'wcpt_table_restricted_users',
			'name'              => 'wcpt_table_restricted_users[]',
			'class'             => 'wcpt-enhanced-select',
			'label'             => __('Users', 'woocommerce-wholesale-pricing'),
			'options'           => $users_array,
			'custom_attributes' => array( 'multiple' => 'multiple' ),
			'value'             => is_array($selected_users) && !empty($selected_users) ? $selected_users : array(),
		)
	);
	?>
</div>
<?php	