<?php
/**
 * Variable list products
 *
 * @package Woocommerce Product Table/metaboxes views
 */

?>
<div class="woocommerce_options_panel">
	<?php
	woocommerce_wp_select(
		array(
		'id'      => 'variable_list_view',
		'name'    => 'variable_list_view',
		'label'   => __('Controls how variable products appear in the table', 'woocommerce-wholesale-pricing'),
		'options' => array(
				''                     => __('--Select the view for variation--', 'woocommerce-wholesale-pricing'),
				'include_variation_dp' => __('Include Variation dropdown', 'woocommerce-wholesale-pricing'),
				'separate_row'         => __('List each variation in a separate row', 'woocommerce-wholesale-pricing'),
				'link_button'          => __('Add a "Select Options" button linking to the single product', 'woocommerce-wholesale-pricing'),
		),
		)
	);
	?>
</div>
