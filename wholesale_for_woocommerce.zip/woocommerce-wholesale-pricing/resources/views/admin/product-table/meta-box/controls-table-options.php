<?php
/**
 * Add controls above & below the table
 *
 * @package Woocommerce Product Table/metaboxes views
 */
$show_page_length    = get_post_meta($post_id, 'display_page_length', true);
$show_product_totals = get_post_meta($post_id, 'display_product_totals', true);
$show_pagination     = get_post_meta($post_id, 'display_pagination', true);
$wcpt_wrap           = get_post_meta($post_id, 'wcpt_wrap', true);
?>
<div class="woocommerce_options_panel">
	<?php
	woocommerce_wp_checkbox(
		array(
		'id'    => 'display_page_length',
		'name'  => 'display_page_length',
		'label' => __('Hide the “Show x products” dropdown list', 'woocommerce-wholesale-pricing'),
		'value' => wc_bool_to_string($show_page_length),
		)
	);
	woocommerce_wp_checkbox(
		array(
		'id'    => 'display_product_totals',
		'name'  => 'display_product_totals',
		'label' => __('Hide the product totals', 'woocommerce-wholesale-pricing'),
		'value' => wc_bool_to_string($show_product_totals),
		)
	);

	woocommerce_wp_checkbox(
		array(
		'id'          => 'display_pagination',
		'name'        => 'display_pagination',
		'label'       => __('Hide the pagination', 'woocommerce-wholesale-pricing'),
		'value'       => wc_bool_to_string($show_pagination),
		'desc_tip'    => true,
		'description' => __('Show paging options that appear below the table when a product table goes onto multiple pages', 'woocommerce-wholesale-pricing'),
		)
	);

	woocommerce_wp_select(
		array(
		'label'         => __('Pagination display', 'woocommerce-wholesale-pricing'),
		'id'            => 'pagingType',
		'name'          => 'pagingType',
		'wrapper_class' => 'pagination-type',
		'class'         => 'wcpt-enhanced-select',
		'options'       => array(
				'numbers'            => __('Page number buttons only', 'woocommerce-wholesale-pricing'),
				'simple'             => __("'Previous' and 'Next' buttons only", 'woocommerce-wholesale-pricing'),
				'simple_numbers'     => __("'Previous' and 'Next' buttons, plus page numbers", 'woocommerce-wholesale-pricing'),
				'full'               => __("'First', 'Previous', 'Next' and 'Last' buttons", 'woocommerce-wholesale-pricing'),
				'full_numbers'       => __("'First', 'Previous', 'Next' and 'Last' buttons, plus page numbers", 'woocommerce-wholesale-pricing'),
				'first_last_numbers' => __(" 'First' and 'Last' buttons, plus page numbers", 'woocommerce-wholesale-pricing'),
		),
		)
	);


	woocommerce_wp_text_input(
		array(
		'id'          => 'wcpt_custom_products_msg',
		'name'        => 'wcpt_custom_products_msg',
		'label'       => __('"No Products" found message', 'woocommerce-wholesale-pricing'),
		'desc_tip'    => true,
		'description' => __('Change the text that appears when there are no products in the table', 'woocommerce-wholesale-pricing'),
		)
	);

	woocommerce_wp_checkbox(
		array(
		'id'          => 'wcpt_wrap',
		'name'        => 'wcpt_wrap',
		'label'       => __('Table Wrap', 'woocommerce-wholesale-pricing'),
		'value'       => wc_bool_to_string($wcpt_wrap),
		'desc_tip'    => true,
		'description' => __('Control whether or not content is wrapped onto multiple lines', 'woocommerce-wholesale-pricing'),
		)
	);

	woocommerce_wp_text_input(
		array(
		'id'          => 'wcpt_scroll',
		'name'        => 'wcpt_scroll',
		'label'       => __('Scroll Offset', 'woocommerce-wholesale-pricing'),
		'type'        => 'number',
		'desc_tip'    => true,
		'description' => __('Change the height that the page scrolls to when you move between pages in the product table', 'woocommerce-wholesale-pricing'),
		)
	);
	?>
</div>
