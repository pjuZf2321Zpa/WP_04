<?php echo esc_html("[wc_quick_order id=$post->ID]");
