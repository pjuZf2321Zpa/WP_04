<form method="post" id="wcpt-import-form">
	<a class="wcpt-import-form page-title-action" href="#"><?php echo esc_html__('Import', 'woocommerce-wholesale-pricing'); ?></a>
</form>
<div id="import-popup" class="import-popup">
	<span class="import-popup-close" >✖️</span>
	<h2><?php echo esc_html__('Upload File to Import', 'woocommerce-wholesale-pricing'); ?></h2>
	<form action="<?php echo esc_url(admin_url('admin-ajax.php?action=wcpt_import_product_table')); ?>" method="post" enctype="multipart/form-data">
	<label for="images" class="drop-container" id="dropcontainer">
	  <span class="drop-title"><?php echo esc_html__('Drop files here', 'woocommerce-wholesale-pricing'); ?></span>
	 <?php echo esc_html__('Or', 'woocommerce-wholesale-pricing'); ?>
	  <input type="file" name="import_file" accept="application/JSON" required>
	  <?php wp_nonce_field('ajax-nonce', 'nonce'); ?>
	  <input type="submit" class="import_files_btn" value="Submit">
	</label>
	</form>
</div>