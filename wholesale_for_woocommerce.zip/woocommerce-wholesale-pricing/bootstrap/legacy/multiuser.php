<?php
/**
 * WWP_Easy_Wholesale_Multiuser
 *
 * Defines a simple, bare-bones object used to compose wholesale-related functionalities.
 *
 * This class is typically used as a mock or data transfer object (DTO) in tests,
 * or as a lightweight entity that needs to inherit the methods provided by the
 * IsWholesale and RegularPriceChange traits without requiring a specific domain
 * base class. By extending \stdClass, it is a basic object structure that gains
 * complex behaviors solely through trait composition.
 *
 * @package    WooCommerceWholesalePricing\Legacy
 * @extends    \stdClass
 */
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\IsWholesale;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\RegularPriceChange;

/**
 * WWP_Easy_Wholesale_Multiuser
 *
 * A composition class that combines traits related to wholesale status and
 * price manipulation.
 *
 * @extends \stdClass
 * @uses    RegularPriceChange Trait providing logic for handling regular price changes,
 * likely including getters and setters for price attributes.
 * @uses    IsWholesale Trait providing methods (e.g., is_wholesale()) to check the
 * current wholesale context status of the object.
 * @extends \stdClass
 */
class WWP_Easy_Wholesale_Multiuser extends stdClass {


	/**
	 * Trait that provides utility functions.
	 */
	use RegularPriceChange;
	use IsWholesale;
}
