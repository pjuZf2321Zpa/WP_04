<?php
/**
 * Application Dependencies Configuration (app.php)
 *
 * This file serves as the primary manifest for the WooCommerce Wholesale Pricing
 * application. It defines the complete list of components (Providers, Services,
 * Screens, and Modules) that the Application Kernel must register and initialize
 * during the plugin's bootstrap process.
 *
 * @package    WooCommerceWholesalePricing\Bootstrap
 */
use WooCommerceWholesalePricing\App\Http\Kernel as Application;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\SettingsService;

/**
 * Defines the application's dependencies and initializable components.
 *
 * The array is structured into four main categories:
 * 1. providers: Classes responsible for environment setup and foundational tasks.
 * 2. services: Classes handling core business logic, data interactions, and hooks.
 * 3. screens: Classes defining the administrative UI pages and their logic.
 * 4. modules: Classes serving as entry points for complex, contained features.
 *
 * @var array $deps
 */
$deps = array(
	/*
	|--------------------------------------------------------------------------
	| Autoloaded Service Providers
	|--------------------------------------------------------------------------
	|
	| The service providers listed here will be automatically loaded on the
	| request to your application. Feel free to add your own services to
	| this array to grant expanded functionality to your applications.
	|
	*/
	'providers' => array(
		\WooCommerceWholesalePricing\App\Providers\Environment::class,
	),

	'migrations' => array(
		\WooCommerceWholesalePricing\Bootstrap\Migration::class,
	),

	/*
	|--------------------------------------------------------------------------
	| Autoloaded Core Services
	|--------------------------------------------------------------------------
	|
	| Services contain the main business logic and handle interactions with WordPress
	| and WooCommerce. They are responsible for things like registering hooks,
	| managing data, and applying plugin logic across the site (frontend/admin).
	|
	*/
	'services'    => array(
		\WooCommerceWholesalePricing\App\Services\UserRoleService::class,
		\WooCommerceWholesalePricing\App\Services\ScriptService::class,
		\WooCommerceWholesalePricing\App\Services\PostTypeService::class,
		\WooCommerceWholesalePricing\App\Services\RoleTaxonomyService::class,
		\WooCommerceWholesalePricing\App\Services\EmailService::class,
		\WooCommerceWholesalePricing\App\Services\RoleUpgradeService::class,
		\WooCommerceWholesalePricing\App\Services\PaymentMethodService::class,
		\WooCommerceWholesalePricing\App\Services\GutenbergBlockService::class,
		\WooCommerceWholesalePricing\App\Services\CouponService::class,
		\WooCommerceWholesalePricing\App\Services\RegistrationRequestService::class,
		\WooCommerceWholesalePricing\App\Services\GroupService::class,
		\WooCommerceWholesalePricing\App\Services\GroupAnnouncementService::class,
		\WooCommerceWholesalePricing\App\Services\GroupMyAccountEndpointService::class,
		\WooCommerceWholesalePricing\App\Services\UserService::class,
		\WooCommerceWholesalePricing\App\Services\ProductCatTaxonomyService::class,
		\WooCommerceWholesalePricing\App\Services\ImportExportService::class,
		\WooCommerceWholesalePricing\App\Services\ProductVisibilityService::class,
		\WooCommerceWholesalePricing\App\Services\RequisitionListService::class,
		\WooCommerceWholesalePricing\App\Services\AdminShopOrderService::class,
		\WooCommerceWholesalePricing\App\Services\AdminProductService::class,
		\WooCommerceWholesalePricing\App\Services\ShopService::class,
		\WooCommerceWholesalePricing\App\Services\WholesaleService::class,
		\WooCommerceWholesalePricing\App\Services\ShopPriceVisibility::class,
		\WooCommerceWholesalePricing\App\Services\TaxService::class,
		\WooCommerceWholesalePricing\App\Services\PrivateStoreService::class,
		\WooCommerceWholesalePricing\App\Services\FormBuilderService::class,
		\WooCommerceWholesalePricing\App\Services\RestAPIService::class,
		\WooCommerceWholesalePricing\App\Services\MiscHookService::class,
		\WooCommerceWholesalePricing\App\Services\ShopProductVariationService::class,
		\WooCommerceWholesalePricing\App\Services\MultilipiIntegrationService::class,

		// AI Assistant abilities (must boot before wp_abilities_api_init).
		\WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities\AbilityRegistry::class,

		// Quote services
		\WooCommerceWholesalePricing\App\Services\Quote\RulesService::class,
		\WooCommerceWholesalePricing\App\Services\Quote\ListService::class,
		// Quote basket is handled by Modules\Quote\QuoteBasketService, which is
		// gated on enable_quote via QuoteService::resolveDependency().
		\WooCommerceWholesalePricing\App\Services\Quote\RequestPageService::class,
		\WooCommerceWholesalePricing\App\Services\Quote\PostTypeService::class,
		\WooCommerceWholesalePricing\App\Services\Quote\AjaxService::class,

		// Product Table services
		\WooCommerceWholesalePricing\App\Services\ProductTable\PostTypeService::class,
		\WooCommerceWholesalePricing\App\Services\ProductTable\AjaxService::class,
		\WooCommerceWholesalePricing\App\Services\ProductTable\ProductTableService::class,
		\WooCommerceWholesalePricing\App\Services\ProductTable\GutenbergBlockService::class,
		\WooCommerceWholesalePricing\App\Services\ProductTable\QuickOrderFormService::class,
		\WooCommerceWholesalePricing\App\Services\ProductTable\QuickOrderShortcodeService::class,

		// Dynamic Rules services
		\WooCommerceWholesalePricing\App\Services\DynamicRules\PostTypeService::class,

		// Sales Agent services
		\WooCommerceWholesalePricing\App\Services\SalesAgent\PostTypeService::class,
		\WooCommerceWholesalePricing\App\Services\SalesAgent\TaxonomyService::class,
		\WooCommerceWholesalePricing\App\Services\SalesAgent\AjaxService::class,
		\WooCommerceWholesalePricing\App\Services\SalesAgent\SalesAgentService::class,


		// Company Credits services
		\WooCommerceWholesalePricing\App\Services\CompanyCredits\PostTypeService::class,
		\WooCommerceWholesalePricing\App\Services\CompanyCredits\PaymentGatewayService::class,
		\WooCommerceWholesalePricing\App\Services\PurchaseOrderGatewayService::class,
		\WooCommerceWholesalePricing\App\Services\CompanyCredits\CompanyCreditsService::class,
		\WooCommerceWholesalePricing\App\Services\CompanyCredits\CreditExpirationService::class,

		\WooCommerceWholesalePricing\App\Services\Quote\QuoteService::class,
		\WooCommerceWholesalePricing\App\Services\Quote\EmailService::class,
		\WooCommerceWholesalePricing\App\Modules\Quote\Handler::class,
	),

	/*
	|--------------------------------------------------------------------------
	| Admin Screens
	|--------------------------------------------------------------------------
	|
	| Screens define the classes responsible for rendering and handling interactions
	| for specific pages or menu items within the WordPress administration area.
	|
	*/
	'screens' => array(
		\WooCommerceWholesalePricing\App\Admin\Screens\Dashboard::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\Settings::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\ProductTable::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\UserRoles::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\Notifications::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\Quote::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\Registration::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\Requests::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\Groups::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\BulkPricing::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\FormBuilder::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\SalesAgent::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\CommissionCategory::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\Payouts::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\PayoutView::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\AgentComissionEdit::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\CompanyCredits::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\DynamicRules::class,
		\WooCommerceWholesalePricing\App\Admin\Screens\AIassistant::class,
	),

	/*
	|--------------------------------------------------------------------------
	| Feature Modules
	|--------------------------------------------------------------------------
	|
	| Modules are higher-level aggregators that wrap several services and settings
	| to manage a complete feature set, often handling the interaction between
	| multiple internal services.
	|
	*/
	'modules'    => array_values(
		array_filter(
			array(
				\WooCommerceWholesalePricing\App\Modules\Registration\Handler::class,
				\WooCommerceWholesalePricing\App\Modules\BulkWholesalePricing\Handler::class,
				\WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Handler::class,
				\WooCommerceWholesalePricing\App\Modules\Quote\Handler::class,
				\WooCommerceWholesalePricing\App\Modules\DynamicRules\Handler::class,
			),
			static function ( $class ) {
				if ( \WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Handler::class === $class ) {
					return SettingsService::is_enabled();
				}

				return true;
			}
		)
	),
);

/**
 * Registers all collected dependencies with the Application Kernel.
 *
 * The Application::register() method is responsible for instantiating these
 * classes, resolving their dependencies (via the service container), and
 * booting them up (e.g., calling an 'init' or 'boot' method) to set up the plugin.
 */
return Application::register($deps);
