<?php

use WooCommerceWholesalePricing\App\Modules\SalesAgent\UserSwitching;

function mendatory_fields() {
	$args = array(
		'taxonomy'   => 'commission_cat',
		'hide_empty' => false,
	);

	$agent_categories = get_terms( $args );

	$value    = array();
	$term_ids = array();
	if ( $agent_categories ) {
		foreach ( $agent_categories as $cat ) {
			$value[]    = '{ "label": "' . $cat->name . '", "value": "' . $cat->term_id . '"}';
			$term_ids[] = $cat->term_id;
		}
	}

	$associativeArrays = array_map( 'json_decode', $value );
	$jsonResult        = json_encode( $associativeArrays );

	// minify json data
	$mendatory_fields = json_decode( '[ { "label": "First Name", "placeholder": "First Name", "type": "textfield", "disableBuilderActions": true, "key": "first_name", "input": true, "tableView": true, "validate":{"required":false} }, { "label": "Last Name", "placeholder": "Last Name", "type": "textfield", "disableBuilderActions": true, "input": true, "key": "last_name", "tableView": false, "validate":{"required":false} }, { "label": "Email", "placeholder": "Email", "type": "email", "tableView": true, "disableBuilderActions": true, "key": "email", "input": true, "validate":{"required":false} }, { "label": "Password", "placeholder": "*****", "autocomplete": "admin", "spellcheck": false, "type": "password", "disableBuilderActions": true, "input": true, "key": "pass", "protected": true, "tableView": false, "validate":{"required":false} }, { "label": "Commission Category", "disableBuilderActions": true, "key": "cat", "type": "select", "input": "true", "tableView": true, "data": { "values": ' . $jsonResult . ' }, "validate":{"required":false} } ]', true );
	return $mendatory_fields;
}

function get_agents_page_url( $type ) {

	$args = array(
		'page'    => 'register-list',
		'section' => $type,
	);

	return esc_url( add_query_arg( $args, admin_url( 'admin.php' ) ) );
}

function get_form_result_with_catagory( $builder_config, $agent_categories ) {

	if ( empty( $builder_config ) ) {
		return false;
	}

	foreach ( $builder_config->components as $components ) {
		if ( 'cat' == $components->key ) {

			if ( ! isset( $components->data ) ) {
				return false;
				break;
			}

			$components->data->values = array();
			foreach ( $agent_categories as $index => $value ) {

				$components->data->values[ $index ] = (object) array(
					'label' => $value->name,
					'value' => $value->term_id,
				);
			}
		}
	}

	return $builder_config;
}

function is_sales_agent_registration_form() {
	if ( ! is_singular() ) {
		return false;
	}

	$post = get_post( get_queried_object_id() );

	if ( ! $post ) {
		return false;
	}

	return has_shortcode( $post->post_content, 'sales_agent_registeration_form' )
		|| has_block( 'salesagent/salesagent-registration', $post );
}

function normalize_agent_ids( $agent_id_meta ) {
	if ( empty( $agent_id_meta ) ) {
		return array();
	}

	if ( is_array( $agent_id_meta ) ) {
		if ( ! array_is_list( $agent_id_meta ) ) {
			$agent_id_meta = array_keys( $agent_id_meta );
		}
		return array_values( array_filter( array_map( 'intval', $agent_id_meta ) ) );
	}

	if ( is_string( $agent_id_meta ) && false !== strpos( $agent_id_meta, ',' ) ) {
		return array_values(
			array_filter(
				array_map(
					'intval',
					array_map( 'trim', explode( ',', $agent_id_meta ) )
				)
			)
		);
	}

	$single_agent_id = (int) $agent_id_meta;
	if ( $single_agent_id <= 0 ) {
		return array();
	}

	return array( $single_agent_id );
}

function filter_valid_agent_ids( $agent_id_meta ) {
	$agent_ids = normalize_agent_ids( $agent_id_meta );
	$valid_ids = array();

	foreach ( $agent_ids as $agent_id ) {
		if ( 'agent' === get_post_type( $agent_id ) && 'publish' === get_post_status( $agent_id ) ) {
			$valid_ids[] = (int) $agent_id;
		}
	}

	return array_values( $valid_ids );
}

if ( ! function_exists( 'wc_agent_user_switching_set_olduser_cookie' ) ) {
	/**
	 * Sets authorisation cookies containing the originating user information.
	 *
	 * @since 1.4.0 The `$token` parameter was added.
	 *
	 * @param int    $old_user_id The ID of the originating user, usually the current logged in user.
	 * @param bool   $pop         Optional. Pop the latest user off the auth cookie, instead of appending the new one. Default false.
	 * @param string $token       Optional. The old user's session token to store for later reuse. Default empty string.
	 */
	function wc_agent_user_switching_set_olduser_cookie( $old_user_id, $pop = false, $token = '' ) {
		$secure_auth_cookie    = UserSwitching::secure_auth_cookie();
		$secure_olduser_cookie = UserSwitching::secure_olduser_cookie();
		$expiration            = time() + 172800; // 48 hours
		$auth_cookie           = wc_agent_user_switching_get_auth_cookie();
		$olduser_cookie        = wp_generate_auth_cookie( $old_user_id, $expiration, 'logged_in', $token );

		if ( $secure_auth_cookie ) {
			$auth_cookie_name = USER_SWITCHING_SECURE_COOKIE;
			$scheme           = 'secure_auth';
		} else {
			$auth_cookie_name = USER_SWITCHING_COOKIE;
			$scheme           = 'auth';
		}

		if ( $pop ) {
			array_pop( $auth_cookie );
		} else {
			array_push( $auth_cookie, wp_generate_auth_cookie( $old_user_id, $expiration, $scheme, $token ) );
		}

		$auth_cookie = json_encode( $auth_cookie );

		/**
		 * Fires immediately before the User Switching authentication cookie is set.
		 *
		 * @since 1.4.0
		 *
		 * @param string $auth_cookie JSON-encoded array of authentication cookie values.
		 * @param int    $expiration  The time when the authentication cookie expires as a UNIX timestamp.
		 * @param int    $old_user_id User ID.
		 * @param string $scheme      Authentication scheme. Values include 'auth' or 'secure_auth'.
		 * @param string $token       User's session token to use for the latest cookie.
		 */
		do_action( 'set_wc_agent_user_switching_cookie', $auth_cookie, $expiration, $old_user_id, $scheme, $token );

		$scheme = 'logged_in';

		/**
		 * Fires immediately before the User Switching old user cookie is set.
		 *
		 * @since 1.4.0
		 *
		 * @param string $olduser_cookie The old user cookie value.
		 * @param int    $expiration     The time when the logged-in authentication cookie expires as a UNIX timestamp.
		 * @param int    $old_user_id    User ID.
		 * @param string $scheme         Authentication scheme. Values include 'auth' or 'secure_auth'.
		 * @param string $token          User's session token to use for this cookie.
		 */
		do_action( 'set_olduser_cookie', $olduser_cookie, $expiration, $old_user_id, $scheme, $token );

		/**
		 * Allows preventing auth cookies from actually being sent to the client.
		 *
		 * @since 1.5.4
		 *
		 * @param bool $send Whether to send auth cookies to the client.
		 */
		if ( ! apply_filters( 'wc_agent_user_switching_send_auth_cookies', true ) ) {
			return;
		}

		setcookie( $auth_cookie_name, $auth_cookie, $expiration, SITECOOKIEPATH, COOKIE_DOMAIN, $secure_auth_cookie, true );
		setcookie( USER_SWITCHING_OLDUSER_COOKIE, $olduser_cookie, $expiration, COOKIEPATH, COOKIE_DOMAIN, $secure_olduser_cookie, true );
	}
}

if ( ! function_exists( 'wc_agent_user_switching_clear_olduser_cookie' ) ) {

	/**
	 * Clears the cookies containing the originating user, or pops the latest item off the end if there's more than one.
	 *
	 * @param bool $clear_all Optional. Whether to clear the cookies (as opposed to just popping the last user off the end). Default true.
	 */
	function wc_agent_user_switching_clear_olduser_cookie( $clear_all = true ) {
		$auth_cookie = wc_agent_user_switching_get_auth_cookie();
		if ( ! empty( $auth_cookie ) ) {
			array_pop( $auth_cookie );
		}
		if ( $clear_all || empty( $auth_cookie ) ) {
			/**
			 * Fires just before the user switching cookies are cleared.
			 *
			 * @since 1.4.0
			 */
			do_action( 'clear_olduser_cookie' );

			/**
			* Filter.
			*
			* @since 1.0.4
			*/
			if ( ! apply_filters( 'wc_agent_user_switching_send_auth_cookies', true ) ) {
				return;
			}

			$expire = time() - 31536000;
			setcookie( USER_SWITCHING_COOKIE, ' ', $expire, SITECOOKIEPATH, COOKIE_DOMAIN );
			setcookie( USER_SWITCHING_SECURE_COOKIE, ' ', $expire, SITECOOKIEPATH, COOKIE_DOMAIN );
			setcookie( USER_SWITCHING_OLDUSER_COOKIE, ' ', $expire, COOKIEPATH, COOKIE_DOMAIN );
		} else {
			if ( UserSwitching::secure_auth_cookie() ) {
				$scheme = 'secure_auth';
			} else {
				$scheme = 'auth';
			}

			$old_cookie = end( $auth_cookie );

			$old_user_id = wp_validate_auth_cookie( $old_cookie, $scheme );
			if ( $old_user_id ) {
				$parts = wp_parse_auth_cookie( $old_cookie, $scheme );
				wc_agent_user_switching_set_olduser_cookie( $old_user_id, true, $parts['token'] );
			}
		}
	}
}

if ( ! function_exists( 'wc_agent_user_switching_get_olduser_cookie' ) ) {

	/**
	 * Gets the value of the cookie containing the originating user.
	 *
	 * @return string|false The old user cookie, or boolean false if there isn't one.
	 */
	function wc_agent_user_switching_get_olduser_cookie() {
		if ( isset( $_COOKIE[ USER_SWITCHING_OLDUSER_COOKIE ] ) ) {
			return wp_unslash( sanitize_text_field( $_COOKIE[ USER_SWITCHING_OLDUSER_COOKIE ] ) );
		} else {
			return false;
		}
	}
}

if ( ! function_exists( 'wc_agent_user_switching_get_auth_cookie' ) ) {

	/**
	 * Gets the value of the auth cookie containing the list of originating users.
	 *
	 * @return string[] Array of originating user authentication cookie values. Empty array if there are none.
	 */
	function wc_agent_user_switching_get_auth_cookie() {
		if ( UserSwitching::secure_auth_cookie() ) {
			$auth_cookie_name = USER_SWITCHING_SECURE_COOKIE;
		} else {
			$auth_cookie_name = USER_SWITCHING_COOKIE;
		}

		if ( isset( $_COOKIE[ $auth_cookie_name ] ) && is_string( $_COOKIE[ $auth_cookie_name ] ) ) {
			$cookie = json_decode( wp_unslash( sanitize_text_field( $_COOKIE[ $auth_cookie_name ] ) ) );
		}
		if ( ! isset( $cookie ) || ! is_array( $cookie ) ) {
			$cookie = array();
		}
		return $cookie;
	}
}

if ( ! function_exists( 'sa_set_auth_cookie' ) ) {
	function sa_set_auth_cookie( $user_id, $remember = false, $secure = '', $token = '' ) {
		if ( $remember ) {
			/**
			 * Filters the duration of the authentication cookie expiration period.
			 *
			 * @since 2.8.0
			 *
			 * @param int  $length   Duration of the expiration period in seconds.
			 * @param int  $user_id  User ID.
			 * @param bool $remember Whether to remember the user login. Default false.
			 */
			$expiration = time() + apply_filters( 'auth_cookie_expiration', 14 * DAY_IN_SECONDS, $user_id, $remember );

			/*
			 * Ensure the browser will continue to send the cookie after the expiration time is reached.
			 * Needed for the login grace period in wp_validate_auth_cookie().
			 */
			$expire = $expiration + ( 12 * HOUR_IN_SECONDS );
		} else {
			/**
			 * This filter is documented in wp-includes/pluggable.php
			 *
			 * @since 1.2
			 */
			$expiration = time() + apply_filters( 'auth_cookie_expiration', 2 * DAY_IN_SECONDS, $user_id, $remember );
			$expire     = 0;
		}

		if ( '' === $secure ) {
			$secure = is_ssl();
		}

		// Front-end cookie is secure when the auth cookie is secure and the site's home URL uses HTTPS.
		$secure_logged_in_cookie = $secure && 'https' === parse_url( get_option( 'home' ), PHP_URL_SCHEME );

		/**
		 * Filters whether the auth cookie should only be sent over HTTPS.
		 *
		 * @since 3.1.0
		 *
		 * @param bool $secure  Whether the cookie should only be sent over HTTPS.
		 * @param int  $user_id User ID.
		 */
		$secure = apply_filters( 'secure_auth_cookie', $secure, $user_id );

		/**
		 * Filters whether the logged in cookie should only be sent over HTTPS.
		 *
		 * @since 3.1.0
		 *
		 * @param bool $secure_logged_in_cookie Whether the logged in cookie should only be sent over HTTPS.
		 * @param int  $user_id                 User ID.
		 * @param bool $secure                  Whether the auth cookie should only be sent over HTTPS.
		 */
		$secure_logged_in_cookie = apply_filters( 'secure_logged_in_cookie', $secure_logged_in_cookie, $user_id, $secure );

		if ( $secure ) {
			$auth_cookie_name = SECURE_AUTH_COOKIE;
			$scheme           = 'secure_auth';
		} else {
			$auth_cookie_name = AUTH_COOKIE;
			$scheme           = 'auth';
		}

		if ( '' === $token ) {
			$manager = \WP_Session_Tokens::get_instance( $user_id );
			$token   = $manager->create( $expiration );
		}

		$auth_cookie      = wp_generate_auth_cookie( $user_id, $expiration, $scheme, $token );
		$logged_in_cookie = wp_generate_auth_cookie( $user_id, $expiration, 'logged_in', $token );

		/**
		 * Fires immediately before the authentication cookie is set.
		 *
		 * @since 2.5.0
		 * @since 4.9.0 The `$token` parameter was added.
		 *
		 * @param string $auth_cookie Authentication cookie value.
		 * @param int    $expire      The time the login grace period expires as a UNIX timestamp.
		 *                            Default is 12 hours past the cookie's expiration time.
		 * @param int    $expiration  The time when the authentication cookie expires as a UNIX timestamp.
		 *                            Default is 14 days from now.
		 * @param int    $user_id     User ID.
		 * @param string $scheme      Authentication scheme. Values include 'auth' or 'secure_auth'.
		 * @param string $token       User's session token to use for this cookie.
		 */
		do_action( 'set_auth_cookie', $auth_cookie, $expire, $expiration, $user_id, $scheme, $token );

		/**
		 * Fires immediately before the logged-in authentication cookie is set.
		 *
		 * @since 2.6.0
		 * @since 4.9.0 The `$token` parameter was added.
		 *
		 * @param string $logged_in_cookie The logged-in cookie value.
		 * @param int    $expire           The time the login grace period expires as a UNIX timestamp.
		 *                                 Default is 12 hours past the cookie's expiration time.
		 * @param int    $expiration       The time when the logged-in authentication cookie expires as a UNIX timestamp.
		 *                                 Default is 14 days from now.
		 * @param int    $user_id          User ID.
		 * @param string $scheme           Authentication scheme. Default 'logged_in'.
		 * @param string $token            User's session token to use for this cookie.
		 */
		do_action( 'set_logged_in_cookie', $logged_in_cookie, $expire, $expiration, $user_id, 'logged_in', $token );

		/**
		 * Allows preventing auth cookies from actually being sent to the client.
		 *
		 * @since 4.7.4
		 * @since 6.2.0 The `$expire`, `$expiration`, `$user_id`, `$scheme`, and `$token` parameters were added.
		 *
		 * @param bool   $send       Whether to send auth cookies to the client. Default true.
		 * @param int    $expire     The time the login grace period expires as a UNIX timestamp.
		 *                           Default is 12 hours past the cookie's expiration time. Zero when clearing cookies.
		 * @param int    $expiration The time when the logged-in authentication cookie expires as a UNIX timestamp.
		 *                           Default is 14 days from now. Zero when clearing cookies.
		 * @param int    $user_id    User ID. Zero when clearing cookies.
		 * @param string $scheme     Authentication scheme. Values include 'auth' or 'secure_auth'.
		 *                           Empty string when clearing cookies.
		 * @param string $token      User's session token to use for this cookie. Empty string when clearing cookies.
		 */
		if ( ! apply_filters( 'send_auth_cookies', true, $expire, $expiration, $user_id, $scheme, $token ) ) {
			return;
		}

		setcookie( $auth_cookie_name, $auth_cookie, $expire, PLUGINS_COOKIE_PATH, COOKIE_DOMAIN, $secure, true );
		setcookie( $auth_cookie_name, $auth_cookie, $expire, ADMIN_COOKIE_PATH, COOKIE_DOMAIN, $secure, true );
		setcookie( LOGGED_IN_COOKIE, $logged_in_cookie, $expire, COOKIEPATH, COOKIE_DOMAIN, $secure_logged_in_cookie, true );
		if ( COOKIEPATH != SITECOOKIEPATH ) {
			setcookie( LOGGED_IN_COOKIE, $logged_in_cookie, $expire, SITECOOKIEPATH, COOKIE_DOMAIN, $secure_logged_in_cookie, true );
		}
	}
}

if ( ! function_exists( 'switch_to_user' ) ) {

	/**
	 * Switches the current logged in user to the specified user.
	 *
	 * @param  int  $user_id      The ID of the user to switch to.
	 * @param  bool $remember     Optional. Whether to 'remember' the user in the form of a persistent browser cookie. Default false.
	 * @param  bool $set_old_user Optional. Whether to set the old user cookie. Default true.
	 * @return false|WP_User WP_User object on success, false on failure.
	 */
	function switch_to_user( $user_id, $remember = false, $set_old_user = true ) {
		$user = get_userdata( $user_id );

		if ( ! $user ) {
			return false;
		}

		$old_user_id  = ( is_user_logged_in() ) ? get_current_user_id() : false;
		$old_token    = function_exists( 'wp_get_session_token' ) ? wp_get_session_token() : '';
		$auth_cookie  = wc_agent_user_switching_get_auth_cookie();
		$cookie_parts = wp_parse_auth_cookie( end( $auth_cookie ) );

		if ( $set_old_user && $old_user_id ) {
			// Switching to another user
			$new_token = '';
			wc_agent_user_switching_set_olduser_cookie( $old_user_id, false, $old_token );
		} else {
			// Switching back, either after being switched off or after being switched to another user
			$new_token = isset( $cookie_parts['token'] ) ? $cookie_parts['token'] : '';
			wc_agent_user_switching_clear_olduser_cookie( false );
		}

		/**
		 * Attaches the original user ID and session token to the new session when a user switches to another user.
		 *
		 * @param  array $session Array of extra data.
		 * @param  int   $user_id User ID.
		 * @return array Array of extra data.
		 */
		$session_filter = function ( array $session, $user_id ) use ( $old_user_id, $old_token ) {
			$session['switched_from_id']      = $old_user_id;
			$session['switched_from_session'] = $old_token;
			return $session;
		};

		add_filter( 'attach_session_information', $session_filter, 99, 2 );

		wp_clear_auth_cookie();
		sa_set_auth_cookie( $user_id, $remember, '', $new_token );
		wp_set_current_user( $user_id ); // phpcs:ignore Generic.PHP.ForbiddenFunctions.Discouraged

		remove_filter( 'attach_session_information', $session_filter, 99 );

		if ( $set_old_user ) {
			/**
			 * Fires when a user switches to another user account.
			 *
			 * @since 0.6.0
			 * @since 1.4.0 The `$new_token` and `$old_token` parameters were added.
			 *
			 * @param int    $user_id     The ID of the user being switched to.
			 * @param int    $old_user_id The ID of the user being switched from.
			 * @param string $new_token   The token of the session of the user being switched to. Can be an empty string
			 *                            or a token for a session that may or may not still be valid.
			 * @param string $old_token   The token of the session of the user being switched from.
			 */
			do_action( 'switch_to_user', $user_id, $old_user_id, $new_token, $old_token );
		} else {
			/**
			 * Fires when a user switches back to their originating account.
			 *
			 * @since 0.6.0
			 * @since 1.4.0 The `$new_token` and `$old_token` parameters were added.
			 *
			 * @param int       $user_id     The ID of the user being switched back to.
			 * @param int|false $old_user_id The ID of the user being switched from, or false if the user is switching back
			 *                               after having been switched off.
			 * @param string    $new_token   The token of the session of the user being switched to. Can be an empty string
			 *                               or a token for a session that may or may not still be valid.
			 * @param string    $old_token   The token of the session of the user being switched from.
			 */
			do_action( 'switch_back_user', $user_id, $old_user_id, $new_token, $old_token );
		}

		if ( $old_token && $old_user_id && ! $set_old_user ) {
			// When switching back, destroy the session for the old user
			$manager = \WP_Session_Tokens::get_instance( $old_user_id );
			$manager->destroy( $old_token );
		}

		return $user;
	}
}

if ( ! function_exists( 'switch_off_user' ) ) {

	/**
	 * Switches off the current logged in user. This logs the current user out while retaining a cookie allowing them to log
	 * straight back in using the 'Switch back to {user}' system.
	 *
	 * @return bool True on success, false on failure.
	 */
	function switch_off_user() {
		$old_user_id = get_current_user_id();

		if ( ! $old_user_id ) {
			return false;
		}

		$old_token = function_exists( 'wp_get_session_token' ) ? wp_get_session_token() : '';

		wc_agent_user_switching_set_olduser_cookie( $old_user_id, false, $old_token );
		wp_clear_auth_cookie();
		wp_set_current_user( 0 ); // phpcs:ignore Generic.PHP.ForbiddenFunctions.Discouraged

		/**
		 * Fires when a user switches off.
		 *
		 * @since 0.6.0
		 * @since 1.4.0 The `$old_token` parameter was added.
		 *
		 * @param int    $old_user_id The ID of the user switching off.
		 * @param string $old_token   The token of the session of the user switching off.
		 */
		do_action( 'switch_off_user', $old_user_id, $old_token );

		return true;
	}
}

if ( ! function_exists( 'current_user_switched' ) ) {

	/**
	 * Returns whether the current user switched into their account.
	 *
	 * @return false|WP_User False if the user isn't logged in or they didn't switch in; old user object (which evaluates to
	 *                       true) if the user switched into the current user account.
	 */
	function current_user_switched() {
		if ( ! is_user_logged_in() ) {
			return false;
		}

		return UserSwitching::get_old_user();
	}
}

function filter_where_condtion( $agent_id = false ) {
	global $wpdb;
	if ( $agent_id ) {
		return $agent_id;
	} else {
		$where = 'WHERE 1';
	}

	if ( isset( $_REQUEST['agent-filter'] ) && ! empty( $_REQUEST['agent-filter'] ) ) {
		$where .= $wpdb->prepare( ' AND agent_id = %d', absint( $_REQUEST['agent-filter'] ) );
	}
	if ( isset( $_REQUEST['date_from'] ) && ! empty( $_REQUEST['date_from'] ) ) {
		$from   = gmdate( 'Y-m-d 00:00:01', strtotime( sanitize_text_field( $_REQUEST['date_from'] ) ) );
		$where .= $wpdb->prepare( ' AND create_date >= %s', $from );
	}

	if ( isset( $_REQUEST['date_to'] ) && ! empty( $_REQUEST['date_to'] ) ) {
		$to     = gmdate( 'Y-m-d 23:59:59', strtotime( sanitize_text_field( $_REQUEST['date_to'] ) ) );
		$where .= $wpdb->prepare( ' AND create_date <= %s', $to );
	}
	return $where;
}
