<?php
/**
 * WCPT Core Functions
 *
 * @package Woocommerce Product Table/Functions.
 */

/**
 * Get wc product table template
 *
 * @param string $template_name Template name.
 * @param array  $args          Arguments. (default: array).
 * @param string $template_path Template path. (default: '').
 * @param string $default_path  Default path. (default: '').
 */
if ( !function_exists('wwp_wc_product_table_get_template') ) {
	function wwp_wc_product_table_get_template( $template_name, $args = array(), $template_path = '', $default_path = '' ) {
		if (! empty($args) && is_array($args) ) {
			extract($args, EXTR_SKIP); // @codingStandardsIgnoreLine
		}

		$located = wwp_wc_product_table_locate_template($template_name, $template_path, $default_path);

		if (! file_exists($located) ) {
			/* translators: %s template */
			wc_doing_it_wrong(__FUNCTION__, sprintf(__('%s does not exist.', 'woocommerce-wholesale-pricing'), '<code>' . $located . '</code>'), '2.1');
			return;
		}

		/**
		 * Filter product table get template
		 * 
		 * @since 1.1.6
		**/
		$located = apply_filters('wcpt_product_table_get_template', $located, $template_name, $args, $template_path, $default_path);
		/**
		 * Action before template part 
		 * 
		 * @since 1.1.6
		**/
		do_action('wcpt_product_table_before_template_part', $template_name, $template_path, $located, $args);

		if (file_exists($located)) {
		include $located; // nosemgrep: audit.php.lang.security.file.inclusion-arg
		} else {
		/* translators: %s template */
		wc_doing_it_wrong(__FUNCTION__, sprintf(__(' %s does not exist.', 'woocommerce-wholesale-pricing'), '<code>' . $located . '</code>'), '2.1');
		return;
		}
		/**
		 * Action after template part 
		 * 
		 * @since 1.1.6
		**/
		do_action('wcpt_product_table_after_template_part', $template_name, $template_path, $located, $args);
	}
}

if ( ! function_exists('wwp_wc_allowed_html') ) {
	function wwp_wc_allowed_html() {

		$allowed_atts = array(
		'role'          => array(),
		'align'      => array(),
		'class'      => array(),
		'id'         => array(),
		'dir'        => array(),
		'lang'       => array(),
		'style'      => array(),
		'xml:lang'   => array(),
		'src'        => array(),
		'alt'        => array(),
		'href'       => array(),
		'rel'        => array(),
		'rev'        => array(),
		'target'     => array(),
		'novalidate' => array(),
		'type'       => array(),
		'value'      => array(),
		'required'   => array(),
		'name'       => array(),
		'tabindex'   => array(),
		'action'     => array(),
		'method'     => array(),
		'for'        => array(),
		'width'      => array(),
		'height'     => array(),
		'data'       => array(),
		'title'      => array(),
		'selected'   => array(),
		'enctype'    => array(),
		'disable'    => array(),
		'disabled'   => array(),
		'aria-label' => array(),
		'data-label' => array(),
		'data-attribute' => array(),
		'data-src'      => array(),
		'data-large_image' => array(),
		'data-variation_ids' => array(),
		'data-h_label' => array(),
		'data-h_taxonomy' => array(),
		'data-h_attribute' => array(),
		'data-v_taxonomy' => array(),
		'data-v_attribute' => array(),
		'data-attribute_count' => array(),
		'data-product_variations' => array(),
		'data-price' => array(),
		'data-product_id' => array(),
		'data-v_label' => array(),
		'min' => array(),
		'max' => array(),
		'step' => array(),
		'srcset' => array(),
		'xmlns' => array(),
		'viewbox' => array(),
		'data-name' => array(),
		'd' => array(),
		'cx' => array(),
		'cy' => array(),
		'r' => array(),
		);

		$allowedposttags['form']     = $allowed_atts;
		$allowedposttags['label']    = $allowed_atts;
		$allowedposttags['select']   = $allowed_atts;
		$allowedposttags['option']   = $allowed_atts;
		$allowedposttags['input']    = $allowed_atts;
		$allowedposttags['textarea'] = $allowed_atts;
		$allowedposttags['link'] = $allowed_atts;
		$allowedposttags['button'] = $allowed_atts;
		$allowedposttags['iframe']   = $allowed_atts;
		$allowedposttags['script']   = $allowed_atts;
		$allowedposttags['style']    = $allowed_atts;
		$allowedposttags['strong']   = $allowed_atts;
		$allowedposttags['small']    = $allowed_atts;
		$allowedposttags['table']    = $allowed_atts;
		$allowedposttags['bdi']    = $allowed_atts;
		$allowedposttags['del']    = $allowed_atts;
		$allowedposttags['ins']    = $allowed_atts;
		$allowedposttags['span']     = $allowed_atts;
		$allowedposttags['abbr']     = $allowed_atts;
		$allowedposttags['code']     = $allowed_atts;
		$allowedposttags['pre']      = $allowed_atts;
		$allowedposttags['div']      = $allowed_atts;
		$allowedposttags['img']      = $allowed_atts;
		$allowedposttags['svg']      = $allowed_atts;
		$allowedposttags['path']      = $allowed_atts;
		$allowedposttags['h1']       = $allowed_atts;
		$allowedposttags['h2']       = $allowed_atts;
		$allowedposttags['h3']       = $allowed_atts;
		$allowedposttags['h4']       = $allowed_atts;
		$allowedposttags['h5']       = $allowed_atts;
		$allowedposttags['h6']       = $allowed_atts;
		$allowedposttags['ol']       = $allowed_atts;
		$allowedposttags['ul']       = $allowed_atts;
		$allowedposttags['li']       = $allowed_atts;
		$allowedposttags['em']       = $allowed_atts;
		$allowedposttags['hr']       = $allowed_atts;
		$allowedposttags['br']       = $allowed_atts;
		$allowedposttags['tr']       = $allowed_atts;
		$allowedposttags['td']       = $allowed_atts;
		$allowedposttags['p']        = $allowed_atts;
		$allowedposttags['a']        = $allowed_atts;
		$allowedposttags['b']        = $allowed_atts;
		$allowedposttags['i']        = $allowed_atts;
		$allowedposttags['defs']        = $allowed_atts;
		$allowedposttags['circle']        = $allowed_atts;
		$allowedposttags['title']        = $allowed_atts;

		return $allowedposttags;
	}
}

/**
 * Locate wc product table template and return the path for inclusion.
 *
 * This is the load order:
 *
 * yourtheme/$template_path/$template_name
 * yourtheme/$template_name
 * $default_path/$template_name
 *
 * @param  string $template_name Template name.
 * @param  string $template_path Template path. (default: '').
 * @param  string $default_path  Default path. (default: '').
 * @return string
 */
if ( ! function_exists('wwp_wc_product_table_locate_template') ) {
	function wwp_wc_product_table_locate_template( $template_name, $template_path = '', $default_path = '' ) {
		if (! $template_path ) {
			/**
			 * Filter product table template path 
			 * 
			 * @since 1.1.6
			**/
			$template_path = apply_filters('wcpt_product_table_template_path', 'wc_product_table/');
		}

		if (! $default_path ) {
			$default_path = WWP_PLUGIN_PATH . 'resources/views/product-table/';
		}

		// Look within passed path within the theme - this is priority.
		$template = locate_template(
			array(
			trailingslashit($template_path) . $template_name,
			$template_name,
			)
		);

		// Get default template/.
		if (! $template ) {
			$template = $default_path . $template_name;
		}

		/**
		 * Filter product table locate template 
		 * 
		 * @since 1.1.6
		**/
		return apply_filters('wcpt_product_table_locate_template', $template, $template_name, $template_path);
	}
}

/**
 * Get array of hidden columns ids
 *
 * @param  array $col_ids array of column ids.
 * @return array
 */
function prepare_columns_ids( $col_ids ) {
	if ( ! is_array( $col_ids ) ) {
		return array();
	}

	$hidden_col_ids = array_map(
		function ( $val ) {
			$data = explode( '_', (string) $val );

			return (int) end( $data );
		},
		$col_ids
	);

	return array_values( $hidden_col_ids );
}
