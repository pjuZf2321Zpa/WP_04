<?php
/**
 * Installation
 *
 * This class handles the initial setup, default options creation, and migration
 * procedures upon plugin activation. It acts as the primary bootstrap for the
 * initial state of the application.
 *
 * @package    WooCommerceWholesalePricing\Bootstrap
 */
namespace WooCommerceWholesalePricing\Bootstrap;

use WooCommerceWholesalePricing\App\Migrations\AIAssistantHistoryTableMigration;
use WooCommerceWholesalePricing\App\Migrations\SalesAgentCommissionsTableMigration;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\Bootstrap\Migration;

/**
 * Installation
 *
 * Manages the plugin's installation and version migration processes.
 */
class Installation {

		
	/**
	 * Includes the WholesaleSettings trait to gain access to helper methods
	 * for reading and writing plugin options (e.g., get_pricing_settings, update_pricing_settings).
	 */
	use WholesaleSettings;

	/**
	 * The primary entry point for installation tasks.
	 *
	 * This method is typically hooked to a WordPress activation routine.
	 *
	 * @return void
	 */
	public function init() {
		self::activation();
	}
	
	/**
	 * Performs initial activation setup.
	 *
	 * This static method checks if the core wholesale pricing settings exist.
	 * If they do not, it initializes them with a safe set of defaults.
	 *
	 * @return void
	 */
	public static function activation() {
		AIAssistantHistoryTableMigration::create_table();
		SalesAgentCommissionsTableMigration::create_table();

		if (self::get_pricing_settings() == false ) { 
			self::update_pricing_settings(
				array( 
					'wholesale_role'        => 'single', 
					'restrict_store_access' => '', 
					'retailer_disabled'     => '', 
					'save_price_disabled'   => '',
					'emailuserrole'         => 'order_email_custom',
				)
			);
		}
	}
}
