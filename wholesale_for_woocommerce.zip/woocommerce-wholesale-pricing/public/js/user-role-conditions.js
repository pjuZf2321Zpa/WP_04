/**
 * Wholesale role Conditions panel: collapse, country/state lists, summary.
 */
(function ($) {
	'use strict';

	var params = window.wwpRoleConditions || {};
	var statesMap = params.states || {};
	var countryNames = params.countries || {};
	var i18n = params.i18n || {};

	function getSelectedCountries() {
		var val = $('#wwp_condition_countries').val();
		return val ? val : [];
	}

	function collectStatesForCountries(countries) {
		var options = [];
		$.each(countries, function (_, country) {
			var states = statesMap[country];
			if (!states || $.isEmptyObject(states)) {
				return;
			}
			$.each(states, function (code, name) {
				options.push({
					id: country + ':' + code,
					text: name + ' (' + country + ')'
				});
			});
		});
		return options;
	}

	function refreshStates() {
		var $states = $('#wwp_condition_states');
		if (!$states.length) {
			return;
		}

		var countries = getSelectedCountries();
		var options = collectStatesForCountries(countries);
		var previous = $states.val() || [];
		var stored = $states.data('selected');
		if ((!previous || !previous.length) && stored) {
			if (typeof stored === 'string') {
				try {
					stored = JSON.parse(stored);
				} catch (e) {
					stored = [];
				}
			}
			if ($.isArray(stored) && stored.length) {
				previous = stored;
				$states.removeData('selected').removeAttr('data-selected');
			}
		}
		var $help = $('.wwp-role-conditions-states-help');

		$states.empty();

		if (!options.length) {
			$states.prop('disabled', true);
			$help.text(i18n.noStates || 'No states/regions for the selected country.');
		} else {
			var validIds = {};
			$states.prop('disabled', false);
			$.each(options, function (_, option) {
				validIds[option.id] = true;
				$states.append($('<option></option>').attr('value', option.id).text(option.text));
			});
			var kept = $.grep(previous, function (value) {
				return !!validIds[value];
			});
			$states.val(kept);
			$help.text(i18n.leaveEmpty || 'Leave empty to apply to the whole country.');
		}

		$states.trigger('change.select2');
		updateSummary();
	}

	function formatStateLabel(value) {
		var parts = (value || '').split(':');
		if (parts.length < 2) {
			return value;
		}
		var country = parts[0];
		var state = parts[1];
		var name = statesMap[country] && statesMap[country][state] ? statesMap[country][state] : state;
		return name + ' (' + country + ')';
	}

	function updateSummary() {
		var $summary = $('.wwp-role-conditions-summary');
		if (!$summary.length || !$('#wwp_conditions_enabled').is(':checked')) {
			$summary.text('');
			return;
		}

		var location = $('#wwp_condition_location').val() === 'billing'
			? (i18n.billing || 'billing address')
			: (i18n.shipping || 'shipping address');
		var countries = getSelectedCountries();
		var states = $('#wwp_condition_states').val() || [];
		var min = $.trim($('#wwp_condition_min_order').val());
		var max = $.trim($('#wwp_condition_max_order').val());
		var place;

		if (states.length) {
			place = states.map(formatStateLabel).join(', ');
		} else if (countries.length) {
			place = countries.map(function (code) {
				return countryNames[code] || code;
			}).join(', ');
		} else {
			place = i18n.anyLocation || 'any location';
		}

		var totals = i18n.anyTotal || 'any order total';
		if (min && max) {
			totals = (i18n.betweenTotals || 'orders from %1$s to %2$s').replace('%1$s', min).replace('%2$s', max);
		} else if (min) {
			totals = (i18n.minTotal || 'orders of at least %s').replace('%s', min);
		} else if (max) {
			totals = (i18n.maxTotal || 'orders up to %s').replace('%s', max);
		}

		$summary.text(
			(i18n.summary || 'Restricted when the %1$s is in %2$s, for %3$s.')
				.replace('%1$s', location)
				.replace('%2$s', place)
				.replace('%3$s', totals)
		);
	}

	function toggleBody() {
		var enabled = $('#wwp_conditions_enabled').is(':checked');
		$('.wwp-role-conditions-body').prop('hidden', !enabled);
		updateSummary();
	}

	$(function () {
		initPurchaseOrderGateway();

		if (!$('.wwp-role-conditions').length) {
			return;
		}

		$(document).on('change', '#wwp_conditions_enabled', toggleBody);
		$(document).on('change', '#wwp_condition_countries', refreshStates);
		$(document).on('change', '#wwp_condition_location, #wwp_condition_states, #wwp_condition_min_order, #wwp_condition_max_order', updateSummary);
		$('form#edittag, form#addtag').on('submit', function () {
			$('#wwp_condition_states').prop('disabled', false);
		});

		toggleBody();
		refreshStates();
	});

	function syncPurchaseOrderGateway() {
		var enabled = $('#wwp_po_enabled').is(':checked');
		var allowUpload = $('#wwp_po_allow_upload').is(':checked');
		$('.wwp-po-gateway-extra').prop('hidden', !enabled);
		$('.wwp-po-upload-settings').prop('hidden', !enabled || !allowUpload);
		$('.wwp-po-require-upload-row').toggleClass('is-disabled', !allowUpload);
		$('#wwp_po_require_upload').prop('disabled', !allowUpload);
		if (!allowUpload) {
			$('#wwp_po_require_upload').prop('checked', false);
		}
	}

	function initPurchaseOrderGateway() {
		if (!$('#wwp-po-gateway').length) {
			return;
		}
		$(document).on('change', '#wwp_po_enabled, #wwp_po_allow_upload', syncPurchaseOrderGateway);
		$('form#edittag, form#addtag').on('submit', function () {
			$('#wwp_po_require_upload').prop('disabled', false);
		});
		syncPurchaseOrderGateway();
	}
})(jQuery);
