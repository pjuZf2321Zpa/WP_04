jQuery(function ($) {
	if (typeof wcpt_quick_order_admin_params === 'undefined') {
		return;
	}

	var params = wcpt_quick_order_admin_params;
	var $modal = $('#wcpt-table-type-modal');

	function openModal() {
		if (!$modal.length) {
			return;
		}

		$modal.attr('aria-hidden', 'false').show();
		$('body').addClass('wcpt-table-type-modal-open');
		$modal.find('.wcpt-table-type-modal__close').trigger('focus');
	}

	function closeModal() {
		if (!$modal.length) {
			return;
		}

		$modal.attr('aria-hidden', 'true').hide();
		$('body').removeClass('wcpt-table-type-modal-open');
	}

	function getAddNewLinks() {
		return $('.page-title-action').filter(function () {
			var href = $(this).attr('href') || '';
			return href.indexOf('post-new.php') !== -1 && href.indexOf('post_type=wcpt') !== -1;
		});
	}

	function initAddNewPopup() {
		if (!$modal.length || !params.quick_order_enabled) {
			return;
		}

		var $addNewLinks = getAddNewLinks();
		if (!$addNewLinks.length) {
			return;
		}

		if (!$modal.parent().is('body')) {
			$modal.appendTo('body');
		}

		$addNewLinks.on('click', function (event) {
			event.preventDefault();
			openModal();
		});

		$modal.on('click', '.wcpt-table-type-modal__close, .wcpt-table-type-modal__backdrop', function () {
			closeModal();
		});

		$modal.on('click', '.wcpt-table-type-option', function (event) {
			event.preventDefault();
			var url = $(this).data('url') || $(this).attr('href');
			if (url) {
				window.location.href = url;
			}
		});

		$(document).on('keydown.wcptTableTypeModal', function (event) {
			if (event.key === 'Escape' && $modal.is(':visible')) {
				closeModal();
			}
		});
	}

	function persistQuickOrderUrlParam() {
		if (!params.is_quick_order_form) {
			return;
		}

		var url = new URL(window.location.href);
		if (url.searchParams.get('table') !== 'quick_order_form') {
			url.searchParams.set('table', 'quick_order_form');
			window.history.replaceState({}, '', url.toString());
		}
	}

	initAddNewPopup();
	persistQuickOrderUrlParam();
});
