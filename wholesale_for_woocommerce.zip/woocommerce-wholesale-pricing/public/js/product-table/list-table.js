jQuery(function ($) {
	if (typeof wcpt_list_table_params === 'undefined') {
		return;
	}

	function initImportUi() {
		var $importForm = $('#wcpt-import-form');
		var $importPopup = $('#import-popup');

		if (!$importForm.length || !$importPopup.length) {
			return;
		}

		var $headerEnd = $('hr.wp-header-end');
		if ($headerEnd.length) {
			$importForm.insertBefore($headerEnd);
			$importPopup.insertBefore($headerEnd);
		}

		$importForm.on('click', '.wcpt-import-form', function (event) {
			event.preventDefault();
			$importPopup.show();
		});

		$importPopup.on('click', '.import-popup-close', function () {
			$importPopup.hide();
		});
	}

	initImportUi();

	function getTogglePayload($input) {
		var action = $input.data('action');
		var postId = $input.data('post-id');
		var payload = {
			action: '',
			post_id: postId,
			nonce: wcpt_list_table_params.nonce,
		};

		if ('onepage_checkout' === action) {
			payload.action = 'wcpt_toggle_onepage_checkout';
			payload.enabled = $input.is(':checked') ? '1' : '0';
		} else if ('post_status' === action) {
			payload.action = 'wcpt_toggle_post_status';
			payload.status = $input.is(':checked') ? 'publish' : 'draft';
		}

		return payload;
	}

	$('#the-list').on('change', '.wcpt-list-toggle', function () {
		var $input = $(this);
		var payload = getTogglePayload($input);

		if (!payload.action) {
			return;
		}

		var previousChecked = !$input.is(':checked');
		$input.prop('disabled', true);

		$.post(wcpt_list_table_params.ajax_url, payload)
			.done(function (response) {
				if (!response || !response.success) {
					$input.prop('checked', previousChecked);
					window.alert(
						(response && response.data && response.data.message) ||
							wcpt_list_table_params.error_message
					);
				}
			})
			.fail(function () {
				$input.prop('checked', previousChecked);
				window.alert(wcpt_list_table_params.error_message);
			})
			.always(function () {
				$input.prop('disabled', false);
			});
	});

	function copyText(text) {
		if (navigator.clipboard && window.isSecureContext) {
			return navigator.clipboard.writeText(text);
		}

		var deferred = $.Deferred();
		var $temp = $('<textarea>')
			.val(text)
			.css({ position: 'fixed', left: '-9999px', top: '0' })
			.appendTo('body');

		$temp[0].focus();
		$temp[0].select();

		try {
			document.execCommand('copy');
			deferred.resolve();
		} catch (error) {
			deferred.reject(error);
		}

		$temp.remove();
		return deferred.promise();
	}

	$('#the-list').on('click', '.wcpt-shortcode-copy', function (event) {
		event.preventDefault();

		var $button = $(this);
		var shortcode = $button.data('shortcode');
		var $feedback = $button.find('.wcpt-shortcode-copy__feedback');
		var copyHint = wcpt_list_table_params.copy_hint;
		var copiedMessage = wcpt_list_table_params.copied_message;

		if (!shortcode) {
			return;
		}

		$.when(copyText(shortcode))
			.done(function () {
				$button.addClass('is-copied');
				$feedback.text(copiedMessage);

				clearTimeout($button.data('copiedTimeout'));
				$button.data(
					'copiedTimeout',
					setTimeout(function () {
						$button.removeClass('is-copied');
						$feedback.text(copyHint);
					}, 2000)
				);
			})
			.fail(function () {
				window.alert(wcpt_list_table_params.copy_error_message);
			});
	});
});
