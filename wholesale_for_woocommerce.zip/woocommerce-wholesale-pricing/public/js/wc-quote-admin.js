jQuery(document).ready(function(){
	
	var ajaxurl = wc_quote_vars.ajax_url;
	var nonce   = wc_quote_vars.nonce;

	jQuery( "form#wc-quote-export-csv-form" ).insertBefore( "hr.wp-header-end" );

	function toggleRulesSpecificContainers(selector, value) {
	    jQuery(selector).each(function () {
	        if (jQuery(this).attr('for').includes(value)) {
	            jQuery(this).find('div.rules-specific-container').slideDown();
	        } else {
	            jQuery(this).find('div.rules-specific-container').slideUp();
	        }
	    });
		}

	function onIncludeToggleChange() {
	    var selectedValue = jQuery("input[name='wc_quote_rules[include_products][toggle]']:checked").val();
	    toggleRulesSpecificContainers('label[for^="wc_quote_rules_"][for$="_include"]', selectedValue);
	}

	function onExcludeToggleChange() {
	    var selectedValue = jQuery("input[name='wc_quote_rules[exclude_products][toggle]']:checked").val();
	    toggleRulesSpecificContainers('label[for^="wc_quote_rules_"][for$="_exclude"]', selectedValue);
	}

	jQuery("input[name='wc_quote_rules[include_products][toggle]']").on('change', onIncludeToggleChange);
	jQuery("input[name='wc_quote_rules[exclude_products][toggle]']").on('change', onExcludeToggleChange);

	onIncludeToggleChange();
	onExcludeToggleChange();

	
	// User Roles Visibility
    function toggleRulesVisibility() {
        var selected = jQuery("input[name='wc_quote_rules[user_roles][toggle]']:checked").val();
        if ( selected === 'all' ) {
            jQuery('div.rules-specific-container.wc_quote_rules_roles_specific').slideUp();
            jQuery('div.rules-specific-container.wc_quote_rules_users_specific').slideUp();
        } else if ( selected === 'specific' )  {
            jQuery('div.rules-specific-container.wc_quote_rules_roles_specific').slideDown();
            jQuery('div.rules-specific-container.wc_quote_rules_users_specific').slideUp();
        } else {
            jQuery('div.rules-specific-container.wc_quote_rules_roles_specific').slideUp();
            jQuery('div.rules-specific-container.wc_quote_rules_users_specific').slideDown();
        }
    }
    toggleRulesVisibility();
    jQuery("input[name='wc_quote_rules[user_roles][toggle]']").on('change', toggleRulesVisibility);


	jQuery('#add-quote-item').click( function(){
		jQuery('div.wc-backbone-modal-content select.wc-quote-add-product').val('').trigger('change');
		jQuery('div.wc-backbone-modal-content input').val('1').trigger('change');
		jQuery('div.wc-backbone-modal-backdrop').show();
		jQuery('div.wc-backbone-modal-content').show();
	});

	jQuery('div.wc-backbone-modal-content button#btn-ok').click( function(event){
		event.preventDefault();

		if( jQuery(this).css('opacity') == 0.2 ) {
			return;
		}

		var current_button = jQuery(this);
		jQuery(this).css('opacity' ,'0.2' );
		jQuery('p.wc-backbone-message').remove();

		jQuery.ajax({
			url: ajaxurl,
			type: 'POST',
			data: {
				action     : 'wc_quote_insert_product_row',
				nonce      : nonce,
				post_id    : jQuery('input#post_ID').val(),
				product_id : jQuery('div.wc-backbone-modal select[name=item_id]').val(),
				quantity   : jQuery('div.wc-backbone-modal input[name="item_qty"]').val(),
			},
			success: function (response) {

				if( response['success'] ) {

					jQuery('div.wc-backbone-modal-content').hide();
					jQuery('.wc-backbone-modal-backdrop').hide();
					current_button.removeClass('loading');
					current_button.css('opacity', '1');
					jQuery('#wc_quote_items_container').replaceWith( response['quote-details-table'] );

				} else {
					current_button.removeClass('loading');
					current_button.css('opacity', '1');
					jQuery('div#wc-backbone-content table.widefat').after("<p class='wc-backbone-message'>" + response['message'] + "</p>");
				}
			},
			error: function (response) {
				current_button.removeClass('loading');
				current_button.css('opacity', '1');
				console.log( response );
			}
		});
	});

		
	jQuery(document).on('click', 'a.delete-order-item', function(event){
		event.preventDefault();
		var answer = window.confirm( wc_quote_vars.remove_item_notice );

		if ( answer ) {
			var current_button = jQuery(this);
			jQuery(this).addClass('loading');
			jQuery(this).closest('tr').css('opacity', '0.4');

			jQuery.ajax({
				url: ajaxurl,
				type: 'POST',
				data: {
					action     : 'wc_quote_delete_quote_item',
					nonce      : nonce,
					quote_key  : current_button.data( 'quote_item_id' ),
					post_id    : jQuery('input#post_ID').val()
				},
				success: function (response) {
					// response = JSON.parse( response );
					jQuery('#wc_quote_items_container').replaceWith( response['quote-details-table'] );

				},
				error: function (response) {
					jQuery(this).removeClass('loading');
					jQuery(this).closest('tr').css('opacity', '1');
					console.log( response );
				}
			});
		}

	});

	jQuery('.modal-close').click( function(e) {
		e.preventDefault();
		jQuery('div.wc-backbone-modal-content button#btn-ok').removeClass('loading');
		jQuery('div.wc-backbone-modal-content button#btn-ok').css('opacity', '1');
		jQuery('.wc-backbone-modal-backdrop').hide();
		jQuery('.wc-backbone-modal-content').hide();
	});
  
	jQuery('.edit_button').click(function(e) {
	  e.preventDefault();

		//   =========== sprint 2.7 Start ===========
		var editUrl = jQuery(this).attr('href');
    	window.open(editUrl, '_blank'); // Open the URL in a new tab
    	return;
	});

	jQuery('.preview_image_btn').click(function(e) {
	  e.preventDefault();

	  var img_src = jQuery(this).attr('href');
	  jQuery('.preview_image_popup').attr('src', img_src);

	  jQuery('div.wc-backbone-modal-backdrop').show();
	  jQuery('div.wc-backbone-modal-content').show();
	});

/************************* Status Icons Start *****************************/

function display_selected_family_icons(){
    var icon_type = jQuery('#wc_quote_status_icon_family').val()
    jQuery('.wc-quote-status-font-families__font').hide();
    jQuery(`.wc-quote-status-font-families__font--${icon_type}`).show();
}

function quote_status_remove_icon() {
     jQuery( '.wc-quote-status-labels-icon__input' ).val('');
    jQuery( '.wc-quote-status-font-families__icon--selected' ).removeClass( 'wc-quote-status-font-families__icon--selected' );
    jQuery( '.quote-status-labels-icon__preview' )
            .html( '' )
            .removeClass()
            .addClass( 'quote-status-labels-icon__preview' );
    jQuery('.wc-quote-status__icon').html( '' ).removeClass().addClass( 'wc-quote-status__icon' );
}

function display_status_icon_preview(icon, icon_family, clickedElement){
    var icon_family_class = '';
    switch ( icon_family ) {
        case 'fontawesome':
            icon_family_class = 'fa ';
            break;

        case 'woocommerce':
            icon_family_class = 'wooicon ';
            break;

        case 'dashicons':
            icon_family_class = 'dashicons ';
            break;
    }

    jQuery( '.wc-quote-status-labels-icon__input' ).val( icon );
    jQuery( '#wc_quote_status_icon_family' ).val( icon_family );
    jQuery( '.wc-quote-status-font-families__icon' ).removeClass( 'wc-quote-status-font-families__icon--selected' );
    if ( clickedElement ) {
        clickedElement.addClass( 'wc-quote-status-font-families__icon--selected' );
    }
    jQuery( '.quote-status-labels-icon__preview' ).removeClass().addClass( `${icon_family_class} ${icon} quote-status-labels-icon__preview` )
    jQuery( '.wc-quote-status__preview-wrapper i' ).removeClass().addClass( `${icon_family_class} ${icon} wc-quote-status__icon` )
    jQuery( '.wc-quote-status-icon-font-families' ).hide();
    jQuery( '.quote-status-labels-icon__clear-icon-action' ).show();
    jQuery( '.wc-quote-status__label' ).show();
}

jQuery(document).ready(function() {

    jQuery('.wc-quote-status-icon-font-families').hide();

    display_selected_family_icons();
    jQuery('#wc_quote_status_icon_family').on('change', function(e) {
        e.preventDefault();
        var icon_type = jQuery(this).val();
        jQuery('.wc-quote-status-font-families__font').hide();
        jQuery(`.wc-quote-status-font-families__font--${icon_type}`).show();
    });

    jQuery('.wc-quote-status-icon-font-families__search-field').on('keyup', function(e) {
        e.preventDefault();
        var value = jQuery( this ).val().toLowerCase().trim();
        if ( ! value  || 2 > value.length ) {
            jQuery( '.wc-quote-status-font-families__wrap .wc-quote-status-font-families__icon' )
                .removeClass( 'wc-quote-status-font-families__icon--display-none' );
            return;
        }
        jQuery( '.wc-quote-status-font-families__wrap .wc-quote-status-font-families__icon' )
        .addClass( function() {
            return this.dataset.icon.indexOf( value ) !== -1 ? '' : 'wc-quote-status-font-families__icon--display-none';
        });
    });

    jQuery('.quote-status-labels-icon__change-icon-action').click(function(){
        jQuery( '.wc-quote-status-icon-font-families' ).toggle();
    });

    jQuery('.quote-status-labels-icon__clear-icon-action').click(function(){
        jQuery( this ).hide();
       quote_status_remove_icon();
    });

    jQuery('.wc-quote-status-font-families__icon').click(function(){
        var icon = jQuery( this ).data( 'icon' );
        var icon_family = jQuery( this ).data( 'icon-family' );
        var clickedElement = jQuery( this );
        display_status_icon_preview(icon, icon_family, clickedElement);
    });

});

/************************* Status Icons End *****************************/






	jQuery(document).on('change', 'input.wc-enable-quote-status', function() {
	    var postID = jQuery(this).attr('data-post-id');
	    var isChecked = jQuery(this).is(':checked') ? 1 : 0;
		jQuery.ajax({
			type: 'POST',
			url: ajaxurl,
			data: {
				action: 'wc_quote_status_save',
				postID: postID,
				nonce: nonce,
				enable_status: isChecked
			},
			success: function(response) {
			},
		});
	});



    function toggleStatusVisibility() {
        var selected = jQuery("#status_type").val();

        if (selected === 'custom') {
            jQuery('tr.wc-quote-status-dropdown').hide();
        } else {
            jQuery('tr.wc-quote-status-dropdown').show();
        }
    }

    toggleStatusVisibility();
    jQuery("#status_type").on('input', toggleStatusVisibility);

	// wc quote custom tax and shipping
	var postId = jQuery('input#post_ID').val();
	jQuery(document).on('click', '#wc_quote_add_tax_shipping', function(e){
		e.preventDefault();
		showTaxShippingModal();
	});

	jQuery(document).on('click', '#wc-quote-tax-shipping-cancel, .wc-quote-tax-shipping-close, #wc-quote-tax-shipping-backdrop', function(e){
		e.preventDefault();
		hideTaxShippingModal();
	});

	jQuery(document).on('click', '#wc-quote-tax-shipping-update', function(e){
		e.preventDefault();

		var $shipping = jQuery('#wc-quote-tax-shipping-input-shipping');
		var $tax = jQuery('#wc-quote-tax-shipping-input-tax');

		var shippingValue = parseFloat($shipping.val());
		var taxValue = parseFloat($tax.val());
		
		if ( isNaN(shippingValue) || shippingValue < 0 ) {
			shippingValue = 0;
		}
		if ( isNaN(taxValue) || taxValue < 0 ) {
			taxValue = 0;
		}
		
		var $message = jQuery('#wc-quote-tax-shipping-message');
		$message.empty();

		var $updateBtn = jQuery(this);
		$updateBtn.prop('disabled', true).css('opacity', 0.7);

		jQuery.ajax({
			url: wc_quote_vars.ajax_url,
			type: 'POST',
			data: {
				action: 'wc_quote_update_tax_shipping',
				nonce: wc_quote_vars.nonce,
				post_id: postId,
				shipping_value: shippingValue,
				tax_value: taxValue
			},
			success: function(response){
				$updateBtn.prop('disabled', false).css('opacity', 1);

				if ( response && response.success ) {
					if ( response['quote-details-table'] ) {
						jQuery('#wc_quote_items_container').replaceWith( response['quote-details-table'] );
					}
					hideTaxShippingModal();
				} else {
					var msg = ( response && response.message ) ? response.message : 'Failed to update.';
					$message.html('<div class="notice notice-error" style="margin-top:10px;">'+msg+'</div>');
				}
			},
			error: function(){
				$updateBtn.prop('disabled', false).css('opacity', 1);
				$message.html('<div class="notice notice-error" style="margin-top:10px;">Server error while updating.</div>');
			}
		});
	});

	function showTaxShippingModal(){
		jQuery('#wc-quote-tax-shipping-backdrop').show();
		jQuery('#wc-quote-tax-shipping-modal').show();
		jQuery('#wc-quote-tax-shipping-message').empty();
	}

	function hideTaxShippingModal(){
		jQuery('#wc-quote-tax-shipping-backdrop').hide();
		jQuery('#wc-quote-tax-shipping-modal').hide();
	}

});