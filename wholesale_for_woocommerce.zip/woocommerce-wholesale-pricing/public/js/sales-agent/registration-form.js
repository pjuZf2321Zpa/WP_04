window.onload = function () {
	var components = USER_REGISTER_FORM.form_fields;

    console.log('components: ', components);

	 Formio.createForm(
      	document.getElementById("registration-form-fields"),
      	components,
      {
        buttonSettings: {
          showCancel: false,
          showPrevious: false,
          showNext: false,
          showSubmit: false,
        },
        breadcrumbSettings: {
          clickable: false,
        },
      }
    ).then( function ( form ) { 
      console.log('form', form);
    	jQuery(document).on("click", "button.woocommerce-form-register__submit", function(e) {
        e.preventDefault();
    		jQuery(this).attr( "data-submission", "woocommerce-form-register" );
    		form.emit('submitButton');
    });

    form.on("submit", function (submission) {   
      console.log('working!!');     
      // console.log('data: ', submission.data);
      var action = jQuery('button.woocommerce-form-register__submit').attr(
          "data-submission" );
          jQuery("form." + action).submit();
          return false;
    });

	});

  jQuery(`p[data-id="registration-form-fields"]`).show();

};