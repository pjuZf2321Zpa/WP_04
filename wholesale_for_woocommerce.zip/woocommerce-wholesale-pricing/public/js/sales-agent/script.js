jQuery(document).ready(function($) {
    jQuery( '#assign_user' ).select2(
        {
            allowClear: true,
            ajax: {
                url: ajax.ajax_url, // AJAX URL is predefined in WordPress admin
                dataType: 'json',
                delay: 250, // delay in ms while typing when to perform a AJAX search
                data: function (params) {
            return {
                    user_filter: params.term, // search query
                    action: 'user_search_ajax', // AJAX action for admin-ajax.php
                    nonce: ajax.nonce
                };
                },
                processResults: function (data) {
                    var options = [];
                    if (data) {

                        // data is the array of arrays, and each of them contains ID and the Label of the option
                        $.each(
                            data,
                            function (index, text) {
                                // do not forget that "index" is just auto incremented value
                                options.push( {id: text[0], text: text[1]} );
                            }
                        );
                    }
                    return {
                        results: options
                    };
                },
                cache: true
            },
            minimumInputLength: 1, // the minimum of symbols to input before perform a search
            width: '100%',
        }
    );

    if ($('.prod-cat-wrapper').length) {
        function safwUpdateCommissionBasisVisibility() {
            var isProduct = $('.prod-cat-wrapper .main_selection_radio:checked').val() === 'commission_on_prod';

            $('.prod-cat-wrapper .safw-prod-selection-section').toggleClass('safw-is-hidden', !isProduct);
            $('.prod-cat-wrapper .safw-cat-selection-section').toggleClass('safw-is-hidden', isProduct);
        }

        $('.prod-cat-wrapper').on('change', '.main_selection_radio', safwUpdateCommissionBasisVisibility);
        safwUpdateCommissionBasisVisibility();
    }

    $('.agent-requested-data').on('click', function(e) {
        e.preventDefault();
		var _this = $(this),
		nonce = $(this).data('nonce'),
		userid = $(this).data('id'),
		commission = $(this).data('commission');
		$.ajax({
			url: ajaxurl,
			type: 'POST',
			data: {
				action: 'sales_agent_requested_user',
				user_id: userid,
				nonce: nonce,
				commission_cat: commission
			},
			success: function (response) {
		   		_this.parents('tr').find("td.status.column-status").html('Approved');
				_this.siblings('.agent-request').attr('disabled', true);
				_this.attr('disabled', true);
			},
			error: function (response) {

			}
      	});
	});

	$('.agent-request-rejected').on('click', function(e) {
		var _this = $(this),
		nonce = $(this).data('nonce'),
		reject = $(this).data('reject'),
		userid = $(this).data('id');

		$.ajax({
			url: ajaxurl,
			type: 'POST',
			data: {
				action: 'sales_agent_requested_user',
				rejected: reject,
				nonce: nonce,
				user_id: userid
			},
			success: function (response) {
                _this.parents('tr').find("td.status.column-status").html('Rejected');
				_this.siblings('.agent-request').attr('disabled', true);
				_this.attr('disabled', true);
			},
			error: function (response) {

			}
      	});
    });

	$(document).on('click', '.wc-view-details', function(e) {
		e.preventDefault();
		var _this = $(this),
		nonce = $(this).data('nonce'),
		postid = $(this).data('id');

		_this.prop('disabled', true);

		$.ajax({
			url: ajaxurl,
			type: 'POST',
			data: {
				action: 'get_agent_data',
				nonce: nonce,
				post_id: postid
			},
			success: function (response) {
				if (response.success) {
					showPopup(response.data.html, $, _this);
				} else {
					alert('Failed to fetch data: ' + (response.data || 'Unknown error'));
					_this.prop('disabled', false);
				}
			},
			error: function () {
				alert('An error occurred while fetching data.');
				_this.prop('disabled', false);
			}
      	});
    });

	 // Event delegation for closing the popup
    $(document).on('click', '.close-button', function() {
        closePopup($);
    });

	$(document).on('click', '.popup', function(e) {
		if ($(e.target).hasClass('popup')) {
			closePopup($);
		}
	});

	$( ".delete-commission" ).click(
		function () {
			if (confirm( ajax.delete_commission )) {

				if (document.location.href.indexOf( '?' ) == -1) {
					var url = window.location.search + "?delete_commission=" + $( this ).attr( "data-commss" )
						+ "&delete_order=" + $( this ).attr( "data-order" ) + "&_wpnonce=" + ajax.delete_commission_nonce;
				} else {
					// for back end add &
					var url = window.location.search + "&delete_commission=" + $( this ).attr( "data-commss" )
						+ "&delete_order=" + $( this ).attr( "data-order" ) + "&_wpnonce=" + ajax.delete_commission_nonce;

				}
				history.pushState( null, null, url );
				location.reload();

			}
		}
	);

	$(document).on("click", ".add-commission-button", function () {
		const userId = $(this).data("user-id");
		const postId = $(this).data("post-id");
		$("#commission-user-id").val(userId);
		$("#commission-post-id").val(postId);
		$(".save-customer-commission").attr("data-user-id", userId);
		$(".save-customer-commission").attr("data-post-id", postId);
		$("#commission-modal").fadeIn(); // Show the modal
	});

	// Close Modal
	$(document).on("click", ".close-modal", function () {
		$("#commission-modal").fadeOut(); // Hide the modal
	});

	// Submit Form via AJAX
	$(document).on("click", ".save-customer-commission", function (e) {
		e.preventDefault(); // Prevent the default button behavior

		const userId = $("#commission-user-id").val();
		const postId = $("#commission-post-id").val();
		//const postId = $(".save-customer-commission").data("post-id");
		const commissionPercentage = $("#commission-percentage").val();

		// Perform validation if needed
		if (!commissionPercentage || commissionPercentage < 0 || commissionPercentage > 100) {
			alert("Please enter a valid commission percentage (1-100).");
			return;
		}
		// Perform the AJAX request
		$.ajax({
			url: ajax.ajax_url, // WordPress AJAX URL
			type: "POST",
			data: {
				action: "save_customer_commission",
				user_id: userId,
				post_id: postId,
				commission_percentage: commissionPercentage,
				security: ajax.nonce
			},
			success: function (response) {
				if (response.success) {
					alert("Commission saved successfully!");
				} else {
					alert(response.data.message || "An error occurred.");
				}
				$("#commission-modal").fadeOut(); // Close the modal
				location.reload();
			},
			error: function () {
				alert("An error occurred while saving the commission.");
				$("#commission-modal").fadeOut();
			},
		});
	});
});

// JavaScript function to create and display the popup with HTML content
function showPopup( htmlContent, $, button ) {
	// Remove any existing popup
	$('.popup').remove();

	// Create a div element for the popup
	var popup = $('<div>', { class: 'popup' });

	// Add content to the popup
	popup.html(`
		<div class="popup-content">
			<span class="close-button">×</span>
			${htmlContent}
		</div>
	`);

	// Add the popup to the body
	$('body').append(popup);

	// Show the popup
	popup.show();

	// Store the button to re-enable it later
	popup.data('button', button);
}

	// Function to close the popup
function closePopup($) {
    var popup = $('.popup');
    if (popup.length) {
        // Re-enable the button
        var button = popup.data('button');
        if (button) {
            button.prop('disabled', false);
        }

        // Remove the popup
        popup.remove();
    }
}