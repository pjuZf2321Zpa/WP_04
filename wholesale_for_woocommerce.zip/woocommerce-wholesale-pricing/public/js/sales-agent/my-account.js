jQuery( document ).ready(
	function ($) {
		function wwpToggleAgentsCustomerOrderBodyClass() {
			$( 'body' ).toggleClass( 'wwp-agents-customer-order', window.location.hash === '#agentsCustomerOrder' );
		}

		wwpToggleAgentsCustomerOrderBodyClass();
		$( window ).on( 'hashchange', wwpToggleAgentsCustomerOrderBodyClass );

		function initUserFilterSelect( $elements ) {
			var selectConfig = {
				ajax: {
					url: ajax.ajax_url,
					dataType: 'json',
					delay: 250,
					data: function (params) {
						return {
							user_filter: params.term,
							action: 'user_search_ajax',
							type: 'agent_customer_search',
							nonce: ajax.nonce
						};
					},
					processResults: function (data) {
						var options = [];
						if (data) {
							$.each(
								data,
								function (index, text) {
									options.push( { id: text[0], text: text[1] } );
								}
							);
						}
						return {
							results: options
						};
					},
					cache: true
				},
				minimumInputLength: 1,
				width: '400px',
				allowClear: true,
			};

			if ($.fn.selectWoo) {
				$elements.selectWoo( selectConfig );
			} else if ($.fn.select2) {
				$elements.select2( selectConfig );
			}
		}
		if ( typeof ajax !== 'undefined' ) {
			initUserFilterSelect( $( '.user-filter' ) );
		}

		$( document ).on(
			'submit',
			'.commission-filters-form, .payout-commission-filters-form',
			function (e) {
				e.preventDefault();

				var $form   = $( this );
				var action  = $form.attr( 'action' ) || $( '.wc_list_commissions_my_account' ).data( 'url' ) || window.location.href.split( '?' )[0];
				var url     = new URL( action, window.location.origin );
				var params  = $form.serializeArray();
				var fieldsToReset = $form.hasClass( 'payout-commission-filters-form' )
					? [ 'page', 'agent_id', 'customer_id', 'date_from', 'date_to' ]
					: [ 'agent_id', 'user-filter', 'date_from', 'date_to' ];

				fieldsToReset.forEach(
					function ( fieldName ) {
						url.searchParams.delete( fieldName );
					}
				);

				params.forEach(
					function (field) {
						if ( ! field.name || '' === String( field.value ).trim() ) {
							return;
						}
						url.searchParams.set( field.name, field.value );
					}
				);

				window.location.assign( url.toString() );
			}
		);

		$( document ).on(
			'click',
			'.submit-filters',
			function (e) {
				if ( $( this ).closest( '.commission-filters-form, .payout-commission-filters-form' ).length ) {
					return;
				}

				e.preventDefault();

				var userFilter = $( this ).closest( '.filter-actions, .wc_list_commissions_my_account, .wc_list_customers_my_account' ).find( '.user-filter' ).val() || '';
				var url        = new URL( window.location.href );

				if ( userFilter ) {
					url.searchParams.set( 'user-filter', userFilter );
				} else {
					url.searchParams.delete( 'user-filter' );
				}

				window.location.href = url.toString();
			}
		);
		if ( typeof select2 !== 'undefined' ) {
			$( ".customer_country" ).select2( { width: '100%', allowClear: true } );
		}

		$('.configure-setup').click(function() {
            $("#SalesAgentModal").css('display','block');
            $('body').css('overflow', 'hidden');
        });

        $(".close").click(function() {
            $("#SalesAgentModal").css('display','none');
        });

        $('.payment-opt:checked', function() {
            var payment_option    =     $('.payment-opt:checked').val();
            $('.'+payment_option+'-info').show().nextAll().hide();
            $('.payment-info-submit').show();
        });

        $('.paypal-info').hide();
        $('.bank-info').hide();
        $('.payoneer-info').hide();
    
        $('.payment-opt').click(function() {
            var payment_option    =     $(this).val();
            $('.payment-info').children().hide();
            $('.'+payment_option+'-info').show().nextAll().hide();
            $('.payment-info-submit').show();
        });

		$( "#commission_date_from" ).datepicker(
			{
				dateFormat: 'yy-mm-dd',
				maxDate: -0,
			}
		);
	
		$( "#commission_date_to" ).datepicker(
			{
				dateFormat: 'yy-mm-dd',
				maxDate: -0,
			}
		);
	
		$( '#commission_date_from' ).change(
			function () {
				var startDate = $( this ).datepicker( 'getDate' );
				$( "#commission_date_to" ).datepicker( "option", "minDate", startDate );
			}
		);
	
		$( '#commission_date_to' ).change(
			function () {
				var endDate = $( this ).datepicker( 'getDate' );
				$( "#commission_date_from" ).datepicker( "option", "maxDate", endDate );
			}
		);

		$( '.clear-filters' ).click( function () {
			var clearUrl = $( this ).data( 'url' );

			if ( clearUrl ) {
				window.location.href = clearUrl;
				return;
			}

			var url = new URL( window.location.href );
			url.searchParams.delete( 'user-filter' );
			url.searchParams.delete( 'date_from' );
			url.searchParams.delete( 'date_to' );
			window.location.href = url.toString();
		} );

		$( '.form-export' ).submit(
			function () {
				if ($( ".agent-filter" ).length) {
					if ($.trim( $( "#commission_date_from" ).val() ) === "" || $.trim( $( ".agent-filter" ).val() ) === "") {
						$( '.message-fillter-error' ).show();
						$( "#export_commissions" ).attr( 'disabled', 'disabled' );
						return false;
					}
				}
			}
		);

		$( ".delete-commission" ).click(
			function () {
				if (confirm( ajax.delete_commission )) {

					if (document.location.href.indexOf( '?' ) == -1) {
						var url = window.location.search + "?delete_commission=" + $( this ).attr( "data-commss" )
							+ "&delete_order=" + $( this ).attr( "data-order" ) + "&_wpnonce=" + ajax.delete_commission_nonce;
					} else {
						// for back end add &
						var url = window.location.search + "&delete_commission=" + $( this ).attr( "data-commss" )
							+ "&delete_order=" + $( this ).attr( "data-order" ) + "&_wpnonce=" + ajax.delete_commission_nonce;

					}
					history.pushState( null, null, url );
					location.reload();

				}
			}
		);

		$('#payment_form').submit(function(e) {
			e.preventDefault();
			//debugger;
			var payment_form_data = $(this).serialize();
		
			var flag_paypal = false;
			var flag_bank = false;
		
			if( payment_form_data == ''  ) {
			  return false;
			}
			
			var payment_type = $("input[name='payout-method']:checked").val();
		
			if ( 'paypal' == payment_type ) {
		
			  var paypal_email = $("input[name='paypal[paypal_email]']").val();
		
			  if ( $.trim( paypal_email ) != '' ) {
				flag_paypal = true;
			  } else {
				flag_paypal = false;
			  }
		
			} else if ( 'bank' == payment_type ) {
		
			  var user_name = $("input[name='bank[full_name]']").val();
			  var bank_city = $("input[name='bank[bank_city]']").val();
			  var bank_name = $("input[name='bank[bank_name]']").val();
			  var acc_num = $("input[name='bank[account_number]']").val();
		
			  if ( $.trim( user_name ) != '' && $.trim( bank_city ) != '' && $.trim( bank_name ) != '' && $.trim( acc_num ) != '' ) {
				  flag_bank = true;
			  } else {
				  flag_bank = false;
			  }
		
			}
		
			if ( flag_paypal || flag_bank ) {
		
			  var ajaxurl = $('.payment-info-submit').data('ajax');
		
			  var data = {
				action: 'agent_payment_details',
				agent_payout_detail: payment_form_data,
				nonce: ajax.nonce
			  };
			  
			  if ( $(this).find('.wc-sales-agent-loader').length <= 0 ) {
				$(this).append( `<span class="wc-sales-agent-loader">Loading...</span>` );   
			  }
		
			  $.post( ajaxurl, data, function( response ) {
				if( response.success == true ) {
				  var thankyou_msg  = "<h3>Thank you! Your Payment Detail has been Saved.</h3>"
				  $('.wc-sales-agent-loader').remove();
				  $('.modal-body').html(thankyou_msg);
				  setTimeout(function(){ 
					location.reload();
				  }, 1500);        
				}
				
			  });
			}
		
		  });

		/**
		 * export action
		 */
		$( '.form-export' ).submit(
			function () {

				if ($( ".agent-filter" ).length) {

					if ($.trim( $( "#commission_date_from" ).val() ) === "" || $.trim( $( ".agent-filter" ).val() ) === "") {
						$( '.message-fillter-error' ).show();
						$( "#export_commissions" ).attr( 'disabled', 'disabled' );
						return false;
					}
				}
			}
		);
	}
);
