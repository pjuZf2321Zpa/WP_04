(function ($) {
	'use strict';

	$(function () {
		var cfgEarly = window.wwp_ccp_admin || {};
		var adminI18n = cfgEarly.i18n || {};
		var companyPostType = cfgEarly.post_type || 'ccp_company';
		var $titleField = $('#title');
		var $postForm = $('#post');

		// Require company name before publish/update/save.
		if ($titleField.length && $postForm.length && $('body').hasClass('post-type-' + companyPostType)) {
			$titleField.prop('required', true);

			$postForm.on('submit', function (event) {
				if ($.trim($titleField.val()) !== '') {
					return;
				}

				event.preventDefault();
				$titleField.focus();
				window.alert(adminI18n.titleRequired || 'Company name is required.');
			});
		}

		var $giveCreditCheckbox = $('#give_credit_to_company');
		var $creditAddRow = $('.wwp-ccp-credit-add-row');

		if ($giveCreditCheckbox.length && $creditAddRow.length) {
			$giveCreditCheckbox.on('change', function () {
				$creditAddRow.toggleClass('is-visible', $(this).is(':checked'));
			});
			$giveCreditCheckbox.trigger('change');
		}

		var $companyApprovedOrders = $('#ccp_company_approved_orders');
		var $managerApprovalWrap = $('#ccp_manager_approval_wrap');

		if ($companyApprovedOrders.length && $managerApprovalWrap.length) {
			$companyApprovedOrders.on('change', function () {
				var isChecked = $(this).is(':checked');
				if (isChecked) {
					$managerApprovalWrap.prop('hidden', false).removeAttr('hidden');
				} else {
					$managerApprovalWrap.find('input[name="ccp_manager_approval"]').prop('checked', false);
					$managerApprovalWrap.prop('hidden', true).attr('hidden', 'hidden');
				}
			});
		}

		if (typeof $.fn.selectWoo !== 'undefined') {
			var $userSelects = $('.wwp-ccp-user-select');

			function getSelectedCompanyUserIds($except) {
				var ids = [];
				$userSelects.each(function () {
					if ($except && this === $except[0]) {
						return;
					}
					var values = $(this).val() || [];
					if (!Array.isArray(values)) {
						values = [values];
					}
					$.each(values, function (_, id) {
						if (id) {
							ids.push(String(id));
						}
					});
				});
				return ids;
			}

			$userSelects.each(function () {
				var $el = $(this);
				if ($el.hasClass('select2-hidden-accessible')) {
					return;
				}
				$el.selectWoo({
					allowClear: true,
					placeholder: $el.data('placeholder') || '',
					minimumInputLength: 1,
					ajax: {
						url: ajaxurl,
						dataType: 'json',
						delay: 250,
						data: function (params) {
							return {
								term: params.term,
								action: 'ccp_search_company_users',
								nonce: cfgEarly.nonce || '',
								post_ID: $('#post_ID').val() || ''
							};
						},
						processResults: function (data) {
							var selected = getSelectedCompanyUserIds();
							var results = [];
							if (data) {
								$.each(data, function (id, text) {
									if (selected.indexOf(String(id)) === -1) {
										results.push({ id: id, text: text });
									}
								});
							}
							return { results: results };
						},
						cache: false
					}
				});

				$el.on('select2:selecting', function (event) {
					var selectedId = '';
					if (event.params && event.params.args && event.params.args.data) {
						selectedId = String(event.params.args.data.id);
					}
					if (!selectedId) {
						return;
					}
					if (getSelectedCompanyUserIds($el).indexOf(selectedId) !== -1) {
						event.preventDefault();
						window.alert(adminI18n.userAlreadySelected || 'This user is already assigned to a company role.');
					}
				});
			});
		}

		if (typeof $.fn.wc_product_search !== 'undefined') {
			$('.wwp-ccp-product-select').wc_product_search({
				allow_clear: true,
				multiple: true,
				placeholder: $('.wwp-ccp-product-select').data('placeholder') || ''
			});
		}

		$('input[name="ccp_restriction_type"]').on('change', function () {
			var value = $(this).val();
			var $fields = $('.wwp-ccp-restriction-fields');
			if (value === 'include' || value === 'exclude') {
				$fields.show();
			} else {
				$fields.hide();
			}
		});

		var $bulkCreditLimit = $('#ccp_bulk_credit_limit');
		var $applyBulkLimit = $('#ccp_apply_bulk_credit_limit');
		var $userLimitInputs = $('.wwp-ccp-user-limit-input');

		function formatPreviewAmount(value) {
			if (value === '' || typeof value === 'undefined' || value === null) {
				return '0.00';
			}
			return String(value);
		}

		function previewBulkLimitOnUsers() {
			var bulkValue = $bulkCreditLimit.val();
			$userLimitInputs.each(function () {
				var $input = $(this);
				var $row = $input.closest('tr');
				$input.val(bulkValue).attr('data-sync-bulk', '1');
				$row.find('.wwp-ccp-user-wallet-balance').text(formatPreviewAmount(bulkValue));
			});
		}

		function restoreOriginalUserLimits() {
			$userLimitInputs.each(function () {
				var $input = $(this);
				var $row = $input.closest('tr');
				var originalLimit = $row.data('original-limit');
				var originalBalance = $row.data('original-balance');

				if ($input.prop('disabled')) {
					$input.val(typeof originalLimit === 'undefined' ? '' : originalLimit);
					$row.find('.wwp-ccp-user-wallet-balance').text(formatPreviewAmount(originalBalance));
				}
			});
		}

		$(document).on('click', '.wwp-ccp-edit-user-limit', function (event) {
			event.preventDefault();

			var $btn = $(this);
			var $row = $btn.closest('tr');
			var $input = $row.find('.wwp-ccp-user-limit-input');
			var userId = $row.data('user-id');

			if (!$input.length || $input.prop('disabled') === false) {
				return;
			}

			$input.prop('disabled', false).trigger('focus');
			$btn.addClass('is-active').attr('aria-pressed', 'true');

			if (userId && !$row.find('.wwp-ccp-user-limit-unlock').length) {
				$row.append(
					$('<input>', {
						type: 'hidden',
						class: 'wwp-ccp-user-limit-unlock',
						name: 'ccp_user_credit_limits_unlock[]',
						value: userId
					})
				);
			}
		});

		if ($applyBulkLimit.length) {
			$applyBulkLimit.on('change', function () {
				if ($(this).is(':checked')) {
					previewBulkLimitOnUsers();
				} else {
					restoreOriginalUserLimits();
				}
			});
		}

		if ($bulkCreditLimit.length && $userLimitInputs.length) {
			$bulkCreditLimit.on('input change', function () {
				var bulkValue = $(this).val();

				if ($applyBulkLimit.length && $applyBulkLimit.is(':checked')) {
					previewBulkLimitOnUsers();
					return;
				}

				$userLimitInputs.filter('[data-sync-bulk="1"]:enabled').each(function () {
					var $input = $(this);
					$input.val(bulkValue);
					$input.closest('tr').find('.wwp-ccp-user-wallet-balance').text(formatPreviewAmount(bulkValue));
				});
			});

			$userLimitInputs.on('input change', function () {
				var $input = $(this);
				var bulkValue = $bulkCreditLimit.val();
				var limitValue = $input.val();

				$input.closest('tr').find('.wwp-ccp-user-wallet-balance').text(formatPreviewAmount(limitValue));

				if ($input.val() !== bulkValue) {
					$input.attr('data-sync-bulk', '0');
				} else {
					$input.attr('data-sync-bulk', '1');
				}
			});
		}

		// Credits Expiration UI toggles.
		var $expEnabled = $('#ccp_credit_expiration_enabled');
		var $expFieldsWrap = $('.wwp-ccp-credit-expiration__fields');
		var $expMode = $('#ccp_credit_expiration_mode');
		var $expMonthWrap = $('#ccp_credit_expiration_month_wrap');

		function syncExpirationUI() {
			if (!$expEnabled.length || !$expFieldsWrap.length) {
				return;
			}

			var isEnabled = $expEnabled.is(':checked');
			if (isEnabled) {
				$expFieldsWrap.prop('hidden', false).removeAttr('hidden');
				$expFieldsWrap.find('input,select,textarea').prop('disabled', false);
			} else {
				$expFieldsWrap.prop('hidden', true).attr('hidden', 'hidden');
				$expFieldsWrap.find('input,select,textarea').prop('disabled', true);
			}

			if (isEnabled && $expMode.length && $expMonthWrap.length) {
				var mode = $expMode.val();
				if ('yearly' === mode) {
					$expMonthWrap.prop('hidden', false).removeAttr('hidden');
				} else {
					$expMonthWrap.prop('hidden', true).attr('hidden', 'hidden');
				}
			}
		}

		if ($expEnabled.length) {
			$expEnabled.on('change', syncExpirationUI);
		}
		if ($expMode.length) {
			$expMode.on('change', syncExpirationUI);
		}
		syncExpirationUI();

		var cfg = window.wwp_ccp_admin || {};
		var adminNonce = cfg.nonce || '';
		var adminAjax = cfg.ajax_url || (typeof ajaxurl !== 'undefined' ? ajaxurl : '');

		function updateAdminRequestRow($row, status) {
			var label = status.charAt(0).toUpperCase() + status.slice(1);
			var badgeClass = 'pending' === status ? 'wwp-ccp-badge--pending' : ('approved' === status ? 'wwp-ccp-badge--approved' : 'wwp-ccp-badge--declined');
			$row.find('.wwp-ccp-request-status-cell').html('<span class="wwp-ccp-badge ' + badgeClass + '">' + label + '</span>');
			$row.find('.wwp-ccp-request-actions-cell').html('—');
		}

		function reviewAdminCreditRequest(action, index, $btn) {
			var companyId = $('.wwp-ccp-credit-requests').data('company-id');
			$btn.prop('disabled', true);

			$.ajax({
				type: 'POST',
				url: adminAjax,
				dataType: 'json',
				data: {
					action: action,
					nonce: adminNonce,
					company_id: companyId,
					index: index
				},
				success: function (response) {
					if (response && response.success) {
						var status = response.data && response.data.status ? response.data.status : '';
						var $row = $btn.closest('tr');
						if (status && $row.length) {
							updateAdminRequestRow($row, status);
						} else {
							window.location.reload();
						}
					} else {
						alert((response && response.data && response.data.message) || (adminI18n.requestFailed || 'Request failed.'));
						$btn.prop('disabled', false);
					}
				},
				error: function (xhr) {
					var message = adminI18n.requestFailed || 'Request failed.';
					if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
						message = xhr.responseJSON.data.message;
					}
					alert(message);
					$btn.prop('disabled', false);
				}
			});
		}

		$(document).on('click', '.wwp-ccp-credit-requests .wwp-ccp-request-approve', function (event) {
			event.preventDefault();
			reviewAdminCreditRequest('ccp_approve_credit_request', $(this).data('index'), $(this));
		});

		$(document).on('click', '.wwp-ccp-credit-requests .wwp-ccp-request-decline', function (event) {
			event.preventDefault();
			if (!confirm(adminI18n.confirmDeclineRequest || 'Decline this credit request?')) {
				return;
			}
			reviewAdminCreditRequest('ccp_decline_credit_request', $(this).data('index'), $(this));
		});
	});
})(jQuery);
