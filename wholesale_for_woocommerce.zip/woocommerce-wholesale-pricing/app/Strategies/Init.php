<?php
/**
 * Init
 *
 * Abstract base class designed to automate the registration of service methods
 * to essential WordPress hooks. Any service extending this class is automatically
 * hooked into the 'init' and 'plugins_loaded' actions upon instantiation.
 *
 * @package    WooCommerceWholesalePricing\Strategies
 */
namespace WooCommerceWholesalePricing\App\Strategies;

/**
 * Init
 *
 * Abstract class providing a default strategy for initial service registration.
 */
abstract class Init {


	/**
	 * Init constructor.
	 *
	 * Automatically registers the `register` method to the 'init' action
	 * and the `loaded` method to the 'plugins_loaded' action.
	 */
	public function __construct() {
		// The 'register' method is typically used for early initialization
		// tasks like post type registration, which must occur early.
		add_action('init', array( $this, 'register' ), 5);

		// The 'loaded' method is used for logic that requires all plugins
		// to be fully loaded, such as dependency resolution or integration logic.
		add_action('plugins_loaded', array( $this, 'loaded' ), 100);
	}

	/**
	 * Abstract method that concrete service classes must implement.
	 *
	 * This method is executed on the WordPress 'init' action (priority 5).
	 * It should contain the primary logic for activating the service.
	 *
	 * @return mixed
	 */
	abstract public function register();

	/**
	 * Optional hook method executed after all plugins have loaded.
	 *
	 * This method is executed on the 'plugins_loaded' action (priority 100).
	 * Child classes can override this method to run late initialization or
	 * dependency-reliant tasks.
	 *
	 * @return void
	 */
	public function loaded() {
	}
}
