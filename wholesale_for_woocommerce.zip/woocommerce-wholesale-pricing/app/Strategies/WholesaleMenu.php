<?php
/**
 * WholesaleMenu
 *
 * Abstract base class for defining and registering admin menu pages and submenus
 * in a WordPress environment, typically used within a WooCommerce plugin structure.
 *
 * This class handles the logic for registering the main top-level menu once and
 * then adding multiple submenu pages beneath it. It also ensures the correct
 * menu item remains highlighted for associated custom post types or taxonomies.
 *
 * @package    WooCommerceWholesalePricing\Strategies
 */
namespace WooCommerceWholesalePricing\App\Strategies;

/**
 * Abstract Class WholesaleMenu
 *
 * Subclasses must define their specific menu details (titles, slug, capability)
 * and implement the abstract `render()` method to display the UI.
 */
abstract class WholesaleMenu {


	/**
	 * Page title
	 * 
	 * @var string The text to be displayed in the browser's title bar when the menu page is active.
	 */
	protected $page_title;

	/**
	 * Menu title
	 * 
	 * @var string The text to be displayed in the menu.
	 */
	protected $menu_title;

	/**
	 * Capability
	 * 
	 * @var string|array The capability required for this menu item to be displayed.
	 * Can be a string (single capability) or an array (for submenus with multiple caps).
	 */
	protected $capability;

	/**
	 * Menu slug
	 * 
	 * @var string The unique slug for the menu page.
	 */
	protected $menu_slug;

	/**
	 * Main registered
	 * 
	 * @var bool Tracks whether the main top-level "Wholesale" menu has been registered.
	 * Used to ensure the main menu is created only by the first instantiated class.
	 */
	protected static $main_registered = false;

	/**
	 * Icon url
	 * 
	 * @var string The icon URL or a Dashicons class for the main menu item.
	 */
	private $icon_url = 'dashicons-store';

	/**
	 * Position
	 * 
	 * @var int The position in the menu structure where the main menu should appear.
	 */
	private $position = 51;
	
	/**
	 * Needs callback
	 * 
	 * @var bool If true, the submenu will use the `render` method as its callback.
	 * If false (e.g., for link-only menus), the callback will be null.
	 */
	protected $needs_callback = true;

	/**
	 * Constructor
	 *
	 * Registers the necessary WordPress actions and filters.
	 */
	public function __construct() {
		add_action('admin_menu', array( $this, 'register' ), 10);
		add_filter('parent_file', array( $this, 'parentMenu' ), 10);
	}   

	/**
	 * Registers the main menu page or a submenu page depending on the registration state.
	 *
	 * This method is hooked into the `admin_menu` action. It first checks a filter
	 * for global menu registration permission.
	 */
	public function register() {
		 /**
		 * Filters whether the wholesale pricing menus should be registered.
		 *
		 * @since 3.0.0
		 * @param bool $can_register True by default.
		 */
		$can_register = apply_filters('wwp_wholesales_menus', true);

		if (! $can_register ) {
			return;
		}
		
		if (! self::$main_registered ) {
			add_menu_page(
				esc_html__('Wholesale Pricing', 'woocommerce-wholesale-pricing'),
				esc_html__('Wholesale', 'woocommerce-wholesale-pricing'),
				wwp_env()->get('capability'),
				wwp_env()->get('menu_slug'),
				function () {
					return wwp_view('admin.menus.dashboard'); 
				},
				$this->icon_url,
				$this->position
			);
			
			$this->register_submenu();

			self::$main_registered = true;

		} elseif (is_array($this->capability) ) {
			foreach ( $this->capability as $cap ) {
				$this->register_submenu($cap);
			}
		} else {
			$this->register_submenu();
		}
	}

	/**
	 * Registers a submenu page under the main wholesale menu slug.
	 *
	 * @param string|null $capability Optional capability override for the submenu.
	 */
	public function register_submenu( $capability = null ) {
		add_submenu_page( 
			wwp_env()->get('menu_slug'),
			$this->get_page_title(),
			$this->get_menu_title(),
			! $capability ? $this->capability : $capability,
			$this->menu_slug, 
			( $this->needs_callback ) ? array( $this, 'render' ) : null
		);
	}

	/**
	 * Filters the parent menu file to ensure correct menu highlighting in the admin sidebar.
	 *
	 * This is essential when associated post types or taxonomies (like `wwp_requests`
	 * or `wholesale_user_roles`) should remain highlighted under the main "Wholesale"
	 * menu instead of defaulting to the "Posts" or "Settings" menus.
	 *
	 * @param  string $parent_file The parent menu slug.
	 * @return string The modified parent menu slug.
	 */
	public function parentMenu( $parent_file ) {
		global $current_screen;

		if (in_array($current_screen->post_type, array( 'wwp_requests', 'wwp_groups' ))
			
			|| in_array($current_screen->taxonomy, array( 'wholesale_user_roles' ))
		) {
			$parent_file = wwp_env()->get('menu_slug');
		}
		return $parent_file;
	}

	/**
	 * Returns the page title for the admin screen.
	 *
	 * This title is displayed in the browser tab and at the top
	 * of the admin page content area.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized page title.
	 */
	abstract public function get_page_title();
	
	/**
	 * Returns the menu title for the admin menu.
	 *
	 * This title is displayed in the WordPress admin menu sidebar
	 * as the label for this menu or submenu item.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized menu title.
	 */
	abstract public function get_menu_title();

	/**
	 * Renders the user interface for the admin screen.
	 *
	 * This method is the callback executed when the submenu page is visited
	 * (if `$needs_callback` is true).
	 *
	 * @return void
	 */
	abstract public function render();
}
