<?php
/**
 * WCPT common collection
 *
 * @package Woocommerce Product Table/Datatype
 */

namespace WooCommerceWholesalePricing\App\Strategies;

if (! defined('ABSPATH') ) {
	exit; // Exit if accessed directly.
}
/**
 * WCPTCommonCollection class.
 */
class DataTableCollection {



	/**
	 * Variable
	 *
	 * @var array
	 */
	protected $collection;

	/**
	 * Constructor
	 *
	 * @param array $collection An array of collection elements.
	 */
	public function __construct( array $collection = array() ) {
		$this->collection = $collection;
	}

	/**
	 * Return data for the key
	 *
	 * @param  string $key Key to verify.
	 * @return mixed
	 */
	public function __get( $key ) {
		return $this->get($key);
	}

	/**
	 * Set data on the key
	 *
	 * @param string $key   Key to verify.
	 * @param mixed  $value value to verify.
	 */
	public function __set( $key, $value ) {
		if ($this->has($key) ) {
			$this->set($key, $value);
		} else {
			$this->add($key, $value);
		}
	}

	/**
	 * Checks whether a specified key if the collection
	 *
	 * @param string $key Key to verify.
	 *
	 * @return bool
	 */
	public function __isset( $key ) {
		return $this->has($key);
	}

	/**
	 * Removes the element with the specified key
	 *
	 * @param string $key Key to verify.
	 */
	public function __unset( $key ) {
		$this->delete($key);
	}

	/**
	 * Checks whether a specified key if the collection
	 *
	 * @param  string $key Key to verify.
	 * @return bool TRUE if the key exists, FALSE otherwise
	 */
	public function has( $key ) {
		return isset($this->collection[ $key ]);
	}

	/**
	 * Checks whether a specified value if the collection
	 *
	 * @param  string $value  Value to verify.
	 * @param  bool   $strict If set TRUE then method use strict check, FALSE means non-strict.
	 * @return bool
	 */
	public function hasValue( $value, $strict = true ) {
		foreach ( $this->collection as $collection_value ) {
			if ($strict ) {
				if ($value === $collection_value ) {
					return true;
				}
			} elseif (strtolower($value) === strtolower($collection_value) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Returns all items in the collection
	 *
	 * @return array
	 */
	public function all() {
		return $this->collection;
	}

	/**
	 * Adds a new item to the collection
	 *
	 * @param  string $key   Key to add.
	 * @param  mixed  $value Value of the element.
	 * @return WCPTCommonCollection
	 */
	public function add( $key, $value ) {
		if (! $this->has($key) ) {
			$this->collection[ $key ] = $value;
		}

		return $this;
	}

	/**
	 * Change the value of an existing key
	 *
	 * @param  string $key   The key to be edited.
	 * @param  mixed  $value The new value.
	 * @return WCPTCommonCollection
	 */
	public function set( $key, $value ) {
		if ($this->has($key) ) {
			$this->collection[ $key ] = $value;
		}

		return $this;
	}

	/**
	 * Get the value of the specified key
	 *
	 * @param  string|array $key     The key whose value you want to get.
	 * @param  mixed        $default Value that returns method if the specified key is not in the collection.
	 * @return mixed
	 */
	public function get( $key, $default = null ) {
		if (is_array($key) ) {
			return array_combine($key, array_map(array( $this, 'get' ), $key));
		}

		if ($this->has($key) ) {
			return $this->collection[ $key ];
		}

		return $default;
	}

	/**
	 * Removes the element with the specified key
	 *
	 * @param  string $key Name of the key to be deleted.
	 * @return bool TRUE if the key exists and removed, FALSE otherwise
	 */
	public function delete( $key ) {
		if ($this->has($key) ) {
			unset($this->collection[ $key ]);
			return true;
		}

		return false;
	}

	/**
	 * Change the current collection to the specified
	 *
	 * @param  array $collection Array elements of the new collection.
	 * @return WCPTCommonCollection
	 */
	public function replace( array $collection ) {
		$this->collection = $collection;

		return $this;
	}

	/**
	 * Merge the specified array with the current collection
	 *
	 * @param  array $collection Array elements.
	 * @return WCPTCommonCollection
	 */
	public function merge( array $collection ) {
		$this->collection = array_merge($this->collection, $collection);

		return $this;
	}

	/**
	 * Applies the callback to the elements of the collection
	 *
	 * @param  callable $callback Callback function to run for each element in the collection.
	 * @return WCPTCommonCollection
	 */
	public function map( callable $callback ) {
		$this->collection = array_map($callback, $this->collection);

		return $this;
	}

	/**
	 * Returns collection keys
	 *
	 * @return array
	 */
	public function getKeys() {
		return array_keys($this->collection);
	}

	/**
	 * Returns collection values
	 *
	 * @return array
	 */
	public function getValues() {
		return array_values($this->collection);
	}

	/**
	 * Checks whether the collection is empty
	 *
	 * @return bool
	 */
	public function isEmpty() {
		return ( count($this->collection) < 1 );
	}


	/**
	 * (PHP 5 &gt;= 5.1.0)<br/>
	 * String representation of object
	 *
	 * @link   http://php.net/manual/en/serializable.serialize.php
	 * @return string the string representation of the object or null
	 */
	public function serialize() {
		return serialize($this->collection);
	}

	/**
	 * (PHP 5 &gt;= 5.1.0)<br/>
	 * Constructs the object
	 *
	 * @link   http://php.net/manual/en/serializable.unserialize.php
	 * @param  string $serialized <p>.
	 *                            The string representation of the object.
	 *                            </p>.
	 * @return void
	 */
	public function unserialize( $serialized ) {
		$this->collection = unserialize($serialized);
	}
}
