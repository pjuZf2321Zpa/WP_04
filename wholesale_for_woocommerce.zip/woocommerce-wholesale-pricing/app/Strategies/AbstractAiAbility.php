<?php
/**
 * Abstract AI ability contract.
 *
 * @package WooCommerceWholesalePricing\App\Strategies
 */

namespace WooCommerceWholesalePricing\App\Strategies;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\SettingsService;

/**
 * Base contract for wholesale AI assistant abilities registered with WordPress.
 */
abstract class AbstractAiAbility {

	/**
	 * Settings key for this ability.
	 *
	 * @return string
	 */
	abstract public function get_key();

	/**
	 * Human-readable label.
	 *
	 * @return string
	 */
	abstract public function get_label();

	/**
	 * Ability description.
	 *
	 * @return string
	 */
	abstract public function get_description();

	/**
	 * Owning plugin slug (wholesale|quote).
	 *
	 * @return string
	 */
	abstract public function get_plugin();

	/**
	 * JSON Schema for ability input.
	 *
	 * @return array<string, mixed>
	 */
	abstract public function get_input_schema();

	/**
	 * JSON Schema for ability output.
	 *
	 * @return array<string, mixed>
	 */
	abstract public function get_output_schema();

	/**
	 * Execute the ability.
	 *
	 * @param mixed $input Ability input.
	 * @return mixed|\WP_Error
	 */
	abstract public function execute( $input );

	/**
	 * Permission check before execution.
	 *
	 * @param mixed $input Ability input.
	 * @return bool|\WP_Error
	 */
	abstract public function check_permission( $input );

	/**
	 * Namespaced ability name for WordPress registration.
	 *
	 * Settings keys use underscores; the Abilities API only allows dashes in names.
	 *
	 * @return string
	 */
	public function get_ability_name() {
		return 'woocommerce-wholesale-pricing/' . str_replace( '_', '-', $this->get_key() );
	}

	/**
	 * Whether this ability is enabled in assistant settings.
	 *
	 * @return bool
	 */
	public function is_enabled() {
		$settings  = ( new SettingsService() )->get_settings();
		$abilities = is_array( isset($settings['abilities']) ? $settings['abilities'] : null ) ? $settings['abilities'] : array();

		return ! empty( $abilities[ $this->get_key() ] );
	}

	/**
	 * Register this ability with the WordPress Abilities API.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			$this->get_ability_name(),
			array(
				'label'               => $this->get_label(),
				'description'         => $this->get_description(),
				'category'            => $this->get_plugin(),
				'input_schema'        => $this->get_input_schema(),
				'output_schema'       => $this->get_output_schema(),
				'execute_callback'    => array( $this, 'execute' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'meta'                => array(
					'show_in_rest' => false,
				),
			)
		);
	}
}
