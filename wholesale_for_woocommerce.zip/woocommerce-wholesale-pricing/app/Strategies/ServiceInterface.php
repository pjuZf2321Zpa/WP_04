<?php
/**
 * ServiceInterface
 *
 * Defines the contract for any class intended to act as a service provider
 * within the application. Services implementing this interface must provide
 * a static method to check for external dependencies.
 *
 * @package    WooCommerceWholesalePricing\Strategies
 */
namespace WooCommerceWholesalePricing\App\Strategies;

/**
 * ServiceInterface
 *
 * This contract mandates a static method for dependency resolution, allowing
 * the application's core loader or container to determine if a service
 * is safe to initialize.
 */
interface ServiceInterface {

	/**
	 * Checks if all necessary external dependencies (e.g., other plugins,
	 * WooCommerce versions, specific environment configurations) are met.
	 *
	 * This method is expected to be called statically before the service
	 * is instantiated or registered.
	 *
	 * @return bool True if dependencies are resolved and the service can proceed,
	 * false otherwise.
	 */
	public static function resolveDependency();
}
