<?php
/**
 * Registration Admin Screen Class
 *
 * This file defines the Registration class, which handles the settings page
 * for managing the Wholesale Registration form in the WooCommerce Wholesale Pricing plugin.
 * It integrates with the admin menu and provides AJAX handling for saving form data.
 *
 * @package    WooCommerceWholesalePricing\Screens
 */
namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Class Registration
 *
 * Manages the Registration Settings admin screen, allowing admin users
 * to configure and save wholesale registration form settings.
 */
class Registration extends WholesaleMenu {


   
	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		$this->capability  = wwp_env()->get('capability') . '_registration_page';
		$this->menu_slug    = 'wwp-registration-setting';

		parent::__construct();
		
		add_action('wp_ajax_wwp_save_form', array( $this, 'save' ));
		add_action('wp_ajax_wc_quote_form_builder_save', array( $this, 'save_quote_form_builder' ));

		add_filter('display_post_states', array( $this, 'registration_page_identifier' ), 10, 2);
	}

	/**
	 * Retrieves the page title for the Registration admin page.
	 *
	 * This title is displayed at the top of the admin screen.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered page title.
	 */
	public function get_page_title() {
		return __('Registration Page', 'woocommerce-wholesale-pricing');
	}

	/**
	 * Retrieves the menu title for the Registration admin menu item.
	 *
	 * This title is displayed in the WordPress admin sidebar menu.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered menu title.
	 */
	public function get_menu_title() {
		return __('Registration Setting', 'woocommerce-wholesale-pricing');
	}
	
	/**
	 * Save
	 *
	 * @return void
	 */
	public function save() {
		if (! isset($_POST['nonce']) || ! wp_verify_nonce(wc_clean($_POST['nonce']), 'wc-wholesale-ajax-nonce') ) {
			wp_send_json_error(array( 'message' => __('Security check failed.', 'woocommerce-wholesale-pricing') ));
		}

		$post = $_POST;

		if (isset($_POST['builder_schema']) ) {
			update_option('wwp_save_form', wp_unslash($post['builder_schema']));
			wp_send_json_success(array( 'message' => __('Form has been saved successfully.', 'woocommerce-wholesale-pricing') ));
		}

		wp_send_json_error(array( 'message' => __('Invalid form schema payload.', 'woocommerce-wholesale-pricing') ));
	}

	/**
	 * Save quote form builder JSON schema.
	 *
	 * @return void
	 */
	public function save_quote_form_builder() {
		if (! isset($_POST['nonce']) || ! wp_verify_nonce(wc_clean($_POST['nonce']), 'wc-quote-ajax-nonce') ) {
			wp_send_json_error(array( 'message' => __('Security check failed.', 'woocommerce-wholesale-pricing') ));
		}

		$post = $_POST;

		if (isset($_POST['builder_schema']) ) {
			update_option('wc_quote_form_builder', wp_unslash($post['builder_schema']));
			wp_send_json_success(array( 'message' => __('Form has been saved successfully.', 'woocommerce-wholesale-pricing') ));
		}

		wp_send_json_error(array( 'message' => __('Invalid form schema payload.', 'woocommerce-wholesale-pricing') ));
	}
	
	/**
	 * Render
	 *
	 * @return string Rendered HTML output.
	 */
	public function render() {
		return wwp_view('admin.menus.registration');
	}

	public function registration_page_identifier( $post_states, $post ) {

		$shortcode = wwp_env()->get('registration_shortcode');
	
		if (has_shortcode($post->post_content, $shortcode) && 'page' == $post->post_type ) {
			$post_states['wwp_registration_page'] = __('Wholesale Registration Page', 'quick-commerce');
		}

		return $post_states;
	}
}
