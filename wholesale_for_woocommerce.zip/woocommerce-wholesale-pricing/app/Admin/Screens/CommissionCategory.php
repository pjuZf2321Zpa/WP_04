<?php
/**
 * Sales Agent Commission Category Admin Screen Class
 *
 * This file defines the Product Table class, rendering of the "Product Table" admin screen in the WooCommerce Wholesale Pricing plugin.
 * It extends the WholesaleMenu base class and integrates with plugin settings.
 *
 * @package    WooCommerceWholesalePricing\Screens
 */
namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Class Sales Agent Commission Category
 *
 * Represents the admin screen for managing Sales Agent Commission Category.
 * This class registers the menu item, adds settings, and renders
 * the associated view.
 */
class CommissionCategory extends WholesaleMenu {

	use WholesaleSettings;
	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		$this->capability  = wwp_env()->get('capability') . '_sales_agent';

		$this->menu_slug  = sprintf('edit-tags.php?taxonomy=%s&post_type=%s', wwp_env()->get('commission_tax_slug'), wwp_env()->get('sales_agent_pt_slug'));

		$this->needs_callback = false;

		parent::__construct();

		add_action('admin_menu', array( $this, 'conditonal_menu' ), 999);
	}


	/**
	 * Retrieves the page title for the Sales Agent admin page.
	 *
	 * This title is displayed at the top of the admin screen.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered page title.
	 */
	public function get_page_title() {
		return __('Commission Category', 'woocommerce-wholesale-pricing');
	}

	/**
	 * Retrieves the menu title for the Sales Agent admin menu item.
	 *
	 * This title is displayed in the WordPress admin sidebar menu.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered menu title.
	 */
	public function get_menu_title() {
		return __('Commission Category', 'woocommerce-wholesale-pricing');
	}

	public function conditonal_menu() {
		$settings = self::get_pricing_settings();
		if (! isset($settings['sales_agent']) || 'no' == $settings['sales_agent'] ) {
			global $submenu;

			if (isset($submenu['wwp_wholesale']) ) {
				foreach ( $submenu['wwp_wholesale'] as $index => &$item ) {
					if ('manage_wholesale_sales_agent' === $item[1] ) {
						unset($submenu['wwp_wholesale'][$index]);
					}
				}
			}
		}
	}
	 
	/**
	 * Render
	 *
	 * @return string Rendered HTML output.
	 */
	public function render() {}
}
