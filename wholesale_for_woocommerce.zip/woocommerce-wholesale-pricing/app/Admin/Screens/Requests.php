<?php
/**
 * Requests Admin Screen Class
 *
 * This file defines the Requests class, which manages the admin interface
 * for viewing and handling wholesale user registration requests in the
 * WooCommerce Wholesale Pricing plugin.
 *
 * @package    WooCommerceWholesalePricing\Screens
 */
namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Class Requests
 *
 * Registers the admin screen for managing wholesale user requests.
 * The menu title includes a count of pending registration requests.
 */
class Requests extends WholesaleMenu {


	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		$this->capability   = wwp_env()->get('capability') . '_user_requests';
		$this->menu_slug  = 'edit.php?post_type=wwp_requests';

		$this->needs_callback = false;

		parent::__construct();

		add_action( 'all_admin_notices', array( $this, 'navigation_buttons' ) );
	}

	/**
	 * Retrieves the page title for the Requests admin page.
	 *
	 * This title is displayed at the top of the admin screen.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered page title.
	 */
	public function get_page_title() {
		return __('Wholesale User Requests', 'woocommerce-wholesale-pricing');
	}

	/**
	 * Retrieves the menu title for the Requests admin menu item.
	 *
	 * This title is displayed in the WordPress admin sidebar menu.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered menu title.
	 */
	public function get_menu_title() {
		/* translators: %s: number of registration requests */
		return sprintf(__('Requests %s', 'woocommerce-wholesale-pricing'), get_registration_requests_count());
	}
	
	/**
	 * Render
	 *
	 * @return void
	 */
	public function render() {
	}

	public function navigation_buttons() {
		if ( ! is_sales_agent_enabled() ) {
			return;
		}

		global $current_screen;
		
		if ( ! $current_screen || ! in_array( $current_screen->id, array( 'edit-wwp_requests', 'wwp_requests', 'edit-agent_approval', 'agent_approval' ) ) ) {
			return;
		}

		wwp_view('admin.sales-agent.requests.meta-buttons', compact('current_screen'));
	}
}
