<?php
/**
 * Export Admin Screen Class
 *
 * This file defines the Export class, which registers the "Export" screen
 * in the WooCommerce Wholesale Pricing plugin. It integrates with the admin
 * menu and is intended to provide functionality for exporting product data.
 *
 * @package    WooCommerceWholesalePricing\Screens
 */
namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Class Export
 *
 * Represents the admin screen for exporting product-related data.
 * This class adds the "Export" submenu under the Wholesale Menu.
 */
class Export extends WholesaleMenu {


	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		$this->capability   = 'manage_options';
		$this->menu_slug  = 'edit.php?post_type=product&page=product_exporter';

		parent::__construct();
	}

	/**
	 * Retrieves the page title for the Export admin page.
	 *
	 * This title is displayed at the top of the admin screen.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered page title.
	 */
	public function get_page_title() {
		return __('Export', 'woocommerce-wholesale-pricing');
	}

	/**
	 * Retrieves the menu title for the Export admin menu item.
	 *
	 * This title is displayed in the WordPress admin sidebar menu.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered menu title.
	 */
	public function get_menu_title() {
		return __('Export', 'woocommerce-wholesale-pricing');
	}
	
	/**
	 * Render
	 *
	 * @return void
	 */
	public function render() {
	}
}
