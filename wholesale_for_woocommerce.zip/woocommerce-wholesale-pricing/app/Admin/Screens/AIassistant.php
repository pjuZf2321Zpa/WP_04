<?php
/**
 * AIassistant Admin Screen Class
 *
 * This file defines the AIassistant class, which handles the registration and rendering
 * of the "AIassistant" admin screen in the WooCommerce Wholesale Pricing plugin.
 * It extends the WholesaleMenu base class to integrate with the plugin's admin menu system.
 *
 * @package    WooCommerceWholesalePricing\Screens
 */
namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Class AIassistant
 *
 * Represents the admin screen for managing AIassistant.
 * This class sets up the admin page under the WooCommerce Wholesale Pricing menu
 * and delegates rendering to the AIassistant handler.
 */
class AIassistant extends WholesaleMenu {


	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		$this->capability   = 'manage_options';
		$this->menu_slug  = 'wwp-aiassistant';

		parent::__construct();
	}

	/**
	 * Retrieves the page title for the AIassistant admin page.
	 *
	 * This title is displayed at the top of the admin screen and
	 * can be modified using the 'wwp_wholsale_AIassistant_title' filter.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered page title.
	 */
	public function get_page_title() {
		/**
		 * Filter page title
		 * 
		 * @since 2.0.0
		 */
		return apply_filters('wwp_wholsale_AIassistant_title', __('AI Assistant', 'woocommerce-wholesale-pricing'));
	}

	/**
	 * Retrieves the menu title for the AIassistant admin menu item.
	 *
	 * This title is displayed in the WordPress admin sidebar menu and
	 * can be modified using the 'wwp_wholsale_AIassistant_title' filter.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered menu title.
	 */
	public function get_menu_title() {
		/**
		 * Filter page title
		 * 
		 * @since 2.0.0
		 */
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-sparkles h-5 w-5 gradient-sparkles" aria-hidden="true"><linearGradient id="sparkle-grad" x1="0%" y1="0%" x2="100%" y2="100%"> <stop offset="0%" stop-color="#ff007f" /> <stop offset="100%" stop-color="#7f00ff" /> </linearGradient><path d="M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z"></path> <path style="stroke: #8d04c0;" d="M20 2v4"></path> <path d="M22 4h-4" style="stroke: #d200ab;fill: #d200ab;"></path> </svg>';
		return "<div style='display:flex;align-items:center;gap:5px;'>" . 
		/**
		 * Filter assitant title
		 * 
		 * @since 3.1.0
		 */
		apply_filters('wwp_wholsale_AIassistant_title', __('AI Assistant', 'woocommerce-wholesale-pricing')) . $svg . '</div>';
	}
	
	/**
	 * Render the AIassistant admin page.
	 *
	 * @return void
	 */
	public function render() {
		wwp_view('admin.menus.ai-assistant');
	}
}
