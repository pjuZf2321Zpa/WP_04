<?php
/**
 * Import Admin Screen Class
 *
 * This file defines the Import class, which registers the "Import" screen
 * in the WooCommerce Wholesale Pricing plugin. It integrates with the admin
 * menu and is intended to provide functionality for importing product data.
 *
 * @package    WooCommerceWholesalePricing\Screens
 */
namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Class Import
 *
 * Represents the admin screen for importing product-related data.
 * This class adds the "Import" submenu under the Wholesale Menu.
 */
class Import extends WholesaleMenu {


	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		$this->capability   = array( wwp_env()->get('capability') . '_import', 'manage_options' );
		$this->menu_slug  = 'edit.php?post_type=product&page=product_importer';

		parent::__construct();
	}

	/**
	 * Retrieves the page title for the Import admin page.
	 *
	 * This title is displayed at the top of the admin screen.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered page title.
	 */
	public function get_page_title() {
		return __('Import', 'woocommerce-wholesale-pricing');
	}

	/**
	 * Retrieves the menu title for the Import admin menu item.
	 *
	 * This title is displayed in the WordPress admin sidebar menu.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered menu title.
	 */
	public function get_menu_title() {
		return __('Import', 'woocommerce-wholesale-pricing');
	}
	
	/**
	 * Render
	 *
	 * @return void
	 */
	public function render() {
	}
}
