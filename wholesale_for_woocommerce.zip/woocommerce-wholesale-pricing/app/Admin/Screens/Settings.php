<?php
/**
 * Settings Admin Screen Class
 *
 * This file defines the Settings class, which registers the "Settings" screen
 * for configuring plugin-level options in the WooCommerce Wholesale Pricing plugin.
 * It integrates with the admin menu and loads a dedicated settings view.
 *
 * @package    WooCommerceWholesalePricing\Screens
 */
namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Class Settings
 *
 * Manages the Wholesale Settings admin screen, allowing site administrators
 * to configure plugin-level options and preferences.
 */
class Settings extends WholesaleMenu {


	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		$this->menu_slug   = wwp_env()->get('menu_slug') . '_settings';
		$this->capability  = wwp_env()->get('capability') . '_settings';

		parent::__construct();
	}

	/**
	 * Retrieves the page title for the Settings admin page.
	 *
	 * This title is displayed at the top of the admin screen.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered page title.
	 */
	public function get_page_title() {
		return __('Wholesale Settings', 'woocommerce-wholesale-pricing');
	}

	/**
	 * Retrieves the menu title for the Settings admin menu item.
	 *
	 * This title is displayed in the WordPress admin sidebar menu.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered menu title.
	 */
	public function get_menu_title() {
		return __('Settings', 'woocommerce-wholesale-pricing');
	}
	
	/**
	 * Render
	 *
	 * @return string Rendered HTML output.
	 */
	public function render() {
		wwp_view('admin.menus.settings');
	}
}
