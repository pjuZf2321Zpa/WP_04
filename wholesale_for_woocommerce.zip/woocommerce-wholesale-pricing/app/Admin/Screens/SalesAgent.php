<?php
/**
 * Sales Agent Admin Screen Class
 *
 * This file defines the Product Table class, rendering of the "Product Table" admin screen in the WooCommerce Wholesale Pricing plugin.
 * It extends the WholesaleMenu base class and integrates with plugin settings.
 *
 * @package    WooCommerceWholesalePricing\Screens
 */
namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Class Sales Agent
 *
 * Represents the admin screen for managing Sales Agent.
 * This class registers the menu item, adds settings, and renders
 * the associated view.
 */
class SalesAgent extends WholesaleMenu {

	use WholesaleSettings;
	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		$this->capability  = wwp_env()->get('capability') . '_sales_agent';

		$this->menu_slug  = 'edit.php?post_type=' . wwp_env()->get('sales_agent_pt_slug');

		$this->needs_callback = false;

		parent::__construct();

		add_action('admin_menu', array( $this, 'conditonal_menu' ), 999);
		add_filter('submenu_file', array( $this, 'submenuMenu' ), 10);
		add_action('admin_footer', array( $this, 'wholesale_menu_active' ));
	}


	/**
	 * Retrieves the page title for the Sales Agent admin page.
	 *
	 * This title is displayed at the top of the admin screen.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered page title.
	 */
	public function get_page_title() {
		return __('Agents', 'woocommerce-wholesale-pricing');
	}

	/**
	 * Retrieves the menu title for the Sales Agent admin menu item.
	 *
	 * This title is displayed in the WordPress admin sidebar menu.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered menu title.
	 */
	public function get_menu_title() {
		return __('Agents', 'woocommerce-wholesale-pricing');
	}

	public function conditonal_menu() {
		$settings = self::get_pricing_settings();
		if (! isset($settings['sales_agent']) || 'no' == $settings['sales_agent'] ) {
			global $submenu;

			if (isset($submenu['wwp_wholesale']) ) {
				foreach ( $submenu['wwp_wholesale'] as $index => &$item ) {
					if ('manage_wholesale_sales_agent' === $item[1] ) {
						unset($submenu['wwp_wholesale'][$index]);
					}
				}
			}
		}
	}
	 
	/**
	 * Render
	 *
	 * @return string Rendered HTML output.
	 */
	public function render() {}

	/**
	 * Filters the parent menu file to ensure correct menu highlighting in the admin sidebar.
	 *
	 * This is essential when associated post types or taxonomies (like `agent`
	 * ) should remain highlighted under the main "Wholesale"
	 * menu instead of defaulting to the "Posts" or "Settings" menus.
	 *
	 * @param  string $parent_file The parent menu slug.
	 * @return string The modified parent menu slug.
	 */
	public function parentMenu( $parent_file ) {
		if ( $this->is_sales_agent_admin_screen() ) {
			$parent_file = wwp_env()->get('menu_slug');
		}

		return $parent_file;
	}

	/**
	 * Filters the active submenu item for sales agent admin screens.
	 *
	 * @param string $submenu_file The submenu slug.
	 * @return string
	 */
	public function submenuMenu( $submenu_file ) {
		$screen = get_current_screen();

		if ( ! $screen ) {
			return $submenu_file;
		}

		$agent_slug     = wwp_env()->get('sales_agent_pt_slug');
		$commission_tax = wwp_env()->get('commission_tax_slug');

		if ( 'agent_approval' === $screen->post_type ) {
			return 'edit.php?post_type=' . wwp_env()->get('request_slug');
		}

		if ( $agent_slug === $screen->post_type && $commission_tax === $screen->taxonomy ) {
			return sprintf( 'edit-tags.php?taxonomy=%s&post_type=%s', $commission_tax, $agent_slug );
		}

		if ( $agent_slug === $screen->post_type && empty( $screen->taxonomy ) ) {
			return 'edit.php?post_type=' . $agent_slug;
		}

		return $submenu_file;
	}

	/**
	 * Ensures the Wholesale top-level menu appears active on sales agent screens.
	 *
	 * @return void
	 */
	public function wholesale_menu_active() {
		$screen = get_current_screen();

		if ( ! $this->is_sales_agent_admin_screen( $screen ) ) {
			return;
		}

		$agent_slug     = wwp_env()->get('sales_agent_pt_slug');
		$commission_tax = wwp_env()->get('commission_tax_slug');
		$menu_slug      = wwp_env()->get('menu_slug');

		if ( 'agent_approval' === $screen->post_type ) {
			$active_submenu = 'edit.php?post_type=' . wwp_env()->get('request_slug');
		} elseif ( $commission_tax === $screen->taxonomy ) {
			$active_submenu = sprintf( 'edit-tags.php?taxonomy=%s&post_type=%s', $commission_tax, $agent_slug );
		} else {
			$active_submenu = 'edit.php?post_type=' . $agent_slug;
		}
		?>
		<style>
			#toplevel_page_<?php echo esc_attr( $menu_slug ); ?>.wp-has-current-submenu > a {
				background-color: #2271b1 !important;
				color: #fff !important;
			}
			#toplevel_page_<?php echo esc_attr( $menu_slug ); ?>.wp-menu-open .wp-submenu {
				display: block !important;
			}
		</style>

		<script type="text/javascript">
			(function($) {
				$(function() {
					var $wholesaleMenu = $('#toplevel_page_<?php echo esc_js( $menu_slug ); ?>');

					if (!$wholesaleMenu.length) {
						return;
					}

					$('.wp-has-current-submenu, .wp-menu-open')
						.not($wholesaleMenu)
						.removeClass('wp-has-current-submenu wp-menu-open')
						.addClass('wp-not-current-submenu');

					$wholesaleMenu
						.removeClass('wp-not-current-submenu')
						.addClass('wp-has-current-submenu wp-menu-open opensub');

					$wholesaleMenu.find('.wp-submenu a')
						.removeClass('current')
						.parent('li')
						.removeClass('current');

					var activeSubmenu = <?php echo wp_json_encode( $active_submenu ); ?>;
					var $activeLink = $wholesaleMenu.find('.wp-submenu a').filter(function() {
						var href = $(this).attr('href') || '';

						return href.indexOf(activeSubmenu) !== -1;
					}).first();

					$activeLink
						.addClass('current')
						.parent('li')
						.addClass('current');
				});
			})(jQuery);
		</script>
		<?php
	}

	/**
	 * Whether the current admin screen belongs to the sales agent module.
	 *
	 * @param \WP_Screen|null $screen Optional screen object.
	 * @return bool
	 */
	private function is_sales_agent_admin_screen( $screen = null ) {
		$screen = $screen ? $screen : get_current_screen();

		if ( ! $screen ) {
			return false;
		}

		return in_array(
			$screen->post_type,
			array(
				wwp_env()->get('sales_agent_pt_slug'),
				'agent_approval',
			),
			true
		);
	}
}
