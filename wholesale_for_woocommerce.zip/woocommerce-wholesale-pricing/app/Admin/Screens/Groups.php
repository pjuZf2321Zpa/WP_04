<?php
/**
 * Groups Admin Screen Class
 *
 * This file defines the Groups class, which manages the "Wholesale Group" admin screen
 * for the WooCommerce Wholesale Pricing plugin. It conditionally registers the menu item
 * based on plugin settings and integrates with the admin menu system.
 *
 * @package    WooCommerceWholesalePricing\Screens
 */
namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Class Groups
 *
 * Handles the admin interface for managing wholesale customer groups.
 * This class conditionally shows or hides the group menu item based on settings.
 */
class Groups extends WholesaleMenu {

	use WholesaleSettings;
	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {
		
		$this->capability   = wwp_env()->get('capability') . '_group';
		$this->menu_slug  = 'edit.php?post_type=wwp_groups';

		$this->needs_callback = false;

		parent::__construct();

		add_action('admin_menu', array( $this, 'conditonal_menu' ), 999);
	}

	/**
	 * Retrieves the page title for the Groups admin page.
	 *
	 * This title is displayed at the top of the admin screen.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered page title.
	 */
	public function get_page_title() {
		return __('Wholesale Group', 'woocommerce-wholesale-pricing');
	}

	/**
	 * Retrieves the menu title for the Groups admin menu item.
	 *
	 * This title is displayed in the WordPress admin sidebar menu.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered menu title.
	 */
	public function get_menu_title() {
		return __('Groups', 'woocommerce-wholesale-pricing');
	}
	
	/**
	 * Conditonal_menu
	 *
	 * @return void
	 */
	public function conditonal_menu() {
		$settings = self::get_pricing_settings();
		if (isset($settings['enable_groups']) && 'no' == $settings['enable_groups'] ) {
			global $submenu;
	
			if (isset($submenu['wwp_wholesale']) ) {
				foreach ( $submenu['wwp_wholesale'] as $index => &$item ) {
					if ('edit.php?post_type=wwp_groups' === $item[2] ) {
						unset($submenu['wwp_wholesale'][$index]);
					}
				}
			}
		}
	}
	
	/**
	 * Render
	 *
	 * @return void
	 */
	public function render() {
	}
}
