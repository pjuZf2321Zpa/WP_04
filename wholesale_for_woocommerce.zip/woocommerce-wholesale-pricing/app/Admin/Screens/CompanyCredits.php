<?php
/**
 * Company Credits Admin Screen.
 *
 * @package WooCommerceWholesalePricing\Screens
 */

namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Companies admin screen under Wholesale menu.
 */
class CompanyCredits extends WholesaleMenu {

	use WholesaleSettings;

	/**
	 * CompanyCredits constructor.
	 */
	public function __construct() {
		$this->capability     = wwp_env()->get( 'capability' ) . '_company_credits';
		$this->menu_slug      = 'edit.php?post_type=' . wwp_env()->get( 'company_credits_slug' );
		$this->needs_callback = false;

		parent::__construct();

		add_filter( 'parent_file', array( $this, 'set_wholesale_parent_menu' ), 11 );
		add_filter( 'submenu_file', array( $this, 'set_company_credits_submenu' ), 11 );
		add_action( 'admin_footer', array( $this, 'wholesale_menu_active' ) );
		add_action( 'admin_menu', array( $this, 'conditonal_menu' ), 999 );
	}

	/**
	 * Page title.
	 *
	 * @return string
	 */
	public function get_page_title() {
		return __( 'Companies', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Menu title.
	 *
	 * @return string
	 */
	public function get_menu_title() {
		return __( 'Companies', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Hide menu when feature is disabled.
	 *
	 * @return void
	 */
	public function conditonal_menu() {
		$settings = self::get_pricing_settings();
		if ( ! isset( $settings['b2b_company_credits'] ) || 'no' == $settings['b2b_company_credits'] ) {
			global $submenu;

			if ( isset( $submenu['wwp_wholesale'] ) ) {
				foreach ( $submenu['wwp_wholesale'] as $index => &$item ) {
					if ( 'manage_wholesale_company_credits' === $item[1] ) {
						unset( $submenu['wwp_wholesale'][ $index ] );
					}
				}
			}
		}
	}

	/**
	 * Whether current screen is a companies screen.
	 *
	 * @param \WP_Screen|null $screen Current screen.
	 * @return bool
	 */
	private function is_company_credits_admin_screen( $screen ) {
		if ( ! $screen ) {
			return false;
		}

		$post_type = wwp_env()->get( 'company_credits_slug' );

		return $post_type === $screen->post_type
			|| in_array( $screen->id, array( 'edit-' . $post_type, $post_type ), true );
	}

	/**
	 * Highlight Wholesale parent menu.
	 *
	 * @param string $parent_file Parent file.
	 * @return string
	 */
	public function set_wholesale_parent_menu( $parent_file ) {
		if ( $this->is_company_credits_admin_screen( get_current_screen() ) ) {
			return wwp_env()->get( 'menu_slug' );
		}

		return $parent_file;
	}

	/**
	 * Highlight Companies submenu.
	 *
	 * @param string $submenu_file Submenu file.
	 * @return string
	 */
	public function set_company_credits_submenu( $submenu_file ) {
		if ( $this->is_company_credits_admin_screen( get_current_screen() ) ) {
			return $this->menu_slug;
		}

		return $submenu_file;
	}

	/**
	 * Keep Wholesale menu expanded on company screens.
	 *
	 * @return void
	 */
	public function wholesale_menu_active() {
		if ( ! $this->is_company_credits_admin_screen( get_current_screen() ) ) {
			return;
		}

		$menu_slug = wwp_env()->get( 'menu_slug' );
		$post_type = wwp_env()->get( 'company_credits_slug' );
		$menu_id   = 'toplevel_page_' . $menu_slug;
		?>
		<style>
			#<?php echo esc_attr( $menu_id ); ?>.wp-has-current-submenu > a {
				background-color: #2271b1 !important;
				color: #fff !important;
			}
			#<?php echo esc_attr( $menu_id ); ?>.wp-menu-open .wp-submenu {
				display: block !important;
			}
		</style>
		<script type="text/javascript">
			(function($) {
				$(function() {
					var $wholesaleMenu = $('#<?php echo esc_js( $menu_id ); ?>');
					if (!$wholesaleMenu.length) {
						return;
					}
					$('.wp-has-current-submenu, .wp-menu-open')
						.not($wholesaleMenu)
						.removeClass('wp-has-current-submenu wp-menu-open')
						.addClass('wp-not-current-submenu');
					$wholesaleMenu
						.removeClass('wp-not-current-submenu')
						.addClass('wp-has-current-submenu wp-menu-open opensub');
					$wholesaleMenu.find('a[href*="post_type=<?php echo esc_js( $post_type ); ?>"]')
						.addClass('current')
						.parent('li').addClass('current');
				});
			})(jQuery);
		</script>
		<?php
	}

	/**
	 * Render callback (not used).
	 *
	 * @return void
	 */
	public function render() {}
}
