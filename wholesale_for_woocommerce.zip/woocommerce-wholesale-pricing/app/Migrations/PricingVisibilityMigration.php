<?php

namespace WooCommerceWholesalePricing\App\Migrations;

use WooCommerceWholesalePricing\App\Providers\WholesaleOption;

class PricingVisibilityMigration {

	public function __construct() {
		add_action( 'init', array( $this, 'migrate' ), 250 );
	}

	public function migrate() {
		$db_version = get_option( 'wwp_wholesale_version' );

		// This option did not exist before 3.1.0, so empty means upgrade from older versions.
		if ( ! empty( $db_version ) ) {
			return;
		}

		$settings = get_option( WholesaleOption::PRICING_OPTION, array() );

		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		$has_changes = false;

		/*
		 * Backward compatibility:
		 * - Pre-3.1.0 retailer_disabled hid both label + price.
		 * - Pre-3.1.0 save_price_disabled hid both label + price.
		 * On upgrade, mirror legacy "yes" values to the new price visibility keys.
		 */
		if (
			isset( $settings['retailer_disabled'] ) &&
			'yes' === $settings['retailer_disabled'] &&
			( ! isset( $settings['retailer_price_disabled'] ) || 'yes' !== $settings['retailer_price_disabled'] )
		) {
			$settings['retailer_price_disabled'] = 'yes';
			$has_changes = true;
		}

		$legacy_save_hidden = (
			( isset( $settings['save_price_disabled'] ) && 'yes' === $settings['save_price_disabled'] ) ||
			( isset( $settings['save_price_label_disabled'] ) && 'yes' === $settings['save_price_label_disabled'] )
		);

		if ( $legacy_save_hidden ) {
			if ( ! isset( $settings['save_price_label_disabled'] ) || 'yes' !== $settings['save_price_label_disabled'] ) {
				$settings['save_price_label_disabled'] = 'yes';
				$has_changes = true;
			}

			if ( ! isset( $settings['save_price_disabled'] ) || 'yes' !== $settings['save_price_disabled'] ) {
				$settings['save_price_disabled'] = 'yes';
				$has_changes = true;
			}
		}

		if ( $has_changes ) {
			update_option( WholesaleOption::PRICING_OPTION, $settings );
		}
	}
}
