<?php

namespace WooCommerceWholesalePricing\App\Migrations;

use WooCommerceWholesalePricing\App\Providers\WholesaleOption;

/**
 * Migrates legacy quote rules and enables quote settings on upgrade.
 */
class EnableQuoteFromRulesMigration {

	const MIGRATED_OPTION              = 'wwp_enable_quote_from_rules_migrated';
	const RULES_ENABLE_RULE_MIGRATED_OPTION = 'wwp_quote_rules_enable_rule_migrated';

	public function __construct() {
		add_action( 'init', array( $this, 'migrate' ), 250 );
	}

	/**
	 * Migrate legacy quote rules and enable quote settings if there are published rules.
	 * 
	 * @return void
	 */
	public function migrate() {

		if ( 'yes' !== get_option( self::RULES_ENABLE_RULE_MIGRATED_OPTION ) ) {
			$this->enable_quote_rules_meta();
			update_option( self::RULES_ENABLE_RULE_MIGRATED_OPTION, 'yes' );
		}

		if ( 'yes' === get_option( self::MIGRATED_OPTION ) ) {
			return;
		}

		if ( $this->has_published_enabled_quote_rules() ) {
			$this->enable_quote_setting();
		}

		update_option( self::MIGRATED_OPTION, 'yes' );
	}

	/**
	 * Backfill enable_rule meta for quote rules created before this version.
	 *
	 * @return void
	 */
	private function enable_quote_rules_meta() {
		$post_type = $this->get_quote_rules_post_type();
		$rule_ids  = get_posts(
			array(
				'post_type'      => $post_type,
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);

		foreach ( $rule_ids as $rule_id ) {
			if ( '1' === (string) get_post_meta( $rule_id, 'enable_rule', true ) ) {
				continue;
			}

			update_post_meta( $rule_id, 'enable_rule', '1' );
		}
	}

	/**
	 * Get the post type for quote rules.
	 * 
	 * @return string
	 */
	private function get_quote_rules_post_type() {
		return function_exists( 'wwp_env' ) ? wwp_env()->get( 'quote_rules_slug' ) : 'wc-quote-rules';
	}

	/**
	 * Check if there are any published quote rules with enable_rule meta set to true.
	 * 
	 * @return bool
	 */
	private function has_published_enabled_quote_rules() {
		$rules = get_posts(
			array(
				'post_type'      => $this->get_quote_rules_post_type(),
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'fields'         => 'ids',
			)
		);

		return ! empty( $rules );
	}

	/**
	 * Enable the quote setting.
	 * 
	 * @return void
	 */
	private function enable_quote_setting() {
		$settings = get_option( WholesaleOption::PRICING_OPTION, array() );

		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		if ( isset( $settings['enable_quote'] ) && 'yes' === $settings['enable_quote'] ) {
			return;
		}

		$settings['enable_quote'] = 'yes';
		update_option( WholesaleOption::PRICING_OPTION, $settings );
	}
}
