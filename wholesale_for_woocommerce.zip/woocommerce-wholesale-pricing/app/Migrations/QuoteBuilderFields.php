<?php

namespace WooCommerceWholesalePricing\App\Migrations;

class QuoteBuilderFields {

	public function __construct() {
		add_action( 'init', array( $this, 'migrate' ), 250 );
	}

	public function migrate() {
		$db_version = get_option( 'wwp_wholesale_version' );

		// This option did not exist before 3.1.0, so empty means upgrade from older versions.
		if ( ! empty( $db_version ) ) {
			return;
		}

		$builder_schema = '{ "components": [ { "label": "Email", "tableView": true, "key": "email", "type": "email", "input": true }, { "label": "Name", "tableView": true, "key": "name", "type": "textfield", "input": true }, { "label": "Message", "autoExpand": false, "tableView": true, "key": "message", "type": "textarea", "input": true } ] }';
		update_option('wc_quote_form_builder', $builder_schema);
	}
}
