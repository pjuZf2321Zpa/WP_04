<?php
/**
 * Checkout Handler Class
 *
 * This file defines the Handler class responsible for handling
 * wholesale-specific logic during the WooCommerce checkout process.
 * It utilizes wholesale pricing settings to modify or manage checkout behavior.
 *
 * @package WooCommerceWholesalePricing\App\Http\Controllers\Checkout
 */
namespace WooCommerceWholesalePricing\App\Http\Controllers\Checkout;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

/**
 * Class Handler
 *
 * Provides checkout-related functionality tailored for wholesale customers.
 * This class currently serves as a base or placeholder for checkout logic integration.
 */
class Handler {

	
	use WholesaleSettings;
	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {
	}
}
