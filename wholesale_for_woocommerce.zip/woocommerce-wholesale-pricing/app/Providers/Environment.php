<?php
/**
 * Environment class.
 *
 * Provides a centralized, singleton repository for critical environment variables,
 * slugs, capabilities, and endpoints used across the WooCommerce Wholesale Pricing plugin.
 *
 * @package    WooCommerceWholesalePricing\Providers
 */
namespace WooCommerceWholesalePricing\App\Providers;

use WooCommerceWholesalePricing\App\Strategies\Singleton;

/**
 * Environment Class (Singleton).
 *
 * Acts as a container for all static, configuration-like variables (slugs,
 * capabilities, shortcodes, endpoints) used by the plugin.
 * Implements the Singleton pattern to ensure global access to a single instance.
 */
class Environment extends Singleton {


	/**
	 * The slug used for the main plugin admin menu page.
	 *
	 * @var string
	 */
	private $menu_slug              = 'wwp_wholesale';

	/**
	 * The capability required for a user to access wholesale management features.
	 *
	 * @var string
	 */
	private $capability             = 'manage_wholesale';

	/**
	 * The taxonomy slug used for defining and storing custom wholesale user roles.
	 *
	 * @var string
	 */
	private $role_taxonomy          = 'wholesale_user_roles';

	/**
	 * The shortcode used to display the wholesale user registration form.
	 *
	 * @var string
	 */
	private $registration_shortcode = 'wwp_registration_form';

	 /**
	  * The custom post type slug for wholesale groups.
	  *
	  * @var string
	  */
	private $group_slug             = 'wwp_groups';

	/**
	 * The custom post type slug for wholesale registration/upgrade requests.
	 *
	 * @var string
	 */
	private $request_slug           = 'wwp_requests';

	/**
	 * The WooCommerce My Account endpoint slug for group announcements.
	 *
	 * @var string
	 */
	private $group_endpoint         = 'group-announcement';

	/**
	 * The WooCommerce My Account endpoint slug for viewing requisitions.
	 *
	 * @var string
	 */
	private $requisition_endpoint   = 'requisition-list';

	/**
	 * The WooCommerce My Account endpoint slug for account upgrade requests.
	 *
	 * @var string
	 */
	private $upgrade_endpoint       = 'upgrade-account';

	private $quote_rules_slug       = 'wc-quote-rules';

	/**
	 * The slug for the quote page.
	 *
	 * @var string
	 */
	private $quote_page_shortcode        = 'wc-quote-request-page';

	private $multilipi_integration_zip = 'https://multilipistorage.blob.core.windows.net/media-seo/seo-scripts/multilipi-multilingual-seo.zip';

	private $product_table_slug       = 'wcpt';

	private $dynamic_rules_slug       = 'dynamic_rules';

	private $sales_agent_pt_slug       = 'agent';

	private $company_credits_slug      = 'ccp_company';

	private $company_credit_logs_slug  = 'ccp_credit_logs';

	private $commission_tax_slug       = 'commission_cat';

	private $payout_page_slug       = 'agent-payout';
	private $payout_view_page_slug       = 'agent-payout-view';
	private $agent_comission_edit_page_slug       = 'agent-commission-edit';

	private $vat_validation_wsdl_url = 'https://ec.europa.eu/taxation_customs/vies/checkVatService.wsdl';

	/**
	 * A self-reference property (typically used by the Singleton trait).
	 *
	 * @var self
	 */
	private $self;

	/**
	 * Constructor.
	 *
	 * Calls the parent constructor to enforce the Singleton pattern.
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Retrieves the value of an environment variable by its key.
	 *
	 * @param  string $key The property name of the environment variable.
	 * @return mixed|null The value of the property, or null if it is not set.
	 */
	public function get( $key ) {
		return isset($this->{$key}) ? $this->{$key} : null;
	}   

	/**
	 * Sets or updates the value of an environment variable.
	 *
	 * @param  string $key   The property name of the environment variable.
	 * @param  mixed  $value The new value to assign.
	 * @return void
	 */
	public function set( $key, $value ) {
		$this->{$key} = $value;
	}
}
