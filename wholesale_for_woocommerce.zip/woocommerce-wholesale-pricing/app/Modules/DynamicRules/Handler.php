<?php
/**
 * Dynamic Rules module handler.
 *
 * Boots runtime rule-type handlers without modifying core wholesale pricing.
 *
 * @package WooCommerceWholesalePricing\App\Modules\DynamicRules
 */

namespace WooCommerceWholesalePricing\App\Modules\DynamicRules;

use WooCommerceWholesalePricing\App\Services\DynamicRules\Rules\AddTaxFeeRule;
use WooCommerceWholesalePricing\App\Services\DynamicRules\Rules\BuyXGetXRule;
use WooCommerceWholesalePricing\App\Services\DynamicRules\Rules\ChangeGroupRule;
use WooCommerceWholesalePricing\App\Services\DynamicRules\Rules\RaisePercentageRule;

/**
 * Class Handler
 *
 * Instantiates Dynamic Rule runtime implementations.
 */
class Handler {

	/**
	 * Constructor.
	 */
	public function __construct() {
		new RaisePercentageRule();
		new BuyXGetXRule();
		new ChangeGroupRule();
		new AddTaxFeeRule();
	}
}
