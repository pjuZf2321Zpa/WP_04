<?php
/**
 * Trait VariablePriceFormat.
 *
 * This trait is responsible for overriding the variable product price HTML
 * to display the correct wholesale price for the current user's role.
 *
 * It follows a strict hierarchy for determining which price structure (tiered,
 * product-specific, category-specific, or global) should be applied.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Traits;

trait VariablePriceHTML {


	/**
	 * Trait containing utility methods
	 */
	use IsWholesale;
	use DiscountedPrice;

	/**
	 * Filters the WooCommerce variable product price HTML.
	 *
	 * This method applies wholesale pricing logic based on a defined hierarchy.
	 *
	 * @param  string               $price   The original price HTML string.
	 * @param  \WC_Product_Variable $product The variable product object.
	 * @return string The modified price HTML string (wholesale price) or the original price.
	 */
	public function wwp_variable_price_format( $price, $product ) {
		global $woocommerce;
		$_product = null;
		$prod_id = $product->get_id();
		$wwp_group = wwp_get_group_post_by_proid($product->get_id(), get_current_user_id());
		
		if (! $this->is_wholesale($prod_id) && ! $wwp_group ) {
			return $price;
		}
		$return_check       = false;
		$product_variations = $product->get_children();
		$wholesale_product_variations = array();
		$original_variation_price     = array();
		$role                         = get_current_user_role_id();
		
		/**
		 * Filter
		 * 
		 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
		 * 
		 * @since 3.1.0
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );

		if (wwp_guest_wholesale_pricing_enabled() ) {
			if (( is_shop() && ! wwp_guest_wholesale_pricing_enabled('display_on_shop') ) || ( is_product() && ! wwp_guest_wholesale_pricing_enabled('display_on_single') ) ) {
				return $price;
			}
			$role = wwp_guest_wholesale_pricing_enabled('role');
		}

		if (wwp_get_group_post_by_proid($product->get_id(), get_current_user_id()) ) {
			$this->tier_table = true;
			return tire_variable_wholesale_product_price_html($prod_id, $product, 'group');
		}
		
		$data                         = get_post_meta($prod_id, 'wholesale_multi_user_pricing', true);

		if (isset($data[ $role ]) ) {
			
			if (tire_variable_wholesale_product_price_html($product->get_id(), $product, 'product') ) {
				$this->tier_table = true;
				return tire_variable_wholesale_product_price_html($product->get_id(), $product, 'product');
			}
		}
		
		if (isset($data[ $role ]) && false === $return_check ) {
		
			foreach ( $product_variations as $product_variation ) {
				if (isset($data[ $role ]) && isset($data[ $role ][ $product_variation ]) ) {
					$_product                       = wc_get_product($product_variation);
					$wholesale_product_variations[] = $this->get_wholesale_price_multi($data[ $role ]['discount_type'], $data[ $role ][ $product_variation ]['wholesaleprice'], $product_variation);
					/**
					* Hooks
					*
					* @since 3.0.0
					*/
					$_price = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );
					$original_variation_price[] = get_post_meta($product_variation, $_price, true);
				}
			}
			
			if (( 'object' != gettype(@$_product) )) {
				return $price;
			}
			
			$return_check = true;
			return variable_wholesale_product_price_html($wholesale_product_variations, $original_variation_price, $_product);
		}
		
		if (tire_variable_wholesale_product_price_html($prod_id, $product, 'category') ) {
			$this->tier_table = true;
			return tire_variable_wholesale_product_price_html($prod_id, $product, 'category');
		}
		
		$terms = get_the_terms($prod_id, 'product_cat');

		if (! is_wp_error($terms) && ! empty($terms) ) {
			foreach ( $terms as $term ) {
				$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
				if (isset($data[ $role ]['min_quatity']) && false === $return_check ) {
					$min_quantity = (int) $data[ $role ]['min_quatity'];

					if (empty($min_quantity) || ! isset($min_quantity) ) {
						$min_quantity = 1;
					}
					$wholesale_product_variations = array();
					$original_variation_price     = array();
					if (isset($data[ $role ]) ) {
						foreach ( $product_variations as $product_variation ) {
								$_product                       = wc_get_product($product_variation);
								$wholesale_product_variations[] = $this->get_wholesale_price_multi($data[ $role ]['discount_type'], $data[ $role ]['wholesale_price'], $product_variation);
								/**
								* Hooks
								*
								* @since 3.0.0
								*/
								$_price = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );
								$original_variation_price[] = get_post_meta( $product_variation, $_price, true );
						}
						$return_check = true;
						return variable_wholesale_product_price_html($wholesale_product_variations, $original_variation_price, $_product);    
					}
				}
			}
		}
		
		$data = get_option('wholesale_multi_user_pricing');
		if (isset($data[ $role ]) && false === $return_check ) {

			if ( is_product_category_excluded_global($product->get_id()) ) {
				return $price;
			}

			if (tire_variable_wholesale_product_price_html($product->get_id(), $product, 'global') ) {
				$this->tier_table = true;
				return tire_variable_wholesale_product_price_html($product->get_id(), $product, 'global');
			}
		}
			
		if (isset($data[ $role ]['min_quatity']) && false === $return_check ) {
			$product_id      = $product->get_id();
			
			if ( is_product_category_excluded_global($product_id) ) {
				return $price;
			}
			$min_quantity = $data[ $role ]['min_quatity'];

			if (empty($min_quantity) || ! isset($min_quantity) ) {
				$min_quantity = 1;
			}
			$wholesale_product_variations = array();
			$original_variation_price     = array();

			foreach ( $product_variations as $product_variation ) {
				$_product                       = wc_get_product($product_variation);
				$wholesale_product_variations[] = $this->get_wholesale_price_multi($data[ $role ]['discount_type'], $data[ $role ]['wholesale_price'], $product_variation);
				/**
				* Hooks
				*
				* @since 3.0.0
				*/
				$_price = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );
				$original_variation_price[] = get_post_meta( $product_variation, $_price, true );
			}
			return variable_wholesale_product_price_html($wholesale_product_variations, $original_variation_price, $_product);
			$return_check = true;
		}

		if (empty($wholesale_product_variations)) {
			return $price;
		}
		
		return variable_wholesale_product_price_html($wholesale_product_variations, $original_variation_price, $_product);
	}
}
