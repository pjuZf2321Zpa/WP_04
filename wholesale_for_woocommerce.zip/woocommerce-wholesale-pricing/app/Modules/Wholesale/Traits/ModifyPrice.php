<?php
/**
 * Trait ModifyPrice.
 *
 * Provides a method to apply a calculated wholesale discount to a product's price,
 * handling both fixed and percentage discount types. It also accounts for tax
 * calculations when a specific product setting ('wwp_variation_explode_eneble') is active.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Traits;

trait ModifyPrice {

	/**
	 * Applies a wholesale price modification (fixed amount or percentage discount)
	 * to a given base price.
	 *
	 * @param  float  $price        The original price to be modified.
	 * @param  string $type         The discount type: 'fixed' or 'percent'.
	 * @param  float  $amount       The discount value (either the fixed new price or the percentage).
	 * @param  int    $variation_id The product ID or variation ID, used primarily for tax calculation logic. Defaults to 0.
	 * @return float The modified price.
	 */
	public function change_price( $price, $type, $amount, $variation_id = 0 ) {
		if (empty($price) || empty($amount) ) {
			return $price;
		}
		if ('fixed' == $type ) {
			// 'fixed' means the $amount is the final wholesale price.
			$price = $amount;
		} else {
			// 'percent' means $amount is the percentage discount to be applied.
			// Note: If $amount in this context is the *discount amount* (as in DiscountedPrice.php),
			// the logic here needs adjustment to subtract the discount from the base price.
			// Assuming $amount is the percentage *of the original price* to keep (e.g., 80 for 20% off).
			// Based on standard usage, let's assume $amount is the percentage discount (e.g., 20).
			// Reinterpreting based on DiscountedPrice.php logic, $amount is the *discount amount*
			// if it were a flat discount, but here it's used to calculate the price.
			// Let's assume the intended logic is: $price = $original_price - ($original_price * $percentage_discount / 100).
			// However, the provided code performs a multiplication, which suggests $amount is the resulting price factor.
			$price = $price * $amount / 100;
		}

		$wc_get_product = wc_get_product($variation_id);
		if (( 'object' == gettype($wc_get_product) )) {
			if ('product_variation' == get_post_type($wc_get_product->get_id()) ) {
				$wwp_variation_explode_eneble = get_post_meta($wc_get_product->get_parent_id(), 'wwp_variation_explode_eneble', true);
			} else {
				$wwp_variation_explode_eneble = get_post_meta($wc_get_product->get_id(), 'wwp_variation_explode_eneble', true);
			}
			if ('yes' == $wwp_variation_explode_eneble ) {
				$price = wwp_get_price_including_tax($wc_get_product, array( 'price' => $price ));
			}
		}
		
		/**
		 * If the store is configured to include tax in prices and we are in the admin area, we need to convert the price back to excluding tax for consistency with how prices are stored and calculated in the backend.
		 * This ensures that the wholesale price is correctly applied and displayed in the admin order details without tax included, as WooCommerce expects prices to be stored excluding tax in the database.
		 */
		if ( 'yes' == get_option('woocommerce_prices_include_tax') && is_admin() ) {
			$price = wc_get_price_excluding_tax($wc_get_product, array( 'price' => $price ));
		}
		
		/**
		 * Filter: wwp_change_price
		 *
		 * Allows modification of the final calculated wholesale price before it is returned.
		 *
		 * @since 2.5.0
		 * @param float $price The modified product price.
		 * @param \WC_Product $wc_get_product The WooCommerce product object.
		 */
		return apply_filters('wwp_change_price', $price, $wc_get_product);
	}
}
