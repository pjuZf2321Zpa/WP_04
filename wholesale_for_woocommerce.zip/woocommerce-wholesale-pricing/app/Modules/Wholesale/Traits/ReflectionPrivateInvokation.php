<?php
/**
 * Trait ReflectionPrivateInvokation.
 *
 * Provides a utility method to invoke private or protected methods on a class
 * instance using PHP's Reflection API. This is typically used for unit testing
 * or accessing necessary functionality in third-party classes when public access is unavailable.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Traits;

trait ReflectionPrivateInvokation {


	/**
	 * Uses PHP Reflection to bypass visibility restrictions and invoke a private or protected method.
	 *
	 * Note: This method is a "hack" and should be used cautiously, as it bypasses encapsulation.
	 *
	 * @param  object|string $class_name The object instance or class name.
	 * @param  string        $methodName The name of the private or protected method to invoke.
	 * @return mixed The return value of the invoked private method.
	 * @throws \Exception If the PHP version is less than 5.3 (no support for ReflectionClass::setAccessible()).
	 */
	public function woo_hack_invoke_private_method( $class_name, $methodName ) {
		if (version_compare(phpversion(), '5.3', '<') ) {
			throw new \Exception('PHP version does not support ReflectionClass::setAccessible()', __LINE__);
		}
		$args = func_get_args();
		unset($args[0], $args[1]);
		$reflection = new \ReflectionClass($class_name);
		$method     = $reflection->getMethod($methodName);
		$method->setAccessible(true);
		$args = array_merge(array( $reflection ), $args);
		return call_user_func_array(array( $method, 'invoke' ), $args);
	}
}
