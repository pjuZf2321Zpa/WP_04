<?php
/**
 * Trait ProductPriceHTML.
 *
 * Handles the front-end display of wholesale pricing on product and shop pages
 * by overriding the default WooCommerce price HTML based on user roles and
 * pricing hierarchy (tiered, general, product, category, global).
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Traits;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

trait ProductPriceHTML {

	/**
	 * Trait containing methods to retrieve excluded categories for wholesale roles.
	 */
	use WholesaleSettings;

	/**
	 * Determines the correct price HTML to display for a wholesale product based
	 * on a strict hierarchy: Tiered > General, from specific (Product) to broad (Global).
	 *
	 * @param  string            $price   The default WooCommerce price HTML string.
	 * @param  \WC_Product|array $product The WC_Product object or cart item array.
	 * @return string The modified price HTML or the original price HTML.
	 */
	public function wwp_change_product_price_display( $price, $product ) {
		if (is_array($product) ) {
			$post_id = $product['product_id'];
			$product = wc_get_product($post_id);
		}
		if ( is_cart() || is_checkout() || 'woocommerce_cart_item_price' === current_filter() ) {
			return $price;
		}
		if (( 'object' != gettype($product) )) {
			return $price;
		}

		/**
		 * Filter
		 * 
		 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
		 * 
		 * @since 3.1.0
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );

		$post_id = $product->get_id();
		if (( 'object' == gettype($product) ) && ( $product->is_type('subscription') || $product->is_type('variable-subscription') || ! $product->is_type('simple') ) ) {
			if ('product_variation' == get_post_type($product->get_id()) ) {
				if (! empty(get_option('woocommerce_price_display_suffix')) ) {
					$price = $price;
				} else {
					$product_price = ( '_price' == $price_key ) ? $product->get_price() : $product->get_regular_price();
					$price = wc_price(wwp_get_price_including_tax($product, array( 'price' => $product_price )));
				}
				return $price;
			} elseif ('bundle' != $product->get_type() ) {
				return $price;
			}
		}

		$role = get_current_user_role_id();
		if (wwp_guest_wholesale_pricing_enabled() ) {
			if (( is_shop() && ! wwp_guest_wholesale_pricing_enabled('display_on_shop') ) || ( is_product() && ! wwp_guest_wholesale_pricing_enabled('display_on_single') ) ) {
				return $price;
			}
			$role = wwp_guest_wholesale_pricing_enabled('role');
		}

		if (wwp_get_group_post_by_proid($product->get_id(), get_current_user_id()) ) {
			$this->tier_table = true;
			return tire_simple_wholesale_product_price_html($product->get_id(), $product, 'group');
		}

		$data = get_post_meta($post_id, 'wholesale_multi_user_pricing', true);
		if (isset($data[ $role ]) ) {
			if (tire_simple_wholesale_product_price_html($product->get_id(), $product, 'product') ) {
				$this->tier_table = true;
				return tire_simple_wholesale_product_price_html($product->get_id(), $product, 'product');
			}
		}

		if (isset($data[ $role ]) ) {
			$my = $data[ $role ];
			if (isset($my['discount_type']) && ! empty($my['discount_type']) && isset($my['wholesale_price']) && ! empty($my['wholesale_price']) && isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {

				return simple_wholesale_product_price_html($my['discount_type'], $my['wholesale_price'], $price, $my['min_quatity'], $product);
			} else {
				return $price;
			}
		}
		
		if (tire_simple_wholesale_product_price_html($product->get_id(), $product, 'category') ) {
			$this->tier_table = true;
			return tire_simple_wholesale_product_price_html($product->get_id(), $product, 'category');
		}

		$terms = get_the_terms($post_id, 'product_cat');
		if (! is_wp_error($terms) && ! empty($terms) ) {
			foreach ( $terms as $term ) {
				$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
				if (isset($data[ $role ]) ) {
					$my = $data[ $role ];
					if (isset($my['discount_type']) && ! empty($my['discount_type']) && isset($my['wholesale_price']) && ! empty($my['wholesale_price']) && isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
						return simple_wholesale_product_price_html($my['discount_type'], $my['wholesale_price'], $price, $my['min_quatity'], $product);
					} else {
						return $price;
					}
				}
			}
		}

		$data = self::get_multiuser_pricing_settings();
		if (isset($data[ $role ]) ) {
			if ( is_product_category_excluded_global($product->get_id() ) ) {
				return $price;
			}
			if (tire_simple_wholesale_product_price_html($product->get_id(), $product, 'global') ) {
				$this->tier_table = true;
				return tire_simple_wholesale_product_price_html($product->get_id(), $product, 'global');
			}
		}
		if (isset($data[ $role ]) ) {
			$my = $data[ $role ];
			if (isset($my['discount_type']) && ! empty($my['discount_type']) && isset($my['wholesale_price']) && ! empty($my['wholesale_price']) && isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
				if ( is_product_category_excluded_global($product->get_id() ) ) {
					return $price;
				}

				return simple_wholesale_product_price_html($my['discount_type'], $my['wholesale_price'], $price, $my['min_quatity'], $product);
			} else {
				return $price;
			}
		}
		
		return $price;
	}
}
