<?php
/**
 * Trait RegularPriceChange.
 *
 * This trait contains the core logic for calculating and applying the final
 * wholesale price to the product's price data, overriding the standard
 * WooCommerce regular price based on user role, quantity, and pricing hierarchy.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Traits;

trait RegularPriceChange {


	/**
	 * Trait containing utility methods.
	 */
	use WholesaleCartSubtotalDiscount;
	use ModifyPrice;
	use Quantity;
	use VariableWholesalePrice;

	/**
	 * Applies the wholesale price to the product's regular price property.
	 * This function implements the wholesale pricing hierarchy.
	 *
	 * Hierarchy Order (Highest Priority First):
	 * 1. Group-level Tiered Pricing
	 * 2. Product-level Tiered Pricing
	 * 3. Product-level Simple Discount
	 * 4. Category-level Tiered Pricing
	 * 5. Category-level Simple Discount
	 * 6. Global-level Tiered Pricing
	 * 7. Global-level Simple Discount
	 *
	 * @param  string|float $price   The regular price passed by WooCommerce filter.
	 * @param  \WC_Product  $product The product object (can be a variation).
	 * @return string|float The modified wholesale price, or the original price if no rule applies.
	 */
	public function wwp_regular_price_change( $price, $product ) {

		// compatible with quote for woocommerce
		if (isset($_REQUEST['wc_quote_convert_to_order_customer']) ) {
			return $price;
		}

		if (is_shop() && 'product_variation' == get_post_type($product->get_id()) ) {
			return $price;
		}

		if (defined('REST_REQUEST') && REST_REQUEST ) {
			return $price; 
		}

		if (is_cart() && ! $this->wholesale_pricing_cart_based_on_subtotal() ) {
			return $price;
		}

		// Cart line items already have wholesale applied via set_price() in
		// wwp_override_product_price_cart(). Mini-cart and other non-is_cart()
		// templates still call get_price() on that same object; skip so 25% is
		// not applied a second time (e.g. $9.00 → $6.75 with 20% tax).
		if ( $this->is_cart_line_item_product( $product ) ) {
			return $price;
		}

		$wholesale_qty = '';

		/**
		 * Filter Hook: product_transient_time_load
		 *
		 * Allows control over whether product transients should be cleared before price calculation.
		 *
		 * @since 2.5.0
		 * @param bool $transient True to clear transients, false otherwise.
		 */
		$transient = apply_filters('product_transient_time_load', true);
		if ($transient ) {
			wc_delete_product_transients($product->get_id());
		}

		$product_id        = $product->get_id();
		$qty               = (int) get_cart_qty($product_id);
		$variation_id      = $product_id;
		$this->product_obj = $product;
		$role              = get_current_user_role_id();

		/**
		 * Filter
		 * 
		 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
		 * 
		 * @since 3.1.0
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );

		if (wwp_guest_wholesale_pricing_enabled() ) {
			if (( is_shop() && ! wwp_guest_wholesale_pricing_enabled('display_on_shop') ) || ( is_product() && ! wwp_guest_wholesale_pricing_enabled('display_on_single') ) ) {
				return $price;
			}
			$role = wwp_guest_wholesale_pricing_enabled('role');
		}

		$ws_group = wwp_get_group_post_by_proid($product_id, get_current_user_id());

		if ($ws_group ) { 
			$group_id = isset($ws_group[0]) ? $ws_group[0] : '';
			if (! empty($group_id) ) {
				if (tire_variable_wholesale_product_price($variation_id, $product, 'group') ) {
					return tire_variable_wholesale_product_price($variation_id, $product, 'group');
				}
			}
		}

		$data              = get_post_meta($variation_id, 'wholesale_multi_user_pricing', true);
		if (isset($data[ $role ]) ) { 
			if (tire_variable_wholesale_product_price($variation_id, $product, 'product') ) {
				return tire_variable_wholesale_product_price($variation_id, $product, 'product');
			}
		}
		if (isset($data[ $role ]) && 'product' == get_post_type($product_id) && isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {

			$my = $data[ $role ];
			if (isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
				$wholesale_qty = $my['min_quatity'];
			}
			/**
			 * Hooks: wwp_mnm_get_price_qty
			 *
			 * Allows external plugins (like Min/Max Quantities) to override the quantity check result.
			 *
			 * @since 3.0.0
			 */
			if (apply_filters('wwp_mnm_get_price_qty', $this->quantity($qty, $wholesale_qty), $product) ) {
				/**
				 * Hooks: wwp_product_addon_get_price_qty
				 *
				 * Allows external plugins (like Product Addons) to modify the price if quantity checks pass.
				 *
				 * @since 3.0.0
				 */
				return apply_filters('wwp_product_addon_get_price_qty', $price, $product);
			} 
			
			$price = get_post_meta($product_id, $price_key, true);
			
			/**
			 * Hooks: wwp_mnm_get_price
			 *
			 * Allows external plugins (like Min/Max Quantities) to modify the price after quantity failure.
			 *
			 * @since 3.0.0
			 */
			$price = apply_filters('wwp_mnm_get_price', $price, $product);
			return $this->change_price($price, $my['discount_type'], $my['wholesale_price'], $product_id);
		
		} elseif ('product_variation' == get_post_type($product_id) ) { 
			
			$variation_id = $product_id;
			$product_id   = wp_get_post_parent_id($product_id);

			$data = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
			if (isset($data[ $role ]) ) {  
				if (isset($data[ $role ][ $variation_id ]['wholesaleprice']) && !empty($data[ $role ][ $variation_id ]['wholesaleprice']) ) { 
					$my = $data[ $role ][ $variation_id ]; 
					if (isset($my['qty']) && ! empty($my['qty']) ) {
						$wholesale_qty = $my['qty'];
					}
					
					if ($this->quantity($qty, $wholesale_qty) ) {
					
						 /**
						 * Hooks: wwp_product_addon_get_price_qty
						 *
						 * Allows external plugins (like Product Addons) to modify the price.
						 *
						 * @since 3.0.0
						 */
						return apply_filters('wwp_product_addon_get_price_qty', $price, $product);
					}
					
					$price = $this->get_variable_wholesale_price($data[ $role ][ $variation_id ], $variation_id);
					
					return $price;
				} else {
					return $price;
				} 
			} else {
				$wc_get_product               = wc_get_product($variation_id);
				$wwp_variation_explode_eneble = get_post_meta($wc_get_product->get_parent_id(), 'wwp_variation_explode_eneble', true);
				if ('yes' == $wwp_variation_explode_eneble ) {
					$price = wwp_get_price_including_tax($wc_get_product, array( 'price' => $price ));
				}
			}
		}

		if ('product_variation' == get_post_type($product_id) ) {  
			$variation_id = $product_id;
			$product_id   = wp_get_post_parent_id($product_id);
		}
		
		if (tire_variable_wholesale_product_price($product_id, $product, 'category') ) {
			return tire_variable_wholesale_product_price($product_id, $product, 'category');
		}
		
		$terms = get_the_terms($product_id, 'product_cat');
		if (! is_wp_error($terms) && ! empty($terms) ) {
			foreach ( $terms as $term ) {
				$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
				if (isset($data[ $role ]) && isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
					$my = $data[ $role ];
					if (isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
						$wholesale_qty = $my['min_quatity'];
					}

					if ($this->quantity($qty, $wholesale_qty) ) {
					
						/**
						 * Hooks: wwp_product_addon_get_price_qty
						 *
						 * Allows external plugins (like Product Addons) to modify the price.
						 *
						 * @since 3.0.0
						 */
						return apply_filters('wwp_product_addon_get_price_qty', $price, $product);
					}
					if (empty(get_post_meta($variation_id, $price_key, true)) ) {
						return $price;
					}
					$price = get_post_meta($variation_id, $price_key, true);
					
					return $this->change_price($price, $my['discount_type'], $my['wholesale_price'], $variation_id);
				}
			}
		}

		$data = self::get_multiuser_pricing_settings();
		
		if (isset($data[ $role ]) ) {  

			if ( is_product_category_excluded_global($product_id) ) {
				return $price;
			}

			if (tire_variable_wholesale_product_price($product_id, $product, 'global') ) {
				return tire_variable_wholesale_product_price($product_id, $product, 'global');
			}
		}
		
		if (isset($data[ $role ]) && isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
			$my = $data[ $role ];
			$product_id = $product->get_id();

			if (is_product_category_excluded_global($product_id) ) {
				return $price;
			}
			if (isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
				$wholesale_qty = (int) $my['min_quatity'];
			}

			if ($this->quantity($qty, $wholesale_qty) ) {
				/**
				 * Hooks: wwp_product_addon_get_price_qty
				 *
				 * Allows external plugins (like Product Addons) to modify the price.
				 *
				 * @since 3.0.0
				 */
				return apply_filters('wwp_product_addon_get_price_qty', $price, $product);
			}

			if (empty(get_post_meta($variation_id, $price_key, true)) ) {
				return $price;
			}

			if (empty($price) ) {
				$price = get_post_meta($variation_id, $price_key, true);
			}
			return $this->change_price($price, $data[ $role ]['discount_type'], $data[ $role ]['wholesale_price'], $variation_id);
		}
		return $price;
	}

	/**
	 * Whether $product is the live cart line-item object (already wholesale-priced).
	 *
	 * Mini-cart, AJAX fragments, and theme drawers call get_price() on $cart_item['data']
	 * outside is_cart(). Product/shop pages use a different WC_Product instance, so they
	 * still receive wholesale via this filter.
	 *
	 * @param \WC_Product $product Product being priced.
	 * @return bool
	 */
	protected function is_cart_line_item_product( $product ) {
		if ( ! is_object( $product ) || ! function_exists( 'WC' ) || ! WC()->cart ) {
			return false;
		}

		foreach ( WC()->cart->get_cart_contents() as $cart_item ) {
			if ( isset( $cart_item['data'] ) && $cart_item['data'] === $product ) {
				return true;
			}
		}

		return false;
	}
}
