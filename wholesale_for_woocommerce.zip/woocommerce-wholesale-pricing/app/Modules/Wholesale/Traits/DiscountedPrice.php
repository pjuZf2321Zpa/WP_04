<?php
/**
 * Trait DiscountedPrice.
 *
 * Provides a helper method to calculate the discounted wholesale price based on
 * general pricing rules (fixed amount or percentage discount).
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Traits;

trait DiscountedPrice {


	/**
	 * Calculates the wholesale price based on discount type (fixed or percentage).
	 *
	 * This function is used to determine the final discounted price when general
	 * pricing rules (non-tiered) are applied at the product, category, or global level.
	 * Note: When 'percent' is used, this function returns the *discount amount*, not the final price.
	 *
	 * @param  string $discount The type of discount: 'fixed' or 'percent'.
	 * @param  float  $wprice   The wholesale value (fixed amount or percentage value).
	 * @param  int    $post_id  The product ID.
	 * @return float The calculated price. If 'fixed', this is the final price. If 'percent', this is the discount amount.
	 */
	public function get_wholesale_price_multi( $discount, $wprice, $post_id ) {

		/**
		 * Filter
		 * 
		 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
		 * 
		 * @since 3.1.0
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );

		if (empty($wprice)) {
			return get_post_meta($post_id, $price_key, true);
		}

		if ('fixed' == $discount ) {
			return $wprice;
		} else {
			$product = wc_get_product( $post_id );
			$product_price = get_post_meta( $post_id, $price_key, true );

			if ( 'bundle' === $product->get_type() && empty( $product_price ) ) {
				$product_price = get_post_meta( $post_id, '_price', true );
			}
			/**
			 * Filter: wwp_check_product_price
			 *
			 * Allows modification of the base product price before the wholesale discount is calculated.
			 *
			 * @since 2.5.0
			 * @param float $product_price The determined base price.
			 * @param \WC_Product $product The product object.
			 * @param int $post_id The product ID.
			 */
			$product_price = apply_filters('wwp_check_product_price', $product_price, $product, $post_id);
			$product_price   = ( isset($product_price) && is_numeric($product_price) ) ? $product_price : 0;
			$wholesale_price = $product_price * $wprice / 100;
			return $wholesale_price;
		}
	}
}
