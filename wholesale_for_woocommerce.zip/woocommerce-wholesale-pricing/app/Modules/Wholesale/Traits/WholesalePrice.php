<?php
/**
 * Trait WholesalePrice.
 *
 * Provides core logic for determining the applicable wholesale price for a WooCommerce product
 * (simple product or variation) based on the current user's role and the product's quantity
 * currently in the cart.
 *
 * It implements a hierarchical pricing lookup: Product > Category > Global.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Traits;

trait WholesalePrice {


	/**
	 * Trait containing utility methods
	 */
	use VariableWholesalePrice;
	use ModifyPrice;
	use DiscountedPrice;

	/**
	 * Determines the correct wholesale price for a given product or variation based on
	 * a hierarchical set of rules (Product > Category > Global) and the quantity
	 * currently in the user's cart.
	 *
	 * The hierarchy of price lookup is:
	 * 1. Product/Variation Level (Variable/Fixed Price + Min Qty check)
	 * 2. Category Level (Variable/Fixed Price + Min Qty check)
	 * 3. Global Level (Variable/Fixed Price + Min Qty check)
	 * 4. Fallback to Regular Price
	 *
	 * @param  \WC_Product|\WC_Product_Variation $product The WooCommerce product object (simple or variation).
	 * @return float|string The calculated wholesale price (a price value), the regular price if
	 * wholesale conditions are not met, or 0 on final failure.
	 */
	public function wwp_get_wholesale_price( $product ) {
		$cart_item_quantities = WC()->cart->get_cart_item_quantities();
		$role  = get_current_user_role_id();
		$variation_id = $product->get_id();
		$wholesale_qty = 1;

		/**
		 * Filter
		 * 
		 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
		 * 
		 * @since 3.1.0
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );

		if ($product->is_type('variation') ) {
			$data = get_post_meta($product->get_id(), 'wholesale_multi_user_pricing', true);
			if (isset($data[ $role ]) ) { 
			
				if (tire_variable_wholesale_product_price($variation_id, wc_get_product($variation_id), 'product') ) {
					return tire_variable_wholesale_product_price($variation_id, wc_get_product($variation_id), 'product');
				}
				
				if (isset($data[ $role ][ $variation_id ]) ) {
				
					$min_quantity = $data[ $role ][ $variation_id ]['qty'];
					if (empty($min_quantity) || ! isset($min_quantity) ) { // IF MIN QUANTITY NOT SET OR DOESN't EXIST ON DB
						$min_quantity = 1;
					}

					if ($min_quantity <= $cart_item_quantities[$variation_id] ) {
						if (! empty($this->get_variable_wholesale_price($data[ $role ][ $variation_id ], $variation_id)) ) {
							return $this->get_variable_wholesale_price($data[ $role ][ $variation_id ], $variation_id);
						} else {
							return get_post_meta($variation_id, $price_key, true);
						}
					} else {
						return get_post_meta($variation_id, $price_key, true);
					}
				} else {
					return get_post_meta($variation_id, $price_key, true);
				}
			}
			$terms = get_the_terms($product->get_parent_id(), 'product_cat');
			if (! is_wp_error($terms) && ! empty($terms) ) {
				foreach ( $terms as $term ) {
					$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
					if (isset($data[ $role ]) ) {
						if (tire_variable_wholesale_product_price($variation_id, wc_get_product($variation_id), 'category') ) {
							return tire_variable_wholesale_product_price($variation_id, wc_get_product($variation_id), 'category');
						}
					
					}
					
					if (isset($data[ $role ]) ) {

						if (isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
						
							$my = $data[ $role ];
							if (isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
								$wholesale_qty = (int) $my['min_quatity'];
							}
							if ($wholesale_qty <= $cart_item_quantities[$variation_id] ) {
								return $this->change_price(get_post_meta($variation_id, $price_key, true), $my['discount_type'], $my['wholesale_price']);
							} else {
								return get_post_meta($variation_id, $price_key, true);
							}
						}   
					}   
				}
			}
			
			$data = get_option('wholesale_multi_user_pricing');
			if (isset($data[ $role ]) ) {
				if (tire_variable_wholesale_product_price($variation_id, wc_get_product($variation_id), 'global') ) { 
					return tire_variable_wholesale_product_price($variation_id, wc_get_product($variation_id), 'global');
				}
			}
			
			if (isset($data[ $role ]) ) {
			
				if (isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
					$my = $data[ $role ];
					if (isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
						$wholesale_qty = $my['min_quatity'];
					}
					if ($wholesale_qty <= $cart_item_quantities[$variation_id] ) {
						return $this->change_price(get_post_meta($variation_id, $price_key, true), $my['discount_type'], $my['wholesale_price']);
					} else {
						return get_post_meta($variation_id, $price_key, true);
					}
				} else {
					return get_post_meta($variation_id, $price_key, true);
				}

			}
		} else {
			$data = get_post_meta($product->get_id(), 'wholesale_multi_user_pricing', true);
			if (isset($data[ $role ]) ) {
				if (tire_variable_wholesale_product_price($product->get_id(), wc_get_product($product->get_id()), 'product') ) {
					return tire_variable_wholesale_product_price($product->get_id(), wc_get_product($product->get_id()), 'product');
				}
			
				$my = $data[ $role ];
				if (isset($my['discount_type']) && ! empty($my['discount_type']) && isset($my['wholesale_price']) && ! empty($my['wholesale_price']) && isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
					
					if (isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
						$wholesale_qty = (int) $my['min_quatity'];
					}

					return $this->get_wholesale_price_multi($my['discount_type'], $my['wholesale_price'], $product->get_id());
				} else {
					return get_post_meta($product->get_id(), $price_key, true);
				}
			}

			$terms = get_the_terms($product->get_id(), 'product_cat');
			if (! is_wp_error($terms) && ! empty($terms) ) {

				foreach ( $terms as $term ) {
					$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);

					if (isset($data[ $role ]) ) {
					
						if (tire_variable_wholesale_product_price($product->get_id(), wc_get_product($product->get_id()), 'category') ) {
							return tire_variable_wholesale_product_price($product->get_id(), wc_get_product($product->get_id()), 'category');
						}
					}

					if (isset($data[ $role ]) ) {

						if (isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
							$my = $data[ $role ];
							if (isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
								$wholesale_qty = (int) $my['min_quatity'];
							}
							return $this->change_price(get_post_meta($product->get_id(), $price_key, true), $my['discount_type'], $my['wholesale_price']);
						} else {
							return get_post_meta($product->get_id(), $price_key, true);
						}
						
					}
				}
			}
			
			$data = get_option('wholesale_multi_user_pricing');
			
			if (isset($data[ $role ]) ) {
			
				if (tire_variable_wholesale_product_price($product->get_id(), wc_get_product($product->get_id()), 'global') ) { 
					return tire_variable_wholesale_product_price($product->get_id(), wc_get_product($product->get_id()), 'global');
				}
			}

			if (isset($data[ $role ]) ) {
			
				if (isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
					
					$my = $data[ $role ];
					if (isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
						$wholesale_qty = $my['min_quatity'];
					}
					return $this->change_price(get_post_meta($product->get_id(), $price_key, true), $my['discount_type'], $my['wholesale_price']);
				} else {
					return get_post_meta($product->get_id(), $price_key, true);
				}
			}
		}
		return 0;
	}
}
