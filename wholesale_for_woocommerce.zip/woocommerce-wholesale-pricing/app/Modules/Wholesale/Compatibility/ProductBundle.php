<?php
/**
 * Compatibility Class for WooCommerce Product Bundles.
 *
 * This class applies wholesale pricing rules to WooCommerce Product Bundles,
 * specifically targeting the display of prices for bundled items and the
 * main bundle price itself.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Compatibility
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Compatibility;

use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\ProductPriceHTML;
use WooCommerceWholesalePricing\App\Strategies\Hookable;

/**
 * ProductBundle Class.
 *
 * Implements compatibility fixes and logic for WooCommerce Product Bundles.
 */
class ProductBundle implements Hookable {

	/**
	 * Trait used for changing product price HTML display logic.
	 */
	use ProductPriceHTML;

	/**
	 * Register the necessary WordPress hooks/filters.
	 *
	 * @return void
	 */
	public function hooks() {
		add_filter('woocommerce_bundled_item_price_html', array( $this, 'wwp_change_product_price_display' ), 200, 2);
		add_action('woocommerce_after_bundle_price', array( $this, 'woocommerce_after_bundle_price' ));
	}

	/**
	 * Hides the default WooCommerce Product Bundle price display using CSS.
	 *
	 * This is typically done to prevent display conflicts or to ensure only the
	 * custom wholesale price HTML (handled by the 'wwp_change_product_price_display' filter)
	 * is visible.
	 *
	 * @return void
	 */
	public function woocommerce_after_bundle_price() {
		?>
		<style>
			.bundle_form .bundle_price {
				display: none!important;
			}
		</style>
		<?php
	}
}
