<?php
/**
 * PaymentGatewayService class to manage payment gateway availability for wholesale users.
 *
 * This service class is responsible for filtering the available payment gateways during
 * checkout based on the restrictions defined for the current wholesale user's role or group.
 *
 * @package    WooCommerceWholesalePricing\App\Modules\Wholesale
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

/**
 * Class PaymentGatewayService
 *
 * Filters the available WooCommerce payment gateways based on the current
 * wholesale user's role or group-specific restrictions.
 */
class PaymentGatewayService {

	/**
	 * Includes methods for retrieving general wholesale settings.
	 */
	use WholesaleSettings;

	/**
	 * PaymentGatewayService constructor.
	 *
	 * Hooks into the WooCommerce payment gateway filter to apply restrictions.
	 */
	public function __construct() {
		add_filter( 'woocommerce_available_payment_gateways', array( $this, 'wwp_available_payment_gateways' ), 200, 1 );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'validate_classic_checkout' ), 10, 2 );
		add_action( 'woocommerce_store_api_checkout_update_order_from_request', array( $this, 'validate_block_checkout' ), 10, 2 );
	}

	/**
	 * Filters the list of available payment gateways based on wholesale user restrictions.
	 *
	 * Restrictions are applied based on:
	 * 1. The user's assigned wholesale group (via post meta).
	 * 2. The user's primary wholesale role (via term meta), including optional location/total conditions.
	 * 3. Store Access ID if 'restrict_store_access' is enabled.
	 *
	 * @hook woocommerce_available_payment_gateways
	 *
	 * @param  array $available_gateways Array of available WC_Payment_Gateway objects.
	 * @return array The filtered array of available WC_Payment_Gateway objects.
	 */
	public function wwp_available_payment_gateways( $available_gateways ) {
		if ( ! $this->should_filter_gateways() ) {
			return $available_gateways;
		}

		$term               = $this->get_wholesale_role_term();
		$restricted_gateway = $this->get_group_restricted_gateways();

		if ( ! empty( $restricted_gateway ) ) {
			$restrict_gateway = array_unique( $restricted_gateway );
			foreach ( $restrict_gateway as $value ) {
				unset( $available_gateways[ $value ] );
			}
		}

		if ( ! empty( $term ) && ! is_wp_error( $term ) && $this->role_payment_conditions_match( $term->term_id ) ) {
			$restricted = get_term_meta( $term->term_id, 'wwp_restricted_pmethods_wholesaler', true );

			if ( ! empty( $restricted ) && ! empty( $available_gateways ) ) {
				foreach ( (array) $restricted as $restrict ) {
					unset( $available_gateways[ $restrict ] );
				}
			}
		}

		return $available_gateways;
	}

	/**
	 * Reject classic checkout if a restricted payment method is submitted.
	 *
	 * @param array    $data   Posted checkout data.
	 * @param \WP_Error $errors Validation errors.
	 * @return void
	 */
	public function validate_classic_checkout( $data, $errors ) {
		$method = isset( $data['payment_method'] ) ? (string) $data['payment_method'] : '';
		if ( $this->is_payment_method_restricted( $method ) ) {
			$errors->add(
				'wwp_payment_method_unavailable',
				$this->get_restricted_payment_error_message()
			);
		}
	}

	/**
	 * Reject block/Store API checkout if a restricted payment method is submitted.
	 *
	 * @param \WC_Order        $order   Order being updated.
	 * @param \WP_REST_Request $request Request object.
	 * @return void
	 */
	public function validate_block_checkout( $order, $request ) {
		unset( $request );
		$method = $order instanceof \WC_Order ? (string) $order->get_payment_method() : '';
		if ( ! $this->is_payment_method_restricted( $method ) ) {
			return;
		}

		$message = $this->get_restricted_payment_error_message();
		if ( class_exists( '\Automattic\WooCommerce\StoreApi\Exceptions\RouteException' ) ) {
			throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException(
				'woocommerce_rest_payment_method_unavailable',
				esc_html( $message ),
				400
			);
		}

		throw new \WC_REST_Exception( 'woocommerce_rest_payment_method_unavailable', esc_html( $message ), 400 );
	}

	/**
	 * Whether a submitted payment method is currently restricted for the shopper.
	 *
	 * @param string $method Gateway ID.
	 * @return bool
	 */
	private function is_payment_method_restricted( $method ) {
		$method = (string) $method;
		if ( '' === $method ) {
			return false;
		}

		$term = $this->get_wholesale_role_term();
		if ( empty( $term ) || is_wp_error( $term ) || ! $this->role_payment_conditions_match( $term->term_id ) ) {
			return false;
		}

		$restricted = get_term_meta( $term->term_id, 'wwp_restricted_pmethods_wholesaler', true );
		if ( empty( $restricted ) || ! is_array( $restricted ) ) {
			return false;
		}

		return in_array( $method, array_map( 'strval', $restricted ), true );
	}

	/**
	 * Whether role payment restrictions apply for this request.
	 *
	 * Conditions off: always restrict. Conditions on: restrict only when address/total match.
	 *
	 * @param int $term_id Role term ID.
	 * @return bool
	 */
	private function role_payment_conditions_match( $term_id ) {
		$term_id = absint( $term_id );
		if ( ! $term_id ) {
			return false;
		}

		$enabled = get_term_meta( $term_id, 'wwp_conditions_enabled', true );
		if ( 'yes' !== $enabled ) {
			return true;
		}
		
		return $this->customer_matches_location( $term_id ) && $this->cart_matches_order_total( $term_id );
	}

	/**
	 * Whether the customer address matches role location conditions.
	 *
	 * @param int $term_id Role term ID.
	 * @return bool
	 */
	private function customer_matches_location( $term_id ) {
		if ( ! function_exists( 'WC' ) || ! WC()->customer ) {
			return false;
		}

		$location = (string) get_term_meta( $term_id, 'wwp_condition_location', true );
		if ( 'billing' !== $location ) {
			$location = 'shipping';
		}

		$customer = WC()->customer;
		$country  = 'billing' === $location ? (string) $customer->get_billing_country() : (string) $customer->get_shipping_country();
		$state    = 'billing' === $location ? (string) $customer->get_billing_state() : (string) $customer->get_shipping_state();

		if ( '' === $country ) {
			return false;
		}

		$countries = $this->normalize_meta_list( get_term_meta( $term_id, 'wwp_condition_countries', true ) );
		$states    = $this->normalize_meta_list( get_term_meta( $term_id, 'wwp_condition_states', true ) );
		
		if ( empty( $countries ) && empty( $states ) ) {
			return true;
		}

		$country_code = strtoupper( $country );
		$state_key    = $country_code . ':' . strtoupper( $state );

		if ( ! empty( $states ) ) {
			if ( in_array( $state_key, $states, true ) ) {
				return true;
			}

			$countries_with_states = array();
			foreach ( $states as $pair ) {
				$parts = explode( ':', $pair, 2 );
				if ( ! empty( $parts[0] ) ) {
					$countries_with_states[ strtoupper( $parts[0] ) ] = true;
				}
			}

			return ! empty( $countries )
				&& in_array( $country_code, $countries, true )
				&& empty( $countries_with_states[ $country_code ] );
		}

		return empty( $countries ) || in_array( $country_code, $countries, true );
	}

	/**
	 * Whether the cart total is within the role min/max.
	 *
	 * @param int $term_id Role term ID.
	 * @return bool
	 */
	private function cart_matches_order_total( $term_id ) {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return false;
		}

		$min = get_term_meta( $term_id, 'wwp_condition_min_order', true );
		$max = get_term_meta( $term_id, 'wwp_condition_max_order', true );
		$min = ( '' === $min || null === $min ) ? null : (float) $min;
		$max = ( '' === $max || null === $max ) ? null : (float) $max;

		if ( null === $min && null === $max ) {
			return true;
		}

		$total = (float) WC()->cart->get_total( 'edit' );

		if ( null !== $min && $total < $min ) {
			return false;
		}

		if ( null !== $max && $total > $max ) {
			return false;
		}

		return true;
	}

	/**
	 * Resolve the wholesale role term for the current shopper.
	 *
	 * @return \WP_Term|string|false
	 */
	private function get_wholesale_role_term() {
		$settings = self::get_pricing_settings();

		if ( isset( $settings['restrict_store_access'] ) && 'yes' === $settings['restrict_store_access'] ) {
			if ( isset( $_COOKIE['access_store_id'] ) && ! empty( $_COOKIE['access_store_id'] ) ) {
				return get_term_by( 'id', sanitize_text_field( wp_unslash( $_COOKIE['access_store_id'] ) ), 'wholesale_user_roles' );
			}
			return '';
		}

		$user_info = get_userdata( get_current_user_id() );
		if ( ! $user_info ) {
			return '';
		}

		$user_roles = (array) $user_info->roles;
		if ( empty( $user_roles ) ) {
			return '';
		}

		return get_term_by( 'slug', $user_roles[0], 'wholesale_user_roles' );
	}

	/**
	 * Restricted gateways from wholesale groups (unconditional).
	 *
	 * @return array
	 */
	private function get_group_restricted_gateways() {
		$settings = self::get_pricing_settings();
		if ( isset( $settings['restrict_store_access'] ) && 'yes' === $settings['restrict_store_access'] ) {
			return array();
		}

		$restricted_gateway = array();
		$ws_group           = function_exists( 'wwp_get_group_post_by_proid' ) ? wwp_get_group_post_by_proid( 0, get_current_user_id() ) : array();
		if ( empty( $ws_group ) ) {
			return array();
		}

		foreach ( $ws_group as $group_id ) {
			$restricted_gateway = get_post_meta( $group_id, '_disable_payment_methods', true );
		}

		return is_array( $restricted_gateway ) ? $restricted_gateway : array();
	}

	/**
	 * Whether gateway filtering should run for this request.
	 *
	 * @return bool
	 */
	private function should_filter_gateways() {
		if ( ! is_admin() ) {
			return true;
		}

		if ( wp_doing_ajax() ) {
			return true;
		}

		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return true;
		}

		return function_exists( 'WC' ) && WC() && is_callable( array( WC(), 'is_rest_api_request' ) ) && WC()->is_rest_api_request();
	}

	/**
	 * Normalize stored country/state lists.
	 *
	 * @param mixed $value Raw meta.
	 * @return string[]
	 */
	private function normalize_meta_list( $value ) {
		if ( empty( $value ) ) {
			return array();
		}
		if ( ! is_array( $value ) ) {
			$value = array( $value );
		}

		return array_values( array_filter( array_map( 'strval', $value ) ) );
	}

	/**
	 * Checkout error when a restricted payment method is used.
	 *
	 * @return string
	 */
	private function get_restricted_payment_error_message() {
		return __( 'This payment method is not available for your address or order total.', 'woocommerce-wholesale-pricing' );
	}
}
