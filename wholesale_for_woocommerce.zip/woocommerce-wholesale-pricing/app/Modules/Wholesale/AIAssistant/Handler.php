<?php
/**
 * AI Assistant module bootstrap.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities\AbilityRegistry;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\ChatSessionStore;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\FloatingAiAssistantLoader;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\SettingsService;

/**
 * Boots the AI Assistant wholesale module.
 */
class Handler {

	/**
	 * Constructor.
	 */
	public function __construct() {
		if ( ! SettingsService::is_enabled() ) {
			return;
		}

		new FloatingAiAssistantLoader();
		new AbilityRegistry();

		add_action( 'init', array( $this, 'register_chat_cleanup_cron' ) );
		add_action( 'wwp_ai_chat_sessions_cleanup', array( $this, 'cleanup_chat_sessions' ) );
	}

	/**
	 * Register daily cleanup for expired chat session files.
	 *
	 * @return void
	 */
	public function register_chat_cleanup_cron() {
		if ( ! wp_next_scheduled( 'wwp_ai_chat_sessions_cleanup' ) ) {
			wp_schedule_event( time(), 'daily', 'wwp_ai_chat_sessions_cleanup' );
		}
	}

	/**
	 * Delete expired encrypted chat session files.
	 *
	 * @return void
	 */
	public function cleanup_chat_sessions() {
		( new ChatSessionStore() )->cleanup_expired();
	}
}
