<?php
/**
 * Maps AI assistant abilities to underlying WordPress data surfaces.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleOption;

/**
 * Single source of truth for ability → post types, taxonomies, options, and fields.
 */
class AbilityDataCatalog {

	/**
	 * Ability metadata keyed by settings key.
	 *
	 * @var array<string, array<string, mixed>>
	 */
	const CATALOG = array(
		'dashboard'                       => array(
			'tool'        => 'dashboard',
			'actions'     => array( 'get' ),
			'post_types'  => array( 'shop_order', 'wwp_requests', 'product' ),
			'taxonomies'  => array( 'product_cat', 'wholesale_user_roles' ),
			'option_keys' => array(),
			'fields'      => array( 'date_from', 'date_to', 'metrics', 'top_products', 'top_customers' ),
		),
		'wholesale_settings'              => array(
			'tool'        => 'wholesale_settings',
			'actions'     => array( 'get', 'update' ),
			'post_types'  => array(),
			'taxonomies'  => array( 'wholesale_user_roles' ),
			'option_keys' => array( WholesaleOption::PRICING_OPTION ),
			'fields'      => array( 'disable_auto_role', 'enable_registration_page', 'requisition_list', 'request_again_submit', 'wholesaler_allow_minimum_qty', 'wwp_hide_price', 'wwp_hide_add_to_cart', 'enable_coupon', 'wholesale_role' ),
		),
		'global_discounts'                => array(
			'tool'        => 'global_discounts',
			'actions'     => array( 'get', 'update' ),
			'post_types'  => array(),
			'taxonomies'  => array( 'wholesale_user_roles', 'product_cat' ),
			'option_keys' => array( WholesaleOption::MULTIUSER_PRICING_OPTION, WholesaleOption::PRICING_OPTION ),
			'fields'      => array( 'role_discounts', 'tier_pricing', 'role_slug', 'discount_type', 'wholesale_price', 'min_quantity', 'min_subtotal' ),
		),
		'cart_discounts'                  => array(
			'tool'        => 'cart_discounts',
			'actions'     => array( 'get', 'update' ),
			'post_types'  => array(),
			'taxonomies'  => array( 'wholesale_user_roles' ),
			'option_keys' => array( WholesaleOption::MULTIUSER_CART_DISCOUNT_OPTION, WholesaleOption::CART_TIER_PRICING_OPTION ),
			'fields'      => array( 'role_discounts', 'tier_pricing', 'discount', 'enabled' ),
		),
		'b2b_user_roles'                  => array(
			'tool'        => 'b2b_user_roles',
			'actions'     => array( 'list', 'get', 'create', 'update', 'delete' ),
			'post_types'  => array(),
			'taxonomies'  => array( 'wholesale_user_roles' ),
			'option_keys' => array(),
			'fields'      => array( 'identifier', 'role.name', 'role.slug', 'role.tax_exempt', 'role.disable_coupons', 'role.restricted_payment_methods', 'role.restricted_shipping_methods', 'role.password' ),
		),
		'wholesale_email_notifications'   => array(
			'tool'        => 'wholesale_email_notifications',
			'actions'     => array( 'list', 'get', 'update' ),
			'post_types'  => array(),
			'taxonomies'  => array(),
			'option_keys' => array(
				'wwp_wholesale_admin_request_notification',
				'wwp_wholesale_user_registration_notification',
				'wwp_wholesale_user_rejection_notification',
				'wwp_wholesale_request_approve_notification',
				'wwp_wholesale_subscription_role_notification',
			),
			'fields'      => array( 'notification_key', 'enabled', 'subject', 'body', 'recipient' ),
		),
		'wholesale_registration'          => array(
			'tool'        => 'wholesale_registration',
			'actions'     => array( 'get', 'update' ),
			'post_types'  => array(),
			'taxonomies'  => array(),
			'option_keys' => array( WholesaleOption::REGISTRATION_OPTION ),
			'fields'      => array( 'enable_billing_*', 'enable_shipping_*', 'enable_tex_id', 'required_tex_id', 'enable_file_upload', 'required_file_upload', 'required_*', 'enable_recaptcha', 'recaptcha_version', 'recaptcha_v2_site_key', 'recaptcha_v3_score' ),
		),
		'woocommerce_products'            => array(
			'tool'        => 'woocommerce_products',
			'actions'     => array( 'list', 'get', 'create', 'update', 'delete' ),
			'post_types'  => array( 'product', 'product_variation' ),
			'taxonomies'  => array( 'product_cat', 'product_tag', 'wholesale_user_roles' ),
			'option_keys' => array(),
			'fields'      => array( 'identifier', 'name', 'sku', 'regular_price', 'wholesale_multi_user_pricing', 'product_tier_pricing', 'step_quantity' ),
		),
		'woocommerce_categories'        => array(
			'tool'        => 'woocommerce_categories',
			'actions'     => array( 'list', 'get', 'create', 'update', 'delete' ),
			'post_types'  => array(),
			'taxonomies'  => array( 'product_cat', 'wholesale_user_roles' ),
			'option_keys' => array(),
			'fields'      => array( 'identifier', 'name', 'slug', 'parent', 'wholesale_multi_user_pricing', 'category_tier_pricing', 'wholesale_product_visibility_multi' ),
		),
		'wholesale_account_requests'      => array(
			'tool'        => 'wholesale_account_requests',
			'actions'     => array( 'list', 'get', 'update', 'delete' ),
			'post_types'  => array( 'wwp_requests' ),
			'taxonomies'  => array( 'wholesale_user_roles' ),
			'option_keys' => array(),
			'fields'      => array( 'identifier', 'status', 'user_role_set', 'rejected_note', '_user_status' ),
		),
		'b2b_user_profiles'               => array(
			'tool'        => 'b2b_user_profiles',
			'actions'     => array( 'list', 'get', 'create', 'update', 'delete' ),
			'post_types'  => array(),
			'taxonomies'  => array( 'wholesale_user_roles' ),
			'option_keys' => array(),
			'fields'      => array( 'identifier', 'user_email', 'role', 'billing_*', 'shipping_*', 'first_name', 'last_name' ),
		),
		'quote_settings'                  => array(
			'tool'        => 'quote_settings',
			'actions'     => array( 'get', 'update' ),
			'post_types'  => array(),
			'taxonomies'  => array(),
			'option_keys' => array(
				WholesaleOption::PRICING_OPTION,
				WholesaleOption::QUOTE_GENERAL_OPTION,
				WholesaleOption::QUOTE_NOTIFICATIONS_OPTION,
				WholesaleOption::QUOTE_PDF_OPTION,
			),
			'fields'      => array(
				'enable_quote',
				'quote_page',
				'enable_build_quote',
				'quote_expire',
				'enable_pdf',
				'enable_pdf_download',
				'enable_pdf_attach',
				'hide_product_list',
				'pdf_show_link',
				'pdf_logo_id',
				'quote_pdf',
				'custom',
			),
		),
		'quote_rules'                     => array(
			'tool'        => 'quote_rules',
			'actions'     => array( 'list', 'get', 'create', 'update', 'delete' ),
			'post_types'  => array( 'wc-quote-rules', 'product', 'wc-quote-status' ),
			'taxonomies'  => array( 'product_cat', 'product_tag', 'wholesale_user_roles' ),
			'option_keys' => array(),
			'fields'      => array( 'identifier', 'enable_rule', 'wc_quote_rules', 'priority', 'user_scope', 'product_inclusions', 'product_exclusions' ),
		),
		'modify_update_quotes'            => array(
			'tool'        => 'modify_update_quotes',
			'actions'     => array( 'list', 'get', 'update' ),
			'post_types'  => array( 'wc-quote', 'product', 'product_variation' ),
			'taxonomies'  => array(),
			'option_keys' => array(),
			'fields'      => array( 'identifier', 'status', 'quote_contents', 'quote_fields', 'quote_content_shipping', 'wc_quote_expire_date', 'post_author' ),
		),
	);

	/**
	 * Compact hint lines for system prompt injection.
	 *
	 * @param list<string> $ability_keys Ability settings keys.
	 * @return list<string>
	 */
	public static function get_hint_lines( array $ability_keys ) {
		$lines = array();

		foreach ( $ability_keys as $key ) {
			$entry =( isset( self::CATALOG[ $key ] ) ? self::CATALOG[ $key ] : null );

			if ( null === $entry ) {
				continue;
			}

			$parts = array(
				$key,
				'tool=' . (string) $entry['tool'],
				'actions=' . implode( '/', (array) $entry['actions'] ),
			);

			$post_types = (array) ( ( isset( $entry['post_types'] ) ? $entry['post_types'] : array() ) );
			if ( ! empty( $post_types ) ) {
				$parts[] = 'post_types=' . implode( ',', $post_types );
			}

			$taxonomies = (array) ( ( isset( $entry['taxonomies'] ) ? $entry['taxonomies'] : array() ) );
			if ( ! empty( $taxonomies ) ) {
				$parts[] = 'taxonomies=' . implode( ',', $taxonomies );
			}

			$option_keys = (array) ( ( isset( $entry['option_keys'] ) ? $entry['option_keys'] : array() ) );
			if ( ! empty( $option_keys ) ) {
				$parts[] = 'options=' . implode( ',', $option_keys );
			}

			$fields = (array) ( ( isset( $entry['fields'] ) ? $entry['fields'] : array() ) );
			if ( ! empty( $fields ) ) {
				$parts[] = 'fields=' . implode( ',', array_slice( $fields, 0, 8 ) );
			}

			$lines[] = implode( '; ', $parts );
		}

		return $lines;
	}

	/**
	 * Catalog entry for an ability key.
	 *
	 * @param string $ability_key Ability settings key.
	 * @return array<string, mixed>|null
	 */
	public static function get_entry( $ability_key ) {
return ( isset( self::CATALOG[ $ability_key ] ) ? self::CATALOG[ $ability_key ] : null );
	}

	/**
	 * Extra intent-matcher keywords derived from post types, taxonomies, options, and fields.
	 *
	 * @param string $ability_key Ability settings key.
	 * @return list<string>
	 */
	public static function get_extra_keywords( $ability_key ) {
		$entry = self::get_entry( $ability_key );

		if ( null === $entry ) {
			return array();
		}

		$keywords = array();

		foreach ( (array) ( ( isset( $entry['post_types'] ) ? $entry['post_types'] : array() ) ) as $post_type ) {
			$post_type = (string) $post_type;
			$keywords[] = $post_type;
			$keywords[] = str_replace( '_', ' ', $post_type );
		}

		foreach ( (array) ( ( isset( $entry['taxonomies'] ) ? $entry['taxonomies'] : array() ) ) as $taxonomy ) {
			$taxonomy = (string) $taxonomy;
			$keywords[] = $taxonomy;
			$keywords[] = str_replace( '_', ' ', $taxonomy );
		}

		foreach ( (array) ( ( isset( $entry['option_keys'] ) ? $entry['option_keys'] : array() ) ) as $option_key ) {
			$option_key = (string) $option_key;
			$keywords[] = $option_key;
			$keywords[] = str_replace( '_', ' ', $option_key );
		}

		foreach ( (array) ( ( isset( $entry['fields'] ) ? $entry['fields'] : array() ) ) as $field ) {
			$field = (string) $field;
			$keywords[] = $field;
			$keywords[] = str_replace( '_', ' ', $field );
			$keywords[] = str_replace( array( '_', '.' ), ' ', $field );
		}

		$tool = (string) ( ( isset( $entry['tool'] ) ? $entry['tool'] : $ability_key ) );
		$keywords[] = $tool;
		$keywords[] = str_replace( '_', ' ', $tool );

		$keywords = array_merge( $keywords, AdminSettingsRegistry::get_matcher_keywords( $ability_key ) );

		return array_values(
			array_unique(
				array_filter(
					array_map(
						static function ( $phrase ) {
							return strtolower( trim( $phrase ) );
						},
						$keywords
					),
					static function ( $phrase ) {
						return strlen( $phrase ) >= 3;
					}
				)
			)
		);
	}

	/**
	 * Ability keys that support mutation actions (create/update/delete).
	 *
	 * @return list<string>
	 */
	public static function get_mutation_ability_keys() {
		$keys = array();

		foreach ( self::CATALOG as $ability_key => $entry ) {
			$actions = (array) ( ( isset( $entry['actions'] ) ? $entry['actions'] : array() ) );
			$mutations = array_intersect( $actions, array( 'create', 'update', 'delete' ) );

			if ( ! empty( $mutations ) ) {
				$keys[] = $ability_key;
			}
		}

		return $keys;
	}
}
