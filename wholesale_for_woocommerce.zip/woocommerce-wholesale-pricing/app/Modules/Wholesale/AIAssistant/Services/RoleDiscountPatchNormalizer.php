<?php
/**
 * Prunes over-filled AI discount patches against stored role rows.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Keeps partial discount updates from overwriting unspecified stored fields.
 */
class RoleDiscountPatchNormalizer {

	/**
	 * Prune redundant or AI-default fields from a role discount patch item.
	 *
	 * @param array<string, mixed> $item       Incoming patch item.
	 * @param array<string, mixed> $stored_row Existing stored role row (may be empty).
	 * @return array<string, mixed>
	 */
	public static function prune_role_discount_item( array $item, array $stored_row ) {
		$has_stored_row = ! empty( $stored_row );
		$pruned         = $item;

		if ( $has_stored_row && array_key_exists( 'enabled', $pruned ) && self::is_enabled_value( $pruned['enabled'] ) ) {
			unset( $pruned['enabled'] );
		}

		if ( isset( $pruned['discount_type'] ) ) {
			$patch_type = sanitize_key( (string) $pruned['discount_type'] );

			// Partial updates should keep the stored discount type unless the user explicitly requests a change.
			if ( $has_stored_row ) {
				unset( $pruned['discount_type'] );
			} elseif ( 'fixed' === $patch_type && self::is_inferred_new_enable_discount_type( $item ) ) {
				// New enables often infer fixed from bare numeric wholesale_price in a full role payload.
				unset( $pruned['discount_type'] );
			}
		}

		if ( $has_stored_row && array_key_exists( 'wholesale_price', $pruned )
			&& ! self::is_single_price_field_changing( 'wholesale_price', $pruned, $stored_row ) ) {
			unset( $pruned['wholesale_price'] );
		}

		if ( $has_stored_row && array_key_exists( 'cart_price', $pruned )
			&& ! self::is_single_price_field_changing( 'cart_price', $pruned, $stored_row ) ) {
			unset( $pruned['cart_price'] );
		}

		if ( $has_stored_row && array_key_exists( 'min_quantity', $pruned ) ) {
			$patch_min  = (int) $pruned['min_quantity'];
			$stored_min = isset( $stored_row['min_quatity'] ) ? (int) $stored_row['min_quatity'] : null;

			// Drop AI-default min_quantity:1 only when a price field is actually changing.
			// If price is unchanged (full read payload), min_quantity may be the user's intent.
			if ( null !== $stored_min && $stored_min !== $patch_min && 1 === $patch_min
				&& self::is_price_field_changing( $pruned, $stored_row ) ) {
				unset( $pruned['min_quantity'] );
			}
		}

		if ( $has_stored_row && array_key_exists( 'min_subtotal', $pruned ) ) {
			$stored = isset( $stored_row['min_subtotal'] ) ? (string) $stored_row['min_subtotal'] : '';
			$patch  = is_numeric( $pruned['min_subtotal'] ) || is_string( $pruned['min_subtotal'] )
				? (string) $pruned['min_subtotal']
				: '';

			if ( $stored === $patch || ( '' === $patch && '' !== $stored ) ) {
				unset( $pruned['min_subtotal'] );
			}
		}

		if ( $has_stored_row && array_key_exists( 'cart_min_subtotal', $pruned ) ) {
			$stored = isset( $stored_row['cart_min_subtotal'] ) ? (string) $stored_row['cart_min_subtotal'] : '';
			$patch  = is_numeric( $pruned['cart_min_subtotal'] ) || is_string( $pruned['cart_min_subtotal'] )
				? (string) $pruned['cart_min_subtotal']
				: '';

			if ( $stored === $patch || ( '' === $patch && '' !== $stored ) ) {
				unset( $pruned['cart_min_subtotal'] );
			}
		}

		if ( $has_stored_row && isset( $pruned['discount_on'], $stored_row['discount_on'] )
			&& sanitize_key( (string) $pruned['discount_on'] ) === sanitize_key( (string) $stored_row['discount_on'] ) ) {
			unset( $pruned['discount_on'] );
		}

		if ( $has_stored_row && array_key_exists( 'exclude_categories', $pruned ) ) {
			$stored_cats = isset( $stored_row['exclude_categories'] ) && is_array( $stored_row['exclude_categories'] )
				? array_map( 'intval', $stored_row['exclude_categories'] )
				: array();
			$patch_cats  = is_array( $pruned['exclude_categories'] )
				? array_map( 'intval', $pruned['exclude_categories'] )
				: array();

			sort( $stored_cats );
			sort( $patch_cats );

			if ( $stored_cats === $patch_cats ) {
				unset( $pruned['exclude_categories'] );
			}
		}

		if ( $has_stored_row && array_key_exists( 'step_quantity', $pruned ) ) {
			$stored = isset( $stored_row['step_quantity'] ) ? (string) $stored_row['step_quantity'] : '';
			$patch  = is_numeric( $pruned['step_quantity'] ) || is_string( $pruned['step_quantity'] )
				? (string) $pruned['step_quantity']
				: '';

			if ( $stored === $patch ) {
				unset( $pruned['step_quantity'] );
			}
		}

		return $pruned;
	}

	/**
	 * Whether a tier_pricing patch item is a no-op (empty placeholder tiers).
	 *
	 * @param array<string, mixed> $item Tier pricing patch item.
	 * @return bool
	 */
	public static function is_noop_tier_patch( array $item ) {
		if ( ! array_key_exists( 'tiers', $item ) ) {
			return true;
		}

		$tiers = $item['tiers'];

		if ( ! is_array( $tiers ) || empty( $tiers ) ) {
			return true;
		}

		foreach ( $tiers as $tier ) {
			if ( ! is_array( $tier ) ) {
				continue;
			}

			$min      = isset( $tier['min'] ) ? (string) $tier['min'] : '';
			$max      = isset( $tier['max'] ) ? (string) $tier['max'] : '';
			$price    = isset( $tier['price'] ) ? (string) $tier['price'] : '';
			$cart_max = isset( $tier['cart_max'] ) ? (string) $tier['cart_max'] : '';

			if ( '' !== $min || '' !== $max || '' !== $price || '' !== $cart_max ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Remove no-op tier pricing entries from a patch.
	 *
	 * @param list<array<string, mixed>> $tier_pricing Tier pricing patch.
	 * @return list<array<string, mixed>>
	 */
	public static function filter_tier_pricing_patch( array $tier_pricing ) {
		$filtered = array();

		foreach ( $tier_pricing as $item ) {
			if ( ! is_array( $item ) || self::is_noop_tier_patch( $item ) ) {
				continue;
			}

			$filtered[] = $item;
		}

		return $filtered;
	}

	/**
	 * Whether discount_type fixed looks like an AI-inferred value on a new role enable.
	 *
	 * Full enable payloads (enabled + price + quantity fields) commonly add fixed by mistake.
	 * Narrower fixed-only requests are left intact.
	 *
	 * @param array<string, mixed> $item Original patch item before pruning.
	 * @return bool
	 */
	private static function is_inferred_new_enable_discount_type( array $item ) {
		if ( ! array_key_exists( 'enabled', $item ) || ! self::is_enabled_value( $item['enabled'] ) ) {
			return false;
		}

		if ( ! array_key_exists( 'wholesale_price', $item ) ) {
			return false;
		}

		return array_key_exists( 'min_quantity', $item ) || array_key_exists( 'step_quantity', $item );
	}

	/**
	 * Is Price field changing in the patch compared to stored row.
	 * 
	 * @param array<string, mixed> $item       Patch item.
	 * @param array<string, mixed> $stored_row Stored role row.
	 * @return bool
	 */
	private static function is_price_field_changing( array $item, array $stored_row ) {
		foreach ( array( 'wholesale_price', 'cart_price' ) as $price_key ) {
			if ( self::is_single_price_field_changing( $price_key, $item, $stored_row ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether a single price field in the patch differs from stored.
	 *
	 * @param string               $price_key  wholesale_price or cart_price.
	 * @param array<string, mixed> $item       Patch item.
	 * @param array<string, mixed> $stored_row Stored role row.
	 * @return bool
	 */
	private static function is_single_price_field_changing( $price_key, array $item, array $stored_row ) {
		if ( ! array_key_exists( $price_key, $item ) ) {
			return false;
		}

		$patch_price  = is_numeric( $item[ $price_key ] ) || is_string( $item[ $price_key ] )
			? (string) $item[ $price_key ]
			: '';
		$stored_price = isset( $stored_row[ $price_key ] ) ? (string) $stored_row[ $price_key ] : '';

		return $patch_price !== $stored_price;
	}

	/**
	 * Whether a value represents an enabled flag.
	 *
	 * @param mixed $value Enabled flag.
	 * @return bool
	 */
	private static function is_enabled_value( $value ) {
		if ( is_bool( $value ) ) {
			return $value;
		}

		if ( is_numeric( $value ) ) {
			return (int) 1 === (int) $value;
		}

		if ( is_string( $value ) ) {
			return in_array( strtolower( trim( $value ) ), array( '1', 'true', 'yes', 'on' ), true );
		}

		return false;
	}
}
