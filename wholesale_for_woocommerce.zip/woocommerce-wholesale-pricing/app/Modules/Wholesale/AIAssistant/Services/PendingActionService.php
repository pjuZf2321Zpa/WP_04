<?php
/**
 * Stores pending AI mutation actions awaiting user approval.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

use WordPress\AiClient\Tools\DTO\FunctionCall;

/**
 * File-backed pending action queue aligned with chat session TTL.
 */
class PendingActionService {

	/**
	 * Pending action subdirectory.
	 */
	const PENDING_DIR = 'pending';

	/**
	 * Human-readable labels for wholesale settings keys.
	 *
	 * @deprecated Use WholesaleSettingsCatalog::get_setting_label().
	 * @var array<string, string>
	 */
	const SETTING_LABELS = array();

	/**
	 * Chat session store.
	 *
	 * @var ChatSessionStore
	 */
	private $session_store;

	/**
	 * Constructor.
	 *
	 * @param ChatSessionStore|null $session_store Optional session store.
	 */
	public function __construct( $session_store = null ) {
		$this->session_store =( isset( $session_store ) ? $session_store : new ChatSessionStore() );
	}

	/**
	 * Queue a mutation for approval.
	 *
	 * @param string       $session_id Session id.
	 * @param FunctionCall $call       Ability function call.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function create( $session_id, FunctionCall $call ) {
		$user_id = get_current_user_id();

		if ( ! $user_id ) {
			return new \WP_Error(
				'wwp_ai_chat_not_logged_in',
				__( 'You must be logged in to queue actions.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 401 )
			);
		}

		$ability_name = \WP_AI_Client_Ability_Function_Resolver::function_name_to_ability_name(
			(string) $call->getName()
		);
		$ability      = wp_get_ability( $ability_name );
		$args         = is_array( $call->getArgs() ) ? $call->getArgs() : array();
		$ability_key  = self::ability_name_to_key( $ability_name );
		$pending_id   = wp_generate_uuid4();

		$payload = array(
			'pending_id'      => $pending_id,
			'user_id'         => $user_id,
			'session_id'      => $session_id,
			'ability_name'    => $ability_name,
			'ability_key'     => $ability_key,
			'label'           => $ability instanceof \WP_Ability ? $ability->get_label() : $ability_name,
			'action_label'    => self::build_action_label( $ability_key, $args ),
			'summary'         => self::build_summary( $ability_key, $ability, $args ),
			'args'            => $args,
			'function_call'   => $call->toArray(),
			'status'          => 'pending',
			'created_at'      => time(),
			'original_prompt' => ChatExecutionContext::is_active() ? ChatExecutionContext::get_prompt() : '',
			'model'           => ChatExecutionContext::is_active() ? ChatExecutionContext::get_model() : '',
		);

		$path = $this->get_pending_path( $user_id, $pending_id, true );

		if ( ! $path ) {
			return new \WP_Error(
				'wwp_ai_pending_storage_failed',
				__( 'Could not store the pending action.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		$encoded = ChatFileEncryption::encrypt( wp_json_encode( $payload ) );

		if ( false === $encoded || false === file_put_contents( $path, $encoded, LOCK_EX ) ) {
			return new \WP_Error(
				'wwp_ai_pending_storage_failed',
				__( 'Could not store the pending action.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		ChatAiLogger::log(
			'pending_action_created',
			array(
				'session_id' => $session_id,
				'pending'    => $payload,
			)
		);

		return $payload;
	}

	/**
	 * Queue a mutation for approval from a known ability key and args.
	 *
	 * @param string               $session_id  Session id.
	 * @param string               $ability_key   Ability settings key.
	 * @param array<string, mixed> $args          Ability arguments.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function create_from_ability_key( $session_id, $ability_key, array $args ) {
		$user_id = get_current_user_id();

		if ( ! $user_id ) {
			return new \WP_Error(
				'wwp_ai_chat_not_logged_in',
				__( 'You must be logged in to queue actions.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 401 )
			);
		}

		$ability_name = 'woocommerce-wholesale-pricing/' . str_replace( '_', '-', $ability_key );
		$ability      = wp_get_ability( $ability_name );
		$pending_id   = wp_generate_uuid4();

		$payload = array(
			'pending_id'      => $pending_id,
			'user_id'         => $user_id,
			'session_id'      => $session_id,
			'ability_name'    => $ability_name,
			'ability_key'     => $ability_key,
			'label'           => $ability instanceof \WP_Ability ? $ability->get_label() : $ability_name,
			'action_label'    => self::build_action_label( $ability_key, $args ),
			'summary'         => self::build_summary( $ability_key, $ability, $args ),
			'args'            => $args,
			'function_call'   => array(
				'name' => $ability_name,
				'args' => $args,
			),
			'status'          => 'pending',
			'created_at'      => time(),
			'original_prompt' => ChatExecutionContext::is_active() ? ChatExecutionContext::get_prompt() : '',
			'model'           => ChatExecutionContext::is_active() ? ChatExecutionContext::get_model() : '',
		);

		$path = $this->get_pending_path( $user_id, $pending_id, true );

		if ( ! $path ) {
			return new \WP_Error(
				'wwp_ai_pending_storage_failed',
				__( 'Could not store the pending action.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		$encoded = ChatFileEncryption::encrypt( wp_json_encode( $payload ) );

		if ( false === $encoded || false === file_put_contents( $path, $encoded, LOCK_EX ) ) {
			return new \WP_Error(
				'wwp_ai_pending_storage_failed',
				__( 'Could not store the pending action.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		ChatAiLogger::log(
			'pending_action_created',
			array(
				'session_id' => $session_id,
				'pending'    => $payload,
				'source'     => 'intent_fallback',
			)
		);

		return $payload;
	}

	/**
	 * Queue one or more mutation steps as a single approval batch.
	 *
	 * @param string                                                                 $session_id Session id.
	 * @param list<array{ability_key: string, args: array<string, mixed>}>           $steps      Mutation steps.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function create_batch( $session_id, array $steps ) {
		$user_id = get_current_user_id();

		if ( ! $user_id ) {
			return new \WP_Error(
				'wwp_ai_chat_not_logged_in',
				__( 'You must be logged in to queue actions.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 401 )
			);
		}

		$normalized_steps = $this->normalize_batch_steps( $steps );

		if ( empty( $normalized_steps ) ) {
			return new \WP_Error(
				'wwp_ai_pending_empty_batch',
				__( 'No valid actions to queue for approval.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$primary_key  = (string) $normalized_steps[0]['ability_key'];
		$ability_name = 'woocommerce-wholesale-pricing/' . str_replace( '_', '-', $primary_key );
		$ability      = wp_get_ability( $ability_name );
		$pending_id   = wp_generate_uuid4();
		$summary      = self::build_batch_summary( $normalized_steps );
		$action_label = count( $normalized_steps ) > 1
			? __( 'apply pending changes', 'woocommerce-wholesale-pricing' )
			: self::build_action_label( $primary_key, $normalized_steps[0]['args'] );

		$payload = array(
			'pending_id'      => $pending_id,
			'user_id'         => $user_id,
			'session_id'      => $session_id,
			'ability_name'    => $ability_name,
			'ability_key'     => $primary_key,
			'label'           => count( $normalized_steps ) > 1
				? __( 'Pending changes', 'woocommerce-wholesale-pricing' )
				: ( $ability instanceof \WP_Ability ? $ability->get_label() : $ability_name ),
			'action_label'    => $action_label,
			'summary'         => $summary,
			'args'            => $normalized_steps[0]['args'],
			'steps'           => $normalized_steps,
			'function_call'   => array(
				'name' => $ability_name,
				'args' => $normalized_steps[0]['args'],
			),
			'status'          => 'pending',
			'created_at'      => time(),
			'original_prompt' => ChatExecutionContext::is_active() ? ChatExecutionContext::get_prompt() : '',
			'model'           => ChatExecutionContext::is_active() ? ChatExecutionContext::get_model() : '',
		);

		$path = $this->get_pending_path( $user_id, $pending_id, true );

		if ( ! $path ) {
			return new \WP_Error(
				'wwp_ai_pending_storage_failed',
				__( 'Could not store the pending action.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		$encoded = ChatFileEncryption::encrypt( wp_json_encode( $payload ) );

		if ( false === $encoded || false === file_put_contents( $path, $encoded, LOCK_EX ) ) {
			return new \WP_Error(
				'wwp_ai_pending_storage_failed',
				__( 'Could not store the pending action.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		ChatAiLogger::log(
			'pending_action_batch_created',
			array(
				'session_id' => $session_id,
				'pending'    => $payload,
			)
		);

		return $payload;
	}

	/**
	 * Build a UI card payload from a stored pending batch.
	 *
	 * @param array<string, mixed> $payload Stored pending payload.
	 * @return array<string, mixed>
	 */
	public static function to_card_payload( array $payload ) {
		return array(
			'pending_id'   => (string) ( ( isset( $payload['pending_id'] ) ? $payload['pending_id'] : '' ) ),
			'label'        => (string) ( ( isset( $payload['label'] ) ? $payload['label'] : '' ) ),
			'action_label' => (string) ( ( isset( $payload['action_label'] ) ? $payload['action_label'] : '' ) ),
			'summary'      => (string) ( ( isset( $payload['summary'] ) ? $payload['summary'] : '' ) ),
			'args'         => is_array(( isset( $payload['args'] ) ? $payload['args'] : null )) ? $payload['args'] : array(),
			'status'       => 'pending',
		);
	}

	/**
	 * Approve and execute a pending action.
	 *
	 * @param string $pending_id Pending action id.
	 * @param string $session_id Session id.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function approve( $pending_id, $session_id ) {
		$payload = $this->load_pending( $pending_id, $session_id );

		if ( is_wp_error( $payload ) ) {
			return $payload;
		}

		$steps = is_array(( isset( $payload['steps'] ) ? $payload['steps'] : null )) ? $payload['steps'] : array();

		if ( ! empty( $steps ) ) {
			return $this->approve_batch( $pending_id, $session_id, $payload, $steps );
		}

		$ability = wp_get_ability( (string) $payload['ability_name'] );

		if ( ! $ability instanceof \WP_Ability ) {
			$this->delete_pending( $pending_id );
			return new \WP_Error(
				'wwp_ai_pending_ability_missing',
				__( 'The ability for this pending action is no longer available.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		$args            = is_array(( isset( $payload['args'] ) ? $payload['args'] : null )) ? $payload['args'] : array();
		$original_prompt = (string) ( ( isset( $payload['original_prompt'] ) ? $payload['original_prompt'] : '' ) );
		$model           = (string) ( ( isset( $payload['model'] ) ? $payload['model'] : '' ) );

		ChatExecutionContext::begin(
			'' !== $original_prompt
				? $original_prompt
				: sprintf(
					/* translators: %s: pending action id */
					__( 'Approved pending action %s', 'woocommerce-wholesale-pricing' ),
					$pending_id
				),
			$model
		);

		$applied = array();

		try {
			$result  = $ability->execute( ! empty( $args ) ? $args : null );
			$applied = ChatExecutionContext::get_applied_changes();
		} finally {
			ChatExecutionContext::end();
			$this->delete_pending( $pending_id );
		}

		if ( is_wp_error( $result ) ) {
			ChatAiLogger::log(
				'pending_action_approved_error',
				array(
					'session_id' => $session_id,
					'pending_id' => $pending_id,
					'payload'    => $payload,
					'error'      => array(
						'code'    => $result->get_error_code(),
						'message' => $result->get_error_message(),
						'data'    => $result->get_error_data(),
					),
				),
				'error'
			);
			return $result;
		}

		ChatAiLogger::log(
			'pending_action_approved',
			array(
				'session_id'      => $session_id,
				'pending_id'      => $pending_id,
				'payload'         => $payload,
				'result'          => $result,
				'applied_changes' => $applied,
			),
			'info'
		);

		$this->update_session_card_status( $pending_id, $session_id, 'approved' );

		return array(
			'pending_id'      => $pending_id,
			'ability_name'    => $payload['ability_name'],
			'label'           => $payload['label'],
			'summary'         => $payload['summary'],
			'result'          => $result,
			'applied_changes' => $applied,
		);
	}

	/**
	 * Approve and execute a multi-step pending batch.
	 *
	 * @param string               $pending_id Pending action id.
	 * @param string               $session_id Session id.
	 * @param array<string, mixed> $payload    Stored payload.
	 * @param list<array<string,mixed>> $steps Batch steps.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function approve_batch( $pending_id, $session_id, array $payload, array $steps ) {
		$steps = self::consolidate_steps( $steps );
		$original_prompt = (string) ( ( isset( $payload['original_prompt'] ) ? $payload['original_prompt'] : '' ) );
		$model           = (string) ( ( isset( $payload['model'] ) ? $payload['model'] : '' ) );

		ChatExecutionContext::begin(
			'' !== $original_prompt
				? $original_prompt
				: sprintf(
					/* translators: %s: pending action id */
					__( 'Approved pending action %s', 'woocommerce-wholesale-pricing' ),
					$pending_id
				),
			$model
		);

		$results = array();
		$applied = array();
		$error   = null;

		try {
			foreach ( $steps as $step ) {
				$ability_key = (string) ( ( isset( $step['ability_key'] ) ? $step['ability_key'] : '' ) );
				$args        = is_array(( isset( $step['args'] ) ? $step['args'] : null )) ? $step['args'] : array();
				$ability_name = 'woocommerce-wholesale-pricing/' . str_replace( '_', '-', $ability_key );
				$ability      = wp_get_ability( $ability_name );

				if ( ! $ability instanceof \WP_Ability ) {
					$error = new \WP_Error(
						'wwp_ai_pending_ability_missing',
						sprintf(
							/* translators: %s: ability key */
							__( 'The ability "%s" for this pending action is no longer available.', 'woocommerce-wholesale-pricing' ),
							$ability_key
						),
						array( 'status' => 404 )
					);
					break;
				}

				$result = $ability->execute( ! empty( $args ) ? $args : null );

				if ( is_wp_error( $result ) ) {
					ChatAiLogger::log(
						'pending_action_batch_step_error',
						array(
							'session_id'  => $session_id,
							'pending_id'  => $pending_id,
							'ability_key' => $ability_key,
							'error'       => array(
								'code'    => $result->get_error_code(),
								'message' => $result->get_error_message(),
							),
						),
						'error'
					);
					$error = $result;
					break;
				}

				$results[] = $result;
			}

			$applied = ChatExecutionContext::get_applied_changes();
		} finally {
			ChatExecutionContext::end();
			$this->delete_pending( $pending_id );
		}

		if ( $error instanceof \WP_Error ) {
			return $error;
		}

		ChatAiLogger::log(
			'pending_action_batch_approved',
			array(
				'session_id'      => $session_id,
				'pending_id'      => $pending_id,
				'payload'         => $payload,
				'results'         => $results,
				'applied_changes' => $applied,
			),
			'info'
		);

		$this->update_session_card_status( $pending_id, $session_id, 'approved' );

		return array(
			'pending_id'      => $pending_id,
			'ability_name'    => $payload['ability_name'],
			'label'           => $payload['label'],
			'summary'         => $payload['summary'],
			'result'          => $results,
			'applied_changes' => $applied,
		);
	}

	/**
	 * Deny a pending action.
	 *
	 * @param string $pending_id Pending action id.
	 * @param string $session_id Session id.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function deny( $pending_id, $session_id ) {
		$payload = $this->load_pending( $pending_id, $session_id );

		if ( is_wp_error( $payload ) ) {
			return $payload;
		}

		$this->delete_pending( $pending_id );

		$this->update_session_card_status( $pending_id, $session_id, 'denied' );

		ChatAiLogger::log(
			'pending_action_denied',
			array(
				'session_id' => $session_id,
				'pending_id' => $pending_id,
				'payload'    => $payload,
			)
		);

		return array(
			'pending_id' => $pending_id,
			'status'     => 'denied',
			'label'      => $payload['label'],
			'summary'    => $payload['summary'],
		);
	}

	/**
	 * Load a pending action for the current user.
	 *
	 * @param string $pending_id Pending action id.
	 * @param string $session_id Session id.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function load_pending( $pending_id, $session_id ) {
		$user_id = get_current_user_id();

		if ( ! $user_id ) {
			return new \WP_Error(
				'wwp_ai_chat_not_logged_in',
				__( 'You must be logged in to manage pending actions.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 401 )
			);
		}

		$path = $this->get_pending_path( $user_id, $pending_id );

		if ( ! $path || ! file_exists( $path ) ) {
			return new \WP_Error(
				'wwp_ai_pending_not_found',
				__( 'This pending action has expired or does not exist.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		$raw = file_get_contents( $path );

		if ( false === $raw || '' === $raw ) {
			$this->delete_pending( $pending_id );
			return new \WP_Error(
				'wwp_ai_pending_not_found',
				__( 'This pending action has expired or does not exist.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		$plaintext = ChatFileEncryption::decrypt( $raw );

		if ( false === $plaintext ) {
			$this->delete_pending( $pending_id );
			return new \WP_Error(
				'wwp_ai_pending_not_found',
				__( 'This pending action has expired or does not exist.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		$payload = json_decode( $plaintext, true );

		if ( ! is_array( $payload ) ) {
			$this->delete_pending( $pending_id );
			return new \WP_Error(
				'wwp_ai_pending_not_found',
				__( 'This pending action has expired or does not exist.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		$created_at = isset( $payload['created_at'] ) ? (int) $payload['created_at'] : 0;

		if ( $created_at <= 0 || ( time() - $created_at ) > ChatSessionStore::TTL ) {
			$this->delete_pending( $pending_id );
			return new \WP_Error(
				'wwp_ai_pending_expired',
				__( 'This pending action has expired.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 410 )
			);
		}

		if ( (int) ( ( isset( $payload['user_id'] ) ? $payload['user_id'] : 0 ) ) !== $user_id ) {
			return new \WP_Error(
				'wwp_ai_pending_forbidden',
				__( 'You do not have permission to manage this pending action.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		if ( (string) ( ( isset( $payload['session_id'] ) ? $payload['session_id'] : '' ) ) !== $session_id ) {
			ChatAiLogger::log(
				'pending_session_mismatch_warning',
				array(
					'pending_id'         => $pending_id,
					'stored_session_id'  => (string) ( ( isset( $payload['session_id'] ) ? $payload['session_id'] : '' ) ),
					'request_session_id' => $session_id,
					'user_id'            => $user_id,
				),
				'warning'
			);
		}

		return $payload;
	}

	/**
	 * Persist approve/deny status on a pending card in stored UI messages.
	 *
	 * @param string $pending_id Pending action id.
	 * @param string $session_id Session id.
	 * @param string $status     Card status (approved or denied).
	 * @return void
	 */
	public function update_session_card_status( $pending_id, $session_id, $status ) {
		if ( '' === $pending_id || '' === $session_id || '' === $status ) {
			return;
		}

		$session = $this->session_store->load( $session_id );

		if ( ! is_array( $session ) ) {
			return;
		}

		$ui_messages = is_array(( isset( $session['ui_messages'] ) ? $session['ui_messages'] : null )) ? $session['ui_messages'] : array();
		$updated     = false;

		foreach ( $ui_messages as $message_index => $message ) {
			if ( ! is_array( $message ) || ! is_array(( isset( $message['pending_actions'] ) ? $message['pending_actions'] : null )) ) {
				continue;
			}

			foreach ( $message['pending_actions'] as $action_index => $action ) {
				if ( ! is_array( $action ) || (string) ( ( isset( $action['pending_id'] ) ? $action['pending_id'] : '' ) ) !== $pending_id ) {
					continue;
				}

				$ui_messages[ $message_index ]['pending_actions'][ $action_index ]['status'] = $status;
				$updated = true;
			}
		}

		if ( ! $updated ) {
			return;
		}

		$this->session_store->save(
			$session_id,
			array(
				'ui_messages' => $ui_messages,
				'ai_history'  => is_array(( isset( $session['ai_history'] ) ? $session['ai_history'] : null )) ? $session['ai_history'] : array(),
			)
		);
	}

	/**
	 * Delete a pending action file.
	 *
	 * @param string $pending_id Pending action id.
	 * @return void
	 */
	private function delete_pending( $pending_id ) {
		$user_id = get_current_user_id();
		$path    = $this->get_pending_path( $user_id, $pending_id );

		if ( $path && file_exists( $path ) ) {
			@unlink( $path );
		}
	}

	/**
	 * Resolve pending action file path.
	 *
	 * @param int    $user_id    User id.
	 * @param string $pending_id Pending action id.
	 * @param bool   $create_dir Whether to create directories.
	 * @return string|null
	 */
	private function get_pending_path( $user_id, $pending_id, $create_dir = false ) {
		if ( $user_id <= 0 || '' === $pending_id ) {
			return null;
		}

		$root = $this->session_store->get_storage_root();

		if ( ! $root ) {
			return null;
		}

		$dir = trailingslashit( $root ) . self::PENDING_DIR . '/' . (string) $user_id;

		if ( $create_dir ) {
			wp_mkdir_p( $dir );

			$index = trailingslashit( $dir ) . 'index.php';
			if ( ! file_exists( $index ) ) {
				file_put_contents( $index, "<?php\n// Silence is golden.\n" );
			}

			$htaccess = trailingslashit( $dir ) . '.htaccess';
			if ( ! file_exists( $htaccess ) ) {
				file_put_contents( $htaccess, "Deny from all\n" );
			}
		}

		$safe_id = preg_replace( '/[^a-zA-Z0-9\-]/', '', $pending_id );

		if ( ! is_string( $safe_id ) || '' === $safe_id ) {
			return null;
		}

		return trailingslashit( $dir ) . $safe_id . '.json';
	}

	/**
	 * Convert ability name to settings key.
	 *
	 * @param string $ability_name Ability name.
	 * @return string
	 */
	public static function ability_name_to_key( $ability_name ) {
		$prefix = 'woocommerce-wholesale-pricing/';

		if ( ! str_starts_with( $ability_name, $prefix ) ) {
			return '';
		}

		return str_replace( '-', '_', substr( $ability_name, strlen( $prefix ) ) );
	}

	/**
	 * Build a lowercase action label for the approval card header.
	 *
	 * @param string               $ability_key Ability settings key.
	 * @param array<string, mixed> $args        Function args.
	 * @return string
	 */
	public static function build_action_label( $ability_key, array $args ) {
		$action = isset( $args['action'] ) ? sanitize_key( (string) $args['action'] ) : 'update';

		$labels = array(
			'b2b_user_roles'      => array(
				'create' => 'add wholesale role',
				'update' => 'update wholesale role',
				'delete' => 'delete wholesale role',
			),
			'wholesale_settings'  => array(
				'update' => 'update wholesale settings',
				'get'    => 'read wholesale settings',
			),
			'global_discounts'    => array(
				'update' => 'update global discounts',
			),
			'cart_discounts'      => array(
				'update' => 'update cart discounts',
			),
			'wholesale_registration' => array(
				'update' => 'update registration settings',
			),
			'modify_update_quotes' => array(
				'update' => 'update quote',
				'create' => 'create quote',
				'delete' => 'delete quote',
			),
			'quote_settings'      => array(
				'update' => 'update quote settings',
			),
			'quote_rules'         => array(
				'create' => 'add quote rule',
				'update' => 'update quote rule',
				'delete' => 'delete quote rule',
			),
			'woocommerce_products' => array(
				'create' => 'add product',
				'update' => 'update product',
				'delete' => 'delete product',
			),
			'woocommerce_categories' => array(
				'create' => 'add category',
				'update' => 'update category',
				'delete' => 'delete category',
			),
		);

		if ( isset( $labels[ $ability_key ][ $action ] ) ) {
			return $labels[ $ability_key ][ $action ];
		}

		$ability_label = str_replace( '_', ' ', $ability_key );

		return trim( $action . ' ' . $ability_label );
	}

	/**
	 * Build a short human-readable summary for UI cards.
	 *
	 * @param string               $ability_key Ability settings key.
	 * @param \WP_Ability|null     $ability     Ability instance.
	 * @param array<string, mixed> $args        Function args.
	 * @return string
	 */
	public static function build_summary( $ability_key, $ability, array $args ) {
		$action = isset( $args['action'] ) ? sanitize_key( (string) $args['action'] ) : '';

		$catalog_summary = AdminSettingsRegistry::format_mutation_summary( $ability_key, $args );

		if ( '' !== $catalog_summary && in_array( $ability_key, AdminSettingsRegistry::get_catalog_ability_keys(), true ) ) {
			if ( 'global_discounts' !== $ability_key ) {
				return $catalog_summary;
			}
		}

		if ( 'b2b_user_roles' === $ability_key && 'create' === $action ) {
			$role = is_array(( isset( $args['role'] ) ? $args['role'] : null )) ? $args['role'] : array();
			$name = isset( $role['name'] ) ? (string) $role['name'] : '';
			$slug = isset( $role['slug'] ) ? (string) $role['slug'] : '';

			if ( '' === $slug && '' !== $name ) {
				$slug = sanitize_title( $name );
			}

			$discount  = isset( $role['discount'] ) ? $role['discount'] : ( ( isset( $role['wholesale_discount'] ) ? $role['wholesale_discount'] : '0' ) );
			$min_order = isset( $role['min_order_amount'] ) ? $role['min_order_amount'] : ( ( isset( $role['minimum_order'] ) ? $role['minimum_order'] : '0' ) );

			if ( '' !== $name ) {
				return sprintf(
					'Add role "%1$s" (%2$s) — %3$s%% off, min order %4$s',
					$name,
					$slug,
					$discount,
					$min_order
				);
			}
		}

		if ( 'wholesale_settings' === $ability_key && 'update' === $action ) {
			$settings = is_array(( isset( $args['settings'] ) ? $args['settings'] : null )) ? $args['settings'] : array();

			if ( ! empty( $settings ) ) {
				return WholesaleSettingsCatalog::format_settings_patch_summary( $settings );
			}
		}

		if ( 'wholesale_registration' === $ability_key && 'update' === $action ) {
			$settings = is_array(( isset( $args['settings'] ) ? $args['settings'] : null )) ? $args['settings'] : array();

			if ( ! empty( $settings ) ) {
				$parts = array();

				foreach ( $settings as $key => $value ) {
					$parts[] = RegistrationFieldCatalog::format_setting_change_summary( (string) $key, (string) $value );
				}

				return implode( '; ', $parts );
			}
		}

		if ( 'woocommerce_categories' === $ability_key && 'create' === $action ) {
			$names = array();
			$bulk  = is_array(( isset( $args['categories'] ) ? $args['categories'] : null )) ? $args['categories'] : array();

			if ( ! empty( $bulk ) ) {
				foreach ( $bulk as $entry ) {
					if ( ! is_array( $entry ) ) {
						continue;
					}

					$category = is_array(( isset( $entry['category'] ) ? $entry['category'] : null )) ? $entry['category'] : $entry;
					$name     = (string) ( ( isset( $category['name'] ) ? $category['name'] : '' ) );

					if ( '' !== $name ) {
						$names[] = $name;
					}
				}
			} elseif ( is_array(( isset( $args['category'] ) ? $args['category'] : null )) ) {
				$name = (string) ( ( isset( $args['category']['name'] ) ? $args['category']['name'] : '' ) );

				if ( '' !== $name ) {
					$names[] = $name;
				}
			}

			if ( ! empty( $names ) ) {
				if ( count( $names ) > 1 ) {
					/* translators: %s: comma-separated category names */
					return sprintf( __( 'Create categories "%s"', 'woocommerce-wholesale-pricing' ), implode( '", "', $names ) );
				}

				/* translators: %s: category name */
				return sprintf( __( 'Create category "%s"', 'woocommerce-wholesale-pricing' ), $names[0] );
			}
		}

		if ( 'global_discounts' === $ability_key && 'update' === $action ) {
			$settings = is_array(( isset( $args['settings'] ) ? $args['settings'] : null )) ? $args['settings'] : array();
			$roles    = is_array(( isset( $settings['role_discounts'] ) ? $settings['role_discounts'] : null )) ? $settings['role_discounts'] : array();

			if ( ! empty( $roles ) ) {
				$parts = array();

				foreach ( $roles as $role ) {
					if ( ! is_array( $role ) ) {
						continue;
					}

					$slug     = (string) ( ( isset( $role['role_slug'] ) ? $role['role_slug'] : ( isset( $role['slug'] ) ? $role['slug'] : '' ) ) );
					$discount = (string) ( ( isset( $role['wholesale_price'] ) ? $role['wholesale_price'] : '' ) );

					if ( '' !== $slug && '' !== $discount ) {
						if ( array_key_exists( 'min_quantity', $role ) ) {
							$min_qty = (int) $role['min_quantity'];
							$parts[] = sprintf(
								'Enable %1$s%% global discount for role %2$s (min qty %3$d)',
								$discount,
								$slug,
								$min_qty
							);
						} else {
							$parts[] = sprintf(
								'Set global wholesale value to %1$s%% for role %2$s',
								$discount,
								$slug
							);
						}
					}
				}

				if ( ! empty( $parts ) ) {
					return implode( '; ', $parts );
				}
			}
		}

		$label = $ability instanceof \WP_Ability ? $ability->get_label() : __( 'Action', 'woocommerce-wholesale-pricing' );

		if ( '' !== $action ) {
			/* translators: 1: action verb, 2: ability label */
			return sprintf( __( '%1$s via %2$s', 'woocommerce-wholesale-pricing' ), ucfirst( $action ), $label );
		}

		$encoded = wp_json_encode( $args );

		if ( is_string( $encoded ) && strlen( $encoded ) <= 120 ) {
			return $encoded;
		}

		return $label;
	}

	/**
	 * Format a single wholesale setting change for approval cards.
	 *
	 * @param string $key   Setting key.
	 * @param string $label Human-readable label.
	 * @param string $value Target value.
	 * @return string
	 */
	private static function format_setting_change_summary( $key, $label, $value ) {
		if ( 'disable_auto_role' === $key ) {
			if ( 'yes' === $value ) {
				return __( 'Disable registration auto-approve (require manual approval)', 'woocommerce-wholesale-pricing' );
			}

			if ( 'no' === $value ) {
				return __( 'Enable registration auto-approve', 'woocommerce-wholesale-pricing' );
			}
		}

		if ( 'yes' === $value ) {
			/* translators: %s: setting label */
			return sprintf( __( 'Enable %s', 'woocommerce-wholesale-pricing' ), $label );
		}

		if ( 'no' === $value ) {
			/* translators: %s: setting label */
			return sprintf( __( 'Disable %s', 'woocommerce-wholesale-pricing' ), $label );
		}

		return sprintf(
			/* translators: 1: setting label, 2: setting value */
			__( 'Set %1$s to %2$s', 'woocommerce-wholesale-pricing' ),
			$label,
			$value
		);
	}

	/**
	 * Merge tool-call steps with intent-fallback steps (tool args win on duplicate ability keys).
	 *
	 * @param list<array{ability_key: string, args: array<string, mixed>}> $primary   Steps from tool calls.
	 * @param list<array{ability_key: string, args: array<string, mixed>}> $secondary Steps from intent fallback.
	 * @return list<array{ability_key: string, args: array<string, mixed>}>
	 */
	public static function merge_unique_steps( array $primary, array $secondary ) {
		$order = array(
			'b2b_user_roles',
			'wholesale_settings',
			'global_discounts',
			'cart_discounts',
			'wholesale_registration',
			'wholesale_email_notifications',
			'woocommerce_products',
			'woocommerce_categories',
			'wholesale_account_requests',
			'b2b_user_profiles',
			'quote_settings',
			'quote_rules',
			'modify_update_quotes',
		);

		$primary_keys = array();

		foreach ( $primary as $step ) {
			$key = sanitize_key( (string) ( ( isset( $step['ability_key'] ) ? $step['ability_key'] : '' ) ) );

			if ( '' !== $key ) {
				$primary_keys[ $key ] = true;
			}
		}

		if ( ! empty( $primary_keys ) ) {
			$filtered_secondary = array();

			foreach ( $secondary as $step ) {
				$key = sanitize_key( (string) ( ( isset( $step['ability_key'] ) ? $step['ability_key'] : '' ) ) );

				if ( '' === $key || isset( $primary_keys[ $key ] ) ) {
					continue;
				}

				$filtered_secondary[] = $step;
			}

			$secondary = $filtered_secondary;
		}

		$consolidated = self::consolidate_steps( array_merge( $secondary, $primary ) );
		$by_key       = array();

		foreach ( $consolidated as $step ) {
			$key = sanitize_key( (string) ( ( isset( $step['ability_key'] ) ? $step['ability_key'] : '' ) ) );

			if ( '' !== $key ) {
				$by_key[ $key ] = $step;
			}
		}

		$merged = array();

		foreach ( $order as $key ) {
			if ( isset( $by_key[ $key ] ) ) {
				$merged[] = $by_key[ $key ];
				unset( $by_key[ $key ] );
			}
		}

		foreach ( $by_key as $step ) {
			$merged[] = $step;
		}

		return $merged;
	}

	/**
	 * Merge multiple steps that target the same ability into one executable step.
	 *
	 * @param list<array<string, mixed>> $steps Raw steps.
	 * @return list<array{ability_key: string, args: array<string, mixed>}>
	 */
	public static function consolidate_steps( array $steps ) {
		$consolidated     = array();
		$settings_by_key  = array();

		foreach ( $steps as $step ) {
			if ( ! is_array( $step ) ) {
				continue;
			}

			$ability_key = sanitize_key( (string) ( ( isset( $step['ability_key'] ) ? $step['ability_key'] : '' ) ) );
			$args        = is_array(( isset( $step['args'] ) ? $step['args'] : null )) ? $step['args'] : array();

			if ( '' === $ability_key || empty( $args ) ) {
				continue;
			}

			$normalized_step = array(
				'ability_key' => $ability_key,
				'args'        => $args,
			);

			if ( ! self::is_mergeable_settings_step( $normalized_step ) ) {
				$consolidated[] = $normalized_step;
				continue;
			}

			if ( ! isset( $settings_by_key[ $ability_key ] ) ) {
				$settings_by_key[ $ability_key ] = count( $consolidated );
				$consolidated[]                 = $normalized_step;
				continue;
			}

			$index = $settings_by_key[ $ability_key ];
			$consolidated[ $index ]['args'] = self::merge_step_args(
				$consolidated[ $index ]['args'],
				$args
			);
		}

		return $consolidated;
	}

	/**
	 * Whether a step's args can be merged with another step for the same ability.
	 *
	 * @param array{ability_key: string, args: array<string, mixed>} $step Normalized step.
	 * @return bool
	 */
	private static function is_mergeable_settings_step( array $step ) {
		$args = is_array(( isset( $step['args'] ) ? $step['args'] : null )) ? $step['args'] : array();

		return isset( $args['settings'] ) && is_array( $args['settings'] );
	}

	/**
	 * Merge mutation args from two steps of the same ability.
	 *
	 * @param array<string, mixed> $existing Existing args.
	 * @param array<string, mixed> $incoming Incoming args.
	 * @return array<string, mixed>
	 */
	private static function merge_step_args( array $existing, array $incoming ) {
		$merged = $existing;
		$action = sanitize_key( (string) ( ( isset( $incoming['action'] ) ? $incoming['action'] : ( isset( $existing['action'] ) ? $existing['action'] : 'update' ) ) ) );

		if ( '' !== $action ) {
			$merged['action'] = $action;
		}

		foreach ( $incoming as $key => $value ) {
			if ( 'settings' === $key && is_array( $value ) ) {
				$base_settings = is_array(( isset( $merged['settings'] ) ? $merged['settings'] : null )) ? $merged['settings'] : array();
				$merged['settings'] = self::merge_settings_patches( $base_settings, $value );
				continue;
			}

			if ( 'action' === $key ) {
				continue;
			}

			$merged[ $key ] = $value;
		}

		return $merged;
	}

	/**
	 * Deep-merge settings patches, including nested quote setting groups.
	 *
	 * @param array<string, mixed> $base     Existing settings patch.
	 * @param array<string, mixed> $incoming Incoming settings patch.
	 * @return array<string, mixed>
	 */
	private static function merge_settings_patches( array $base, array $incoming ) {
		$merged = $base;

		foreach ( $incoming as $key => $value ) {
			if ( is_array( $value ) && is_array(( isset( $merged[ $key ] ) ? $merged[ $key ] : null )) ) {
				$merged[ $key ] = self::merge_settings_patches( $merged[ $key ], $value );
				continue;
			}

			$merged[ $key ] = $value;
		}

		return $merged;
	}

	/**
	 * Normalize batch steps and drop invalid entries.
	 *
	 * @param list<array<string, mixed>> $steps Raw steps.
	 * @return list<array{ability_key: string, args: array<string, mixed>}>
	 */
	private function normalize_batch_steps( array $steps ) {
		$normalized = array();

		foreach ( $steps as $step ) {
			if ( ! is_array( $step ) ) {
				continue;
			}

			$ability_key = sanitize_key( (string) ( ( isset( $step['ability_key'] ) ? $step['ability_key'] : '' ) ) );
			$args        = is_array(( isset( $step['args'] ) ? $step['args'] : null )) ? $step['args'] : array();

			if ( '' === $ability_key || empty( $args ) ) {
				continue;
			}

			$normalized[] = array(
				'ability_key' => $ability_key,
				'args'        => $args,
			);
		}

		return self::consolidate_steps( $normalized );
	}

	/**
	 * Build a combined summary for a batch of steps.
	 *
	 * @param list<array{ability_key: string, args: array<string, mixed>}> $steps Steps.
	 * @return string
	 */
	public static function build_batch_summary( array $steps ) {
		$summaries = array();

		foreach ( $steps as $step ) {
			$ability_key  = (string) ( ( isset( $step['ability_key'] ) ? $step['ability_key'] : '' ) );
			$args         = is_array(( isset( $step['args'] ) ? $step['args'] : null )) ? $step['args'] : array();
			$ability_name = 'woocommerce-wholesale-pricing/' . str_replace( '_', '-', $ability_key );
			$ability      = wp_get_ability( $ability_name );
			$summary      = self::build_summary( $ability_key, $ability instanceof \WP_Ability ? $ability : null, $args );

			if ( '' !== $summary ) {
				$summaries[] = $summary;
			}
		}

		return ! empty( $summaries ) ? implode( '; ', $summaries ) : __( 'Apply pending changes', 'woocommerce-wholesale-pricing' );
	}
}
