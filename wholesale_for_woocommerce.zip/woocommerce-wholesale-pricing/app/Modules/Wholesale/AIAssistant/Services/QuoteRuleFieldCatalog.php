<?php
/**
 * Maps quote rule field phrases to quote_rules keys.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Catalog for wc-quote-rules post meta fields.
 */
class QuoteRuleFieldCatalog {

	use SettingCatalogTrait;

	/**
	 * Get Entries
	 * 
	 * @return array<string, array<string, mixed>>
	 */
	private static function get_entries() {
		static $entries = null;

		if ( null !== $entries ) {
			return $entries;
		}

		$entries = array(
			'hide_price' => array(
				'key'     => 'hide_price',
				'label'   => 'Hide Price',
				'phrases' => array( 'hide price quote rule', 'quote rule hide price' ),
			),
			'show_single' => array(
				'key'     => 'show_single',
				'label'   => 'Show Add to Quote on Product Page',
				'phrases' => array( 'show add to quote single', 'quote button single product', 'show on single product page' ),
			),
			'show_shop' => array(
				'key'     => 'show_shop',
				'label'   => 'Show Add to Quote on Shop Page',
				'phrases' => array( 'show add to quote shop', 'quote button shop page', 'show on shop page' ),
			),
			'hide_cart_single' => array(
				'key'     => 'hide_cart_single',
				'label'   => 'Hide Add to Cart on Product Page',
				'phrases' => array( 'hide add to cart single', 'hide cart single product' ),
			),
			'hide_cart_shop' => array(
				'key'     => 'hide_cart_shop',
				'label'   => 'Hide Add to Cart on Shop Page',
				'phrases' => array( 'hide add to cart shop', 'hide cart shop page' ),
			),
		);

		return $entries;
	}

	/**
	 * Resolve entry from messages
	 * 
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>|null
	 */
	public static function resolve_entry_from_message( $normalized ) {
		return self::resolve_entry_from_phrases( $normalized, self::get_entries() );
	}

	/**
	 * Build mutation args
	 * 
	 * @param string $message Original message.
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>
	 */
	public static function build_mutation_args( $message, $normalized ) {
		$entry = self::resolve_entry_from_message( $normalized );

		if ( ! is_array( $entry ) ) {
			return array();
		}

		$identifier = self::extract_identifier( $message );

		if ( null === $identifier ) {
			return array();
		}

		$key = (string) ( ( isset( $entry['key'] ) ? $entry['key'] : '' ) );

		if ( ! self::matches_enable_intent( $normalized ) && ! self::matches_disable_intent( $normalized ) ) {
			return array();
		}

		$enabled = self::matches_enable_intent( $normalized ) && ! self::matches_disable_intent( $normalized );

		return array(
			'action'       => 'update',
			'identifier'   => $identifier,
			'wc_quote_rules' => array(
				$key => $enabled ? '1' : '',
			),
		);
	}

	/**
	 * Extract indentifier
	 * 
	 * @param string $message Original message.
	 * @return int|null
	 */
	public static function extract_identifier( $message ) {
		if ( preg_match( '/\b(?:rule|quote rule|id)\s*#?\s*(\d+)\b/i', $message, $matches ) ) {
			return (int) $matches[1];
		}

		return null;
	}

	/**
	 * Get matched keywords
	 * 
	 * @return list<string>
	 */
	public static function get_matcher_keywords() {
		return self::collect_matcher_keywords( self::get_entries() );
	}

	/**
	 * Get hint lines
	 * 
	 * @return list<string>
	 */
	public static function get_hint_lines() {
		return self::collect_hint_lines( self::get_entries() );
	}

	/**
	 * Format Mutation summary
	 * 
	 * @param array<string, mixed> $args Mutation args.
	 * @return string
	 */
	public static function format_mutation_summary( array $args ) {
		return sprintf(
			/* translators: %s: rule identifier */
			__( 'Update quote rule #%s', 'woocommerce-wholesale-pricing' ),
( isset( $args['identifier'] ) ? $args['identifier'] : '' )
		);
	}
}
