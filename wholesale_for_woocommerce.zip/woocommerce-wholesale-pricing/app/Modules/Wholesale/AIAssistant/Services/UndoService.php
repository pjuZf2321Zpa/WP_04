<?php
/**
 * Dispatches undo operations to resource-specific handlers.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo\AccountRequestUndoHandler;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo\CartDiscountsUndoHandler;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo\CategoryUndoHandler;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo\EmailNotificationUndoHandler;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo\GlobalDiscountsUndoHandler;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo\ProductUndoHandler;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo\QuoteRulesUndoHandler;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo\QuoteSettingsUndoHandler;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo\QuoteUndoHandler;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo\SettingsUndoHandler;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo\UndoHandlerInterface;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo\UserRoleUndoHandler;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo\UserUndoHandler;

/**
 * Undo service for AI change history rows.
 */
class UndoService {

	/**
	 * Change history service.
	 *
	 * @var ChangeHistoryService
	 */
	private $history_service;

	/**
	 * Registered undo handlers.
	 *
	 * @var list<UndoHandlerInterface>
	 */
	private $handlers;

	/**
	 * Constructor.
	 *
	 * @param ChangeHistoryService|null $history_service Optional history service.
	 * @param list<UndoHandlerInterface>|null $handlers Optional custom handlers.
	 */
	public function __construct( $history_service = null, $handlers = null ) {
		$this->history_service =( isset( $history_service ) ? $history_service : new ChangeHistoryService() );
		$this->handlers        =( isset( $handlers ) ? $handlers : array(
			new UserRoleUndoHandler(),
			new EmailNotificationUndoHandler(),
			new AccountRequestUndoHandler(),
			new UserUndoHandler(),
			new ProductUndoHandler(),
			new CategoryUndoHandler(),
			new GlobalDiscountsUndoHandler(),
			new CartDiscountsUndoHandler(),
			new QuoteSettingsUndoHandler(),
			new QuoteRulesUndoHandler(),
			new QuoteUndoHandler(),
			new SettingsUndoHandler(),
		) );
	}

	/**
	 * Undo a change history row by id.
	 *
	 * @param int $id History row id.
	 * @return array<string, mixed>|\WP_Error Updated row payload.
	 */
	public function undo( $id ) {
		$row = $this->history_service->get_raw( $id );
		if ( null === $row ) {
			return new \WP_Error(
				'wwp_ai_history_not_found',
				__( 'Change history entry not found.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		if ( (int) ( ( isset( $row['status'] ) ? $row['status'] : 0 ) ) !== 1 ) {
			return new \WP_Error(
				'wwp_ai_history_already_undone',
				__( 'This change has already been undone.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$action_type   = (string) ( ( isset( $row['action_type'] ) ? $row['action_type'] : '' ) );
		$resource_type = (string) ( ( isset( $row['resource_type'] ) ? $row['resource_type'] : '' ) );
		$handler       = $this->resolve_handler( $action_type, $resource_type );

		if ( null === $handler ) {
			return new \WP_Error(
				'wwp_ai_undo_no_handler',
				__( 'No undo handler is available for this change.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$result = $handler->undo( $row );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$user_id = get_current_user_id();
		$this->history_service->mark_undone( $id, $user_id );

		$updated = $this->history_service->get( $id );
		if ( null === $updated ) {
			return new \WP_Error(
				'wwp_ai_history_reload_failed',
				__( 'Change was undone but could not be reloaded.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		return $updated;
	}

	/**
	 * Resolve a handler for the given action and resource type.
	 *
	 * @param string $action_type   Action type.
	 * @param string $resource_type Resource type.
	 * @return UndoHandlerInterface|null
	 */
	private function resolve_handler( $action_type, $resource_type ) {
		foreach ( $this->handlers as $handler ) {
			if ( $handler->supports( $action_type, $resource_type ) ) {
				return $handler;
			}
		}

		return null;
	}
}
