<?php
/**
 * AI Assistant settings service.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities\AbilityCatalog;
use WooCommerceWholesalePricing\App\Providers\WholesaleOption;

/**
 * Reads and writes wholesale AI assistant settings.
 */
class SettingsService {

	/**
	 * Valid visibility values.
	 *
	 * @var list<string>
	 */
	const VISIBILITY_VALUES = array( 'wholesale', 'all' );

	/**
	 * Valid permission mode values.
	 *
	 * @var list<string>
	 */
	const PERMISSION_VALUES = array( 'suggest', 'approval', 'auto' );

	/**
	 * Valid rollback window values.
	 *
	 * @var list<string>
	 */
	const ROLLBACK_VALUES = array( '5', '10', '25', '50' );

	/**
	 * Valid ability keys.
	 *
	 * @return list<string>
	 */
	private function get_ability_keys() {
		return AbilityCatalog::get_all_keys();
	}

	/**
	 * Valid UI provider ids for assistant activation.
	 *
	 * @var list<string>
	 */
	const PROVIDER_IDS = array( 'openai', 'anthropic', 'gemini' );

	/**
	 * Whether the AI assistant is enabled in stored settings.
	 *
	 * Reads the option directly so bootstrapping can skip module load before full sanitization.
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		$stored = get_option( WholesaleOption::AI_ASSISTANT_OPTION, null );

		if ( null === $stored ) {
			return true;
		}

		if ( ! is_array( $stored ) || ! array_key_exists( 'enabled', $stored ) ) {
			return true;
		}

		return (bool) $stored['enabled'];
	}

	/**
	 * Get saved settings merged with defaults.
	 *
	 * @return array<string, mixed>
	 */
	public function get_settings() {
		$stored = get_option( WholesaleOption::AI_ASSISTANT_OPTION, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		return $this->sanitize( array_merge( $this->get_defaults(), $stored ) );
	}

	/**
	 * Save settings after sanitization.
	 *
	 * @param array<string, mixed> $settings Raw settings input.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function save_settings( array $settings ) {
		$existing = $this->get_settings();

		if ( isset( $settings['abilities'] ) && is_array( $settings['abilities'] ) ) {
			$settings['abilities'] = array_merge(
				is_array(( isset( $existing['abilities'] ) ? $existing['abilities'] : null )) ? $existing['abilities'] : array(),
				$settings['abilities']
			);
		}

		$sanitized = $this->sanitize( array_merge( $existing, $settings ) );
		update_option( WholesaleOption::AI_ASSISTANT_OPTION, $sanitized );

		if ( (string) ( ( isset( $existing['rollback'] ) ? $existing['rollback'] : $this->get_defaults()['rollback'] ) ) !== (string) $sanitized['rollback'] ) {
			( new ChangeHistoryService( $this ) )->prune_excess();
		}

		return $sanitized;
	}

	/**
	 * Default settings schema.
	 *
	 * @return array<string, mixed>
	 */
	public function get_defaults() {
		return array(
			'enabled'          => true,
			'visibility'       => 'wholesale',
			'permission'       => 'approval',
			'model'            => '',
			'rollback'         => '10',
			'activeProviders'  => array(),
			'abilities'        => AbilityCatalog::get_default_abilities(),
		);
	}

	/**
	 * Sanitize settings input.
	 *
	 * @param array<string, mixed> $settings Raw settings.
	 * @return array<string, mixed>
	 */
	public function sanitize( array $settings ) {
		$defaults = $this->get_defaults();

		$visibility = isset( $settings['visibility'] ) ? (string) $settings['visibility'] : $defaults['visibility'];
		if ( ! in_array( $visibility, self::VISIBILITY_VALUES, true ) ) {
			$visibility = $defaults['visibility'];
		}

		$permission = isset( $settings['permission'] ) ? (string) $settings['permission'] : $defaults['permission'];
		if ( ! in_array( $permission, self::PERMISSION_VALUES, true ) ) {
			$permission = $defaults['permission'];
		}

		$rollback = isset( $settings['rollback'] ) ? (string) $settings['rollback'] : $defaults['rollback'];
		if ( ! in_array( $rollback, self::ROLLBACK_VALUES, true ) ) {
			$rollback = $defaults['rollback'];
		}

		$abilities_in  = is_array(( isset( $settings['abilities'] ) ? $settings['abilities'] : null )) ? $settings['abilities'] : array();
		$abilities_out = $defaults['abilities'];

		foreach ( $this->get_ability_keys() as $key ) {
			if ( ! AbilityCatalog::is_active( $key ) ) {
				$abilities_out[ $key ] = false;
				continue;
			}

			if ( array_key_exists( $key, $abilities_in ) ) {
				$abilities_out[ $key ] = (bool) $abilities_in[ $key ];
			}
		}

		$active_providers = array();
		if ( isset( $settings['activeProviders'] ) && is_array( $settings['activeProviders'] ) ) {
			foreach ( $settings['activeProviders'] as $provider_id ) {
				$provider_id = sanitize_text_field( (string) $provider_id );
				if ( in_array( $provider_id, self::PROVIDER_IDS, true ) ) {
					$active_providers[] = $provider_id;
				}
			}
			$active_providers = array_values( array_unique( $active_providers ) );
		}

		return array(
			'enabled'         => isset( $settings['enabled'] ) ? (bool) $settings['enabled'] : $defaults['enabled'],
			'visibility'      => $visibility,
			'permission'      => $permission,
			'model'           => isset( $settings['model'] ) ? sanitize_text_field( (string) $settings['model'] ) : $defaults['model'],
			'rollback'        => $rollback,
			'activeProviders' => $active_providers,
			'abilities'       => $abilities_out,
		);
	}

	/**
	 * Get provider ids enabled for the wholesale assistant.
	 *
	 * @return list<string>
	 */
	public function get_active_providers() {
		$settings = $this->get_settings();
		return $settings['activeProviders'];
	}

	/**
	 * Mark a provider as active in the assistant (does not touch WordPress API keys).
	 *
	 * @param string $provider_id UI provider id.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function activate_provider( $provider_id ) {
		if ( ! in_array( $provider_id, self::PROVIDER_IDS, true ) ) {
			return new \WP_Error( 'invalid_provider', __( 'Invalid provider.', 'woocommerce-wholesale-pricing' ), array( 'status' => 400 ) );
		}

		$settings = $this->get_settings();
		if ( ! in_array( $provider_id, $settings['activeProviders'], true ) ) {
			$settings['activeProviders'][] = $provider_id;
			update_option( WholesaleOption::AI_ASSISTANT_OPTION, $settings );
		}

		return $settings;
	}

	/**
	 * Mark a provider as inactive in the assistant (does not touch WordPress API keys).
	 *
	 * @param string $provider_id UI provider id.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function deactivate_provider( $provider_id ) {
		if ( ! in_array( $provider_id, self::PROVIDER_IDS, true ) ) {
			return new \WP_Error( 'invalid_provider', __( 'Invalid provider.', 'woocommerce-wholesale-pricing' ), array( 'status' => 400 ) );
		}

		$settings = $this->get_settings();
		$settings['activeProviders'] = array_values(
			array_filter(
				$settings['activeProviders'],
				static function ( $id ) use ( $provider_id ) {
					return $id !== $provider_id;
				}
			)
		);

		update_option( WholesaleOption::AI_ASSISTANT_OPTION, $settings );

		return $settings;
	}

	/**
	 * Migrate active providers for sites that connected before this flag existed.
	 *
	 * @param list<string> $configured_provider_ids UI provider ids with valid WordPress keys.
	 * @return array<string, mixed>
	 */
	public function maybe_migrate_active_providers( array $configured_provider_ids ) {
		$stored = get_option( WholesaleOption::AI_ASSISTANT_OPTION, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		// Only migrate legacy sites where the flag has never been saved. An
		// existing-but-empty list means the user deactivated all providers,
		// which must not be overridden here.
		if ( array_key_exists( 'activeProviders', $stored ) ) {
			return $this->get_settings();
		}

		if ( empty( $configured_provider_ids ) ) {
			return $this->get_settings();
		}

		$settings                      = $this->sanitize( array_merge( $this->get_defaults(), $stored ) );
		$settings['activeProviders'] = array_values(
			array_intersect( $configured_provider_ids, self::PROVIDER_IDS )
		);
		update_option( WholesaleOption::AI_ASSISTANT_OPTION, $settings );

		return $settings;
	}
}
