<?php
/**
 * Maps quote entity field phrases to modify_update_quotes keys.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Catalog for wc-quote post fields and line items.
 */
class ModifyQuoteFieldCatalog {

	use SettingCatalogTrait;

	/**
	 * Get status entries
	 * 
	 * @return array<string, array<string, mixed>>
	 */
	private static function get_status_entries() {
		return array(
			'accept' => array(
				'key'    => 'status',
				'label'  => 'Accept Quote',
				'value'  => 'quote_accepted',
				'phrases' => array( 'accept quote', 'quote accepted' ),
			),
			'reject' => array(
				'key'    => 'status',
				'label'  => 'Reject Quote',
				'value'  => 'quote_rejected',
				'phrases' => array( 'reject quote', 'quote rejected' ),
			),
			'convert' => array(
				'key'    => 'status',
				'label'  => 'Convert Quote to Order',
				'value'  => 'quote_converted',
				'phrases' => array( 'convert quote', 'convert quote to order', 'quote converted' ),
			),
			'quoted' => array(
				'key'    => 'status',
				'label'  => 'Mark Quote as Quoted',
				'value'  => 'quote_quoted',
				'phrases' => array( 'mark quote quoted', 'quote quoted', 'pending quoted' ),
			),
			'expire' => array(
				'key'    => 'status',
				'label'  => 'Expire Quote',
				'value'  => 'quote_expired',
				'phrases' => array( 'expire quote', 'quote expired' ),
			),
		);
	}

	/**
	 * Resolve entry from message
	 * 
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>|null
	 */
	public static function resolve_entry_from_message( $normalized ) {
		return self::resolve_entry_from_phrases( $normalized, self::get_status_entries() );
	}

	/**
	 * Build mutation args
	 * 
	 * @param string $message Original message.
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>
	 */
	public static function build_mutation_args( $message, $normalized ) {
		$entry = self::resolve_entry_from_message( $normalized );

		if ( ! is_array( $entry ) ) {
			return array();
		}

		$identifier = self::extract_identifier( $message );

		if ( null === $identifier ) {
			return array();
		}

		return array(
			'action'     => 'update',
			'identifier' => $identifier,
			'status'     => (string) ( ( isset( $entry['value'] ) ? $entry['value'] : '' ) ),
		);
	}

	/**
	 * Extract indentifier
	 * 
	 * @param string $message Original message.
	 * @return int|null
	 */
	public static function extract_identifier( $message ) {
		if ( preg_match( '/\b(?:quote|id)\s*#?\s*(\d+)\b/i', $message, $matches ) ) {
			return (int) $matches[1];
		}

		return null;
	}

	/**
	 * Get matched keywords
	 * 
	 * @return list<string>
	 */
	public static function get_matcher_keywords() {
		return self::collect_matcher_keywords( self::get_status_entries() );
	}

	/**
	 * Get hint lines
	 * 
	 * @return list<string>
	 */
	public static function get_hint_lines() {
		return self::collect_hint_lines( self::get_status_entries() );
	}

	/**
	 * Format mutation summary
	 * 
	 * @param array<string, mixed> $args Mutation args.
	 * @return string
	 */
	public static function format_mutation_summary( array $args ) {
		$id     =( isset( $args['identifier'] ) ? $args['identifier'] : '' );
		$status = (string) ( ( isset( $args['status'] ) ? $args['status'] : '' ) );

		foreach ( self::get_status_entries() as $entry ) {
			if ( ( ( isset( $entry['value'] ) ? $entry['value'] : '' ) ) === $status ) {
				return sprintf(
					/* translators: 1: action label, 2: quote id */
					__( '%1$s for quote #%2$s', 'woocommerce-wholesale-pricing' ),
					$entry['label'],
					$id
				);
			}
		}

		return sprintf(
			/* translators: %s: quote id */
			__( 'Update quote #%s', 'woocommerce-wholesale-pricing' ),
			$id
		);
	}
}
