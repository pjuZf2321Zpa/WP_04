<?php
/**
 * Maps product-level wholesale field phrases to woocommerce_products keys.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Catalog for product meta fields from admin product panels.
 */
class ProductFieldCatalog {

	use SettingCatalogTrait;

	/**
	 * Get Entries
	 * 
	 * @return array<string, array<string, mixed>>
	 */
	private static function get_entries() {
		static $entries = null;

		if ( null !== $entries ) {
			return $entries;
		}

		$entries = array(
			'hide_for_customer' => array(
				'key'     => '_wwp_hide_for_customer',
				'label'   => 'Hide Product For Customer Role',
				'phrases' => array( 'hide product for customer', 'hide from customer role' ),
			),
			'hide_for_visitor' => array(
				'key'     => '_wwp_hide_for_visitor',
				'label'   => 'Hide Product For Guest Users',
				'phrases' => array( 'hide product for guest', 'hide from visitor', 'hide for guest users' ),
			),
			'visibility_multi' => array(
				'key'     => 'wholesale_product_visibility_multi',
				'label'   => 'Hide Product for Wholesaler Roles',
				'phrases' => array( 'hide product for wholesaler', 'wholesale product visibility' ),
			),
			'request_for_sample' => array(
				'key'     => 'request_for_sample_enable',
				'label'   => 'Sample Product',
				'phrases' => array( 'sample product', 'request for sample product', 'enable sample on product' ),
			),
			'variation_explode' => array(
				'key'     => 'wwp_variation_explode_eneble',
				'label'   => 'Attributes Quantity',
				'phrases' => array( 'attributes quantity', 'variation explode', 'enable attributes quantity' ),
			),
			'wholesale_price' => array(
				'key'     => 'wholesale_price',
				'label'   => 'Wholesale Price',
				'phrases' => array( 'wholesale price', 'product wholesale price', 'set wholesale price' ),
			),
			'min_quantity' => array(
				'key'     => 'min_quatity',
				'label'   => 'Minimum Quantity',
				'phrases' => array( 'min quantity', 'minimum quantity product', 'product min qty' ),
			),
			'step_quantity' => array(
				'key'     => 'step_quantity',
				'label'   => 'Step Quantity',
				'phrases' => array( 'step quantity', 'quantity step product' ),
			),
			'tier_pricing' => array(
				'key'     => 'product_tier_pricing',
				'label'   => 'Product Tier Pricing',
				'phrases' => array( 'product tier pricing', 'tier pricing product', 'quantity breaks product' ),
			),
		);

		return $entries;
	}

	/**
	 * Resolve entry from message
	 * 
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>|null
	 */
	public static function resolve_entry_from_message( $normalized ) {
		return self::resolve_entry_from_phrases( $normalized, self::get_entries() );
	}

	/**
	 * Build mutation args
	 * 
	 * @param string $message Original message.
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>
	 */
	public static function build_mutation_args( $message, $normalized ) {
		$entry = self::resolve_entry_from_message( $normalized );

		if ( ! is_array( $entry ) ) {
			return array();
		}

		$identifier = self::extract_identifier( $message );

		if ( null === $identifier ) {
			return array();
		}

		$key = (string) ( ( isset( $entry['key'] ) ? $entry['key'] : '' ) );
		$args = array(
			'action'     => 'update',
			'identifier' => $identifier,
		);

		if ( preg_match( '/(\d+(?:\.\d+)?)\s*%/', $normalized, $percent ) && 'wholesale_price' === $key ) {
			$role_slug = self::extract_role_slug( $normalized );
			$pricing   = array(
				'wholesale_price' => $percent[1],
				'discount_type'   => 'percent',
			);

			if ( null !== $role_slug ) {
				$pricing['role_slug'] = $role_slug;
			}

			$args['wholesale_multi_user_pricing'] = array( $pricing );

			return $args;
		}

		if ( preg_match( '/(\d+)\s*(?:min|minimum)/', $normalized, $min ) && 'min_quatity' === $key ) {
			$args['wholesale_multi_user_pricing'] = array(
				'min_quantity' => (int) $min[1],
			);

			return $args;
		}

		if ( self::matches_enable_intent( $normalized ) || self::matches_disable_intent( $normalized ) ) {
			$enabled = self::matches_enable_intent( $normalized ) && ! self::matches_disable_intent( $normalized );
			$args['meta'] = array( $key => $enabled ? 'yes' : '' );

			return $args;
		}

		return array();
	}

	/**
	 * Extract indentifier
	 * 
	 * @param string $message Original message.
	 * @return int|string|null
	 */
	public static function extract_identifier( $message ) {
		if ( preg_match( '/\b(?:product|id)\s*#?\s*(\d+)\b/i', $message, $matches ) ) {
			return (int) $matches[1];
		}

		if ( preg_match( '/product\s+"([^"]+)"/i', $message, $matches ) ) {
			return $matches[1];
		}

		if ( preg_match( '/\bon\s+"([^"]+)"/i', $message, $matches ) ) {
			return $matches[1];
		}

		return null;
	}

	/**
	 * Extract role slug
	 * 
	 * @param string $normalized Lowercased message.
	 * @return string|null
	 */
	public static function extract_role_slug( $normalized ) {
		if ( preg_match( '/\brole\s+([a-z0-9_-]+)\b/', $normalized, $matches ) ) {
			return sanitize_key( $matches[1] );
		}

		return null;
	}

	/**
	 * Get matched keywords
	 * 
	 * @return list<string>
	 */
	public static function get_matcher_keywords() {
		return self::collect_matcher_keywords( self::get_entries() );
	}

	/**
	 * Get hint lines
	 * 
	 * @return list<string>
	 */
	public static function get_hint_lines() {
		return self::collect_hint_lines( self::get_entries() );
	}

	/**
	 * Format mutation summary
	 * 
	 * @param array<string, mixed> $args Mutation args.
	 * @return string
	 */
	public static function format_mutation_summary( array $args ) {
		$id =( isset( $args['identifier'] ) ? $args['identifier'] : '' );

		if ( isset( $args['wholesale_multi_user_pricing'] ) ) {
			return sprintf(
				/* translators: %s: product identifier */
				__( 'Update wholesale pricing on product %s', 'woocommerce-wholesale-pricing' ),
				$id
			);
		}

		if ( isset( $args['meta'] ) && is_array( $args['meta'] ) ) {
			$key = (string) array_key_first( $args['meta'] );

			foreach ( self::get_entries() as $entry ) {
				if ( ( ( isset( $entry['key'] ) ? $entry['key'] : '' ) ) === $key ) {
					return sprintf(
						/* translators: 1: field label, 2: product identifier */
						__( 'Update %1$s on product %2$s', 'woocommerce-wholesale-pricing' ),
						$entry['label'],
						$id
					);
				}
			}
		}

		return sprintf(
			/* translators: %s: product identifier */
			__( 'Update product %s', 'woocommerce-wholesale-pricing' ),
			$id
		);
	}
}
