<?php
/**
 * Request-scoped context for AI chat executions (prompt/model/history ids).
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Tracks orchestration metadata while abilities execute.
 */
class ChatExecutionContext {

	/**
	 * Whether a chat execution scope is active.
	 *
	 * @var bool
	 */
	private static $active = false;

	/**
	 * User prompt for the current chat turn.
	 *
	 * @var string
	 */
	private static $prompt = '';

	/**
	 * Model id for the current chat turn.
	 *
	 * @var string
	 */
	private static $model = '';

	/**
	 * Recorded change history row ids from this turn.
	 *
	 * @var list<int>
	 */
	private static $applied_changes = array();

	/**
	 * Begin a chat execution scope.
	 *
	 * @param string $prompt User message.
	 * @param string $model  Selected model id.
	 * @return void
	 */
	public static function begin( $prompt, $model ) {
		self::$active          = true;
		self::$prompt          = $prompt;
		self::$model           = $model;
		self::$applied_changes = array();
	}

	/**
	 * End the current chat execution scope.
	 *
	 * @return void
	 */
	public static function end() {
		self::$active          = false;
		self::$prompt          = '';
		self::$model           = '';
		self::$applied_changes = array();
	}

	/**
	 * Whether chat execution context is active.
	 *
	 * @return bool
	 */
	public static function is_active() {
		return self::$active;
	}

	/**
	 * Current user prompt.
	 *
	 * @return string
	 */
	public static function get_prompt() {
		return self::$prompt;
	}

	/**
	 * Current model id.
	 *
	 * @return string
	 */
	public static function get_model() {
		return self::$model;
	}

	/**
	 * Track a recorded change history row.
	 *
	 * @param int $history_id Row id.
	 * @return void
	 */
	public static function add_applied_change( $history_id ) {
		if ( $history_id > 0 ) {
			self::$applied_changes[] = $history_id;
		}
	}

	/**
	 * Applied change history ids for the active turn.
	 *
	 * @return list<array{history_id: int}>
	 */
	public static function get_applied_changes() {
		return array_map(
			static function ( $history_id ) {
				return array( 'history_id' => $history_id );
			},
			array_values( array_unique( self::$applied_changes ) )
		);
	}
}
