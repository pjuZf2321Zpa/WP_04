<?php
/**
 * Resolves enabled AI assistant abilities for chat orchestration.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities\AbilityCatalog;

/**
 * Maps settings toggles to registered WordPress abilities.
 */
class ChatAbilityRegistryService {

	/**
	 * Settings service.
	 *
	 * @var SettingsService
	 */
	private $settings_service;

	/**
	 * Constructor.
	 *
	 * @param SettingsService|null $settings_service Optional settings service.
	 */
	public function __construct( $settings_service = null ) {
		$this->settings_service =( isset( $settings_service ) ? $settings_service : new SettingsService() );
	}

	/**
	 * Get enabled WP_Ability instances for chat.
	 *
	 * @return list<\WP_Ability>
	 */
	public function get_enabled_abilities() {
		if ( ! function_exists( 'wp_get_ability' ) ) {
			return array();
		}

		$settings  = $this->settings_service->get_settings();
		$abilities = is_array(( isset( $settings['abilities'] ) ? $settings['abilities'] : null )) ? $settings['abilities'] : array();
		$enabled   = array();

		foreach ( AbilityCatalog::get_active_keys() as $key ) {
			if ( empty( $abilities[ $key ] ) ) {
				continue;
			}

			$ability_name = 'woocommerce-wholesale-pricing/' . str_replace( '_', '-', $key );
			$ability      = wp_get_ability( $ability_name );

			if ( $ability instanceof \WP_Ability ) {
				$enabled[] = $ability;
			}
		}

		return $enabled;
	}

	/**
	 * Settings keys for abilities enabled in chat.
	 *
	 * @return list<string>
	 */
	public function get_enabled_ability_keys() {
		$settings  = $this->settings_service->get_settings();
		$abilities = is_array(( isset( $settings['abilities'] ) ? $settings['abilities'] : null )) ? $settings['abilities'] : array();
		$enabled   = array();

		foreach ( AbilityCatalog::get_active_keys() as $key ) {
			if ( ! empty( $abilities[ $key ] ) ) {
				$enabled[] = $key;
			}
		}

		return $enabled;
	}

	/**
	 * Human-readable labels for enabled abilities.
	 *
	 * @return list<string>
	 */
	public function get_enabled_ability_labels() {
		return array_map(
			static function ( \WP_Ability $ability ) {
				return $ability->get_label();
			},
			$this->get_enabled_abilities()
		);
	}

	/**
	 * Labels for catalog abilities that are toggled off in settings.
	 *
	 * @return list<string>
	 */
	public function get_disabled_ability_labels() {
		$labels = array();

		foreach ( $this->get_disabled_active_abilities() as $key ) {
			$labels[] = $this->get_ability_label_by_key( $key );
		}

		return $labels;
	}

	/**
	 * Ability keys that exist in the catalog but are disabled in settings.
	 *
	 * @return list<string>
	 */
	public function get_disabled_active_abilities() {
		$settings  = $this->settings_service->get_settings();
		$abilities = is_array(( isset( $settings['abilities'] ) ? $settings['abilities'] : null )) ? $settings['abilities'] : array();
		$disabled  = array();

		foreach ( AbilityCatalog::get_active_keys() as $key ) {
			if ( empty( $abilities[ $key ] ) ) {
				$disabled[] = $key;
			}
		}

		return $disabled;
	}

	/**
	 * Human-readable label for an ability settings key.
	 *
	 * @param string $key Ability settings key.
	 * @return string
	 */
	public function get_ability_label_by_key( $key ) {
		$ability_name = 'woocommerce-wholesale-pricing/' . str_replace( '_', '-', $key );
		$ability      = function_exists( 'wp_get_ability' ) ? wp_get_ability( $ability_name ) : null;

		if ( $ability instanceof \WP_Ability ) {
			return $ability->get_label();
		}

		return ucwords( str_replace( '_', ' ', $key ) );
	}
}
