<?php
/**
 * Orchestrates AI chat turns with permission-aware ability execution.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

use WordPress\AiClient\Messages\DTO\Message;
use WordPress\AiClient\Messages\DTO\MessagePart;
use WordPress\AiClient\Messages\DTO\UserMessage;

/**
 * Runs the AI prompt loop and persists ephemeral session state.
 */
class ChatOrchestratorService {

	/**
	 * Maximum tool-call loop iterations.
	 */
	const MAX_ITERATIONS = 5;

	/**
	 * Settings service.
	 *
	 * @var SettingsService
	 */
	private $settings_service;

	/**
	 * Ability registry service.
	 *
	 * @var ChatAbilityRegistryService
	 */
	private $ability_registry;

	/**
	 * Session store.
	 *
	 * @var ChatSessionStore
	 */
	private $session_store;

	/**
	 * Pending action service.
	 *
	 * @var PendingActionService
	 */
	private $pending_service;

	/**
	 * Connector service.
	 *
	 * @var ConnectorService
	 */
	private $connector_service;

	/**
	 * Constructor.
	 *
	 * @param SettingsService|null            $settings_service  Optional settings service.
	 * @param ChatAbilityRegistryService|null $ability_registry  Optional ability registry.
	 * @param ChatSessionStore|null           $session_store     Optional session store.
	 * @param PendingActionService|null       $pending_service   Optional pending service.
	 * @param ConnectorService|null           $connector_service Optional connector service.
	 */
	public function __construct(
		$settings_service = null,
		$ability_registry = null,
		$session_store = null,
		$pending_service = null,
		$connector_service = null
	) {
		$this->settings_service  =( isset( $settings_service ) ? $settings_service : new SettingsService() );
		$this->ability_registry  =( isset( $ability_registry ) ? $ability_registry : new ChatAbilityRegistryService( $this->settings_service ) );
		$this->session_store     =( isset( $session_store ) ? $session_store : new ChatSessionStore() );
		$this->pending_service   =( isset( $pending_service ) ? $pending_service : new PendingActionService( $this->session_store ) );
		$this->connector_service =( isset( $connector_service ) ? $connector_service : new ConnectorService( $this->settings_service ) );
	}

	/**
	 * Handle a user chat message.
	 *
	 * @param string $session_id Session id.
	 * @param string $message    User message.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function handle_message( $session_id, $message ) {
		$message = trim( $message );

		if ( '' === $session_id ) {
			return new \WP_Error(
				'wwp_ai_chat_missing_session',
				__( 'A chat session id is required.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( '' === $message ) {
			return new \WP_Error(
				'wwp_ai_chat_empty_message',
				__( 'Please enter a message.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( ! function_exists( 'wp_ai_client_prompt' ) || ! class_exists( '\WP_AI_Client_Ability_Function_Resolver' ) ) {
			return new \WP_Error(
				'wwp_ai_chat_unavailable',
				__( 'WordPress AI Client is not available on this site.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 503 )
			);
		}

		if ( ! function_exists( 'wp_supports_ai' ) || ! wp_supports_ai() ) {
			return new \WP_Error(
				'wwp_ai_chat_disabled',
				__( 'AI features are not supported in this environment.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 503 )
			);
		}

		$settings = $this->settings_service->get_settings();

		if ( empty( $settings['enabled'] ) ) {
			return new \WP_Error(
				'wwp_ai_chat_disabled',
				__( 'The AI Assistant is disabled.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		$this->settings_service->maybe_migrate_active_providers(
			$this->connector_service->get_configured_provider_ids()
		);

		if ( ! $this->connector_service->has_any_active_provider() ) {
			ChatAiLogger::log(
				'chat_provider_check_failed',
				array(
					'session_id'          => $session_id,
					'configured_providers'=> $this->connector_service->get_configured_provider_ids(),
					'active_providers'    => $this->settings_service->get_active_providers(),
					'connected_providers' => $this->connector_service->get_connected_providers(),
				),
				'warning'
			);

			return new \WP_Error(
				'wwp_ai_chat_no_provider',
				__( 'Connect an AI provider in AI Assistant settings before chatting.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$abilities = $this->ability_registry->get_enabled_abilities();

		if ( empty( $abilities ) ) {
			return new \WP_Error(
				'wwp_ai_chat_no_abilities',
				__( 'Enable at least one AI ability in settings before chatting.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$abilities_map = is_array(( isset( $settings['abilities'] ) ? $settings['abilities'] : null )) ? $settings['abilities'] : array();
		$permission    = (string) ( ( isset( $settings['permission'] ) ? $settings['permission'] : 'approval' ) );
		$required_key  = ChatAbilityIntentMatcher::match( $message );

		if ( $required_key && empty( $abilities_map[ $required_key ] ) ) {
			$label = $this->ability_registry->get_ability_label_by_key( $required_key );
			$reply = sprintf(
				/* translators: %s: ability label */
				__( 'The "%s" ability is disabled. Enable it in AI Assistant settings (Abilities) to perform this action.', 'woocommerce-wholesale-pricing' ),
				$label
			);

			ChatAiLogger::log(
				'ability_disabled_short_circuit',
				array(
					'session_id'    => $session_id,
					'ability_key'   => $required_key,
					'ability_label' => $label,
					'user_message'  => $message,
				),
				'info'
			);

			return $this->build_direct_reply( $session_id, $message, $reply, $permission, array(
				'ability_required' => $required_key,
			) );
		}

		$model   = (string) ( ( isset( $settings['model'] ) ? $settings['model'] : '' ) );
		$_wwp_nc = $this->session_store->load( $session_id );
		$session =( null !== ( $_wwp_nc ) ? $_wwp_nc : array(
			'ui_messages' => array(),
			'ai_history'  => array(),
		) );

		$ui_messages = is_array(( isset( $session['ui_messages'] ) ? $session['ui_messages'] : null )) ? $session['ui_messages'] : array();
		$ai_history  = ChatHistorySanitizer::sanitize(
			$this->deserialize_messages(( isset( $session['ai_history'] ) ? $session['ai_history'] : array() ))
		);

		$ui_messages[] = array(
			'role'       => 'user',
			'content'    => $message,
			'created_at' => gmdate( 'c' ),
		);

		$ai_history[] = new UserMessage( array( new MessagePart( $message ) ) );

		$gate = new PermissionAwareAbilityResolver( $abilities, $permission, $session_id, $this->pending_service );
		$gate->reset_pending_actions();

		ChatExecutionContext::begin( $message, $model );

		ChatAiLogger::log(
			'chat_started',
			array(
				'session_id'     => $session_id,
				'permission'     => $permission,
				'model'          => $model,
				'user_message'   => $message,
				'abilities'      => array_map(
					static function ( \WP_Ability $ability ) {
						return $ability->get_name();
					},
					$abilities
				),
			),
			'info'
		);

		try {
			$reply           = '';
			$pending_actions = array();
			$collected_steps = array();
			$history         = ChatHistorySanitizer::sanitize( $ai_history );
			$intent_hint    = '';
			$matched_key    = $required_key;

			if ( $matched_key && ! empty( $abilities_map[ $matched_key ] ) ) {
				$prefetch_data = $this->prefetch_ability_data( $matched_key );

				ChatAiLogger::log(
					'intent_prefetch',
					array(
						'session_id'    => $session_id,
						'ability_key'   => $matched_key,
						'user_message'  => $message,
						'prefetch_data' => $prefetch_data,
					),
					'info'
				);

				$intent_hint = ChatIntentHintBuilder::build(
					$message,
					$matched_key,
					is_array( $prefetch_data ) ? $prefetch_data : array(),
					$permission
				);
			}

			$system_prompt  = $this->build_system_prompt( $permission, $settings, $intent_hint );

			for ( $iteration = 0; $iteration < self::MAX_ITERATIONS; $iteration++ ) {
				$history = ChatHistorySanitizer::repair_tool_pairs( $history );

				$builder = wp_ai_client_prompt()
					->using_system_instruction( $system_prompt )
					->with_history( ...$history )
					->using_abilities( ...$abilities );

				if ( '' !== $model ) {
					$builder = $builder->using_model_preference( $model );
				}

				$result = $builder->generate_result();

				if ( is_wp_error( $result ) ) {
					ChatAiLogger::log(
						'ai_generation_error',
						array(
							'session_id' => $session_id,
							'iteration'  => $iteration,
							'model'      => $model,
							'error'      => array(
								'code'    => $result->get_error_code(),
								'message' => $result->get_error_message(),
								'data'    => $result->get_error_data(),
							),
						),
						'error'
					);
					return $result;
				}

				$had_tool_calls  = false;
				$candidate_reply = '';

				foreach ( $result->toMessages() as $candidate_message ) {
					foreach ( ChatHistorySanitizer::expand_tool_messages( $candidate_message ) as $model_message ) {
						$model_message = ChatHistorySanitizer::ensure_model_message_call_ids( $model_message );
						$history[]     = $model_message;

						if ( ! $gate->has_ability_calls( $model_message ) ) {
							$candidate_text = $this->extract_text_from_message( $model_message );
							if ( '' !== $candidate_text ) {
								$candidate_reply = $candidate_text;
							}
							continue;
						}

						$had_tool_calls      = true;
						$response_messages   = $gate->resolve_messages( $model_message );
						$expected_responses  = 0;

						foreach ( $model_message->getParts() as $part ) {
							if ( $part->getType()->isFunctionCall() ) {
								++$expected_responses;
							}
						}

						if ( count( $response_messages ) < $expected_responses ) {
							$resolved_ids = array();

							foreach ( $response_messages as $response_message ) {
								foreach ( $response_message->getParts() as $part ) {
									if ( ! $part->getType()->isFunctionResponse() ) {
										continue;
									}

									$response = $part->getFunctionResponse();
									if ( $response instanceof \WordPress\AiClient\Tools\DTO\FunctionResponse ) {
										$response_id = $response->getId();
										if ( is_string( $response_id ) && '' !== $response_id ) {
											$resolved_ids[ $response_id ] = true;
										}
									}
								}
							}

							foreach ( $model_message->getParts() as $part ) {
								if ( ! $part->getType()->isFunctionCall() ) {
									continue;
								}

								$call = $part->getFunctionCall();
								if ( ! $call instanceof \WordPress\AiClient\Tools\DTO\FunctionCall ) {
									continue;
								}

								$call_id = ChatHistorySanitizer::resolve_call_id( $call );
								if ( isset( $resolved_ids[ $call_id ] ) ) {
									continue;
								}

								$response_messages[] = new UserMessage(
									array(
										new MessagePart(
											new \WordPress\AiClient\Tools\DTO\FunctionResponse(
												$call_id,
												$call->getName(),
												array(
													'status'  => 'error',
													'code'    => 'tool_resolution_failed',
													'message' => __( 'The tool call could not be resolved.', 'woocommerce-wholesale-pricing' ),
												)
											)
										),
									)
								);
							}
						}

						foreach ( $response_messages as $response_message ) {
							$history[] = $response_message;
						}

						$new_steps       = $gate->get_pending_steps();
						$collected_steps = array_merge( $collected_steps, $new_steps );
						$gate->reset_pending_actions();
					}
				}

				$history = ChatHistorySanitizer::repair_tool_pairs( $history );

				ChatAiLogger::log(
					'ai_iteration',
					array(
						'session_id'        => $session_id,
						'iteration'         => $iteration,
						'has_ability_calls' => $had_tool_calls,
						'candidate_reply'   => $candidate_reply,
						'history_count'     => count( $history ),
					)
				);

				if ( ! $had_tool_calls ) {
					if ( '' !== $candidate_reply ) {
						$reply = $candidate_reply;
					} else {
						try {
							$reply = $result->toText();
						} catch ( \Throwable $e ) {
							$reply = __( 'I completed the request.', 'woocommerce-wholesale-pricing' );
						}
					}
					break;
				}

				ChatAiLogger::log(
					'ability_responses',
					array(
						'session_id'      => $session_id,
						'iteration'       => $iteration,
						'pending_actions' => $pending_actions,
					)
				);
			}

			if ( '' === $reply ) {
				try {
					$reply = end( $history ) instanceof Message
						? $this->extract_text_from_message( end( $history ) )
						: __( 'I need more information to continue.', 'woocommerce-wholesale-pricing' );
				} catch ( \Throwable $e ) {
					$reply = __( 'I need more information to continue.', 'woocommerce-wholesale-pricing' );
				}
			}

			if ( 'approval' === $permission ) {
				$had_tool_steps  = ! empty( $collected_steps );
				$fallback_steps  = $had_tool_steps
					? array()
					: ChatIntentHintBuilder::resolve_all_mutation_steps( $message );
				$collected_steps = PendingActionService::merge_unique_steps( $collected_steps, $fallback_steps );

				if ( ! empty( $collected_steps ) ) {
					$batch = $this->pending_service->create_batch( $session_id, $collected_steps );

					if ( is_array( $batch ) ) {
						$pending_actions = array( PendingActionService::to_card_payload( $batch ) );
						$reply           = $this->strip_confirmation_prompt( $reply );

						ChatAiLogger::log(
							'pending_action_batch',
							array(
								'session_id' => $session_id,
								'steps'      => $collected_steps,
								'pending_id' => ( isset( $batch['pending_id'] ) ? $batch['pending_id'] : '' ),
								'source'     => $had_tool_steps ? 'tool_calls' : 'intent_fallback',
							),
							'info'
						);
					} elseif ( is_wp_error( $batch ) ) {
						$error_note = sprintf(
							/* translators: %s: error message */
							__( "I couldn't queue that change: %s", 'woocommerce-wholesale-pricing' ),
							$batch->get_error_message()
						);
						$reply = trim( $reply . "\n\n" . $error_note );

						ChatAiLogger::log(
							'pending_action_batch_failed',
							array(
								'session_id' => $session_id,
								'steps'      => $collected_steps,
								'error'      => array(
									'code'    => $batch->get_error_code(),
									'message' => $batch->get_error_message(),
									'data'    => $batch->get_error_data(),
								),
							),
							'error'
						);
					}
				}
			}

			$assistant_message = array(
				'role'       => 'assistant',
				'content'    => $reply,
				'created_at' => gmdate( 'c' ),
			);

			if ( ! empty( $pending_actions ) ) {
				$assistant_message['pending_actions'] = $pending_actions;
			}

			$ui_messages[] = $assistant_message;

			$applied_changes = ChatExecutionContext::get_applied_changes();

			$this->session_store->save(
				$session_id,
				array(
					'ui_messages' => $ui_messages,
					'ai_history'  => $this->serialize_messages( $history ),
				)
			);

			ChatAiLogger::log(
				'chat_completed',
				array(
					'session_id'      => $session_id,
					'reply'           => $reply,
					'pending_actions' => array_values( $pending_actions ),
					'applied_changes' => $applied_changes,
				),
				'info'
			);

			return array(
				'reply'           => $reply,
				'messages'        => $ui_messages,
				'pending_actions' => array_values( $pending_actions ),
				'applied_changes' => $applied_changes,
				'session_id'      => $session_id,
				'permission'      => $permission,
			);
		} finally {
			ChatExecutionContext::end();
		}
	}

	/**
	 * Restore UI messages for a session.
	 *
	 * @param string $session_id Session id.
	 * @return array<string, mixed>
	 */
	public function get_session( $session_id ) {
		if ( '' === $session_id ) {
			return array(
				'session_id' => '',
				'messages'   => array(),
			);
		}

		$session = $this->session_store->load( $session_id );

		return array(
			'session_id' => $session_id,
			'messages'   => is_array(( isset( $session['ui_messages'] ) ? $session['ui_messages'] : null )) ? $session['ui_messages'] : array(),
		);
	}

	/**
	 * Clear a chat session.
	 *
	 * @param string $session_id Session id.
	 * @return bool
	 */
	public function clear_session( $session_id ) {
		return $this->session_store->clear( $session_id );
	}

	/**
	 * Build permission-specific system instructions.
	 *
	 * @param string               $permission  Permission mode.
	 * @param array<string, mixed> $settings    Assistant settings.
	 * @param string               $intent_hint Optional intent routing hint.
	 * @return string
	 */
	private function build_system_prompt( $permission, array $settings, $intent_hint = '' ) {

		// ── Abilities ──────────────────────────────────────────────────────────
		$enabled_abilities  = $this->ability_registry->get_enabled_ability_labels();
		$disabled_abilities = $this->ability_registry->get_disabled_ability_labels();
	
		$enabled_list  = ! empty( $enabled_abilities )
			? implode( ', ', $enabled_abilities )
			: __( 'None', 'woocommerce-wholesale-pricing' );
	
		$disabled_list = ! empty( $disabled_abilities )
			? implode( ', ', $disabled_abilities )
			: __( 'None', 'woocommerce-wholesale-pricing' );
	
		// ── Site context ───────────────────────────────────────────────────────
		$site_name = get_bloginfo( 'name' );
		$site_url  = get_site_url();
	
		// ── Build prompt sections ──────────────────────────────────────────────
		$lines = array();
	
		// 1. Identity & role
		$lines[] = sprintf(
			/* translators: %s: Comma-separated site name and site url. */
			__( 'You are the AI Assistant for the WooCommerce Wholesale Pricing plugin on %1$s (%2$s). You help store administrators manage their B2B wholesale store by using the registered tools/abilities available to you.', 'woocommerce-wholesale-pricing' ),
			$site_name,
			$site_url
		);
	
		// 2. Core behavioral rules
		$lines[] = __( 'CORE BEHAVIOR RULES (follow these strictly):
	- When a user asks for data, analytics, reports, or information: IMMEDIATELY call the relevant read tool. Do NOT ask the user what data they want — fetch it and present it.
	- When a user asks to make a change: follow the permission mode rules below exactly.
	- Never say "I cannot do that" if an enabled tool exists for the task. Use the tool.
	- Never ask the user to "provide" data that a tool can fetch for you.
	- If a request is ambiguous between two abilities, pick the most likely one, execute it, and present results. You can clarify after.
	- Always present tool results in clean readable markdown: tables for lists, bold for key values, inline code for IDs and slugs.
	- Use exact values returned by tools for currency, numbers, IDs, and slugs — never round or guess.
	- NEVER ask the admin for information that a tool can fetch. If you genuinely need the current value of a setting before changing it, call the read tool first, read the value, then proceed. Example: admin says "Enable Requisition List" → WRONG: "Could you tell me if it is currently enabled?" → RIGHT: set the Requisition List setting to enabled and proceed per the permission mode.
	- For any "enable X" / "disable X" / "set X to Y" request the intent is explicit — execute or queue the change directly. Do not fetch current state first unless you need the existing value to compute the new one (e.g. incrementing a number). For boolean toggles, "enable" always means true and "disable" always means false; no read call is needed before a boolean mutation.
	- If a required ability is disabled, do not attempt the action. Tell the user exactly which ability to enable and where: AI Assistant → Abilities → [Ability Name].', 'woocommerce-wholesale-pricing' );
	
		// 3. Plugin domain context
		$lines[] = __( 'PLUGIN DOMAIN CONTEXT:
	This plugin manages a WooCommerce B2B wholesale store. You have knowledge of:
	- Dashboard & Analytics: B2B revenue metrics, order counts, AOV, top products, top customers, refunds, registrations
	- Wholesale Settings: core plugin configuration across all settings tabs
	- Global Pricing & Discounts: per-role wholesale pricing, tier pricing, min quantity/subtotal thresholds
	- Cart Total Discounts: cart-level discount rules and tier discount ranges per role
	- B2B User Roles: custom wholesale role taxonomy with tax, coupon, payment, and shipping restrictions
	- Email Notifications: wholesale registration, subscription upgrade, and quote email templates
	- Registration Settings: registration form fields and reCAPTCHA configuration
	- Products: WooCommerce product CRUD with per-product per-role wholesale pricing
	- Categories: WooCommerce category CRUD with per-category per-role wholesale pricing
	- Account Requests: review and approve/reject wholesale registration applications
	- B2B User Profiles: WordPress user CRUD with wholesale role assignment and meta management
	- Quote Settings: general quote and quote PDF configuration
	- Quote Rules: rules governing which users/products trigger quote flow instead of checkout
	- Quotes: view and update existing quote records and statuses', 'woocommerce-wholesale-pricing' );
	
		// 4. Proactive tool usage patterns
		$lines[] = __( 'HOW TO HANDLE COMMON REQUEST TYPES:
	
	User asks for dashboard / analytics / reports / summary:
	→ Immediately call the dashboard analytics tool with default date range (last 30 days unless specified).
	→ Present: Net B2B Total, Gross B2B Total, Order Count, AOV, top 5 products, top 5 customers.
	→ Do NOT ask "what metrics would you like?" — fetch all and present them.
	
	User asks about revenue / sales / orders over a date range:
	→ Call dashboard analytics tool with the specified date range.
	→ If no date range given, default to last 30 days and state this in your response.
	
	User asks to enable / disable / toggle a setting ("Enable X", "Turn on X", "Activate X", "Disable X", "Turn off X"):
	→ The intent is explicit. Do NOT ask whether it is currently on or off, and do NOT read it first just to check its state.
	→ "Enable / Turn on / Activate X" always means set X to true. "Disable / Turn off X" always means set X to false.
	→ Proceed immediately per permission mode: Auto mode → call the update tool now; Approval mode → call the update tool so the approval card appears; Suggest mode → give manual steps only.

	User asks to set a setting to a specific value (non-boolean, e.g. "set discount to 15%"):
	→ If the new value is absolute, proceed directly per permission mode — no read needed.
	→ Only call the read tool first if you need the existing value to compute the new one (e.g. "increase the discount by 5%").
	→ Present current value → proposed value when it helps the admin understand the change.
	
	User asks about a wholesale user / customer:
	→ Call the user profile read tool with their name, email, or ID.
	→ Present their profile, roles, and meta in a clean summary.
	
	User asks to approve / reject a registration request:
	→ Call the list requests tool filtered by pending status.
	→ Present applicant details, then follow permission mode rules before executing.
	
	User asks about a quote:
	→ Call the quote list tool, filter by customer or status as relevant.
	→ Present quote summary. Follow permission mode rules before any update.
	
	User asks about pricing for a role or product:
	→ Determine scope: product-level, category-level, or global.
	→ Call the relevant read tool, present current pricing structure clearly in a table.', 'woocommerce-wholesale-pricing' );
	
		// 5. Enabled / disabled abilities
		$lines[] = sprintf(
			/* translators: %s: Comma-separated list of enabled AI assistant abilities. */
			__( 'ENABLED ABILITIES (you may use these tools now): %s', 'woocommerce-wholesale-pricing' ),
			$enabled_list
		);
		$lines[] = sprintf(
			/* translators: %s: Comma-separated list of disabled AI assistant abilities. */
			__( 'DISABLED ABILITIES (do NOT attempt these — tell user to enable at AI Assistant → Abilities): %s', 'woocommerce-wholesale-pricing' ),
			$disabled_list
		);
	
		// 6. Permission mode
		if ( 'suggest' === $permission ) {
	
			$lines[] = __( 'PERMISSION MODE: Suggestion Only
	
	Your role in this mode is to be an intelligent advisor — not an executor.
	
	WHAT YOU DO:
	- Answer questions, explain settings, and provide recommendations based on what the admin asks.
	- You MAY call read-only tools (get/list/dashboard) to fetch live data to support your answers.
	- You MUST NOT call any tool that creates, updates, or deletes anything — ever.
	
	WHAT YOU DO WHEN A CHANGE IS REQUESTED:
	- Do NOT execute the change.
	- Do NOT call any mutation tool.
	- Instead, respond with a clear explanation of what the change would do, then provide exact manual navigation steps so the admin can do it themselves.
	
	FORMAT FOR MANUAL STEPS:
	"To apply this change manually:
	1. Go to Wholesale → [Menu] → [Sub-menu]
	2. Find the [Setting Name] field
	3. Set it to [Value]
	4. Click Save"
	
	EXAMPLES:
	- Admin asks "change the discount for the Retailer role to 15%" → Do NOT update. Explain the change, then give manual steps to Wholesale → Settings → Global Wholesale Pricing → Retailer Role → Discount Value.
	- Admin asks "approve this registration request" → Do NOT approve. Give manual steps to Wholesale → Requests → [Applicant Name] → Approve.
	- Admin asks "show me the dashboard" → Fetch and display analytics data (read-only is allowed).', 'woocommerce-wholesale-pricing' );
	
		} elseif ( 'approval' === $permission ) {
	
		$lines[] = __( 'PERMISSION MODE: Apply After Approval

In this mode, read operations run immediately, but every change must be confirmed by the admin through an approval card rendered in the chat panel.

FOR READ REQUESTS (analytics, get, list, dashboard):
- Execute the read tool immediately and present the results. No approval needed.

FOR MUTATION REQUESTS (create, update, delete, approve, reject, assign):
- Write a 1-2 sentence plain-English explanation of what you are about to do (e.g. "I will enable the Requisition List setting for you.").
- Then CALL the appropriate mutation tool with the exact, complete arguments you intend to apply.
- The system automatically intercepts that tool call, holds it, and shows the admin an approval card with Approve and Deny buttons. Calling the tool only QUEUES the change — it is not executed until the admin clicks Approve.
- Provide every required argument so the queued action is ready to run as-is. Never queue an action with placeholder, guessed, or missing values.

WHAT NOT TO DO IN THIS MODE:
- Do NOT print "APPROVE/DENY" instructions or ask the admin to reply with APPROVE — the card buttons handle confirmation.
- Do NOT print the action as a JSON or code block in your reply. Express the action only by calling the tool.
- Do NOT wait for a text "APPROVE" reply before calling the tool. Calling the tool IS how you request approval.
- Do NOT ask "Would you like me to proceed?", "Shall I apply this?", or any similar confirmation question — the Approve button on the card is the only confirmation.
- Do NOT execute the change yourself or claim it is done — the admin must approve it first.

IMPORTANT RULES:
- When the admin requests multiple fields or settings within the same ability (e.g. enable two registration form fields), make ONE mutation tool call whose settings object includes ALL requested changes.
- When the admin requests changes across different abilities, you may make multiple mutation tool calls in the same response; the system batches them into one approval card.
- Never tell the admin that a second field must wait for a separate approval if it belongs to the same settings update.
- For bulk actions (e.g. "approve all pending requests"): read the list first, then make a single mutation tool call that covers them so one approval card represents the batch.', 'woocommerce-wholesale-pricing' );
	
		} else {
	
			$lines[] = __( 'PERMISSION MODE: Auto Apply
	
	In this mode you have full execution authority. Act decisively and efficiently.
	
	FOR ALL REQUESTS (read or mutation):
	- Execute the appropriate tool immediately without asking for approval.
	- Read operations: fetch and present results directly.
	- Mutation operations (create, update, delete): execute and confirm what was done.
	
	AFTER EXECUTING A MUTATION:
	- Always confirm completion with a brief summary: "Done — [what was changed / created / deleted]."
	- Show the result (new value, created ID, updated record) so the admin can verify.
	
	EXCEPTION — DESTRUCTIVE BULK ACTIONS:
	For actions that cannot be undone and affect multiple records simultaneously (e.g. "delete all rejected requests", "remove wholesale role from all users"), apply a single lightweight confirmation before executing:
	- State: "This will [action] [count] records permanently. Executing now — reply STOP within 10 seconds to cancel."
	- Then proceed. This is not a hard approval gate — it is a brief warning only.
	- For single-record deletions (delete one product, remove one user): no confirmation needed. Execute directly.
	
	TONE:
	- Be efficient and direct. Do not over-explain or pad responses.
	- Lead with the result, follow with details if needed.', 'woocommerce-wholesale-pricing' );
	
		}
	
		// 7. Response format
		$lines[] = __( 'RESPONSE FORMAT:
	- Use markdown: ## headings for sections, **bold** for key values, tables for lists of data.
	- For analytics/reports: lead with a headline metric summary, then break into sections.
	- For settings: show current value → proposed value in a clear before/after format.
	- For lists (users, quotes, requests): use a table with the most important columns.
	- Keep responses concise. Do not pad with unnecessary explanation.
	- Never expose raw PHP arrays, option keys, or internal identifiers unless the admin specifically asks.', 'woocommerce-wholesale-pricing' );
	
		// 7. Ability data reference for enabled tools
		$data_reference = ChatIntentHintBuilder::build_data_reference(
			$this->ability_registry->get_enabled_ability_keys()
		);

		if ( '' !== $data_reference ) {
			$lines[] = $data_reference;
		}

		// 8. Optional intent hint
		if ( '' !== $intent_hint ) {
			$lines[] = $intent_hint;
		}

		// 9. Site environment from plugin context
		$scope_lines = ChatPluginContext::get_scope_lines();
		if ( ! empty( $scope_lines ) ) {
			$lines[] = __( 'SITE ENVIRONMENT:', 'woocommerce-wholesale-pricing' );
			$lines   = array_merge( $lines, $scope_lines );
		}
	
		return implode( "\n\n", $lines );
	}

	/**
	 * Prefetch read-only ability data for intent routing.
	 *
	 * @param string $ability_key Ability settings key.
	 * @return array<string, mixed>|null
	 */
	private function prefetch_ability_data( $ability_key ) {
		if ( ! function_exists( 'wp_get_ability' ) ) {
			return null;
		}

		$prefetch_input = ChatIntentHintBuilder::get_prefetch_input( $ability_key );

		if ( null === $prefetch_input ) {
			return null;
		}

		$ability_name = 'woocommerce-wholesale-pricing/' . str_replace( '_', '-', $ability_key );
		$ability      = wp_get_ability( $ability_name );

		if ( ! $ability instanceof \WP_Ability ) {
			return null;
		}

		$result = $ability->execute( $prefetch_input );

		if ( is_wp_error( $result ) ) {
			return null;
		}

		return is_array( $result ) ? $result : array(
			'result' => $result,
		);
	}

	/**
	 * Deserialize stored AI history arrays into Message objects.
	 *
	 * @param mixed $stored Stored history.
	 * @return list<Message>
	 */
	private function deserialize_messages( $stored ) {
		if ( ! is_array( $stored ) ) {
			return array();
		}

		$messages = array();

		foreach ( $stored as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			try {
				$messages[] = Message::fromArray( $item );
			} catch ( \Throwable $e ) {
				continue;
			}
		}

		return $messages;
	}

	/**
	 * Serialize Message objects for storage.
	 *
	 * @param list<Message> $messages Message history.
	 * @return list<array<string, mixed>>
	 */
	private function serialize_messages( array $messages ) {
		return array_map(
			static function ( Message $message ) {
				return $message->toArray();
			},
			$messages
		);
	}

	/**
	 * Extract visible text from a message.
	 *
	 * @param Message $message Message instance.
	 * @return string
	 */
	private function extract_text_from_message( Message $message ) {
		$chunks = array();

		foreach ( $message->getParts() as $part ) {
			$text = $part->getText();

			if ( null !== $text && '' !== $text ) {
				$chunks[] = $text;
			}
		}

		return implode( "\n", $chunks );
	}

	/**
	 * Remove trailing confirmation questions when an approval card is shown.
	 *
	 * @param string $reply Assistant reply text.
	 * @return string
	 */
	private function strip_confirmation_prompt( $reply ) {
		$patterns = array(
			'/\s*(?:would you like me to proceed|shall i (?:apply|proceed|make)|do you want me to (?:proceed|apply)|would you like me to (?:apply|make))[^.?!]*[.?!]?\s*$/iu',
			'/\s*(?:please confirm|let me know if you(?:\'|’)d like me to)[^.?!]*[.?!]?\s*$/iu',
		);

		$cleaned = $reply;

		foreach ( $patterns as $pattern ) {
			$cleaned = preg_replace( $pattern, '', $cleaned );
		}

		$cleaned = trim( (string) $cleaned );

		return '' !== $cleaned ? $cleaned : $reply;
	}

	/**
	 * Build and persist a direct assistant reply without calling the AI.
	 *
	 * @param string               $session_id Session id.
	 * @param string               $message    User message.
	 * @param string               $reply      Assistant reply text.
	 * @param string               $permission Permission mode.
	 * @param array<string, mixed> $extra      Extra response fields.
	 * @return array<string, mixed>
	 */
	private function build_direct_reply( $session_id, $message, $reply, $permission, array $extra = array() ) {
		$_wwp_nc = $this->session_store->load( $session_id );
		$session =( null !== ( $_wwp_nc ) ? $_wwp_nc : array(
			'ui_messages' => array(),
			'ai_history'  => array(),
		) );

		$ui_messages = is_array(( isset( $session['ui_messages'] ) ? $session['ui_messages'] : null )) ? $session['ui_messages'] : array();
		$_wwp_nc = $ui_messages[ count( $ui_messages ) - 1 ];
		if ( empty( $ui_messages ) || 'user' !== ( ( null !== ( $_wwp_nc['role'] ) ? $_wwp_nc : '' ) ) || ( ( null !== ( $_wwp_nc['content'] ) ? $_wwp_nc : '' ) ) !== $message ) {
			$ui_messages[] = array(
				'role'       => 'user',
				'content'    => $message,
				'created_at' => gmdate( 'c' ),
			);
		}

		$assistant_message = array(
			'role'       => 'assistant',
			'content'    => $reply,
			'created_at' => gmdate( 'c' ),
		);

		$ui_messages[] = $assistant_message;

		$this->session_store->save(
			$session_id,
			array(
				'ui_messages' => $ui_messages,
				'ai_history'  => is_array(( isset( $session['ai_history'] ) ? $session['ai_history'] : null )) ? $session['ai_history'] : array(),
			)
		);

		return array_merge(
			array(
				'reply'           => $reply,
				'messages'        => $ui_messages,
				'pending_actions' => array(),
				'applied_changes' => array(),
				'session_id'      => $session_id,
				'permission'      => $permission,
			),
			$extra
		);
	}
}
