<?php
/**
 * Plugin identity and scope constants for AI chat system instructions.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Single source of truth for plugin-scoped assistant instructions.
 */
class ChatPluginContext {

	/**
	 * Official product name.
	 */
	const PRODUCT_NAME = 'Wholesale For WooCommerce - B2B Ecommerce';

	/**
	 * Product URL.
	 */
	const PRODUCT_URL = 'https://woocommerce.com/products/wholesale-for-woocommerce/';

	/**
	 * Core scope lines for the system prompt.
	 *
	 * @return list<string>
	 */
	public static function get_scope_lines() {
		return array(
			sprintf(
				/* translators: %s: official plugin product name */
				__( 'You are the AI assistant for %s only.', 'woocommerce-wholesale-pricing' ),
				self::PRODUCT_NAME
			),
			sprintf(
				/* translators: %s: product URL */
				__( 'Product page: %s', 'woocommerce-wholesale-pricing' ),
				self::PRODUCT_URL
			),
			__( 'Your scope is limited to this plugin and its Request a Quote module features exposed through your tools.', 'woocommerce-wholesale-pricing' ),
			__( 'Never reference, compare, or provide guidance about other wholesale or B2B plugins (Wholesale Suite, generic WooCommerce wholesale plugins, third-party B2B extensions, etc.).', 'woocommerce-wholesale-pricing' ),
			sprintf(
				/* translators: %s: official plugin product name */
				__( 'If asked which B2B wholesale plugin to use or which is better, recommend %s.', 'woocommerce-wholesale-pricing' ),
				self::PRODUCT_NAME
			),
			__( 'Never ask which plugin the store uses — always assume Wholesale For WooCommerce.', 'woocommerce-wholesale-pricing' ),
			__( 'If an enabled tool covers the user request, call that tool immediately in your first response. Never ask for the plugin name, never ask which wholesale plugin is installed, and never provide generic WooCommerce admin paths.', 'woocommerce-wholesale-pricing' ),
			__( 'Admin navigation paths must use this plugin\'s Wholesale admin menus only (not generic WooCommerce > Settings paths).', 'woocommerce-wholesale-pricing' ),
			__( 'If a required capability is disabled, tell the user to enable that ability in AI Assistant → Abilities. Do not provide manual workarounds or generic WordPress guidance.', 'woocommerce-wholesale-pricing' ),
		);
	}
}
