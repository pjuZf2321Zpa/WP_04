<?php
/**
 * Aggregates per-ability admin setting catalogs for AI intent routing.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Single registry for catalog keywords, hints, and mutation resolution.
 */
class AdminSettingsRegistry {

	/**
	 * Ability key => catalog class map.
	 *
	 * @var array<string, class-string>
	 */
	const CATALOG_MAP = array(
		'wholesale_settings'            => WholesaleSettingsCatalog::class,
		'wholesale_registration'        => RegistrationFieldCatalog::class,
		'wholesale_email_notifications' => EmailNotificationCatalog::class,
		'quote_settings'                => QuoteSettingsCatalog::class,
		'woocommerce_products'          => ProductFieldCatalog::class,
		'woocommerce_categories'        => CategoryFieldCatalog::class,
		'b2b_user_roles'                => RoleFieldCatalog::class,
		'wholesale_account_requests'    => AccountRequestFieldCatalog::class,
		'quote_rules'                   => QuoteRuleFieldCatalog::class,
		'modify_update_quotes'          => ModifyQuoteFieldCatalog::class,
	);

	/**
	 * Get catalog ability keys
	 * 
	 * @return list<string>
	 */
	public static function get_catalog_ability_keys() {
		return array_keys( self::CATALOG_MAP );
	}

	/**
	 * Get matched keywords
	 * 
	 * @param string $ability_key Ability key.
	 * @return list<string>
	 */
	public static function get_matcher_keywords( $ability_key ) {
		$class =( isset( self::CATALOG_MAP[ $ability_key ] ) ? self::CATALOG_MAP[ $ability_key ] : null );

		if ( null === $class || ! method_exists( $class, 'get_matcher_keywords' ) ) {
			return array();
		}

		return $class::get_matcher_keywords();
	}

	/**
	 * Get hint lines
	 * 
	 * @param string $ability_key Ability key.
	 * @return list<string>
	 */
	public static function get_hint_lines( $ability_key ) {
		$class =( isset( self::CATALOG_MAP[ $ability_key ] ) ? self::CATALOG_MAP[ $ability_key ] : null );

		if ( null === $class || ! method_exists( $class, 'get_hint_lines' ) ) {
			return array();
		}

		return $class::get_hint_lines();
	}

	/**
	 * Build searchable settings reference for system prompt injection.
	 *
	 * @param list<string> $ability_keys Ability keys.
	 * @return string
	 */
	public static function build_settings_search_reference( array $ability_keys ) {
		$lines = array();

		foreach ( $ability_keys as $ability_key ) {
			$hint_lines = self::get_hint_lines( $ability_key );

			if ( empty( $hint_lines ) ) {
				continue;
			}

			$lines[] = sprintf(
				'%s searchable: %s',
				$ability_key,
				implode( '; ', array_slice( $hint_lines, 0, 25 ) )
			);
		}

		if ( empty( $lines ) ) {
			return '';
		}

		return __( '--- Searchable admin settings ---', 'woocommerce-wholesale-pricing' ) . "\n"
			. implode( "\n", $lines ) . "\n"
			. __( '--- End searchable admin settings ---', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Resolve deterministic mutation args for an ability.
	 *
	 * @param string $message     Original message.
	 * @param string $normalized  Lowercased message.
	 * @param string $ability_key Ability key.
	 * @return array<string, mixed>|null
	 */
	public static function resolve_mutation_args( $message, $normalized, $ability_key ) {
		switch ( $ability_key ) {
			case 'wholesale_settings':
				$patch = WholesaleSettingsCatalog::build_combined_settings_patch( $normalized );

				if ( empty( $patch ) ) {
					$patch = WholesaleSettingsCatalog::build_settings_patch( $normalized );
				}

				if ( empty( $patch ) ) {
					return null;
				}

				return array(
					'action'   => 'update',
					'settings' => $patch,
				);

			case 'wholesale_registration':
				$patch = RegistrationFieldCatalog::build_combined_settings_patch( $normalized );

				if ( empty( $patch ) ) {
					return null;
				}

				return array(
					'action'   => 'update',
					'settings' => $patch,
				);

			case 'wholesale_email_notifications':
				$args = EmailNotificationCatalog::build_mutation_args( $normalized );

				return empty(( isset( $args['notification_key'] ) ? $args['notification_key'] : '' )) ? null : $args;

			case 'quote_settings':
				$settings = QuoteSettingsCatalog::build_mutation_settings( $normalized );

				return empty( $settings ) ? null : array(
					'action'   => 'update',
					'settings' => $settings,
				);

			case 'woocommerce_products':
				$args = ProductFieldCatalog::build_mutation_args( $message, $normalized );

				return empty( $args ) ? null : $args;

			case 'woocommerce_categories':
				$args = CategoryFieldCatalog::build_mutation_args( $message, $normalized );

				return empty( $args ) ? null : $args;

			case 'b2b_user_roles':
				$args = RoleFieldCatalog::build_mutation_args( $message, $normalized );

				return empty( $args ) ? null : $args;

			case 'wholesale_account_requests':
				$args = AccountRequestFieldCatalog::build_mutation_args( $message, $normalized );

				return empty( $args ) ? null : $args;

			case 'quote_rules':
				$args = QuoteRuleFieldCatalog::build_mutation_args( $message, $normalized );

				return empty( $args ) ? null : $args;

			case 'modify_update_quotes':
				$args = ModifyQuoteFieldCatalog::build_mutation_args( $message, $normalized );

				return empty( $args ) ? null : $args;
		}

		return null;
	}

	/**
	 * Whether a catalog can resolve a mutation from the message alone.
	 *
	 * @param string $ability_key Ability key.
	 * @param string $normalized  Lowercased message.
	 * @return bool
	 */
	public static function can_resolve_mutation( $ability_key, $normalized ) {
		switch ( $ability_key ) {
			case 'wholesale_settings':
				return ! empty( WholesaleSettingsCatalog::build_combined_settings_patch( $normalized ) )
					|| '' !== WholesaleSettingsCatalog::resolve_key_from_message( $normalized );
			case 'wholesale_registration':
				return ! empty( RegistrationFieldCatalog::resolve_all_fields_from_message( $normalized ) );
			case 'wholesale_email_notifications':
				return null !== EmailNotificationCatalog::resolve_entry_from_message( $normalized );
			case 'quote_settings':
				return ! empty( QuoteSettingsCatalog::build_combined_settings_patch( $normalized ) )
					|| null !== QuoteSettingsCatalog::resolve_entry_from_message( $normalized );
			case 'woocommerce_products':
				return null !== ProductFieldCatalog::resolve_entry_from_message( $normalized );
			case 'woocommerce_categories':
				return null !== CategoryFieldCatalog::resolve_entry_from_message( $normalized );
			case 'b2b_user_roles':
				return null !== RoleFieldCatalog::resolve_entry_from_message( $normalized );
			case 'wholesale_account_requests':
				return null !== AccountRequestFieldCatalog::resolve_entry_from_message( $normalized );
			case 'quote_rules':
				return null !== QuoteRuleFieldCatalog::resolve_entry_from_message( $normalized );
			case 'modify_update_quotes':
				return null !== ModifyQuoteFieldCatalog::resolve_entry_from_message( $normalized );
		}

		return false;
	}

	/**
	 * Format approval summary for catalog-backed mutations.
	 *
	 * @param string               $ability_key Ability key.
	 * @param array<string, mixed> $args        Mutation args.
	 * @return string
	 */
	public static function format_mutation_summary( $ability_key, array $args ) {
		switch ( $ability_key ) {
			case 'wholesale_settings':
				$settings = is_array(( isset( $args['settings'] ) ? $args['settings'] : null )) ? $args['settings'] : array();

				return WholesaleSettingsCatalog::format_settings_patch_summary( $settings );

			case 'wholesale_registration':
				$settings = is_array(( isset( $args['settings'] ) ? $args['settings'] : null )) ? $args['settings'] : array();
				$parts    = array();

				foreach ( $settings as $key => $value ) {
					$parts[] = RegistrationFieldCatalog::format_setting_change_summary( (string) $key, (string) $value );
				}

				return implode( '; ', $parts );

			case 'wholesale_email_notifications':
				return EmailNotificationCatalog::format_mutation_summary( $args );

			case 'quote_settings':
				$settings = is_array(( isset( $args['settings'] ) ? $args['settings'] : null )) ? $args['settings'] : array();
				$parts    = array();

				if ( isset( $settings['enable_quote'] ) ) {
					$parts[] = QuoteSettingsCatalog::format_setting_change_summary( 'enable_quote', $settings['enable_quote'] ? 'yes' : '' );
				}

				foreach ( array( 'general', 'notifications', 'pdf' ) as $group ) {
					if ( ! is_array(( isset( $settings[ $group ] ) ? $settings[ $group ] : null )) ) {
						continue;
					}

					foreach ( $settings[ $group ] as $key => $value ) {
						$parts[] = QuoteSettingsCatalog::format_setting_change_summary( (string) $key, (string) $value );
					}
				}

				return implode( '; ', $parts );

			case 'woocommerce_products':
				return ProductFieldCatalog::format_mutation_summary( $args );

			case 'woocommerce_categories':
				return CategoryFieldCatalog::format_mutation_summary( $args );

			case 'b2b_user_roles':
				return RoleFieldCatalog::format_mutation_summary( $args );

			case 'wholesale_account_requests':
				return AccountRequestFieldCatalog::format_mutation_summary( $args );

			case 'quote_rules':
				return QuoteRuleFieldCatalog::format_mutation_summary( $args );

			case 'modify_update_quotes':
				return ModifyQuoteFieldCatalog::format_mutation_summary( $args );
		}

		return '';
	}
}
