<?php
/**
 * Builds intent-specific system prompt hints for chat orchestration.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities\AbilityCatalog;

/**
 * Maps detected user intents to concrete tool-usage instructions.
 */
class ChatIntentHintBuilder {

	/**
	 * Read-only prefetch payloads per ability key.
	 *
	 * @var array<string, array<string, mixed>>
	 */
	const PREFETCH_INPUT = array(
		'wholesale_settings'              => array( 'action' => 'get' ),
		'global_discounts'                => array( 'action' => 'get' ),
		'cart_discounts'                  => array( 'action' => 'get' ),
		'b2b_user_roles'                  => array( 'action' => 'list' ),
		'wholesale_registration'          => array( 'action' => 'get' ),
		'wholesale_email_notifications'   => array( 'action' => 'list' ),
		'quote_settings'                  => array( 'action' => 'get' ),
		'quote_rules'                     => array( 'action' => 'list' ),
		'dashboard'                       => array( 'action' => 'get' ),
		'woocommerce_products'            => array( 'action' => 'list' ),
		'woocommerce_categories'          => array( 'action' => 'list' ),
		'wholesale_account_requests'      => array( 'action' => 'list' ),
		'b2b_user_profiles'               => array( 'action' => 'list' ),
		'modify_update_quotes'            => array( 'action' => 'list' ),
	);

	/**
	 * Prefetch input for an ability key.
	 *
	 * @param string $ability_key Ability settings key.
	 * @return array<string, mixed>|null
	 */
	public static function get_prefetch_input( $ability_key ) {
return ( isset( self::PREFETCH_INPUT[ $ability_key ] ) ? self::PREFETCH_INPUT[ $ability_key ] : null );
	}

	/**
	 * Resolve deterministic mutation arguments from a user message.
	 *
	 * Used as a fallback when the model explains a change but does not call the tool.
	 *
	 * @param string $message     User message.
	 * @param string $ability_key Matched ability key.
	 * @return array<string, mixed>|null
	 */
	public static function resolve_mutation_args( $message, $ability_key ) {
		$steps = self::resolve_all_mutation_steps( $message );

		foreach ( $steps as $step ) {
			if ( ( ( isset( $step['ability_key'] ) ? $step['ability_key'] : '' ) ) === $ability_key ) {
				return is_array(( isset( $step['args'] ) ? $step['args'] : null )) ? $step['args'] : null;
			}
		}

		return null;
	}

	/**
	 * Resolve all deterministic mutation steps from a user message.
	 *
	 * @param string $message User message.
	 * @return list<array{ability_key: string, args: array<string, mixed>}>
	 */
	public static function resolve_all_mutation_steps( $message ) {
		$normalized = strtolower( trim( $message ) );

		if ( '' === $normalized ) {
			return array();
		}

		$matched = ChatAbilityIntentMatcher::match_all( $message, 5 );
		$steps   = array();
		$order   = array(
			'b2b_user_roles',
			'wholesale_settings',
			'global_discounts',
			'cart_discounts',
			'wholesale_registration',
			'wholesale_email_notifications',
			'woocommerce_products',
			'woocommerce_categories',
			'wholesale_account_requests',
			'b2b_user_profiles',
			'quote_settings',
			'quote_rules',
			'modify_update_quotes',
		);

		foreach ( $order as $ability_key ) {
			if ( ! AbilityCatalog::is_active( $ability_key ) ) {
				continue;
			}

			if ( ! self::should_attempt_parser( $ability_key, $normalized, $matched ) ) {
				continue;
			}

			$args = self::resolve_step_args_for_ability( $message, $normalized, $ability_key );

			if ( is_array( $args ) && ! empty( $args ) ) {
				$steps[] = array(
					'ability_key' => $ability_key,
					'args'        => $args,
				);
			}
		}

		return $steps;
	}

	/**
	 * Whether a parser should run for an ability key.
	 *
	 * @param string        $ability_key Ability key.
	 * @param string        $normalized  Lowercased message.
	 * @param list<string>  $matched     Matched ability keys.
	 * @return bool
	 */
	private static function should_attempt_parser( $ability_key, $normalized, array $matched ) {
		if ( in_array( $ability_key, $matched, true ) ) {
			return true;
		}

		switch ( $ability_key ) {
			case 'wholesale_settings':
				return ! empty( WholesaleSettingsCatalog::build_combined_settings_patch( $normalized ) )
					|| '' !== WholesaleSettingsCatalog::resolve_key_from_message( $normalized )
					|| self::matches_auto_approve_intent( $normalized );
			case 'b2b_user_roles':
				if ( ! empty( WholesaleSettingsCatalog::build_combined_settings_patch( $normalized ) ) ) {
					return false;
				}

				return self::matches_role_create_intent( $normalized )
					|| AdminSettingsRegistry::can_resolve_mutation( $ability_key, $normalized )
					|| ( in_array( $ability_key, $matched, true ) && self::matches_mutation_intent( $normalized ) );
			case 'global_discounts':
				return self::matches_global_discount_intent( $normalized );
			case 'cart_discounts':
				return self::matches_cart_discount_intent( $normalized );
			case 'wholesale_account_requests':
				return AdminSettingsRegistry::can_resolve_mutation( $ability_key, $normalized )
					|| self::matches_account_request_mutation_intent( $normalized );
			case 'quote_settings':
				return AdminSettingsRegistry::can_resolve_mutation( $ability_key, $normalized )
					|| ( in_array( $ability_key, $matched, true )
						&& ( self::matches_enable_intent( $normalized ) || self::matches_disable_intent( $normalized ) ) );
			case 'wholesale_registration':
				return AdminSettingsRegistry::can_resolve_mutation( $ability_key, $normalized )
					|| ( in_array( $ability_key, $matched, true ) && self::matches_mutation_intent( $normalized ) );
			case 'wholesale_email_notifications':
			case 'woocommerce_products':
			case 'woocommerce_categories':
			case 'quote_rules':
			case 'modify_update_quotes':
				return AdminSettingsRegistry::can_resolve_mutation( $ability_key, $normalized )
					|| ( in_array( $ability_key, $matched, true ) && self::matches_mutation_intent( $normalized ) );
		}

		if ( in_array( $ability_key, $matched, true ) && self::matches_mutation_intent( $normalized ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Resolve mutation args for a single ability.
	 *
	 * @param string $message     Original message.
	 * @param string $normalized    Lowercased message.
	 * @param string $ability_key   Ability key.
	 * @return array<string, mixed>|null
	 */
	private static function resolve_step_args_for_ability( $message, $normalized, $ability_key ) {
		switch ( $ability_key ) {
			case 'wholesale_settings':
				return self::resolve_wholesale_settings_mutation( $normalized );
			case 'b2b_user_roles':
				return self::resolve_b2b_user_roles_mutation( $message, $normalized );
			case 'global_discounts':
				return self::resolve_global_discounts_mutation( $message, $normalized );
			case 'cart_discounts':
				return self::resolve_cart_discounts_mutation( $normalized );
			case 'wholesale_account_requests':
				return self::resolve_account_requests_mutation( $message, $normalized );
			case 'quote_settings':
				return self::resolve_quote_settings_mutation( $normalized );
			case 'wholesale_registration':
				return self::resolve_wholesale_registration_mutation( $normalized );
			case 'wholesale_email_notifications':
			case 'woocommerce_products':
			case 'woocommerce_categories':
			case 'quote_rules':
			case 'modify_update_quotes':
				return AdminSettingsRegistry::resolve_mutation_args( $message, $normalized, $ability_key );
		}

		return null;
	}

	/**
	 * Whether the message expresses a create/update/delete intent.
	 *
	 * @param string $normalized Lowercased message.
	 * @return bool
	 */
	private static function matches_mutation_intent( $normalized ) {
		if ( self::matches_enable_intent( $normalized ) || self::matches_disable_intent( $normalized ) ) {
			return true;
		}

		return 1 === preg_match( '/\b(create|add|update|modify|change|set|enable|disable|delete|remove|approve|reject)\b/', $normalized );
	}

	/**
	 * Whether the message is about approving/rejecting account requests.
	 *
	 * @param string $normalized Lowercased message.
	 * @return bool
	 */
	private static function matches_account_request_mutation_intent( $normalized ) {
		return ( str_contains( $normalized, 'approve' ) || str_contains( $normalized, 'reject' ) )
			&& ( str_contains( $normalized, 'request' ) || str_contains( $normalized, 'application' ) );
	}

	/**
	 * Build a compact ability data reference block for the system prompt.
	 *
	 * @param list<string> $ability_keys Ability settings keys.
	 * @return string
	 */
	public static function build_data_reference( array $ability_keys ) {
		$ability_keys = array_values( array_unique( array_filter( $ability_keys ) ) );

		if ( empty( $ability_keys ) ) {
			return '';
		}

		$hint_lines = AbilityDataCatalog::get_hint_lines( $ability_keys );
		$search_ref = AdminSettingsRegistry::build_settings_search_reference( $ability_keys );

		if ( empty( $hint_lines ) && '' === $search_ref ) {
			return '';
		}

		$lines   = array();
		$lines[] = __( '--- Ability data reference ---', 'woocommerce-wholesale-pricing' );
		$lines   = array_merge( $lines, $hint_lines );

		if ( '' !== $search_ref ) {
			$lines[] = $search_ref;
		}

		$lines[] = __( '--- End ability data reference ---', 'woocommerce-wholesale-pricing' );

		return implode( "\n", $lines );
	}

	/**
	 * Build JSON tool-args hint when catalog resolves a mutation.
	 *
	 * @param string $message     User message.
	 * @param string $ability_key Ability key.
	 * @return string
	 */
	private static function build_catalog_mutation_hint( $message, $ability_key ) {
		$normalized = strtolower( trim( $message ) );
		$args       = AdminSettingsRegistry::resolve_mutation_args( $message, $normalized, $ability_key );

		if ( ! is_array( $args ) || empty( $args ) ) {
			return '';
		}

		$encoded = wp_json_encode( $args, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

		if ( ! is_string( $encoded ) ) {
			return '';
		}

		return sprintf(
			/* translators: 1: ability key, 2: JSON tool arguments */
			__( 'Intent: apply admin setting change. Call %1$s with exactly: %2$s', 'woocommerce-wholesale-pricing' ),
			$ability_key,
			$encoded
		);
	}

	/**
	 * Build an intent hint block for the system prompt.
	 *
	 * @param string               $message       User message.
	 * @param string               $ability_key   Matched ability key.
	 * @param array<string, mixed> $prefetch_data Prefetched ability data.
	 * @param string               $permission    Permission mode.
	 * @return string
	 */
	public static function build( $message, $ability_key, array $prefetch_data = array(), $permission = 'approval' ) {
		$lines   = array();
		$lines[] = __( '--- Intent routing (mandatory) ---', 'woocommerce-wholesale-pricing' );
		$lines[] = sprintf(
			/* translators: %s: official plugin product name */
			__( 'Plugin in scope: %s only. Never ask which plugin the store uses.', 'woocommerce-wholesale-pricing' ),
			ChatPluginContext::PRODUCT_NAME
		);
		$lines[] = sprintf(
			/* translators: %s: ability settings key */
			__( 'Detected ability for this request: %s.', 'woocommerce-wholesale-pricing' ),
			$ability_key
		);
		$lines[] = sprintf(
			/* translators: %s: ability settings key */
			__( 'You MUST call the %s mutation tool in this response with the exact arguments below. Do not ask "Would you like me to proceed?" or wait for confirmation — the UI approval card handles that.', 'woocommerce-wholesale-pricing' ),
			$ability_key
		);

		if ( 'approval' === $permission ) {
			$lines[] = __( 'Approval mode: call the mutation tool now. The chat panel will show Approve and Deny buttons automatically. Your text reply should only explain the change in 1-2 sentences — never ask the admin to confirm in text.', 'woocommerce-wholesale-pricing' );
		}

		$reference_keys = array_values(
			array_unique(
				array_filter(
					array_merge(
						array( $ability_key ),
						ChatAbilityIntentMatcher::match_all( $message, 5 )
					)
				)
			)
		);
		$data_reference = self::build_data_reference( $reference_keys );

		if ( '' !== $data_reference ) {
			$lines[] = $data_reference;
		}

		$intent_hint = self::build_intent_specific_hint( $message, $ability_key, $permission );

		if ( '' !== $intent_hint ) {
			$lines[] = $intent_hint;
		}

		foreach ( $reference_keys as $extra_key ) {
			if ( $extra_key === $ability_key ) {
				continue;
			}

			$extra_hint = self::build_intent_specific_hint( $message, $extra_key, $permission );

			if ( '' !== $extra_hint ) {
				$lines[] = $extra_hint;
			}
		}

		if ( ! empty( $prefetch_data ) ) {
			$encoded = wp_json_encode( $prefetch_data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

			if ( is_string( $encoded ) ) {
				$lines[] = sprintf(
					/* translators: %s: JSON snapshot */
					__( 'Current data snapshot (from prefetch): %s', 'woocommerce-wholesale-pricing' ),
					$encoded
				);
			}
		}

		$lines[] = __( '--- End intent routing ---', 'woocommerce-wholesale-pricing' );

		return implode( "\n", $lines );
	}

	/**
	 * Build high-confidence mapping hints for known request patterns.
	 *
	 * @param string $message     User message.
	 * @param string $ability_key Matched ability key.
	 * @param string $permission  Permission mode.
	 * @return string
	 */
	private static function build_intent_specific_hint( $message, $ability_key, $permission ) {
		$normalized = strtolower( trim( $message ) );

		if ( 'dashboard' === $ability_key ) {
			return __( 'Intent: fetch B2B analytics. Call dashboard with action get. Use date_from/date_to for date ranges; include metrics, top_products, and top_customers.', 'woocommerce-wholesale-pricing' );
		}

		if ( 'wholesale_settings' === $ability_key ) {
			$setting_hint = self::build_wholesale_settings_hint( $normalized, $permission );

			if ( '' !== $setting_hint ) {
				return $setting_hint;
			}
		}

		if ( 'b2b_user_roles' === $ability_key && ( str_contains( $normalized, 'add role' ) || str_contains( $normalized, 'create role' ) || str_contains( $normalized, 'new role' ) ) ) {
			return __( 'Intent: create a wholesale role. Call b2b_user_roles with action create and role.name, role.slug, and any restrictions from the user message.', 'woocommerce-wholesale-pricing' );
		}

		if ( 'b2b_user_roles' === $ability_key ) {
			$catalog_hint = self::build_catalog_mutation_hint( $message, $ability_key );

			if ( '' !== $catalog_hint ) {
				return $catalog_hint;
			}
		}

		if ( 'cart_discounts' === $ability_key && str_contains( $normalized, 'cart' ) ) {
			return __( 'Intent: update cart total discounts. Call cart_discounts with action update and include ONLY fields the user asked to change. Omit min cart subtotal, discount_on, discount_type, enabled, and tier_pricing unless explicitly requested.', 'woocommerce-wholesale-pricing' );
		}

		if ( 'global_discounts' === $ability_key ) {
			return __( 'Intent: update global/role discounts. Call global_discounts with action update and settings.role_discounts containing ONLY fields the user asked to change (e.g. role_slug + wholesale_price). Omit min_quantity, discount_type, enabled, and tier_pricing unless the user explicitly requests them.', 'woocommerce-wholesale-pricing' );
		}

		if ( 'woocommerce_products' === $ability_key ) {
			$catalog_hint = self::build_catalog_mutation_hint( $message, $ability_key );

			if ( '' !== $catalog_hint ) {
				return $catalog_hint;
			}

			if ( str_contains( $normalized, 'create' ) || str_contains( $normalized, 'add product' ) ) {
				return __( 'Intent: create a product. Call woocommerce_products with action create and name, sku, regular_price, and wholesale_multi_user_pricing as needed.', 'woocommerce-wholesale-pricing' );
			}

			if ( str_contains( $normalized, 'delete' ) || str_contains( $normalized, 'remove product' ) ) {
				return __( 'Intent: delete a product. Call woocommerce_products with action delete and identifier (product ID or SKU).', 'woocommerce-wholesale-pricing' );
			}

			if ( str_contains( $normalized, 'update' ) || str_contains( $normalized, 'sku' ) || preg_match( '/#\d+|\bproduct\s+\d+/i', $message ) ) {
				return __( 'Intent: update a product. Call woocommerce_products with action update, identifier (ID or SKU), and the fields to change.', 'woocommerce-wholesale-pricing' );
			}

			return __( 'Intent: list or read products. Call woocommerce_products with action list or get and identifier when a specific product is named.', 'woocommerce-wholesale-pricing' );
		}

		if ( 'woocommerce_categories' === $ability_key ) {
			$catalog_hint = self::build_catalog_mutation_hint( $message, $ability_key );

			if ( '' !== $catalog_hint ) {
				return $catalog_hint;
			}

			if ( str_contains( $normalized, 'create' ) || str_contains( $normalized, 'add categor' ) ) {
				return __( 'Intent: create product categories. Call woocommerce_categories once with action create and either a categories array [{name, slug, parent}, ...] for multiple categories or category for a single category. Multiple create tool calls in the same response are also batched.', 'woocommerce-wholesale-pricing' );
			}

			if ( str_contains( $normalized, 'delete' ) || str_contains( $normalized, 'remove categor' ) ) {
				return __( 'Intent: delete a category. Call woocommerce_categories with action delete and identifier (term ID or slug).', 'woocommerce-wholesale-pricing' );
			}

			if ( str_contains( $normalized, 'pricing' ) || str_contains( $normalized, 'visibility' ) || str_contains( $normalized, 'discount' )
				|| str_contains( $normalized, 'wholesale price' ) || str_contains( $normalized, 'min quantity' )
				|| str_contains( $normalized, 'step quantity' ) ) {
				return __( 'Intent: update category wholesale pricing or visibility. Call woocommerce_categories with action update, identifier, and wholesale.role_pricing containing ONLY fields the user asked to change (e.g. role_slug, enabled, wholesale_price, min_quantity, step_quantity). Omit discount_type, enabled, min_quantity, and tier_pricing unless explicitly requested. Include discount_type only when the user says fixed, percent, or %.', 'woocommerce-wholesale-pricing' );
			}

			return __( 'Intent: list or read categories. Call woocommerce_categories with action list or get and identifier when a specific category is named.', 'woocommerce-wholesale-pricing' );
		}

		if ( 'b2b_user_profiles' === $ability_key ) {
			if ( str_contains( $normalized, 'create' ) || str_contains( $normalized, 'add user' ) ) {
				return __( 'Intent: create a B2B user. Call b2b_user_profiles with action create, user_email, role, and billing/shipping fields from the message.', 'woocommerce-wholesale-pricing' );
			}

			if ( str_contains( $normalized, 'assign role' ) || str_contains( $normalized, 'update' ) ) {
				return __( 'Intent: update a B2B user profile. Call b2b_user_profiles with action update, identifier (user ID or email), and role or meta fields to change.', 'woocommerce-wholesale-pricing' );
			}

			return __( 'Intent: list or read B2B users. Call b2b_user_profiles with action list or get and identifier when a specific user is named.', 'woocommerce-wholesale-pricing' );
		}

		if ( 'wholesale_account_requests' === $ability_key ) {
			$catalog_hint = self::build_catalog_mutation_hint( $message, $ability_key );

			if ( '' !== $catalog_hint ) {
				return $catalog_hint;
			}

			if ( str_contains( $normalized, 'approve' ) ) {
				return __( 'Intent: approve a wholesale registration request. Call wholesale_account_requests with action update, identifier, status active, and user_role_set.', 'woocommerce-wholesale-pricing' );
			}

			if ( str_contains( $normalized, 'reject' ) ) {
				return __( 'Intent: reject a wholesale registration request. Call wholesale_account_requests with action update, identifier, status rejected, and rejected_note if provided.', 'woocommerce-wholesale-pricing' );
			}

			return __( 'Intent: list or review account requests. Call wholesale_account_requests with action list (filter status waiting) or get with identifier.', 'woocommerce-wholesale-pricing' );
		}

		if ( 'wholesale_email_notifications' === $ability_key ) {
			$catalog_hint = self::build_catalog_mutation_hint( $message, $ability_key );

			if ( '' !== $catalog_hint ) {
				return $catalog_hint;
			}

			return __( 'Intent: update wholesale email notifications. Call wholesale_email_notifications with action update, notification_key, and enabled/subject/body/recipient fields.', 'woocommerce-wholesale-pricing' );
		}

		if ( 'wholesale_registration' === $ability_key ) {
			$catalog_hint = self::build_catalog_mutation_hint( $message, $ability_key );

			if ( '' !== $catalog_hint ) {
				return $catalog_hint;
			}

			return __( 'Intent: update registration form settings. Call wholesale_registration once with action update and a single settings object that includes every requested field (enable_billing_*, enable_shipping_*, enable_tex_id, required_tex_id, enable_file_upload, required_file_upload, or recaptcha fields). Never split related fields into separate tool calls or tell the admin to approve them separately.', 'woocommerce-wholesale-pricing' );
		}

		if ( 'quote_settings' === $ability_key ) {
			$catalog_hint = self::build_catalog_mutation_hint( $message, $ability_key );

			if ( '' !== $catalog_hint ) {
				return $catalog_hint;
			}

			return __( 'Intent: update quote settings. Call quote_settings with action update and settings grouped as { "enable_quote": bool, "general": {...}, "notifications": {...}, "pdf": { "enable_pdf": true, "quote_pdf": "custom", "custom": "bronze" } }. PDF fields must be under settings.pdf.', 'woocommerce-wholesale-pricing' );
		}

		if ( 'quote_rules' === $ability_key ) {
			$catalog_hint = self::build_catalog_mutation_hint( $message, $ability_key );

			if ( '' !== $catalog_hint ) {
				return $catalog_hint;
			}

			if ( str_contains( $normalized, 'create' ) || str_contains( $normalized, 'add rule' ) ) {
				return __( 'Intent: create a quote rule. Call quote_rules with action create, enable_rule, wc_quote_rules, priority, user_scope, and product inclusions/exclusions.', 'woocommerce-wholesale-pricing' );
			}

			return __( 'Intent: list or update quote rules. Call quote_rules with action list or update and identifier when a specific rule is named.', 'woocommerce-wholesale-pricing' );
		}

		if ( 'modify_update_quotes' === $ability_key ) {
			$catalog_hint = self::build_catalog_mutation_hint( $message, $ability_key );

			if ( '' !== $catalog_hint ) {
				return $catalog_hint;
			}

			if ( str_contains( $normalized, 'status' ) || str_contains( $normalized, 'accept' ) || str_contains( $normalized, 'convert' ) || str_contains( $normalized, 'reject' ) ) {
				return __( 'Intent: update quote status or contents. Call modify_update_quotes with action update, identifier (quote ID), status, and quote_contents/quote_fields as needed.', 'woocommerce-wholesale-pricing' );
			}

			return __( 'Intent: list or read quotes. Call modify_update_quotes with action list or get and identifier when a specific quote is named.', 'woocommerce-wholesale-pricing' );
		}

		return '';
	}

	/**
	 * Build wholesale_settings intent hint from message phrases.
	 *
	 * @param string $normalized Lowercased message.
	 * @param string $permission Permission mode.
	 * @return string
	 */
	private static function build_wholesale_settings_hint( $normalized, $permission ) {
		if ( self::matches_auto_approve_intent( $normalized ) ) {
			if ( self::matches_enable_auto_approve_intent( $normalized ) ) {
				return __( 'Intent: enable registration auto-approve. Call wholesale_settings with action update and settings: { "disable_auto_role": "no" }.', 'woocommerce-wholesale-pricing' );
			}

			return __( 'Intent: disable registration auto-approve (require manual approval). Call wholesale_settings with action update and settings: { "disable_auto_role": "yes" }.', 'woocommerce-wholesale-pricing' );
		}

		$combined_patch = WholesaleSettingsCatalog::build_combined_settings_patch( $normalized );

		if ( ! empty( $combined_patch ) && 'approval' === $permission ) {
			$encoded = wp_json_encode( $combined_patch );

			if ( is_string( $encoded ) ) {
				return sprintf(
					/* translators: %s: JSON settings patch */
					__( 'Intent: update wholesale settings. Call wholesale_settings with action update and settings: %s. Do not create B2B roles — these are plugin settings under Wholesale → Settings.', 'woocommerce-wholesale-pricing' ),
					$encoded
				);
			}
		}

		$setting_key = self::resolve_setting_key( $normalized );

		if ( '' === $setting_key ) {
			return '';
		}

		$enable = self::matches_enable_intent( $normalized );
		$disable = self::matches_disable_intent( $normalized );

		if ( $enable && ! $disable ) {
			$value = WholesaleSettingsCatalog::get_boolean_value( $setting_key, true );

			return sprintf(
				/* translators: 1: setting key, 2: setting value */
				__( 'Intent: enable setting. Call wholesale_settings with action update and settings: { "%1$s": "%2$s" }. Do not ask for confirmation.', 'woocommerce-wholesale-pricing' ),
				$setting_key,
				$value
			);
		}

		if ( $disable && ! $enable ) {
			$value = WholesaleSettingsCatalog::get_boolean_value( $setting_key, false );

			return sprintf(
				/* translators: 1: setting key, 2: setting value */
				__( 'Intent: disable setting. Call wholesale_settings with action update and settings: { "%1$s": "%2$s" }. Do not ask for confirmation.', 'woocommerce-wholesale-pricing' ),
				$setting_key,
				$value
			);
		}

		if ( $enable ) {
			return sprintf(
				/* translators: %s: setting key */
				__( 'Intent: update wholesale setting "%s". Call wholesale_settings with action update and the correct enabled value ("yes" for on, "no" for off).', 'woocommerce-wholesale-pricing' ),
				$setting_key
			);
		}

		return '';
	}

	/**
	 * Resolve a wholesale_settings option key from the user message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string
	 */
	private static function resolve_setting_key( $normalized ) {
		return WholesaleSettingsCatalog::resolve_key_from_message( $normalized );
	}

	/**
	 * Whether the message is about registration auto-approval settings.
	 *
	 * @param string $normalized Lowercased message.
	 * @return bool
	 */
	private static function matches_auto_approve_intent( $normalized ) {
		$phrases = array(
			'auto approv',
			'auto approve',
			'disable auto',
			'enable auto',
			'manual approv',
			'registration approv',
			'wholesale registration',
			'wholeslae registration',
		);

		foreach ( $phrases as $phrase ) {
			if ( str_contains( $normalized, $phrase ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether the user wants to enable (not disable) auto-approve.
	 *
	 * @param string $normalized Lowercased message.
	 * @return bool
	 */
	private static function matches_enable_auto_approve_intent( $normalized ) {
		$enable_phrases = array(
			'enable auto',
			'turn on auto',
			'allow auto',
		);

		foreach ( $enable_phrases as $phrase ) {
			if ( str_contains( $normalized, $phrase ) ) {
				return true;
			}
		}

		return str_contains( $normalized, 'enable' ) && str_contains( $normalized, 'auto approv' );
	}

	/**
	 * Whether the user wants to enable a setting.
	 *
	 * @param string $normalized Lowercased message.
	 * @return bool
	 */
	private static function matches_enable_intent( $normalized ) {
		$phrases = array( 'enable', 'turn on', 'activate', 'allow' );

		foreach ( $phrases as $phrase ) {
			if ( str_contains( $normalized, $phrase ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether the user wants to disable a setting.
	 *
	 * @param string $normalized Lowercased message.
	 * @return bool
	 */
	private static function matches_disable_intent( $normalized ) {
		$phrases = array( 'disable', 'turn off', 'deactivate', 'disallow' );

		foreach ( $phrases as $phrase ) {
			if ( str_contains( $normalized, $phrase ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Build wholesale_settings mutation args when intent is unambiguous.
	 *
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>|null
	 */
	private static function resolve_wholesale_settings_mutation( $normalized ) {
		if ( self::matches_auto_approve_intent( $normalized ) ) {
			if ( self::matches_enable_auto_approve_intent( $normalized ) ) {
				return array(
					'action'   => 'update',
					'settings' => array(
						'disable_auto_role' => 'no',
					),
				);
			}

			return array(
				'action'   => 'update',
				'settings' => array(
					'disable_auto_role' => 'yes',
				),
			);
		}

		$combined_patch = WholesaleSettingsCatalog::build_combined_settings_patch( $normalized );

		if ( ! empty( $combined_patch ) ) {
			return array(
				'action'   => 'update',
				'settings' => $combined_patch,
			);
		}

		$setting_key = self::resolve_setting_key( $normalized );

		if ( '' === $setting_key ) {
			return null;
		}

		$enable  = self::matches_enable_intent( $normalized );
		$disable = self::matches_disable_intent( $normalized );

		if ( $enable && ! $disable ) {
			$value = WholesaleSettingsCatalog::get_boolean_value( $setting_key, true );

			return array(
				'action'   => 'update',
				'settings' => array(
					$setting_key => $value,
				),
			);
		}

		if ( $disable && ! $enable ) {
			$value = WholesaleSettingsCatalog::get_boolean_value( $setting_key, false );

			return array(
				'action'   => 'update',
				'settings' => array(
					$setting_key => $value,
				),
			);
		}

		return null;
	}

	/**
	 * Whether the message requests creating a wholesale role.
	 *
	 * @param string $normalized Lowercased message.
	 * @return bool
	 */
	private static function matches_role_create_intent( $normalized ) {
		if ( ! empty( WholesaleSettingsCatalog::build_combined_settings_patch( $normalized ) ) ) {
			return false;
		}

		if ( preg_match( '/\b(set|default|apply|change|update)\b.{0,80}\b(role|roles)\b/', $normalized ) ) {
			return false;
		}

		if ( preg_match( '/\b(create|add|new)\b.{0,40}\b(role|roles)\b/', $normalized ) ) {
			return true;
		}

		$phrases = array(
			'create role',
			'create a role',
			'add role',
			'add a role',
			'new role',
			'create wholesale role',
			'create a wholesale role',
			'add wholesale role',
			'new wholesale role',
			'wholesale user role',
			'wholeasle user role',
		);

		foreach ( $phrases as $phrase ) {
			if ( str_contains( $normalized, $phrase ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether the message requests global/role discount changes.
	 *
	 * @param string $normalized Lowercased message.
	 * @return bool
	 */
	private static function matches_global_discount_intent( $normalized ) {
		return str_contains( $normalized, 'global discount' )
			|| str_contains( $normalized, 'global wholesale' )
			|| ( str_contains( $normalized, 'discount' ) && preg_match( '/\d+\s*%/', $normalized ) );
	}

	/**
	 * Whether the message requests cart total discount changes.
	 *
	 * @param string $normalized Lowercased message.
	 * @return bool
	 */
	private static function matches_cart_discount_intent( $normalized ) {
		return str_contains( $normalized, 'cart discount' )
			|| str_contains( $normalized, 'cart total discount' );
	}

	/**
	 * Extract a role name from the user message.
	 *
	 * @param string $message Original message.
	 * @return string
	 */
	private static function extract_role_name( $message ) {
		if ( preg_match( '/"([^"]{2,120})"/', $message, $matches ) ) {
			return trim( $matches[1] );
		}

		if ( preg_match( "/'([^']{2,120})'/", $message, $matches ) ) {
			return trim( $matches[1] );
		}

		if ( preg_match( '/\b(?:create|add|new)\s+(?:a\s+)?(?:wholesale\s+)?role\s+(?:called\s+)?([a-z0-9][a-z0-9\s\-]{1,80}?)(?:\s+and|\s+with|\s*$)/i', $message, $matches ) ) {
			return trim( $matches[1] );
		}

		if ( preg_match( '/\brole\s+called\s+([a-z0-9][a-z0-9\s\-]{1,80}?)(?:\s+and|\s+with|\s*$)/i', $message, $matches ) ) {
			return trim( $matches[1] );
		}

		return '';
	}

	/**
	 * Build b2b_user_roles create mutation args.
	 *
	 * @param string $message    Original message.
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>|null
	 */
	private static function resolve_b2b_user_roles_mutation( $message, $normalized ) {
		if ( self::matches_role_create_intent( $normalized ) ) {
			$name = self::extract_role_name( $message );

			if ( '' !== $name ) {
				$slug = sanitize_title( $name );

				if ( '' !== $slug ) {
					return array(
						'action' => 'create',
						'role'   => array(
							'name' => $name,
							'slug' => $slug,
						),
					);
				}
			}
		}

		return AdminSettingsRegistry::resolve_mutation_args( $message, $normalized, 'b2b_user_roles' );
	}

	/**
	 * Build global_discounts update mutation args.
	 *
	 * @param string $message    Original message.
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>|null
	 */
	private static function resolve_global_discounts_mutation( $message, $normalized ) {
		if ( ! self::matches_global_discount_intent( $normalized ) ) {
			return null;
		}

		$discount  = '';
		$role_patch = array();

		if ( preg_match( '/(\d+(?:\.\d+)?)\s*%/', $normalized, $discount_match ) ) {
			$discount = (string) $discount_match[1];
		} elseif ( preg_match( '/\b(?:to|value|price|discount)\s+(\d+(?:\.\d+)?)\b/', $normalized, $value_match ) ) {
			$discount = (string) $value_match[1];
		}

		if ( '' !== $discount ) {
			$role_patch['wholesale_price'] = $discount;
		}

		if ( preg_match( '/min(?:imum)?\s*(?:qty|quantity)\s*(?:to\s+)?(\d+)/', $normalized, $qty_match )
			|| preg_match( '/min(?:imum)?\s*(?:qty|quantity)?\s+(\d+)/', $normalized, $qty_match ) ) {
			$role_patch['min_quantity'] = max( 1, (int) $qty_match[1] );
		}

		if ( empty( $role_patch ) ) {
			return null;
		}

		if ( preg_match( '/\bfixed\b/', $normalized ) ) {
			$role_patch['discount_type'] = 'fixed';
		} elseif ( preg_match( '/\bpercent\b|\b%/', $normalized ) ) {
			$role_patch['discount_type'] = 'percent';
		}

		$role_name = self::extract_role_name( $message );
		$role_slug = '' !== $role_name ? sanitize_title( $role_name ) : '';

		if ( '' === $role_slug && preg_match( '/\brole\s+([a-z0-9\-_]+)/', $normalized, $slug_match ) ) {
			$role_slug = sanitize_title( $slug_match[1] );
		}

		if ( '' === $role_slug && str_contains( $normalized, 'wholesaler' ) ) {
			$role_slug = 'default_wholesaler';
		}

		if ( '' === $role_slug ) {
			return null;
		}

		$role_patch['role_slug'] = $role_slug;

		return array(
			'action'   => 'update',
			'settings' => array(
				'role_discounts' => array( $role_patch ),
			),
		);
	}

	/**
	 * Build cart_discounts update mutation args.
	 *
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>|null
	 */
	private static function resolve_cart_discounts_mutation( $normalized ) {
		if ( ! self::matches_cart_discount_intent( $normalized ) ) {
			return null;
		}

		if ( ! preg_match( '/(\d+(?:\.\d+)?)\s*%/', $normalized, $discount_match ) ) {
			return null;
		}

		return array(
			'action'   => 'update',
			'settings' => array(
				'discount' => (string) $discount_match[1],
				'enabled'  => true,
			),
		);
	}

	/**
	 * Build wholesale_account_requests update mutation args.
	 *
	 * @param string $message    Original message.
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>|null
	 */
	private static function resolve_account_requests_mutation( $message, $normalized ) {
		$catalog_args = AdminSettingsRegistry::resolve_mutation_args( $message, $normalized, 'wholesale_account_requests' );

		if ( is_array( $catalog_args ) && ! empty( $catalog_args ) ) {
			return $catalog_args;
		}

		if ( ! self::matches_account_request_mutation_intent( $normalized ) ) {
			return null;
		}

		$identifier = self::extract_numeric_identifier( $message );

		if ( null === $identifier ) {
			return null;
		}

		if ( str_contains( $normalized, 'reject' ) ) {
			return array(
				'action'     => 'update',
				'identifier' => $identifier,
				'status'     => 'rejected',
			);
		}

		if ( str_contains( $normalized, 'approve' ) ) {
			return array(
				'action'     => 'update',
				'identifier' => $identifier,
				'status'     => 'active',
			);
		}

		return null;
	}

	private static function resolve_wholesale_registration_mutation( $normalized ) {
		return AdminSettingsRegistry::resolve_mutation_args( '', $normalized, 'wholesale_registration' );
	}

	/**
	 * Build quote_settings update mutation args.
	 *
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>|null
	 */
	private static function resolve_quote_settings_mutation( $normalized ) {
		return AdminSettingsRegistry::resolve_mutation_args( '', $normalized, 'quote_settings' );
	}

	/**
	 * Extract a numeric post/request ID from the user message.
	 *
	 * @param string $message Original message.
	 * @return int|null
	 */
	private static function extract_numeric_identifier( $message ) {
		if ( preg_match( '/#(\d+)/', $message, $matches ) ) {
			return (int) $matches[1];
		}

		if ( preg_match( '/\b(?:request|id|quote|order|product|user)\s*#?\s*(\d+)\b/i', $message, $matches ) ) {
			return (int) $matches[1];
		}

		return null;
	}
}
