<?php
/**
 * Contract for undo handlers.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo;

/**
 * Undo handler interface.
 */
interface UndoHandlerInterface {

	/**
	 * Whether this handler supports the given action and resource type.
	 *
	 * @param string $action_type   Action type.
	 * @param string $resource_type Resource type.
	 * @return bool
	 */
	public function supports( $action_type, $resource_type );

	/**
	 * Revert the recorded change.
	 *
	 * @param array<string, mixed> $row Raw history row with decoded JSON.
	 * @return true|\WP_Error
	 */
	public function undo( array $row );
}
