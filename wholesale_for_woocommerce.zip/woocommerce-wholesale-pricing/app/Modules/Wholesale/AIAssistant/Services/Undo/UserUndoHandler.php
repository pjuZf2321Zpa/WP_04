<?php
/**
 * Undo handler for WordPress users.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo;

/**
 * Reverts create/delete/update actions on users.
 */
class UserUndoHandler implements UndoHandlerInterface {

	/**
	 * {@inheritDoc}
	 */
	public function supports( $action_type, $resource_type ) {
		return 'user' === $resource_type && in_array( $action_type, array( 'create', 'delete', 'update' ), true );
	}

	/**
	 * {@inheritDoc}
	 */
	public function undo( array $row ) {
		$action_type = (string) ( ( isset( $row['action_type'] ) ? $row['action_type'] : '' ) );

		switch ( $action_type ) {
			case 'create':
				return $this->undo_create( $row );
			case 'delete':
				return $this->undo_delete( $row );
			case 'update':
				return $this->undo_update( $row );
		}

		return new \WP_Error(
			'wwp_ai_undo_unsupported_action',
			__( 'Unsupported undo action for user.', 'woocommerce-wholesale-pricing' ),
			array( 'status' => 400 )
		);
	}

	/**
	 * Undo user creation by deleting the user.
	 *
	 * @param array<string, mixed> $row History row.
	 * @return true|\WP_Error
	 */
	private function undo_create( array $row ) {
		$resource = is_array(( isset( $row['resource'] ) ? $row['resource'] : null )) ? $row['resource'] : array();
		$user_id  = (int) ( ( isset( $resource['ID'] ) ? $resource['ID'] : ( isset( $resource['id'] ) ? $resource['id'] : 0 ) ) );

		if ( $user_id <= 0 ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_resource',
				__( 'Cannot undo user creation: missing user id.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$deleted = wp_delete_user( $user_id );
		if ( ! $deleted ) {
			return new \WP_Error(
				'wwp_ai_undo_user_delete_failed',
				__( 'Failed to delete user while undoing creation.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		return true;
	}

	/**
	 * Undo user deletion by recreating from before state.
	 *
	 * @param array<string, mixed> $row History row.
	 * @return true|\WP_Error
	 */
	private function undo_delete( array $row ) {
		$before = is_array(( isset( $row['before_state'] ) ? $row['before_state'] : null )) ? $row['before_state'] : array();

		if ( empty( $before['user_login'] ) || empty( $before['user_email'] ) ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_before_state',
				__( 'Cannot undo user deletion: missing before state.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$user_id = wp_insert_user( $before );
		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}

		if ( ! empty( $before['meta'] ) && is_array( $before['meta'] ) ) {
			foreach ( $before['meta'] as $meta_key => $meta_value ) {
				update_user_meta( $user_id, $meta_key, $meta_value );
			}
		}

		return true;
	}

	/**
	 * Undo user update by restoring before state.
	 *
	 * @param array<string, mixed> $row History row.
	 * @return true|\WP_Error
	 */
	private function undo_update( array $row ) {
		$before = is_array(( isset( $row['before_state'] ) ? $row['before_state'] : null )) ? $row['before_state'] : array();
		$user_id = (int) ( ( isset( $before['ID'] ) ? $before['ID'] : ( isset( $before['id'] ) ? $before['id'] : 0 ) ) );

		if ( $user_id <= 0 ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_before_state',
				__( 'Cannot undo user update: missing before state.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$before['ID'] = $user_id;
		$result       = wp_update_user( $before );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( ! empty( $before['meta'] ) && is_array( $before['meta'] ) ) {
			foreach ( $before['meta'] as $meta_key => $meta_value ) {
				update_user_meta( $user_id, $meta_key, $meta_value );
			}
		}

		return true;
	}
}
