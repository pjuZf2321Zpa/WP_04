<?php
/**
 * Undo handler for wholesale email notification settings.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo;

use WooCommerceWholesalePricing\App\Services\WholesaleEmailNotificationService;

/**
 * Reverts update actions on wholesale email notification options.
 */
class EmailNotificationUndoHandler implements UndoHandlerInterface {

	/**
	 * Notification service.
	 *
	 * @var WholesaleEmailNotificationService
	 */
	private $notification_service;

	/**
	 * Constructor.
	 *
	 * @param WholesaleEmailNotificationService|null $notification_service Optional service.
	 */
	public function __construct( $notification_service = null ) {
		$this->notification_service =( isset( $notification_service ) ? $notification_service : new WholesaleEmailNotificationService() );
	}

	/**
	 * {@inheritDoc}
	 */
	public function supports( $action_type, $resource_type ) {
		return 'email_notification' === $resource_type && 'update' === $action_type;
	}

	/**
	 * {@inheritDoc}
	 */
	public function undo( array $row ) {
		$before = is_array(( isset( $row['before_state'] ) ? $row['before_state'] : null )) ? $row['before_state'] : array();

		if ( empty( $before['notification_id'] ) || empty( $before['options'] ) ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_before_state',
				__( 'Cannot undo notification update: missing before state.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		return $this->notification_service->restore_notification( $before );
	}
}
