<?php
/**
 * Undo handler for wholesale account requests.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo;

use WooCommerceWholesalePricing\App\Services\WholesaleAccountRequestService;

/**
 * Reverts update/delete actions on wwp_requests posts.
 */
class AccountRequestUndoHandler implements UndoHandlerInterface {

	/**
	 * Request service.
	 *
	 * @var WholesaleAccountRequestService
	 */
	private $request_service;

	/**
	 * Constructor.
	 *
	 * @param WholesaleAccountRequestService|null $request_service Optional service.
	 */
	public function __construct( $request_service = null ) {
		$this->request_service =( isset( $request_service ) ? $request_service : new WholesaleAccountRequestService() );
	}

	/**
	 * {@inheritDoc}
	 */
	public function supports( $action_type, $resource_type ) {
		return 'account_request' === $resource_type && in_array( $action_type, array( 'update', 'delete' ), true );
	}

	/**
	 * {@inheritDoc}
	 */
	public function undo( array $row ) {
		$action_type = (string) ( ( isset( $row['action_type'] ) ? $row['action_type'] : '' ) );
		$before      = is_array(( isset( $row['before_state'] ) ? $row['before_state'] : null )) ? $row['before_state'] : array();

		if ( empty( $before ) ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_before_state',
				__( 'Cannot undo account request change: missing before state.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( 'update' === $action_type ) {
			return $this->request_service->restore_request( $before );
		}

		if ( 'delete' === $action_type ) {
			$result = $this->request_service->restore_deleted_request( $before );
			if ( is_wp_error( $result ) ) {
				return $result;
			}

			return true;
		}

		return new \WP_Error(
			'wwp_ai_undo_unsupported_action',
			__( 'Unsupported undo action for account request.', 'woocommerce-wholesale-pricing' ),
			array( 'status' => 400 )
		);
	}
}
