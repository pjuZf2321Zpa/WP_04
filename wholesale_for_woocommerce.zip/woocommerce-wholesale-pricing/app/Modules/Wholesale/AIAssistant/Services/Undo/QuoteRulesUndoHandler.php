<?php
/**
 * Undo handler for quote rules.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo;

use WooCommerceWholesalePricing\App\Services\Quote\WholesaleQuoteRuleService;

/**
 * Reverts create/update/delete actions on wc-quote-rules posts.
 */
class QuoteRulesUndoHandler implements UndoHandlerInterface {

	/**
	 * Quote rule service.
	 *
	 * @var WholesaleQuoteRuleService
	 */
	private $rule_service;

	/**
	 * Constructor.
	 *
	 * @param WholesaleQuoteRuleService|null $rule_service Optional service.
	 */
	public function __construct( $rule_service = null ) {
		$this->rule_service =( isset( $rule_service ) ? $rule_service : new WholesaleQuoteRuleService() );
	}

	/**
	 * {@inheritDoc}
	 */
	public function supports( $action_type, $resource_type ) {
		return 'quote_rule' === $resource_type && in_array( $action_type, array( 'create', 'update', 'delete' ), true );
	}

	/**
	 * {@inheritDoc}
	 */
	public function undo( array $row ) {
		$action_type = (string) ( ( isset( $row['action_type'] ) ? $row['action_type'] : '' ) );

		switch ( $action_type ) {
			case 'create':
				return $this->undo_create( $row );
			case 'update':
				return $this->undo_update( $row );
			case 'delete':
				return $this->undo_delete( $row );
		}

		return new \WP_Error(
			'wwp_ai_undo_unsupported_action',
			__( 'Unsupported undo action for quote rule.', 'woocommerce-wholesale-pricing' ),
			array( 'status' => 400 )
		);
	}

	/**
	 * Undo rule creation by deleting the post.
	 *
	 * @param array<string, mixed> $row History row.
	 * @return true|\WP_Error
	 */
	private function undo_create( array $row ) {
		$resource = is_array(( isset( $row['resource'] ) ? $row['resource'] : null )) ? $row['resource'] : array();
		$rule_id  = (int) ( ( isset( $resource['rule_id'] ) ? $resource['rule_id'] : ( isset( $resource['id'] ) ? $resource['id'] : 0 ) ) );

		if ( $rule_id <= 0 ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_resource',
				__( 'Cannot undo quote rule creation: missing rule id.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$deleted = $this->rule_service->delete_rule( $rule_id );
		if ( is_wp_error( $deleted ) ) {
			return $deleted;
		}

		return true;
	}

	/**
	 * Undo rule update by restoring before state.
	 *
	 * @param array<string, mixed> $row History row.
	 * @return true|\WP_Error
	 */
	private function undo_update( array $row ) {
		$before = is_array(( isset( $row['before_state'] ) ? $row['before_state'] : null )) ? $row['before_state'] : array();
		if ( empty( $before ) ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_before_state',
				__( 'Cannot undo quote rule update: missing before state.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		return $this->rule_service->restore_rule( $before );
	}

	/**
	 * Undo rule deletion by recreating from before state.
	 *
	 * @param array<string, mixed> $row History row.
	 * @return true|\WP_Error
	 */
	private function undo_delete( array $row ) {
		$before = is_array(( isset( $row['before_state'] ) ? $row['before_state'] : null )) ? $row['before_state'] : array();
		if ( empty( $before ) ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_before_state',
				__( 'Cannot undo quote rule deletion: missing before state.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$result = $this->rule_service->restore_deleted_rule( $before );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return true;
	}
}
