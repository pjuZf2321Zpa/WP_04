<?php
/**
 * Undo handler for wc-quote posts.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo;

use WooCommerceWholesalePricing\App\Services\Quote\WholesaleQuoteService;

/**
 * Reverts update actions on quotes.
 */
class QuoteUndoHandler implements UndoHandlerInterface {

	/**
	 * Quote service.
	 *
	 * @var WholesaleQuoteService
	 */
	private $quote_service;

	/**
	 * Constructor.
	 *
	 * @param WholesaleQuoteService|null $quote_service Optional service.
	 */
	public function __construct( $quote_service = null ) {
		$this->quote_service =( isset( $quote_service ) ? $quote_service : new WholesaleQuoteService() );
	}

	/**
	 * {@inheritDoc}
	 */
	public function supports( $action_type, $resource_type ) {
		return 'quote' === $resource_type && 'update' === $action_type;
	}

	/**
	 * {@inheritDoc}
	 */
	public function undo( array $row ) {
		$before = is_array(( isset( $row['before_state'] ) ? $row['before_state'] : null )) ? $row['before_state'] : array();
		if ( empty( $before ) ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_before_state',
				__( 'Cannot undo quote update: missing before state.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		return $this->quote_service->restore_quote( $before );
	}
}
