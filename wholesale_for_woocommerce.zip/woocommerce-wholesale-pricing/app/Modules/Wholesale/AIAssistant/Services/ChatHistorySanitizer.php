<?php
/**
 * Ensures AI chat history has valid function call IDs for provider APIs.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

use WordPress\AiClient\Messages\DTO\Message;
use WordPress\AiClient\Messages\DTO\MessagePart;
use WordPress\AiClient\Messages\DTO\ModelMessage;
use WordPress\AiClient\Messages\DTO\UserMessage;
use WordPress\AiClient\Tools\DTO\FunctionCall;
use WordPress\AiClient\Tools\DTO\FunctionResponse;

/**
 * Normalizes function call/response IDs required by OpenAI Responses API.
 */
class ChatHistorySanitizer {

	/**
	 * Sanitize a full message history before sending to the model.
	 *
	 * @param list<Message> $messages Message history.
	 * @return list<Message>
	 */
	public static function sanitize( array $messages ) {
		$sanitized     = array();
		$pending_calls = array();

		foreach ( $messages as $message ) {
			if ( ! $message instanceof Message ) {
				continue;
			}

			foreach ( self::expand_tool_messages( $message ) as $expanded_message ) {
				$sanitized[] = self::sanitize_message( $expanded_message, $pending_calls );
			}
		}

		return self::repair_tool_pairs( $sanitized );
	}

	/**
	 * Ensure model messages contain stable function call IDs before execution.
	 *
	 * @param Message $message Model message.
	 * @return Message
	 */
	public static function ensure_model_message_call_ids( Message $message ) {
		$pending_calls = array();

		return self::sanitize_message( $message, $pending_calls );
	}

	/**
	 * Split model messages so each function call is its own message.
	 *
	 * The OpenAI Responses API only exports one function_call per message item.
	 *
	 * @param Message $message Message instance.
	 * @return list<Message>
	 */
	public static function expand_tool_messages( Message $message ) {
		$text_parts  = array();
		$call_parts  = array();
		$other_parts = array();

		foreach ( $message->getParts() as $part ) {
			$type = $part->getType();

			if ( $type->isFunctionCall() ) {
				$call_parts[] = $part;
				continue;
			}

			if ( $type->isFunctionResponse() ) {
				return array( $message );
			}

			$text = $part->getText();
			if ( null !== $text && '' !== $text ) {
				$text_parts[] = $part;
				continue;
			}

			$other_parts[] = $part;
		}

		if ( empty( $call_parts ) ) {
			return array( $message );
		}

		$messages = array();
		$lead     = array_merge( $text_parts, $other_parts );

		if ( ! empty( $lead ) ) {
			$messages[] = self::rebuild_message( $message, $lead );
		}

		foreach ( $call_parts as $call_part ) {
			$messages[] = self::rebuild_message( $message, array( $call_part ) );
		}

		return $messages;
	}

	/**
	 * Inject missing tool outputs and drop unmatched responses.
	 *
	 * @param list<Message> $messages Message history.
	 * @return list<Message>
	 */
	public static function repair_tool_pairs( array $messages ) {
		$repaired    = array();
		$open_calls  = array();

		foreach ( $messages as $message ) {
			if ( ! $message instanceof Message ) {
				continue;
			}

			$parts         = $message->getParts();
			$function_call = self::extract_single_function_call( $parts );

			if ( null !== $function_call && $message->getRole()->isModel() ) {
				$call_id                   = self::resolve_call_id( $function_call );
				$_wwp_nc = $function_call->getName();
				$open_calls[ $call_id ]    =( null !== ( $_wwp_nc ) ? $_wwp_nc : 'unknown' );
				$repaired[]                = self::rebuild_message(
					$message,
					array( new MessagePart( new FunctionCall( $call_id, $function_call->getName(), $function_call->getArgs() ) ) )
				);
				continue;
			}

			$function_response = self::extract_single_function_response( $parts );

			if ( null !== $function_response && $message->getRole()->isUser() ) {
				$response_id   = $function_response->getId();
				$_wwp_nc = $function_response->getName();
				$function_name =( null !== ( $_wwp_nc ) ? $_wwp_nc : 'unknown' );

				if ( ! self::is_valid_call_id( $response_id ) ) {
					$response_id = self::shift_open_call_id( $open_calls, $function_name );
				} elseif ( ! isset( $open_calls[ $response_id ] ) ) {
					$response_id = self::shift_open_call_id( $open_calls, $function_name );
				}

				if ( ! self::is_valid_call_id( $response_id ) || ! isset( $open_calls[ $response_id ] ) ) {
					continue;
				}

				unset( $open_calls[ $response_id ] );

				$repaired[] = new UserMessage(
					array(
						new MessagePart(
							new FunctionResponse(
								$response_id,
								$function_response->getName(),
								$function_response->getResponse()
							)
						),
					)
				);
				continue;
			}

			$repaired[] = $message;
		}

		if ( ! empty( $open_calls ) ) {
			$repaired = self::remove_orphan_tool_calls( $repaired, array_keys( $open_calls ) );
		}

		return $repaired;
	}

	/**
	 * Remove model tool-call messages that never received an output.
	 *
	 * @param list<Message> $messages   Message history.
	 * @param list<string>  $orphan_ids Unresolved call ids.
	 * @return list<Message>
	 */
	private static function remove_orphan_tool_calls( array $messages, array $orphan_ids ) {
		if ( empty( $orphan_ids ) ) {
			return $messages;
		}

		$orphan_lookup = array_fill_keys( $orphan_ids, true );
		$filtered      = array();

		foreach ( $messages as $message ) {
			if ( ! $message instanceof Message || ! $message->getRole()->isModel() ) {
				$filtered[] = $message;
				continue;
			}

			$function_call = self::extract_single_function_call( $message->getParts() );

			if ( null === $function_call ) {
				$filtered[] = $message;
				continue;
			}

			$call_id = $function_call->getId();
			if ( ! self::is_valid_call_id( $call_id ) ) {
				$call_id = self::resolve_call_id( $function_call );
			}

			if ( isset( $orphan_lookup[ (string) $call_id ] ) ) {
				continue;
			}

			$filtered[] = $message;
		}

		return $filtered;
	}

	/**
	 * Whether a call id is safe to send to provider APIs.
	 *
	 * @param string|null $id Call id.
	 * @return bool
	 */
	public static function is_valid_call_id( $id ) {
		if ( ! is_string( $id ) || '' === $id ) {
			return false;
		}

		return 'unknown' !== strtolower( $id );
	}

	/**
	 * Resolve a non-empty function call ID.
	 *
	 * @param FunctionCall $call Function call.
	 * @return string
	 */
	public static function resolve_call_id( FunctionCall $call ) {
		$id = $call->getId();

		if ( self::is_valid_call_id( $id ) ) {
			return (string) $id;
		}

		return self::generate_call_id();
	}

	/**
	 * Generate a unique function call id.
	 *
	 * @return string
	 */
	public static function generate_call_id() {
		if ( function_exists( 'wp_generate_uuid4' ) ) {
			return 'call_' . wp_generate_uuid4();
		}

		return 'call_' . uniqid( '', true );
	}

	/**
	 * Sanitize a single message.
	 *
	 * @param Message                       $message       Message instance.
	 * @param array<string, list<string>>   $pending_calls Pending call ids keyed by function name (FIFO queues).
	 * @return Message
	 */
	private static function sanitize_message( Message $message, array &$pending_calls ) {
		$parts = array();

		foreach ( $message->getParts() as $part ) {
			$type = $part->getType();

			if ( $type->isFunctionCall() ) {
				$call = $part->getFunctionCall();

				if ( ! $call instanceof FunctionCall ) {
					continue;
				}

				$id   = self::resolve_call_id( $call );
				$_wwp_nc = $call->getName();
				$name =( null !== ( $_wwp_nc ) ? $_wwp_nc : 'unknown' );

				if ( ! isset( $pending_calls[ $name ] ) || ! is_array( $pending_calls[ $name ] ) ) {
					$pending_calls[ $name ] = array();
				}

				$pending_calls[ $name ][] = $id;

				$parts[] = new MessagePart(
					new FunctionCall( $id, $name, $call->getArgs() )
				);
				continue;
			}

			if ( $type->isFunctionResponse() ) {
				$response = $part->getFunctionResponse();

				if ( ! $response instanceof FunctionResponse ) {
					continue;
				}

				$id   = $response->getId();
				$_wwp_nc = $response->getName();
				$name =( null !== ( $_wwp_nc ) ? $_wwp_nc : 'unknown' );

				if ( ! self::is_valid_call_id( $id ) ) {
					if ( ! empty( $pending_calls[ $name ] ) ) {
						$id = array_shift( $pending_calls[ $name ] );
					} else {
						continue;
					}
				}

				$parts[] = new MessagePart(
					new FunctionResponse( $id, $name, $response->getResponse() )
				);
				continue;
			}

			$parts[] = $part;
		}

		if ( empty( $parts ) ) {
			return $message;
		}

		return self::rebuild_message( $message, $parts );
	}

	/**
	 * Rebuild a message with replacement parts.
	 *
	 * @param Message          $message Source message.
	 * @param list<MessagePart> $parts   Replacement parts.
	 * @return Message
	 */
	private static function rebuild_message( Message $message, array $parts ) {
		if ( $message instanceof UserMessage ) {
			return new UserMessage( $parts );
		}

		if ( $message instanceof ModelMessage ) {
			return new ModelMessage( $parts );
		}

		return new Message( $message->getRole(), $parts );
	}

	/**
	 * Extract a function call when the message only contains one tool call.
	 *
	 * @param list<MessagePart> $parts Message parts.
	 * @return FunctionCall|null
	 */
	private static function extract_single_function_call( array $parts ) {
		if ( 1 !== count( $parts ) || ! $parts[0]->getType()->isFunctionCall() ) {
			return null;
		}

		$call = $parts[0]->getFunctionCall();

		return $call instanceof FunctionCall ? $call : null;
	}

	/**
	 * Extract a function response when the message only contains one tool response.
	 *
	 * @param list<MessagePart> $parts Message parts.
	 * @return FunctionResponse|null
	 */
	private static function extract_single_function_response( array $parts ) {
		if ( 1 !== count( $parts ) || ! $parts[0]->getType()->isFunctionResponse() ) {
			return null;
		}

		$response = $parts[0]->getFunctionResponse();

		return $response instanceof FunctionResponse ? $response : null;
	}

	/**
	 * Shift the next unresolved call id for a function name.
	 *
	 * @param array<string, string> $open_calls Open call ids keyed by call id.
	 * @param string                $name       Function name.
	 * @return string|null
	 */
	private static function shift_open_call_id( array $open_calls, $name ) {
		foreach ( $open_calls as $call_id => $function_name ) {
			if ( $function_name === $name ) {
				return $call_id;
			}
		}

		return null;
	}
}
