<?php
/**
 * Conditionally loads the floating AI assistant in wp-admin.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Enqueues and mounts the floating AI assistant based on saved settings.
 */
class FloatingAiAssistantLoader {

	/**
	 * Wholesale post types that belong under the Wholesale admin menu.
	 *
	 * @var list<string>
	 */
	const WHOLESALE_POST_TYPES = array(
		'wwp_requests',
		'wwp_groups',
		'wc-quote',
		'wc-quote-rules',
		'custom_pdf',
	);

	/**
	 * Wholesale taxonomies associated with the Wholesale admin menu.
	 *
	 * @var list<string>
	 */
	const WHOLESALE_TAXONOMIES = array(
		'wholesale_user_roles',
	);

	/**
	 * Settings service.
	 *
	 * @var SettingsService
	 */
	private $settings_service;

	/**
	 * Whether assets were enqueued for the current request.
	 *
	 * @var bool
	 */
	private $loaded = false;

	/**
	 * Constructor.
	 *
	 * @param SettingsService|null $settings_service Optional settings service.
	 */
	public function __construct( $settings_service = null ) {
		$this->settings_service =( isset( $settings_service ) ? $settings_service : new SettingsService() );

		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ), 20 );
		add_action( 'admin_footer', array( $this, 'render_mount_point' ) );
	}

	/**
	 * Enqueue floating assistant assets when appropriate.
	 *
	 * @return void
	 */
	public function enqueue() {
		if ( ! $this->should_load() ) {
			return;
		}

		$asset_path = WWP_PLUGIN_PATH . 'build/pages/floating-ai-assistant.asset.php';
		$dependencies = array();
		$version      = WWP_VERSION;

		if ( file_exists( $asset_path ) ) {
			$asset = include $asset_path;
			if ( isset( $asset['dependencies'] ) && is_array( $asset['dependencies'] ) ) {
				$dependencies = $asset['dependencies'];
			}
			if ( isset( $asset['version'] ) ) {
				$version = $asset['version'];
			}
		}

		wp_enqueue_style(
			'wwp-floating-ai-assistant',
			WWP_PLUGIN_URL . 'build/pages/floating-ai-assistant.css',
			array(),
			$version,
			'all'
		);

		wp_enqueue_script(
			'wwp-floating-ai-assistant',
			WWP_PLUGIN_URL . 'build/pages/floating-ai-assistant.js',
			$dependencies,
			$version,
			array( 'in_footer' => true )
		);

		$settings = $this->settings_service->get_settings();

		wp_localize_script(
			'wwp-floating-ai-assistant',
			'wwpFloatingAiAssistant',
			array(
				'restUrl'        => rest_url( 'wholesale/v1/ai-assistant/' ),
				'nonce'          => wp_create_nonce( 'wp_rest' ),
				'permission'     => (string) ( ( isset( $settings['permission'] ) ? $settings['permission'] : 'approval' ) ),
				'enabled'        => ! empty( $settings['enabled'] ),
				'historyUrl'     => admin_url( 'admin.php?page=wwp-aiassistant&tab=history' ),
			)
		);

		$this->loaded = true;
	}

	/**
	 * Output the React mount point in the admin footer.
	 *
	 * @return void
	 */
	public function render_mount_point() {
		if ( ! $this->loaded ) {
			return;
		}

		echo '<div id="wwp-floating-ai-assistant"></div>';
	}

	/**
	 * Whether the floating assistant should load on the current admin screen.
	 *
	 * @return bool
	 */
	public function should_load() {
		if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		$settings = $this->settings_service->get_settings();
		if ( empty( $settings['enabled'] ) ) {
			return false;
		}

		// Hide the assistant when no AI provider is configured and active.
		if ( ! ( new ConnectorService( $this->settings_service ) )->has_any_active_provider() ) {
			return false;
		}

		$visibility = isset( $settings['visibility'] ) ? (string) $settings['visibility'] : 'wholesale';
		if ( 'all' === $visibility ) {
			return $this->has_admin_screen();
		}

		return $this->is_wholesale_admin_screen();
	}

	/**
	 * Whether a valid admin screen is available.
	 *
	 * @return bool
	 */
	private function has_admin_screen() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		return null !== $screen;
	}

	/**
	 * Whether the current screen is part of the Wholesale admin area.
	 *
	 * @return bool
	 */
	private function is_wholesale_admin_screen() {
		global $parent_file;

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( null === $screen ) {
			return false;
		}

		$menu_slug = function_exists( 'wwp_env' ) ? (string) wwp_env()->get( 'menu_slug' ) : 'wwp_wholesale';

		if ( $parent_file === $menu_slug ) {
			return true;
		}

		if ( 'toplevel_page_' . $menu_slug === $screen->id ) {
			return true;
		}

		if ( str_starts_with( $screen->id, 'wholesale_page_' ) ) {
			return true;
		}

		if ( ! empty( $screen->post_type ) && in_array( $screen->post_type, self::WHOLESALE_POST_TYPES, true ) ) {
			return true;
		}

		if ( ! empty( $screen->taxonomy ) && in_array( $screen->taxonomy, self::WHOLESALE_TAXONOMIES, true ) ) {
			return true;
		}

		return false;
	}
}
