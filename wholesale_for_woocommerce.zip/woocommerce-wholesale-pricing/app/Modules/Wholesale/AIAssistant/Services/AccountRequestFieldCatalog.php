<?php
/**
 * Maps account request field phrases to wholesale_account_requests keys.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Catalog for wholesale registration request meta fields.
 */
class AccountRequestFieldCatalog {

	use SettingCatalogTrait;

	/**
	 * Get Entries
	 * 
	 * @return array<string, array<string, mixed>>
	 */
	private static function get_entries() {
		static $entries = null;

		if ( null !== $entries ) {
			return $entries;
		}

		$entries = array(
			'approve' => array(
				'key'    => 'status',
				'label'  => 'Approve Request',
				'value'  => 'active',
				'phrases' => array( 'approve request', 'approve registration', 'approve application', 'approve wholesale request' ),
			),
			'reject' => array(
				'key'    => 'status',
				'label'  => 'Reject Request',
				'value'  => 'rejected',
				'phrases' => array( 'reject request', 'reject registration', 'reject application', 'reject wholesale request' ),
			),
			'assign_role' => array(
				'key'    => 'user_role_set',
				'label'  => 'Assign Wholesale Role',
				'phrases' => array( 'assign role request', 'set role on request', 'user role set request' ),
			),
			'rejected_note' => array(
				'key'    => 'rejected_note',
				'label'  => 'Reject Note',
				'phrases' => array( 'reject note', 'rejection note', 'rejected note' ),
			),
		);

		return $entries;
	}

	/**
	 * Resolve entry from message
	 * 
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>|null
	 */
	public static function resolve_entry_from_message( $normalized ) {
		return self::resolve_entry_from_phrases( $normalized, self::get_entries() );
	}

	/**
	 * Build mutation args
	 * 
	 * @param string $message Original message.
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>
	 */
	public static function build_mutation_args( $message, $normalized ) {
		$entry = self::resolve_entry_from_message( $normalized );

		if ( ! is_array( $entry ) ) {
			return array();
		}

		$identifier = self::extract_identifier( $message );

		if ( null === $identifier ) {
			return array();
		}

		$args = array(
			'action'     => 'update',
			'identifier' => $identifier,
		);

		$key = (string) ( ( isset( $entry['key'] ) ? $entry['key'] : '' ) );

		if ( 'status' === $key ) {
			$args['status'] = (string) ( ( isset( $entry['value'] ) ? $entry['value'] : '' ) );

			return $args;
		}

		if ( 'user_role_set' === $key && preg_match( '/\brole\s+([a-z0-9_-]+)\b/i', $message, $matches ) ) {
			$args['user_role_set'] = sanitize_key( $matches[1] );

			return $args;
		}

		if ( 'rejected_note' === $key && preg_match( '/note\s+"([^"]+)"/i', $message, $matches ) ) {
			$args['rejected_note'] = $matches[1];

			return $args;
		}

		return array();
	}

	/**
	 * Extract indentifier
	 * 
	 * @param string $message Original message.
	 * @return int|null
	 */
	public static function extract_identifier( $message ) {
		if ( preg_match( '/\b(?:request|application|id)\s*#?\s*(\d+)\b/i', $message, $matches ) ) {
			return (int) $matches[1];
		}

		return null;
	}

	/**
	 * Get matched keywords
	 * 
	 * @return list<string>
	 */
	public static function get_matcher_keywords() {
		return self::collect_matcher_keywords( self::get_entries() );
	}

	/**
	 * Get hint lines
	 * 
	 * @return list<string>
	 */
	public static function get_hint_lines() {
		return self::collect_hint_lines( self::get_entries() );
	}

	/**
	 * Format mutation summary
	 * 
	 * @param array<string, mixed> $args Mutation args.
	 * @return string
	 */
	public static function format_mutation_summary( array $args ) {
		$id =( isset( $args['identifier'] ) ? $args['identifier'] : '' );

		if ( isset( $args['status'] ) ) {
			if ( 'active' === $args['status'] ) {
				return sprintf(
					/* translators: %s: request id */
					__( 'Approve registration request #%s', 'woocommerce-wholesale-pricing' ),
					$id
				);
			}

			return sprintf(
				/* translators: %s: request id */
				__( 'Reject registration request #%s', 'woocommerce-wholesale-pricing' ),
				$id
			);
		}

		return sprintf(
			/* translators: %s: request id */
			__( 'Update registration request #%s', 'woocommerce-wholesale-pricing' ),
			$id
		);
	}
}
