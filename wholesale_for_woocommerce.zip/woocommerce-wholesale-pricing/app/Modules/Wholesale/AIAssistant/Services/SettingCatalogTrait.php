<?php
/**
 * Shared helpers for admin setting catalog classes.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Intent matching and phrase resolution utilities for setting catalogs.
 */
trait SettingCatalogTrait {

	/**
	 * Resolve the best matching catalog entry from phrase lists.
	 *
	 * @param string $normalized Lowercased message.
	 * @param array<string, array<string, mixed>> $entries Catalog entries keyed by id.
	 * @return array<string, mixed>|null
	 */
	protected static function resolve_entry_from_phrases( $normalized, array $entries ) {
		$best     = null;
		$best_len = 0;

		foreach ( $entries as $entry ) {
			$phrases = is_array(( isset( $entry['phrases'] ) ? $entry['phrases'] : null )) ? $entry['phrases'] : array();

			foreach ( $phrases as $phrase ) {
				$phrase = strtolower( trim( (string) $phrase ) );

				if ( '' === $phrase ) {
					continue;
				}

				if ( str_contains( $normalized, $phrase ) && strlen( $phrase ) > $best_len ) {
					$best     = $entry;
					$best_len = strlen( $phrase );
				}
			}
		}

		return $best;
	}

	/**
	 * Resolve all matching entries (non-overlapping by key).
	 *
	 * @param string $normalized Lowercased message.
	 * @param array<string, array<string, mixed>> $entries Catalog entries keyed by id.
	 * @return list<array<string, mixed>>
	 */
	protected static function resolve_all_entries_from_phrases( $normalized, array $entries ) {
		$matches = array();

		foreach ( $entries as $entry_id => $entry ) {
			$phrases = is_array(( isset( $entry['phrases'] ) ? $entry['phrases'] : null )) ? $entry['phrases'] : array();

			foreach ( $phrases as $phrase ) {
				$phrase = strtolower( trim( (string) $phrase ) );

				if ( '' !== $phrase && str_contains( $normalized, $phrase ) ) {
					$match_key = is_string( $entry_id ) && '' !== $entry_id
						? $entry_id
						: (string) ( ( isset( $entry['enable_key'] ) ? $entry['enable_key'] : ( isset( $entry['key'] ) ? $entry['key'] : '' ) ) );

					if ( '' !== $match_key && ! isset( $matches[ $match_key ] ) ) {
						$matches[ $match_key ] = $entry;
					}

					break;
				}
			}
		}

		return array_values( $matches );
	}

	/**
	 * Matches enable intent
	 * 
	 * @param string $normalized Lowercased message.
	 * @return bool
	 */
	public static function matches_enable_intent( $normalized ) {
		$phrases = array( 'enable', 'turn on', 'activate', 'show', 'display', 'allow' );

		foreach ( $phrases as $phrase ) {
			if ( str_contains( $normalized, $phrase ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Matches disable intent
	 * 
	 * @param string $normalized Lowercased message.
	 * @return bool
	 */
	public static function matches_disable_intent( $normalized ) {
		$phrases = array( 'disable', 'turn off', 'deactivate', 'hide', 'remove', 'disallow' );

		foreach ( $phrases as $phrase ) {
			if ( str_contains( $normalized, $phrase ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Matches required intent
	 * 
	 * @param string $normalized Lowercased message.
	 * @return bool
	 */
	public static function matches_required_intent( $normalized ) {
		return 1 === preg_match( '/\b(required|mandatory|must have|make it required|make required)\b/', $normalized );
	}

	/**
	 * Matches optional intent
	 * 
	 * @param string $normalized Lowercased message.
	 * @return bool
	 */
	public static function matches_optional_intent( $normalized ) {
		return 1 === preg_match( '/\b(optional|not required|make optional)\b/', $normalized );
	}

	/**
	 * Build yes/no patch for a boolean catalog entry.
	 *
	 * @param string               $normalized Lowercased message.
	 * @param array<string, mixed> $entry      Catalog entry.
	 * @return array<string, string>
	 */
	protected static function build_boolean_patch( $normalized, array $entry ) {
		$key      = (string) ( ( isset( $entry['key'] ) ? $entry['key'] : '' ) );
		$inverted = ! empty( $entry['inverted'] );
		$storage  = (string) ( ( isset( $entry['storage'] ) ? $entry['storage'] : 'yes_empty' ) );

		if ( '' === $key ) {
			return array();
		}

		$wants_enable  = self::matches_enable_intent( $normalized );
		$wants_disable = self::matches_disable_intent( $normalized );

		if ( ! $wants_enable && ! $wants_disable ) {
			return array();
		}

		$enabled = $wants_enable && ! $wants_disable;

		if ( $inverted ) {
			$enabled = ! $enabled;
		}

		if ( 'yes_no' === $storage ) {
			return array( $key => $enabled ? 'yes' : 'no' );
		}

		return array( $key => $enabled ? 'yes' : '' );
	}

	/**
	 * Build enable/required patch for paired field entries.
	 *
	 * @param string               $normalized Lowercased message.
	 * @param array<string, mixed> $entry      Catalog entry with enable_key and optional required_key.
	 * @return array<string, string>
	 */
	protected static function build_paired_field_patch( $normalized, array $entry ) {
		$settings       = array();
		$enable_key     = (string) ( ( isset( $entry['enable_key'] ) ? $entry['enable_key'] : '' ) );
		$required_key   = (string) ( ( isset( $entry['required_key'] ) ? $entry['required_key'] : '' ) );
		$wants_enable   = self::matches_enable_intent( $normalized );
		$wants_disable  = self::matches_disable_intent( $normalized );
		$wants_required = self::matches_required_intent( $normalized );
		$wants_optional = self::matches_optional_intent( $normalized );

		if ( '' !== $enable_key ) {
			if ( $wants_enable && ! $wants_disable ) {
				$settings[ $enable_key ] = 'yes';
			} elseif ( $wants_disable && ! $wants_enable ) {
				$settings[ $enable_key ] = '';
			}
		}

		if ( '' !== $required_key ) {
			if ( $wants_required ) {
				$settings[ $required_key ] = 'yes';

				if ( '' !== $enable_key && ! isset( $settings[ $enable_key ] ) && ! $wants_disable ) {
					$settings[ $enable_key ] = 'yes';
				}
			} elseif ( $wants_optional ) {
				$settings[ $required_key ] = '';
			}
		}

		return $settings;
	}

	/**
	 * Collect matcher keywords from catalog entries.
	 *
	 * @param array<string, array<string, mixed>> $entries Catalog entries.
	 * @return list<string>
	 */
	protected static function collect_matcher_keywords( array $entries ) {
		$keywords = array();

		foreach ( $entries as $entry ) {
			$phrases = is_array(( isset( $entry['phrases'] ) ? $entry['phrases'] : null )) ? $entry['phrases'] : array();

			foreach ( $phrases as $phrase ) {
				$phrase = strtolower( trim( (string) $phrase ) );

				if ( strlen( $phrase ) >= 3 ) {
					$keywords[] = $phrase;
				}
			}

			$key = (string) ( ( isset( $entry['key'] ) ? $entry['key'] : '' ) );

			if ( '' !== $key ) {
				$keywords[] = $key;
				$keywords[] = str_replace( '_', ' ', $key );
			}
		}

		return array_values( array_unique( $keywords ) );
	}

	/**
	 * Build compact hint lines for system prompt injection.
	 *
	 * @param array<string, array<string, mixed>> $entries Catalog entries.
	 * @param int                                 $limit   Max entries.
	 * @return list<string>
	 */
	protected static function collect_hint_lines( array $entries, $limit = 40 ) {
		$lines = array();
		$count = 0;

		foreach ( $entries as $entry ) {
			if ( $count >= $limit ) {
				break;
			}

			$label = (string) ( ( isset( $entry['label'] ) ? $entry['label'] : '' ) );
			$key   = (string) ( ( isset( $entry['key'] ) ? $entry['key'] : ( isset( $entry['enable_key'] ) ? $entry['enable_key'] : '' ) ) );

			if ( '' === $key ) {
				continue;
			}

			$lines[] = sprintf( '%s (%s)', $label, $key );
			++$count;
		}

		return $lines;
	}
}
