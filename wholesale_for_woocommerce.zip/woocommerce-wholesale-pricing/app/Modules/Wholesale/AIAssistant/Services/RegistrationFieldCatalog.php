<?php
/**
 * Maps registration form field phrases to wholesale_registration setting keys.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Central catalog for wholesale_registration intent matching and approval summaries.
 */
class RegistrationFieldCatalog {

	use SettingCatalogTrait;

	/**
	 * Address field slugs shared by billing/shipping groups.
	 *
	 * @var list<array{slug: string, label: string, enable_suffix: string, country_enable?: string}>
	 */
	const ADDRESS_SLUGS = array(
		array(
			'slug'           => 'first_name',
			'label'          => 'First Name',
			'enable_suffix'  => 'first_name',
		),
		array(
			'slug'           => 'last_name',
			'label'          => 'Last Name',
			'enable_suffix'  => 'last_name',
		),
		array(
			'slug'           => 'company',
			'label'          => 'Company',
			'enable_suffix'  => 'company',
		),
		array(
			'slug'           => 'address_1',
			'label'          => 'Address Line 1',
			'enable_suffix'  => 'address_1',
		),
		array(
			'slug'           => 'address_2',
			'label'          => 'Address Line 2',
			'enable_suffix'  => 'address_2',
		),
		array(
			'slug'           => 'city',
			'label'          => 'City',
			'enable_suffix'  => 'city',
		),
		array(
			'slug'           => 'post_code',
			'label'          => 'Postcode',
			'enable_suffix'  => 'post_code',
		),
		array(
			'slug'           => 'country',
			'label'          => 'Country',
			'enable_suffix'  => 'country',
		),
		array(
			'slug'           => 'state',
			'label'          => 'State',
			'enable_suffix'  => 'state',
		),
		array(
			'slug'           => 'phone',
			'label'          => 'Phone',
			'enable_suffix'  => 'phone',
		),
	);

	/**
	 * Standalone boolean/text registration settings.
	 *
	 * @var array<string, array<string, mixed>>
	 */
	const STANDALONE_ENTRIES = array(
		'tax_id_display' => array(
			'key'     => 'tax_id_display',
			'label'   => 'Tax ID Display',
			'storage' => 'yes_no',
			'phrases' => array( 'tax id display', 'show tax id on form' ),
		),
		'extra_pass_field' => array(
			'key'     => 'extra_pass_field',
			'label'   => 'Confirm Password',
			'storage' => 'yes_no',
			'phrases' => array( 'confirm password', 'extra password field', 'password confirmation' ),
		),
		'extra_role_fields' => array(
			'key'     => 'extra_role_fields',
			'label'   => 'User Role Selection',
			'storage' => 'yes_no',
			'phrases' => array( 'user role field', 'role selection on registration', 'extra role fields' ),
		),
		'multiple_file_upload' => array(
			'key'     => 'multiple_file_upload',
			'label'   => 'Multiple File Upload',
			'storage' => 'yes_no',
			'phrases' => array( 'multiple file upload', 'multiple uploads', 'allow multiple files' ),
		),
		'custommer_billing_address' => array(
			'key'     => 'custommer_billing_address',
			'label'   => 'Billing Address Form',
			'storage' => 'yes_empty',
			'phrases' => array( 'billing address form', 'enable billing address', 'default billing fields' ),
		),
		'custommer_shipping_address' => array(
			'key'     => 'custommer_shipping_address',
			'label'   => 'Shipping Address Form',
			'storage' => 'yes_empty',
			'phrases' => array( 'shipping address form', 'enable shipping address', 'default shipping fields' ),
		),
		'display_fields_registration' => array(
			'key'     => 'display_fields_registration',
			'label'   => 'Extra Fields on Registration',
			'storage' => 'yes_empty',
			'phrases' => array( 'extra fields on registration', 'display fields registration', 'show extra fields registration' ),
		),
		'display_fields_myaccount' => array(
			'key'     => 'display_fields_myaccount',
			'label'   => 'Extra Fields on My Account',
			'storage' => 'yes_empty',
			'phrases' => array( 'extra fields on my account', 'display fields my account', 'show extra fields account' ),
		),
		'display_fields_checkout' => array(
			'key'     => 'display_fields_checkout',
			'label'   => 'Extra Fields on Checkout',
			'storage' => 'yes_empty',
			'phrases' => array( 'extra fields on checkout', 'display fields checkout', 'show extra fields checkout' ),
		),
		'enable_recaptcha' => array(
			'key'     => 'enable_recaptcha',
			'label'   => 'reCAPTCHA on Registration',
			'storage' => 'yes_empty',
			'phrases' => array( 'recaptcha registration', 'enable recaptcha registration', 'captcha on registration form', 'google recaptcha registration' ),
		),
		'enable_recaptcha_quote' => array(
			'key'     => 'enable_recaptcha_quote',
			'label'   => 'reCAPTCHA on Quote',
			'storage' => 'yes_empty',
			'phrases' => array( 'recaptcha quote', 'enable recaptcha quote', 'captcha on quote', 'google recaptcha quote' ),
		),
	);

	/**
	 * Special paired fields (tax id, file upload).
	 *
	 * @var array<string, array<string, mixed>>
	 */
	const PAIRED_ENTRIES = array(
		'tax_id' => array(
			'label'        => 'Tax ID',
			'enable_key'   => 'enable_tex_id',
			'required_key' => 'required_tex_id',
			'phrases'      => array( 'tax id field', 'tax id', 'tax-id', 'vat number', 'vat id' ),
		),
		'file_upload' => array(
			'label'        => 'File Upload',
			'enable_key'   => 'enable_file_upload',
			'required_key' => 'required_file_upload',
			'phrases'      => array( 'file upload field', 'file upload', 'upload file', 'document upload' ),
		),
	);

	/**
	 * Get all entries
	 * 
	 * @return array<string, array<string, mixed>>
	 */
	private static function get_all_entries() {
		static $entries = null;

		if ( null !== $entries ) {
			return $entries;
		}

		$entries = array();

		foreach ( self::PAIRED_ENTRIES as $id => $entry ) {
			$entries[ $id ] = $entry;
		}

		foreach ( array( 'billing', 'shipping' ) as $group ) {
			foreach ( self::ADDRESS_SLUGS as $field ) {
				$slug   = (string) $field['slug'];
				$label  = (string) $field['label'];
				$suffix = (string) $field['enable_suffix'];
				$id     = $group . '_' . $slug;

				$entries[ $id ] = array(
					'label'        => ucfirst( $group ) . ' ' . $label,
					'enable_key'   => 'enable_' . $group . '_' . $suffix,
					'required_key' => 'required_' . $group . '_' . $suffix,
					'phrases'      => array(
						$group . ' ' . strtolower( $label ),
						$group . ' ' . str_replace( '_', ' ', $slug ),
						strtolower( $label ) . ' on ' . $group,
					),
				);
			}
		}

		foreach ( self::STANDALONE_ENTRIES as $id => $entry ) {
			$entries[ $id ] = $entry;
		}

		return $entries;
	}

	/**
	 * Resolve a registration field from the user message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>|null
	 */
	public static function resolve_field_from_message( $normalized ) {
		return self::resolve_entry_from_phrases( $normalized, self::get_all_entries() );
	}

	/**
	 * Resolve all matching registration fields from the user message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return list<array<string, mixed>>
	 */
	public static function resolve_all_fields_from_message( $normalized ) {
		return self::resolve_all_entries_from_phrases( $normalized, self::get_all_entries() );
	}

	/**
	 * Build settings patch for one catalog entry.
	 *
	 * @param string               $normalized Lowercased message.
	 * @param array<string, mixed> $entry      Catalog entry.
	 * @return array<string, string>
	 */
	public static function build_settings_patch( $normalized, array $entry ) {
		if ( isset( $entry['enable_key'] ) ) {
			return self::build_paired_field_patch( $normalized, $entry );
		}

		return self::build_boolean_patch( $normalized, $entry );
	}

	/**
	 * Build combined settings patch from message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return array<string, string>
	 */
	public static function build_combined_settings_patch( $normalized ) {
		$settings = array();
		$entries  = self::resolve_all_fields_from_message( $normalized );

		if ( empty( $entries ) ) {
			$single = self::resolve_field_from_message( $normalized );

			if ( is_array( $single ) ) {
				$entries = array( $single );
			}
		}

		foreach ( $entries as $entry ) {
			$patch = self::build_settings_patch( $normalized, $entry );

			foreach ( $patch as $key => $value ) {
				$settings[ $key ] = $value;
			}
		}

		return $settings;
	}

	/**
	 * Normalize incoming settings keys from AI tool arguments.
	 *
	 * @param array<string, mixed> $settings Raw settings patch.
	 * @return array<string, mixed>
	 */
	public static function normalize_settings_keys( array $settings ) {
		$normalized = array();

		foreach ( $settings as $key => $value ) {
			$sanitized_key = sanitize_key( (string) $key );

			if ( '' === $sanitized_key ) {
				continue;
			}

			$normalized[ $sanitized_key ] = $value;
		}

		return $normalized;
	}

	/**
	 * Get matched keywords
	 * 
	 * @return list<string>
	 */
	public static function get_matcher_keywords() {
		return self::collect_matcher_keywords( self::get_all_entries() );
	}

	/**
	 * Get hint lines
	 * 
	 * @return list<string>
	 */
	public static function get_hint_lines() {
		return self::collect_hint_lines( self::get_all_entries() );
	}

	/**
	 * Human-readable label for a registration setting key.
	 *
	 * @param string $key Setting key.
	 * @return string
	 */
	public static function get_setting_label( $key ) {
		foreach ( self::get_all_entries() as $entry ) {
			if ( ( ( isset( $entry['enable_key'] ) ? $entry['enable_key'] : '' ) ) === $key ) {
				/* translators: %s: field label */
				return sprintf( __( '%s field visibility', 'woocommerce-wholesale-pricing' ), $entry['label'] );
			}

			if ( ( ( isset( $entry['required_key'] ) ? $entry['required_key'] : '' ) ) === $key ) {
				/* translators: %s: field label */
				return sprintf( __( '%s field required', 'woocommerce-wholesale-pricing' ), $entry['label'] );
			}

			if ( ( ( isset( $entry['key'] ) ? $entry['key'] : '' ) ) === $key ) {
				return (string) $entry['label'];
			}
		}

		return $key;
	}

	/**
	 * Format one registration setting change for approval cards.
	 *
	 * @param string $key   Setting key.
	 * @param string $value Target value.
	 * @return string
	 */
	public static function format_setting_change_summary( $key, $value ) {
		foreach ( self::get_all_entries() as $entry ) {
			if ( ( ( isset( $entry['enable_key'] ) ? $entry['enable_key'] : '' ) ) === $key ) {
				if ( 'yes' === $value ) {
					/* translators: %s: field label */
					return sprintf( __( 'Enable %s field on registration form', 'woocommerce-wholesale-pricing' ), $entry['label'] );
				}

				/* translators: %s: field label */
				return sprintf( __( 'Hide %s field on registration form', 'woocommerce-wholesale-pricing' ), $entry['label'] );
			}

			if ( ( ( isset( $entry['required_key'] ) ? $entry['required_key'] : '' ) ) === $key ) {
				if ( 'yes' === $value ) {
					/* translators: %s: field label */
					return sprintf( __( 'Make %s field required on registration form', 'woocommerce-wholesale-pricing' ), $entry['label'] );
				}

				/* translators: %s: field label */
				return sprintf( __( 'Make %s field optional on registration form', 'woocommerce-wholesale-pricing' ), $entry['label'] );
			}

			if ( ( ( isset( $entry['key'] ) ? $entry['key'] : '' ) ) === $key ) {
				if ( 'yes' === $value ) {
					/* translators: %s: setting label */
					return sprintf( __( 'Enable %s', 'woocommerce-wholesale-pricing' ), $entry['label'] );
				}

				/* translators: %s: setting label */
				return sprintf( __( 'Disable %s', 'woocommerce-wholesale-pricing' ), $entry['label'] );
			}
		}

		return $key;
	}
}
