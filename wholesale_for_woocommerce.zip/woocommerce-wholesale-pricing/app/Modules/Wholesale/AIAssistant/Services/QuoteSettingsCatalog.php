<?php
/**
 * Maps quote settings phrases to quote_settings ability keys.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

use WooCommerceWholesalePricing\App\Services\WholesaleQuoteSettingsService;

/**
 * Central catalog for quote_settings intent matching and approval summaries.
 */
class QuoteSettingsCatalog {

	use SettingCatalogTrait;

	/**
	 * Catalog entries keyed by setting key.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	private static function get_entries() {
		static $entries = null;

		if ( null !== $entries ) {
			return $entries;
		}

		$entries = array(
			'enable_quote' => array(
				'key'     => 'enable_quote',
				'label'   => 'Enable Quote Module',
				'group'   => 'top',
				'storage' => 'boolean',
				'phrases' => array( 'enable quote module', 'quote module', 'disable quote module' ),
			),
			'quote_page' => array(
				'key'     => 'quote_page',
				'label'   => 'Quote List Page',
				'group'   => 'general',
				'storage' => 'page_id',
				'phrases' => array( 'quote list page', 'quote page id', 'quote page' ),
			),
			'empty_email' => array(
				'key'     => 'empty_email',
				'label'   => 'Empty Quote After Email',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'empty quote after email', 'clear quote after email' ),
			),
			'wc_requote' => array(
				'key'     => 'wc_requote',
				'label'   => 'Re-Quote',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 're-quote', 'requote', 're quote' ),
			),
			'enable_convert_cart' => array(
				'key'     => 'enable_convert_cart',
				'label'   => 'Convert Quote to Cart',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'convert quote to cart', 'quote to cart' ),
			),
			'enable_build_quote' => array(
				'key'     => 'enable_build_quote',
				'label'   => 'Show Build Quote',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'show build quote', 'build quote on cart' ),
			),
			'empty_cart' => array(
				'key'     => 'empty_cart',
				'label'   => 'Empty Cart',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'empty cart after quote', 'empty cart quote' ),
			),
			'enable_show_quote_details' => array(
				'key'     => 'enable_show_quote_details',
				'label'   => 'Show Quote Details in Order',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'show quote details in order', 'quote details in order' ),
			),
			'mini_cart' => array(
				'key'     => 'mini_cart',
				'label'   => 'Quote Basket',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'enable quote basket', 'disable quote basket', 'quote basket', 'mini cart quote', 'quote mini cart' ),
			),
			'quote_basket_menu' => array(
				'key'     => 'quote_basket_menu',
				'label'   => 'Quote Basket Menu',
				'group'   => 'general',
				'storage' => 'menu_ids',
				'phrases' => array( 'quote basket menu', 'quote basket in menu' ),
			),
			'disable_basket_roles' => array(
				'key'     => 'disable_basket_roles',
				'label'   => 'Disable Quote Basket for Roles',
				'group'   => 'general',
				'storage' => 'role_slugs',
				'phrases' => array( 'disable quote basket for roles', 'disable basket roles' ),
			),
			'quote_basket_style' => array(
				'key'     => 'quote_basket_style',
				'label'   => 'Quote Basket Style',
				'group'   => 'general',
				'storage' => 'basket_style',
				'phrases' => array( 'quote basket style', 'quote basket dropdown', 'quote basket icon' ),
			),
			'quote_expire' => array(
				'key'     => 'quote_expire',
				'label'   => 'Quote Expire',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'quote expire', 'quote expiry', 'quote expiration' ),
			),
			'enable_offered' => array(
				'key'     => 'enable_offered',
				'label'   => 'Offered Price',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'offered price', 'enable offered price' ),
			),
			'inc_dec_offered_price' => array(
				'key'     => 'inc_dec_offered_price',
				'label'   => 'Offered Price Mode',
				'group'   => 'general',
				'storage' => 'offered_mode',
				'phrases' => array( 'offered price increase', 'offered price decrease', 'inc dec offered price' ),
			),
			'increase_offered_price' => array(
				'key'     => 'increase_offered_price',
				'label'   => 'Increase Offered Price',
				'group'   => 'general',
				'storage' => 'number',
				'phrases' => array( 'increase offered price', 'offered price increase percent' ),
			),
			'decrease_offered_price' => array(
				'key'     => 'decrease_offered_price',
				'label'   => 'Decrease Offered Price',
				'group'   => 'general',
				'storage' => 'number',
				'phrases' => array( 'decrease offered price', 'offered price decrease percent' ),
			),
			'display_tax' => array(
				'key'     => 'display_tax',
				'label'   => 'Display Tax on Quote',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'display tax quote', 'show tax on quote' ),
			),
			'enable_standard' => array(
				'key'     => 'enable_standard',
				'label'   => 'Standard Price on Quote',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'standard price quote', 'enable standard price' ),
			),
			'return_shop' => array(
				'key'     => 'return_shop',
				'label'   => 'Return to Shop',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'return to shop quote', 'return shop on quote page' ),
			),
			'convert_to_order' => array(
				'key'     => 'convert_to_order',
				'label'   => 'Convert to Order',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'convert quote to order', 'convert to order quote' ),
			),
			'send_to_checkout' => array(
				'key'     => 'send_to_checkout',
				'label'   => 'Convert to Checkout',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'convert to checkout', 'send quote to checkout' ),
			),
			'display_quote_converter' => array(
				'key'     => 'display_quote_converter',
				'label'   => 'Display Quote Converter',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'quote converter', 'display quote converter' ),
			),
			'display_quote_counter' => array(
				'key'     => 'display_quote_counter',
				'label'   => 'Quote Counter',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'quote counter', 'display quote counter' ),
			),
			'counter_shop' => array(
				'key'     => 'counter_shop',
				'label'   => 'Quote Counter on Shop',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'quote counter shop', 'counter on shop page' ),
			),
			'counter_single_product' => array(
				'key'     => 'counter_single_product',
				'label'   => 'Quote Counter on Product',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'quote counter product', 'counter on single product' ),
			),
			'show_on_stock' => array(
				'key'     => 'show_on_stock',
				'label'   => 'Show Out of Stock on Quote',
				'group'   => 'general',
				'storage' => 'stock_visibility',
				'phrases' => array( 'show out of stock quote', 'hide out of stock quote', 'show on stock quote' ),
			),
			'display_browse_list' => array(
				'key'     => 'display_browse_list',
				'label'   => 'Browse Quote List',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'browse quote list', 'view quote cart list' ),
			),
			'custom_tax_shipping' => array(
				'key'     => 'custom_tax_shipping',
				'label'   => 'Custom Tax and Shipping',
				'group'   => 'general',
				'storage' => 'yes_empty',
				'phrases' => array( 'custom tax shipping quote', 'custom tax and shipping' ),
			),
			'email_success_msg' => array(
				'key'     => 'email_success_msg',
				'label'   => 'Email Success Message',
				'group'   => 'notifications',
				'storage' => 'text',
				'phrases' => array( 'quote email success message', 'email success message quote' ),
			),
			'email_error_msg' => array(
				'key'     => 'email_error_msg',
				'label'   => 'Email Error Message',
				'group'   => 'notifications',
				'storage' => 'text',
				'phrases' => array( 'quote email error message', 'email error message quote' ),
			),
			'email_valid_msg' => array(
				'key'     => 'email_valid_msg',
				'label'   => 'Email Validation Message',
				'group'   => 'notifications',
				'storage' => 'text',
				'phrases' => array( 'quote email validation message', 'email validation message quote' ),
			),
			'add_quote_redirect' => array(
				'key'     => 'add_quote_redirect',
				'label'   => 'Add to Quote Redirect',
				'group'   => 'notifications',
				'storage' => 'yes_empty',
				'phrases' => array( 'add to quote redirect', 'add quote redirect' ),
			),
			'add_quote_redirect_url' => array(
				'key'     => 'add_quote_redirect_url',
				'label'   => 'Add to Quote Redirect URL',
				'group'   => 'notifications',
				'storage' => 'url',
				'phrases' => array( 'add to quote redirect url', 'add quote redirect url' ),
			),
			'send_quote_redirect' => array(
				'key'     => 'send_quote_redirect',
				'label'   => 'Send Quote Redirect',
				'group'   => 'notifications',
				'storage' => 'yes_empty',
				'phrases' => array( 'send quote redirect' ),
			),
			'send_quote_redirect_url' => array(
				'key'     => 'send_quote_redirect_url',
				'label'   => 'Send Quote Redirect URL',
				'group'   => 'notifications',
				'storage' => 'url',
				'phrases' => array( 'send quote redirect url' ),
			),
			'enable_pdf' => array(
				'key'     => 'enable_pdf',
				'label'   => 'Enable Quote PDF',
				'group'   => 'pdf',
				'storage' => 'yes_empty',
				'phrases' => array( 'enable pdf', 'quote pdf', 'enable quote pdf' ),
			),
			'enable_pdf_download' => array(
				'key'     => 'enable_pdf_download',
				'label'   => 'PDF Download',
				'group'   => 'pdf',
				'storage' => 'yes_empty',
				'phrases' => array( 'pdf download', 'enable pdf download' ),
			),
			'enable_pdf_attach' => array(
				'key'     => 'enable_pdf_attach',
				'label'   => 'Attach PDF in Email',
				'group'   => 'pdf',
				'storage' => 'yes_empty',
				'phrases' => array( 'attach pdf email', 'pdf in email', 'attach pdf in email' ),
			),
			'hide_product_list' => array(
				'key'     => 'hide_product_list',
				'label'   => 'Hide Product List from Email',
				'group'   => 'pdf',
				'storage' => 'yes_empty',
				'phrases' => array( 'hide product list email', 'hide product list from email' ),
			),
			'pdf_logo_id' => array(
				'key'     => 'pdf_logo_id',
				'label'   => 'PDF Logo',
				'group'   => 'pdf',
				'storage' => 'attachment_id',
				'phrases' => array( 'pdf logo', 'quote pdf logo', 'upload logo for pdf' ),
			),
			'pdf_show_link' => array(
				'key'     => 'pdf_show_link',
				'label'   => 'Show Accept Link in PDF',
				'group'   => 'pdf',
				'storage' => 'yes_empty',
				'phrases' => array( 'pdf accept link', 'show link accept checkout pdf' ),
			),
			'quote_pdf' => array(
				'key'     => 'quote_pdf',
				'label'   => 'PDF Template',
				'group'   => 'pdf',
				'storage' => 'pdf_template',
				'phrases' => array( 'pdf template', 'quote pdf template', 'default pdf template', 'custom pdf template' ),
			),
			'custom' => array(
				'key'     => 'custom',
				'label'   => 'Custom PDF Template Color',
				'group'   => 'pdf',
				'storage' => 'pdf_color',
				'phrases' => array( 'custom template bronze', 'custom template darkblue', 'custom template lightblue', 'pdf template color', 'pdf color template' ),
			),
		);

		return $entries;
	}

	/**
	 * Resolve entry from message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>|null
	 */
	public static function resolve_entry_from_message( $normalized ) {
		return self::resolve_entry_from_phrases( $normalized, self::get_entries() );
	}

	/**
	 * Build settings patch for a single best-matching entry.
	 *
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>
	 */
	public static function build_settings_patch( $normalized ) {
		$combined = self::build_combined_settings_patch( $normalized );

		if ( ! empty( $combined ) ) {
			return $combined;
		}

		return array();
	}

	/**
	 * Build settings patch resolving all matching entries in one message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>
	 */
	public static function build_combined_settings_patch( $normalized ) {
		$settings = array();
		$entries  = self::resolve_all_entries_from_phrases( $normalized, self::get_entries() );

		if ( empty( $entries ) ) {
			$single = self::resolve_entry_from_phrases( $normalized, self::get_entries() );

			if ( is_array( $single ) ) {
				$entries = array( $single );
			}
		}

		foreach ( $entries as $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}

			$patch = self::build_entry_patch( $normalized, $entry );

			if ( isset( $patch['enable_quote'] ) ) {
				$settings['enable_quote'] = $patch['enable_quote'];
			}

			foreach ( array( 'general', 'notifications', 'pdf' ) as $group ) {
				if ( empty( $patch[ $group ] ) || ! is_array( $patch[ $group ] ) ) {
					continue;
				}

				if ( ! isset( $settings[ $group ] ) || ! is_array( $settings[ $group ] ) ) {
					$settings[ $group ] = array();
				}

				$settings[ $group ] = array_merge( $settings[ $group ], $patch[ $group ] );
			}
		}

		if ( ! isset( $settings['pdf']['quote_pdf'] ) ) {
			$template = self::resolve_pdf_template_from_message( $normalized );

			if ( '' !== $template ) {
				if ( ! isset( $settings['pdf'] ) || ! is_array( $settings['pdf'] ) ) {
					$settings['pdf'] = array();
				}

				$settings['pdf']['quote_pdf'] = $template;
			}
		}

		if ( ! isset( $settings['pdf']['custom'] ) ) {
			$color = self::resolve_pdf_color_from_message( $normalized );

			if ( '' !== $color ) {
				if ( ! isset( $settings['pdf'] ) || ! is_array( $settings['pdf'] ) ) {
					$settings['pdf'] = array();
				}

				$settings['pdf']['custom'] = $color;
			}
		}

		return $settings;
	}

	/**
	 * Flatten nested quote settings patch for mutation args.
	 *
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>
	 */
	public static function build_mutation_settings( $normalized ) {
		return self::build_combined_settings_patch( $normalized );
	}

	/**
	 * Get matcher keywords.
	 *
	 * @return list<string>
	 */
	public static function get_matcher_keywords() {
		return self::collect_matcher_keywords( self::get_entries() );
	}

	/**
	 * Get hint lines.
	 *
	 * @return list<string>
	 */
	public static function get_hint_lines() {
		return self::collect_hint_lines( self::get_entries() );
	}

	/**
	 * Human-readable label for a setting key.
	 *
	 * @param string $key Setting key.
	 * @return string
	 */
	public static function get_setting_label( $key ) {
		$entries = self::get_entries();

		if ( isset( $entries[ $key ] ) ) {
			return (string) $entries[ $key ]['label'];
		}

		return ucwords( str_replace( '_', ' ', $key ) );
	}

	/**
	 * Format settings change summary.
	 *
	 * @param string $key   Setting key.
	 * @param mixed  $value Value.
	 * @return string
	 */
	public static function format_setting_change_summary( $key, $value ) {
		$label = self::get_setting_label( (string) $key );
		$entry = isset( self::get_entries()[ $key ] ) ? self::get_entries()[ $key ] : null;
		$storage = is_array( $entry ) ? (string) ( isset( $entry['storage'] ) ? $entry['storage'] : '' ) : '';

		if ( in_array( $storage, array( 'yes_empty', 'boolean' ), true ) || 'enable_quote' === $key ) {
			$enabled = in_array( $value, array( 'yes', '1', 'true', '1.0', 1, true ), true );

			if ( $enabled ) {
				/* translators: %s: setting label */
				return sprintf( __( 'Enable %s', 'woocommerce-wholesale-pricing' ), $label );
			}

			/* translators: %s: setting label */
			return sprintf( __( 'Disable %s', 'woocommerce-wholesale-pricing' ), $label );
		}

		if ( 'pdf_template' === $storage ) {
			$display = 'custom' === (string) $value
				? __( 'Custom Template', 'woocommerce-wholesale-pricing' )
				: __( 'Default Template', 'woocommerce-wholesale-pricing' );

			/* translators: 1: setting label, 2: template */
			return sprintf( __( 'Set %1$s to %2$s', 'woocommerce-wholesale-pricing' ), $label, $display );
		}

		if ( 'pdf_color' === $storage ) {
			/* translators: 1: setting label, 2: color slug */
			return sprintf( __( 'Set %1$s to %2$s', 'woocommerce-wholesale-pricing' ), $label, (string) $value );
		}

		if ( in_array( $storage, array( 'text', 'url', 'number', 'page_id', 'attachment_id', 'menu_ids', 'role_slugs', 'basket_style', 'offered_mode', 'stock_visibility' ), true ) ) {
			if ( is_array( $value ) ) {
				$value = implode( ', ', array_map( 'strval', $value ) );
			}

			/* translators: 1: setting label, 2: value */
			return sprintf( __( 'Set %1$s to %2$s', 'woocommerce-wholesale-pricing' ), $label, (string) $value );
		}

		/* translators: 1: setting label, 2: value */
		return sprintf( __( 'Set %1$s to %2$s', 'woocommerce-wholesale-pricing' ), $label, is_scalar( $value ) ? (string) $value : '' );
	}

	/**
	 * Build a patch for a single catalog entry.
	 *
	 * @param string               $normalized Lowercased message.
	 * @param array<string, mixed> $entry      Catalog entry.
	 * @return array<string, mixed>
	 */
	private static function build_entry_patch( $normalized, array $entry ) {
		$key     = (string) ( ( isset( $entry['key'] ) ? $entry['key'] : '' ) );
		$group   = (string) ( ( isset( $entry['group'] ) ? $entry['group'] : 'general' ) );
		$storage = (string) ( ( isset( $entry['storage'] ) ? $entry['storage'] : 'yes_empty' ) );

		if ( '' === $key ) {
			return array();
		}

		if ( 'boolean' === $storage || 'top' === $group ) {
			$wants_enable  = self::matches_enable_intent( $normalized );
			$wants_disable = self::matches_disable_intent( $normalized );

			if ( ! $wants_enable && ! $wants_disable ) {
				return array();
			}

			return array(
				'enable_quote' => $wants_enable && ! $wants_disable,
			);
		}

		if ( in_array( $storage, array( 'yes_empty', 'yes_no' ), true ) ) {
			$patch = self::build_boolean_patch( $normalized, $entry );

			if ( empty( $patch ) ) {
				return array();
			}

			$bool_patch = array(
				$key => 'yes' === ( isset( $patch[ $key ] ) ? $patch[ $key ] : '' ) || '1' === ( isset( $patch[ $key ] ) ? $patch[ $key ] : '' ),
			);

			return self::wrap_group_patch( $group, $bool_patch );
		}

		$value = self::resolve_value_from_message( $normalized, $storage );

		if ( '' === $value && ! is_array( $value ) ) {
			return array();
		}

		return self::wrap_group_patch( $group, array( $key => $value ) );
	}

	/**
	 * Wrap a flat field patch in its settings group.
	 *
	 * @param string               $group Group name.
	 * @param array<string, mixed> $patch Field patch.
	 * @return array<string, mixed>
	 */
	private static function wrap_group_patch( $group, array $patch ) {
		if ( 'top' === $group ) {
			return $patch;
		}

		return array(
			'general'       => 'general' === $group ? $patch : array(),
			'notifications' => 'notifications' === $group ? $patch : array(),
			'pdf'           => 'pdf' === $group ? $patch : array(),
		);
	}

	/**
	 * Resolve a non-boolean value from message based on storage type.
	 *
	 * @param string $normalized Lowercased message.
	 * @param string $storage    Storage type.
	 * @return mixed
	 */
	private static function resolve_value_from_message( $normalized, $storage ) {
		switch ( $storage ) {
			case 'text':
				return self::extract_text_value( $normalized );
			case 'url':
				return self::extract_url_value( $normalized );
			case 'number':
				return self::extract_number_value( $normalized );
			case 'page_id':
			case 'attachment_id':
				return self::extract_numeric_id( $normalized );
			case 'pdf_template':
				return self::resolve_pdf_template_from_message( $normalized );
			case 'pdf_color':
				return self::resolve_pdf_color_from_message( $normalized );
			case 'basket_style':
				return self::resolve_basket_style_from_message( $normalized );
			case 'offered_mode':
				return self::resolve_offered_mode_from_message( $normalized );
			case 'stock_visibility':
				return self::resolve_stock_visibility_from_message( $normalized );
			case 'menu_ids':
				return self::extract_numeric_id_list( $normalized );
			case 'role_slugs':
				return self::extract_role_slug_list( $normalized );
			default:
				return '';
		}
	}

	/**
	 * Extract text from quoted or trailing phrasing.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string
	 */
	public static function extract_text_value( $normalized ) {
		if ( preg_match( '/\bto\s+"([^"]+)"/', $normalized, $matches ) ) {
			return sanitize_text_field( $matches[1] );
		}

		if ( preg_match( "/\bto\s+'([^']+)'/", $normalized, $matches ) ) {
			return sanitize_text_field( $matches[1] );
		}

		if ( preg_match( '/\bto\s+(.+)$/u', $normalized, $matches ) ) {
			$value = trim( $matches[1] );
			$value = preg_replace( '/\s+(and|with)\s+.+$/', '', $value );

			return sanitize_text_field( trim( (string) $value ) );
		}

		return '';
	}

	/**
	 * Extract a URL from the message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string
	 */
	public static function extract_url_value( $normalized ) {
		if ( preg_match( '#https?://[^\s"\']+#i', $normalized, $matches ) ) {
			return esc_url_raw( $matches[0] );
		}

		$text = self::extract_text_value( $normalized );

		return '' !== $text ? esc_url_raw( $text ) : '';
	}

	/**
	 * Extract a numeric value from the message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string
	 */
	public static function extract_number_value( $normalized ) {
		if ( preg_match( '/\bto\s+(\d+(?:\.\d+)?)\b/', $normalized, $matches ) ) {
			return (string) $matches[1];
		}

		if ( preg_match( '/\b(\d+(?:\.\d+)?)\s*%/', $normalized, $matches ) ) {
			return (string) $matches[1];
		}

		return '';
	}

	/**
	 * Extract a numeric ID from the message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string
	 */
	public static function extract_numeric_id( $normalized ) {
		if ( preg_match( '/#(\d+)/', $normalized, $matches ) ) {
			return (string) absint( $matches[1] );
		}

		if ( preg_match( '/\b(?:id|attachment|page|logo)\s*#?\s*(\d+)\b/', $normalized, $matches ) ) {
			return (string) absint( $matches[1] );
		}

		return '';
	}

	/**
	 * Extract a list of numeric IDs from the message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return list<int>
	 */
	public static function extract_numeric_id_list( $normalized ) {
		if ( ! preg_match_all( '/#?(\d+)/', $normalized, $matches ) ) {
			return array();
		}

		return array_values( array_map( 'absint', $matches[1] ) );
	}

	/**
	 * Extract role slugs from the message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return list<string>
	 */
	public static function extract_role_slug_list( $normalized ) {
		$slugs = array();

		if ( preg_match_all( '/\b([a-z0-9][a-z0-9_-]*_wholesaler)\b/', $normalized, $matches ) ) {
			foreach ( $matches[1] as $slug ) {
				$slugs[] = sanitize_key( $slug );
			}
		}

		if ( 'wholesaler' === $normalized || str_contains( $normalized, 'default wholesaler' ) ) {
			$slugs[] = 'default_wholesaler';
		}

		return array_values( array_unique( $slugs ) );
	}

	/**
	 * Resolve PDF template mode from message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string
	 */
	public static function resolve_pdf_template_from_message( $normalized ) {
		if ( str_contains( $normalized, 'custom template' ) || str_contains( $normalized, 'custom pdf' ) ) {
			return 'custom';
		}

		if ( str_contains( $normalized, 'default template' ) || str_contains( $normalized, 'default pdf' ) ) {
			return 'default';
		}

		return '';
	}

	/**
	 * Resolve custom PDF color template from message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string
	 */
	public static function resolve_pdf_color_from_message( $normalized ) {
		foreach ( WholesaleQuoteSettingsService::PDF_TEMPLATE_COLORS as $color ) {
			if ( str_contains( $normalized, $color ) ) {
				return $color;
			}
		}

		return '';
	}

	/**
	 * Resolve quote basket style from message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string
	 */
	public static function resolve_basket_style_from_message( $normalized ) {
		if ( str_contains( $normalized, 'dropdown' ) ) {
			return 'dropdown';
		}

		if ( str_contains( $normalized, 'icon' ) ) {
			return 'icon';
		}

		return '';
	}

	/**
	 * Resolve offered price mode from message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string
	 */
	public static function resolve_offered_mode_from_message( $normalized ) {
		if ( str_contains( $normalized, 'decrease' ) || str_contains( $normalized, 'dec' ) ) {
			return 'dec';
		}

		if ( str_contains( $normalized, 'increase' ) || str_contains( $normalized, 'inc' ) ) {
			return 'inc';
		}

		return '';
	}

	/**
	 * Resolve stock visibility from message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string
	 */
	public static function resolve_stock_visibility_from_message( $normalized ) {
		if ( str_contains( $normalized, 'hide' ) ) {
			return 'hide';
		}

		if ( str_contains( $normalized, 'show' ) ) {
			return 'show';
		}

		return '';
	}
}
