<?php
/**
 * Wholesale Registration Settings ability.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\ChangeHistoryService;
use WooCommerceWholesalePricing\App\Providers\WholesaleOption;
use WooCommerceWholesalePricing\App\Services\WholesaleRegistrationSettingsService;
use WooCommerceWholesalePricing\App\Strategies\AbstractAiAbility;

/**
 * Get and update wholesale registration form settings.
 */
class WholesaleRegistrationAbility extends AbstractAiAbility {

	/**
	 * Registration settings service.
	 *
	 * @var WholesaleRegistrationSettingsService
	 */
	private $settings_service;

	/**
	 * Change history service.
	 *
	 * @var ChangeHistoryService
	 */
	private $history_service;

	/**
	 * Constructor.
	 *
	 * @param WholesaleRegistrationSettingsService|null $settings_service Optional service.
	 * @param ChangeHistoryService|null                 $history_service  Optional history service.
	 */
	public function __construct(
		$settings_service = null,
		$history_service = null
	) {
		$this->settings_service =( isset( $settings_service ) ? $settings_service : new WholesaleRegistrationSettingsService() );
		$this->history_service  =( isset( $history_service ) ? $history_service : new ChangeHistoryService() );
	}

	/**
	 * Get key
	 * 
	 * @inheritDoc
	 */
	public function get_key() {
		return 'wholesale_registration';
	}

	/**
	 * Get label
	 * 
	 * @inheritDoc
	 */
	public function get_label() {
		return __( 'Wholesale Registration Settings', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get description
	 * 
	 * @inheritDoc
	 */
	public function get_description() {
		return __( 'Reads and writes wholesale registration settings under Wholesale → Registration Requests. Covers registration form fields (billing, shipping, other — each with enable, required, label) and reCAPTCHA configuration (enable for registration/quote, v2/v3 version, site key, secret key, v3 score, badge position, v2 theme).', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get plugin
	 * 
	 * @inheritDoc
	 */
	public function get_plugin() {
		return 'wholesale';
	}

	/**
	 * Get input schema
	 * 
	 * @inheritDoc
	 */
	public function get_input_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'action'   => array(
					'type'        => 'string',
					'enum'        => array( 'get', 'update' ),
					'description' => __( 'Action to perform.', 'woocommerce-wholesale-pricing' ),
				),
				'settings' => array(
					'type'                 => 'object',
					'description'          => __( 'Partial registration settings patch (billing/shipping/other fields, labels, required flags, reCaptcha).', 'woocommerce-wholesale-pricing' ),
					'additionalProperties' => true,
				),
			),
			'required'             => array( 'action' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * Get output schema
	 * 
	 * @inheritDoc
	 */
	public function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'option_key' => array( 'type' => 'string' ),
				'settings'   => array(
					'type'                 => 'object',
					'additionalProperties' => true,
				),
			),
		);
	}

	/**
	 * Execute
	 * 
	 * @inheritDoc
	 */
	public function execute( $input ) {
		$payload = is_array( $input ) ? $input : array();
		$action  = isset( $payload['action'] ) ? sanitize_key( (string) $payload['action'] ) : '';

		switch ( $action ) {
			case 'get':
				return $this->settings_service->get_settings();

			case 'update':
				$settings = is_array(( isset( $payload['settings'] ) ? $payload['settings'] : null )) ? $payload['settings'] : array();
				$before   = $this->settings_service->snapshot_settings();
				$updated  = $this->settings_service->update_settings( $settings );

				if ( is_wp_error( $updated ) ) {
					return $updated;
				}

				$this->record_change(
					'update',
					array(
						'option_key' => WholesaleOption::REGISTRATION_OPTION,
					),
					$before,
					__( 'Updated wholesale registration settings.', 'woocommerce-wholesale-pricing' )
				);

				return $updated;

			case 'create':
			case 'delete':
				return new \WP_Error(
					'wwp_registration_action_not_allowed',
					__( 'Create and delete are not supported for registration settings. Use update with empty values to clear fields.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);

			default:
				return new \WP_Error(
					'wwp_registration_invalid_action',
					__( 'Invalid action. Use get or update.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
		}
	}

	/**
	 * Check permission
	 * 
	 * @inheritDoc
	 */
	public function check_permission( $input ) {
		if ( ! $this->is_enabled() ) {
			return new \WP_Error(
				'wwp_ability_disabled',
				__( 'The Wholesale Registration Settings ability is disabled in AI Assistant settings.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error(
				'wwp_ability_forbidden',
				__( 'You do not have permission to manage wholesale registration settings.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Register ability with update annotations.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			$this->get_ability_name(),
			array(
				'label'               => $this->get_label(),
				'description'         => $this->get_description(),
				'category'            => $this->get_plugin(),
				'input_schema'        => $this->get_input_schema(),
				'output_schema'       => $this->get_output_schema(),
				'execute_callback'    => array( $this, 'execute' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'meta'                => array(
					'show_in_rest' => false,
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => false,
						'idempotent'  => false,
					),
				),
			)
		);
	}

	/**
	 * Record a mutating change in history.
	 *
	 * @param string                    $action_type Action type.
	 * @param array<string, mixed>      $resource    Resource snapshot.
	 * @param array<string, mixed>|null $before      Before state.
	 * @param string                    $description Change description.
	 * @return void
	 */
	private function record_change( $action_type, array $resource, $before, $description ) {
		$this->history_service->record(
			array(
				'tool'               => 'wholesale_registration',
				'ability'            => $this->get_key(),
				'change_description' => $description,
				'action_type'        => $action_type,
				'resource_type'      => 'settings',
				'resource'           => $resource,
				'before_state'       => $before,
			)
		);
	}
}
