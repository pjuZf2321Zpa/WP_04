<?php
/**
 * B2B User Roles ability.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\ChangeHistoryService;
use WooCommerceWholesalePricing\App\Services\WholesaleUserRoleService;
use WooCommerceWholesalePricing\App\Strategies\AbstractAiAbility;

/**
 * CRUD ability for wholesale_user_roles taxonomy.
 */
class B2bUserRolesAbility extends AbstractAiAbility {

	/**
	 * Role service.
	 *
	 * @var WholesaleUserRoleService
	 */
	private $role_service;

	/**
	 * Change history service.
	 *
	 * @var ChangeHistoryService
	 */
	private $history_service;

	/**
	 * Constructor.
	 *
	 * @param WholesaleUserRoleService|null $role_service    Optional role service.
	 * @param ChangeHistoryService|null     $history_service Optional history service.
	 */
	public function __construct( $role_service = null, $history_service = null ) {
		$this->role_service    =( isset( $role_service ) ? $role_service : new WholesaleUserRoleService() );
		$this->history_service =( isset( $history_service ) ? $history_service : new ChangeHistoryService() );
	}

	/**
	 * Get label
	 * 
	 * @inheritDoc
	 */
	public function get_key() {
		return 'b2b_user_roles';
	}

	/**
	 * Get label
	 * 
	 * @inheritDoc
	 */
	public function get_label() {
		return __( 'Manage B2B User Roles', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get description
	 * 
	 * @inheritDoc
	 */
	public function get_description() {
		return __( 'Full CRUD for B2B wholesale user roles under Wholesale → User Roles. Per role: name, slug, description, tax exempt toggle and tax classes, disable coupons toggle, disabled payment methods, disabled shipping methods, and private store password. Role slugs are referenced by pricing and discount abilities.', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get plugin
	 * 
	 * @inheritDoc
	 */
	public function get_plugin() {
		return 'wholesale';
	}

	/**
	 * Get input schema
	 * 
	 * @inheritDoc
	 */
	public function get_input_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'action'     => array(
					'type'        => 'string',
					'enum'        => array( 'list', 'get', 'create', 'update', 'delete' ),
					'description' => __( 'CRUD action to perform.', 'woocommerce-wholesale-pricing' ),
				),
				'identifier' => array(
					'type'        => array( 'string', 'integer' ),
					'description' => __( 'Role slug or term id (required for get, update, delete).', 'woocommerce-wholesale-pricing' ),
				),
				'role'       => $this->get_role_object_schema(),
			),
			'required'             => array( 'action' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * Get output schema
	 * 
	 * @inheritDoc
	 */
	public function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'roles'   => array(
					'type'  => 'array',
					'items' => $this->get_role_object_schema(),
				),
				'role'    => $this->get_role_object_schema(),
				'deleted' => array( 'type' => 'boolean' ),
				'slug'    => array( 'type' => 'string' ),
			),
		);
	}

	/**
	 * Execute
	 * 
	 * @inheritDoc
	 */
	public function execute( $input ) {
		$payload = is_array( $input ) ? $input : array();
		$action  = isset( $payload['action'] ) ? sanitize_text_field( (string) $payload['action'] ) : '';

		switch ( $action ) {
			case 'list':
				return array( 'roles' => $this->role_service->list_roles() );

			case 'get':
				$identifier =( isset( $payload['identifier'] ) ? $payload['identifier'] : null );
				if ( null === $identifier || '' === $identifier ) {
					return new \WP_Error(
						'wwp_role_missing_identifier',
						__( 'Role identifier is required.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$role = $this->role_service->get_role( $identifier );
				return is_wp_error( $role ) ? $role : array( 'role' => $role );

			case 'create':
				$role_data = is_array(( isset( $payload['role'] ) ? $payload['role'] : null )) ? $payload['role'] : array();
				if ( empty( $role_data['name'] ) ) {
					return new \WP_Error(
						'wwp_role_missing_name',
						__( 'Role name is required for create.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$created = $this->role_service->create_role( $role_data );
				if ( is_wp_error( $created ) ) {
					return $created;
				}
				$this->record_change(
					'create',
					array(
						'term_id' => ( isset( $created['term_id'] ) ? $created['term_id'] : 0 ),
						'slug'    => ( isset( $created['slug'] ) ? $created['slug'] : '' ),
						'name'    => ( isset( $created['name'] ) ? $created['name'] : '' ),
					),
					null,
					sprintf(
						/* translators: %s: role name */
						__( 'Created wholesale role "%s".', 'woocommerce-wholesale-pricing' ),
( isset( $created['name'] ) ? $created['name'] : '' )
				  )
				);
				return array( 'role' => $created );

			case 'update':
				$identifier =( isset( $payload['identifier'] ) ? $payload['identifier'] : null );
				if ( null === $identifier || '' === $identifier ) {
					return new \WP_Error(
						'wwp_role_missing_identifier',
						__( 'Role identifier is required.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$role_data = is_array(( isset( $payload['role'] ) ? $payload['role'] : null )) ? $payload['role'] : array();
				if ( empty( $role_data ) ) {
					return new \WP_Error(
						'wwp_role_missing_data',
						__( 'Role data is required for update.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$before  = $this->role_service->snapshot_role( $identifier );
				$updated = $this->role_service->update_role( $identifier, $role_data );
				if ( is_wp_error( $updated ) ) {
					return $updated;
				}
				$this->record_change(
					'update',
					array(
						'term_id' => ( isset( $updated['term_id'] ) ? $updated['term_id'] : 0 ),
						'slug'    => ( isset( $updated['slug'] ) ? $updated['slug'] : '' ),
						'name'    => ( isset( $updated['name'] ) ? $updated['name'] : '' ),
					),
					$before,
					sprintf(
						/* translators: %s: role name */
						__( 'Updated wholesale role "%s".', 'woocommerce-wholesale-pricing' ),
( isset( $updated['name'] ) ? $updated['name'] : '' )
				  )
				);
				return array( 'role' => $updated );

			case 'delete':
				$identifier =( isset( $payload['identifier'] ) ? $payload['identifier'] : null );
				if ( null === $identifier || '' === $identifier ) {
					return new \WP_Error(
						'wwp_role_missing_identifier',
						__( 'Role identifier is required.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$before  = $this->role_service->snapshot_role( $identifier );
				$deleted = $this->role_service->delete_role( $identifier );
				if ( is_wp_error( $deleted ) ) {
					return $deleted;
				}
				$this->record_change(
					'delete',
					array(
						'slug' => ( isset( $deleted['slug'] ) ? $deleted['slug'] : '' ),
						'name' => ( isset( $before['args']['name'] ) ? $before['args']['name'] : ( ( isset( $deleted['slug'] ) ? $deleted['slug'] : '' ) ) ),
					),
					$before,
					sprintf(
						/* translators: %s: role slug */
						__( 'Deleted wholesale role "%s".', 'woocommerce-wholesale-pricing' ),
( isset( $deleted['slug'] ) ? $deleted['slug'] : '' )
				  )
				);
				return $deleted;

			default:
				return new \WP_Error(
					'wwp_role_invalid_action',
					__( 'Invalid action. Use list, get, create, update, or delete.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
		}
	}

	/**
	 * Check permission
	 * 
	 * @inheritDoc
	 */
	public function check_permission( $input ) {
		if ( ! $this->is_enabled() ) {
			return new \WP_Error(
				'wwp_ability_disabled',
				__( 'The B2B User Roles ability is disabled in AI Assistant settings.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error(
				'wwp_ability_forbidden',
				__( 'You do not have permission to manage wholesale user roles.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Register ability with destructive annotations for mutating actions.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			$this->get_ability_name(),
			array(
				'label'               => $this->get_label(),
				'description'         => $this->get_description(),
				'category'            => $this->get_plugin(),
				'input_schema'        => $this->get_input_schema(),
				'output_schema'       => $this->get_output_schema(),
				'execute_callback'    => array( $this, 'execute' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'meta'                => array(
					'show_in_rest' => false,
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => false,
					),
				),
			)
		);
	}

	/**
	 * JSON schema fragment for a role object.
	 *
	 * @return array<string, mixed>
	 */
	private function get_role_object_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'term_id'                     => array( 'type' => 'integer' ),
				'name'                        => array( 'type' => 'string' ),
				'slug'                        => array( 'type' => 'string' ),
				'description'                 => array( 'type' => 'string' ),
				'user_count'                  => array( 'type' => 'integer' ),
				'tax_exempt'                  => array( 'type' => 'boolean' ),
				'role_tax_exempt'             => array( 'type' => 'string' ),
				'disable_coupons'             => array( 'type' => 'boolean' ),
				'payment_methods'             => array( 'type' => 'object' ),
				'disabled_payment_methods'    => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				'disabled_shipping_methods'   => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				'password'                    => array( 'type' => 'string' ),
				'subscription_variation_id'   => array( 'type' => 'string' ),
			),
		);
	}

	/**
	 * Record a mutating change in history.
	 *
	 * @param string                    $action_type Action type.
	 * @param array<string, mixed>      $resource    Resource snapshot.
	 * @param array<string, mixed>|null $before      Before state.
	 * @param string                    $description Change description.
	 * @return void
	 */
	private function record_change( $action_type, array $resource, $before, $description ) {
		$this->history_service->record(
			array(
				'tool'               => 'b2b_user_roles',
				'ability'            => $this->get_key(),
				'change_description' => $description,
				'action_type'        => $action_type,
				'resource_type'      => 'user_role',
				'resource'           => $resource,
				'before_state'       => $before,
			)
		);
	}
}
