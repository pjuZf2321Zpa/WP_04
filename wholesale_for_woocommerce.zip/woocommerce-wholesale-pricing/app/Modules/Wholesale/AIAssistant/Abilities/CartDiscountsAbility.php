<?php
/**
 * Wholesale Cart Discounts ability.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\ChangeHistoryService;
use WooCommerceWholesalePricing\App\Providers\WholesaleOption;
use WooCommerceWholesalePricing\App\Services\WholesaleCartDiscountService;
use WooCommerceWholesalePricing\App\Strategies\AbstractAiAbility;

/**
 * Get and update wholesale cart-level discounts and tier pricing.
 */
class CartDiscountsAbility extends AbstractAiAbility {

	/**
	 * Cart discount settings service.
	 *
	 * @var WholesaleCartDiscountService
	 */
	private $settings_service;

	/**
	 * Change history service.
	 *
	 * @var ChangeHistoryService
	 */
	private $history_service;

	/**
	 * Constructor.
	 *
	 * @param WholesaleCartDiscountService|null $settings_service Optional service.
	 * @param ChangeHistoryService|null         $history_service  Optional history service.
	 */
	public function __construct(
		$settings_service = null,
		$history_service = null
	) {
		$this->settings_service =( isset( $settings_service ) ? $settings_service : new WholesaleCartDiscountService() );
		$this->history_service  =( isset( $history_service ) ? $history_service : new ChangeHistoryService() );
	}

	/**
	 * Get key
	 * 
	 * @inheritDoc
	 */
	public function get_key() {
		return 'cart_discounts';
	}

	/**
	 * Get label
	 * 
	 * @inheritDoc
	 */
	public function get_label() {
		return __( 'Manage Wholesale Cart Discounts', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get description
	 * 
	 * @inheritDoc
	 */
	public function get_description() {
		return __( 'Reads and writes cart total discount rules under Wholesale → Settings → Cart Total Discounts. Per role: activation toggle, discount type (percent/fixed), discount value, tier discount mode, min cart subtotal/quantity, and tiered ranges. Use action update with a partial settings patch — include ONLY fields the user asked to change; omit unchanged keys such as min cart subtotal, discount_on, and tier_pricing unless explicitly requested.', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get plugin
	 * 
	 * @inheritDoc
	 */
	public function get_plugin() {
		return 'wholesale';
	}

	/**
	 * Get input schema
	 * 
	 * @inheritDoc
	 */
	public function get_input_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'action'   => array(
					'type'        => 'string',
					'enum'        => array( 'get', 'update' ),
					'description' => __( 'Action to perform.', 'woocommerce-wholesale-pricing' ),
				),
				'settings' => array(
					'type'        => 'object',
					'description' => __( 'Partial cart discount settings patch. Include only role_discounts and/or tier_pricing keys being changed. Each role_discounts item should contain only the fields the user asked to update.', 'woocommerce-wholesale-pricing' ),
					'properties'  => array(
						'role_discounts' => array(
							'type'  => 'array',
							'items' => array(
								'type'       => 'object',
								'properties' => array(
									'role_slug'          => array( 'type' => 'string' ),
									'slug'               => array( 'type' => 'string' ),
									'role'               => array( 'type' => 'string' ),
									'role_id'            => array( 'type' => 'integer' ),
									'role_name'          => array( 'type' => 'string' ),
									'enabled'            => array( 'type' => 'boolean' ),
									'discount_type'      => array(
										'type' => 'string',
										'enum' => array( 'percent', 'fixed' ),
									),
									'cart_price'         => array( 'type' => 'string' ),
									'discount_on'        => array(
										'type' => 'string',
										'enum' => array( 'cart_discount_amount', 'cart_discount_quantity' ),
									),
									'cart_min_subtotal'  => array( 'type' => 'string' ),
								),
							),
						),
						'tier_pricing'   => array(
							'type'  => 'array',
							'items' => array(
								'type'       => 'object',
								'properties' => array(
									'role_slug' => array( 'type' => 'string' ),
									'slug'      => array( 'type' => 'string' ),
									'role'      => array( 'type' => 'string' ),
									'role_id'   => array( 'type' => 'integer' ),
									'role_name' => array( 'type' => 'string' ),
									'tiers'     => array(
										'type'  => 'array',
										'items' => array(
											'type'       => 'object',
											'properties' => array(
												'min'      => array( 'type' => 'string' ),
												'max'      => array( 'type' => 'string' ),
												'price'    => array( 'type' => 'string' ),
												'cart_max' => array( 'type' => 'string' ),
											),
										),
									),
								),
							),
						),
					),
				),
			),
			'required'             => array( 'action' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * Get output schema
	 * 
	 * @inheritDoc
	 */
	public function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'cart_discount_option_key' => array( 'type' => 'string' ),
				'tier_pricing_option_key'  => array( 'type' => 'string' ),
				'role_discounts'           => array(
					'type'  => 'array',
					'items' => array( 'type' => 'object' ),
				),
				'tier_pricing'             => array(
					'type'  => 'array',
					'items' => array( 'type' => 'object' ),
				),
			),
		);
	}

	/**
	 * Execute
	 * 
	 * @inheritDoc
	 */
	public function execute( $input ) {
		$payload = is_array( $input ) ? $input : array();
		$action  = isset( $payload['action'] ) ? sanitize_key( (string) $payload['action'] ) : '';

		switch ( $action ) {
			case 'get':
				return $this->settings_service->get_settings();

			case 'update':
				$settings = is_array(( isset( $payload['settings'] ) ? $payload['settings'] : null )) ? $payload['settings'] : array();
				$before   = $this->settings_service->snapshot_settings();
				$updated  = $this->settings_service->update_settings( $settings );

				if ( is_wp_error( $updated ) ) {
					return $updated;
				}

				$this->record_change(
					'update',
					array(
						'cart_discount_option_key' => WholesaleOption::MULTIUSER_CART_DISCOUNT_OPTION,
						'tier_pricing_option_key'  => WholesaleOption::CART_TIER_PRICING_OPTION,
					),
					$before,
					__( 'Updated wholesale cart discount settings.', 'woocommerce-wholesale-pricing' )
				);

				return $updated;

			case 'create':
			case 'delete':
				return new \WP_Error(
					'wwp_cart_discounts_action_not_allowed',
					__( 'Create and delete are not supported. Use update with enabled false to remove role discounts, or empty tiers to clear tier pricing.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);

			default:
				return new \WP_Error(
					'wwp_cart_discounts_invalid_action',
					__( 'Invalid action. Use get or update.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
		}
	}

	/**
	 * Check permission
	 * 
	 * @inheritDoc
	 */
	public function check_permission( $input ) {
		if ( ! $this->is_enabled() ) {
			return new \WP_Error(
				'wwp_ability_disabled',
				__( 'The Manage Wholesale Cart Discounts ability is disabled in AI Assistant settings.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error(
				'wwp_ability_forbidden',
				__( 'You do not have permission to manage wholesale cart discounts.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Register ability with update annotations.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			$this->get_ability_name(),
			array(
				'label'               => $this->get_label(),
				'description'         => $this->get_description(),
				'category'            => $this->get_plugin(),
				'input_schema'        => $this->get_input_schema(),
				'output_schema'       => $this->get_output_schema(),
				'execute_callback'    => array( $this, 'execute' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'meta'                => array(
					'show_in_rest' => false,
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => false,
						'idempotent'  => false,
					),
				),
			)
		);
	}

	/**
	 * Record a mutating change in history.
	 *
	 * @param string                    $action_type Action type.
	 * @param array<string, mixed>      $resource    Resource snapshot.
	 * @param array<string, mixed>|null $before      Before state.
	 * @param string                    $description Change description.
	 * @return void
	 */
	private function record_change( $action_type, array $resource, $before, $description ) {
		$this->history_service->record(
			array(
				'tool'               => 'cart_discounts',
				'ability'            => $this->get_key(),
				'change_description' => $description,
				'action_type'        => $action_type,
				'resource_type'      => 'cart_discounts',
				'resource'           => $resource,
				'before_state'       => $before,
			)
		);
	}
}
