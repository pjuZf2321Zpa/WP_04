<?php
/**
 * AI Assistant ability catalog.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities;

/**
 * Single source of truth for ability keys, availability, and plugin ownership.
 */
class AbilityCatalog {

	/**
	 * Ability definitions keyed by settings key.
	 *
	 * @var array<string, array{active: bool, plugin: string, default: bool}>
	 */
	const ABILITIES = array(
		'dashboard'                       => array(
			'active'  => true,
			'plugin'  => 'wholesale',
			'default' => true,
		),
		'wholesale_settings'              => array(
			'active'  => true,
			'plugin'  => 'wholesale',
			'default' => true,
		),
		'global_discounts'                => array(
			'active'  => true,
			'plugin'  => 'wholesale',
			'default' => true,
		),
		'cart_discounts'                    => array(
			'active'  => true,
			'plugin'  => 'wholesale',
			'default' => true,
		),
		'b2b_user_roles'                    => array(
			'active'  => true,
			'plugin'  => 'wholesale',
			'default' => true,
		),
		'wholesale_email_notifications'     => array(
			'active'  => true,
			'plugin'  => 'wholesale',
			'default' => false,
		),
		'wholesale_registration'            => array(
			'active'  => true,
			'plugin'  => 'wholesale',
			'default' => false,
		),
		'woocommerce_products'            => array(
			'active'  => true,
			'plugin'  => 'wholesale',
			'default' => false,
		),
		'woocommerce_categories'          => array(
			'active'  => true,
			'plugin'  => 'wholesale',
			'default' => false,
		),
		'wholesale_account_requests'      => array(
			'active'  => true,
			'plugin'  => 'wholesale',
			'default' => true,
		),
		'registration_forms'              => array(
			'active'  => false,
			'plugin'  => 'wholesale',
			'default' => false,
		),
		'bulk_tiered_pricing'             => array(
			'active'  => false,
			'plugin'  => 'wholesale',
			'default' => false,
		),
		'wholesale_groups'                => array(
			'active'  => false,
			'plugin'  => 'wholesale',
			'default' => false,
		),
		'b2b_user_profiles'               => array(
			'active'  => true,
			'plugin'  => 'wholesale',
			'default' => true,
		),
		'quote_settings'                  => array(
			'active'  => true,
			'plugin'  => 'quote',
			'default' => true,
		),
		'quote_rules'                     => array(
			'active'  => true,
			'plugin'  => 'quote',
			'default' => true,
		),
		'modify_update_quotes'            => array(
			'active'  => true,
			'plugin'  => 'quote',
			'default' => true,
		),
		'add_organize_quotes'             => array(
			'active'  => false,
			'plugin'  => 'quote',
			'default' => false,
		),
		'quote_email_notifications'       => array(
			'active'  => false,
			'plugin'  => 'quote',
			'default' => false,
		),
		'request_a_quote_forms'           => array(
			'active'  => false,
			'plugin'  => 'quote',
			'default' => false,
		),
	);

	/**
	 * All ability keys.
	 *
	 * @return list<string>
	 */
	public static function get_all_keys() {
		return array_keys( self::ABILITIES );
	}

	/**
	 * Keys for abilities that are currently available.
	 *
	 * @return list<string>
	 */
	public static function get_active_keys() {
		return array_values(
			array_filter(
				self::get_all_keys(),
				static function ( $key ) {
					return self::is_active( $key );
				}
			)
		);
	}

	/**
	 * Whether the ability is available (not coming soon).
	 *
	 * @param string $key Ability key.
	 * @return bool
	 */
	public static function is_active( $key ) {
		return ! empty( self::ABILITIES[ $key ]['active'] );
	}

	/**
	 * Plugin slug for an ability.
	 *
	 * @param string $key Ability key.
	 * @return string
	 */
	public static function get_plugin( $key ) {
		return (string) ( ( isset( self::ABILITIES[ $key ]['plugin'] ) ? self::ABILITIES[ $key ]['plugin'] : 'wholesale' ) );
	}

	/**
	 * Default enabled state for an ability.
	 *
	 * @param string $key Ability key.
	 * @return bool
	 */
	public static function get_default_enabled( $key ) {
		if ( ! self::is_active( $key ) ) {
			return false;
		}

		return ! empty( self::ABILITIES[ $key ]['default'] );
	}

	/**
	 * Default abilities map for settings.
	 *
	 * @return array<string, bool>
	 */
	public static function get_default_abilities() {
		$defaults = array();

		foreach ( self::get_all_keys() as $key ) {
			$defaults[ $key ] = self::get_default_enabled( $key );
		}

		return $defaults;
	}
}
