<?php
/**
 * B2B User Profiles ability.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\ChangeHistoryService;
use WooCommerceWholesalePricing\App\Services\WholesaleB2bUserProfileService;
use WooCommerceWholesalePricing\App\Strategies\AbstractAiAbility;

/**
 * CRUD ability for wholesale/B2B WordPress users.
 */
class B2bUserProfilesAbility extends AbstractAiAbility {

	/**
	 * User profile service.
	 *
	 * @var WholesaleB2bUserProfileService
	 */
	private $user_service;

	/**
	 * Change history service.
	 *
	 * @var ChangeHistoryService
	 */
	private $history_service;

	/**
	 * Constructor.
	 *
	 * @param WholesaleB2bUserProfileService|null $user_service    Optional service.
	 * @param ChangeHistoryService|null           $history_service Optional history service.
	 */
	public function __construct(
		$user_service = null,
		$history_service = null
	) {
		$this->user_service    =( isset( $user_service ) ? $user_service : new WholesaleB2bUserProfileService() );
		$this->history_service =( isset( $history_service ) ? $history_service : new ChangeHistoryService() );
	}

	/**
	 * Get key
	 * 
	 * @inheritDoc
	 */
	public function get_key() {
		return 'b2b_user_profiles';
	}

	/**
	 * Get label
	 * 
	 * @inheritDoc
	 */
	public function get_label() {
		return __( 'Manage B2B User Profiles', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get description
	 * 
	 * @inheritDoc
	 */
	public function get_description() {
		return __( 'Full CRUD for WordPress users with B2B wholesale profile management. Manages core fields (name, email, password), user meta (billing, shipping, custom fields), and wholesale role assignment. Supports user search and filtering by role, email, or date. Prevents accidental deletion of admin accounts.', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get plugin
	 * 
	 * @inheritDoc
	 */
	public function get_plugin() {
		return 'wholesale';
	}

	/**
	 * Get input schema
	 * 
	 * @inheritDoc
	 */
	public function get_input_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'action'           => array(
					'type'        => 'string',
					'enum'        => array( 'list', 'get', 'create', 'update', 'delete' ),
					'description' => __( 'CRUD action to perform.', 'woocommerce-wholesale-pricing' ),
				),
				'identifier'       => array(
					'type'        => array( 'string', 'integer' ),
					'description' => __( 'User ID, email, or login (required for get, update, delete).', 'woocommerce-wholesale-pricing' ),
				),
				'user'             => $this->get_user_input_schema(),
				'search'           => array(
					'type'        => 'string',
					'description' => __( 'Search users by login, email, or display name (list).', 'woocommerce-wholesale-pricing' ),
				),
				'role'             => array(
					'type'        => 'string',
					'description' => __( 'Filter or assign a WordPress role slug.', 'woocommerce-wholesale-pricing' ),
				),
				'wholesale_only'   => array(
					'type'        => 'boolean',
					'description' => __( 'When true, list only users with wholesale roles.', 'woocommerce-wholesale-pricing' ),
				),
				'per_page'         => array(
					'type'        => 'integer',
					'description' => __( 'Results per page for list (max 100).', 'woocommerce-wholesale-pricing' ),
				),
				'page'             => array(
					'type'        => 'integer',
					'description' => __( 'Page number for list.', 'woocommerce-wholesale-pricing' ),
				),
				'reassign_user_id' => array(
					'type'        => 'integer',
					'description' => __( 'Optional user ID to reassign posts to when deleting.', 'woocommerce-wholesale-pricing' ),
				),
			),
			'required'             => array( 'action' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * Get output schema
	 * 
	 * @inheritDoc
	 */
	public function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'users'      => array(
					'type'  => 'array',
					'items' => $this->get_user_output_schema(),
				),
				'user'       => $this->get_user_output_schema(),
				'total'      => array( 'type' => 'integer' ),
				'deleted'    => array( 'type' => 'boolean' ),
				'user_id'    => array( 'type' => 'integer' ),
				'user_login' => array( 'type' => 'string' ),
			),
		);
	}

	/**
	 * Execute
	 * 
	 * @inheritDoc
	 */
	public function execute( $input ) {
		$payload = is_array( $input ) ? $input : array();
		$action  = isset( $payload['action'] ) ? sanitize_key( (string) $payload['action'] ) : '';

		switch ( $action ) {
			case 'list':
				return $this->user_service->list_users(
					array(
						'search'         => ( isset( $payload['search'] ) ? $payload['search'] : '' ),
						'role'           => ( isset( $payload['role'] ) ? $payload['role'] : '' ),
						'wholesale_only' => ! empty( $payload['wholesale_only'] ),
						'per_page'       => isset( $payload['per_page'] ) ? (int) $payload['per_page'] : 20,
						'page'           => isset( $payload['page'] ) ? (int) $payload['page'] : 1,
					)
				);

			case 'get':
				$identifier =( isset( $payload['identifier'] ) ? $payload['identifier'] : null );
				if ( null === $identifier || '' === $identifier ) {
					return new \WP_Error(
						'wwp_user_missing_identifier',
						__( 'User identifier is required.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$user = $this->user_service->get_user( $identifier );
				return is_wp_error( $user ) ? $user : array( 'user' => $user );

			case 'create':
				$user_data = is_array(( isset( $payload['user'] ) ? $payload['user'] : null )) ? $payload['user'] : array();
				if ( isset( $payload['role'] ) && ! isset( $user_data['role'] ) ) {
					$user_data['role'] = $payload['role'];
				}
				$created = $this->user_service->create_user( $user_data );
				if ( is_wp_error( $created ) ) {
					return $created;
				}
				$this->record_change(
					'create',
					array(
						'ID'         => ( isset( $created['ID'] ) ? $created['ID'] : 0 ),
						'user_login' => ( isset( $created['user_login'] ) ? $created['user_login'] : '' ),
						'user_email' => ( isset( $created['user_email'] ) ? $created['user_email'] : '' ),
					),
					null,
					sprintf(
						/* translators: %s: user login */
						__( 'Created B2B user "%s".', 'woocommerce-wholesale-pricing' ),
( isset( $created['user_login'] ) ? $created['user_login'] : '' )
				  )
				);
				return array( 'user' => $created );

			case 'update':
				$identifier =( isset( $payload['identifier'] ) ? $payload['identifier'] : null );
				if ( null === $identifier || '' === $identifier ) {
					return new \WP_Error(
						'wwp_user_missing_identifier',
						__( 'User identifier is required.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$user_data = is_array(( isset( $payload['user'] ) ? $payload['user'] : null )) ? $payload['user'] : array();
				if ( isset( $payload['role'] ) && ! isset( $user_data['role'] ) && ! isset( $user_data['roles'] ) ) {
					$user_data['role'] = $payload['role'];
				}
				$before  = $this->resolve_snapshot( $identifier );
				$updated = $this->user_service->update_user( $identifier, $user_data );
				if ( is_wp_error( $updated ) ) {
					return $updated;
				}
				$this->record_change(
					'update',
					array(
						'ID'         => ( isset( $updated['ID'] ) ? $updated['ID'] : 0 ),
						'user_login' => ( isset( $updated['user_login'] ) ? $updated['user_login'] : '' ),
					),
					is_wp_error( $before ) ? null : $before,
					sprintf(
						/* translators: %s: user login */
						__( 'Updated B2B user "%s".', 'woocommerce-wholesale-pricing' ),
( isset( $updated['user_login'] ) ? $updated['user_login'] : '' )
				  )
				);
				return array( 'user' => $updated );

			case 'delete':
				$identifier =( isset( $payload['identifier'] ) ? $payload['identifier'] : null );
				if ( null === $identifier || '' === $identifier ) {
					return new \WP_Error(
						'wwp_user_missing_identifier',
						__( 'User identifier is required.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$before  = $this->resolve_snapshot( $identifier );
				$deleted = $this->user_service->delete_user(
					$identifier,
					isset( $payload['reassign_user_id'] ) ? (int) $payload['reassign_user_id'] : 0
				);
				if ( is_wp_error( $deleted ) ) {
					return $deleted;
				}
				$this->record_change(
					'delete',
					array(
						'ID'         => ( isset( $deleted['user_id'] ) ? $deleted['user_id'] : 0 ),
						'user_login' => ( isset( $deleted['user_login'] ) ? $deleted['user_login'] : '' ),
					),
					is_wp_error( $before ) ? null : $before,
					sprintf(
						/* translators: %s: user login */
						__( 'Deleted B2B user "%s".', 'woocommerce-wholesale-pricing' ),
( isset( $deleted['user_login'] ) ? $deleted['user_login'] : '' )
				  )
				);
				return $deleted;

			default:
				return new \WP_Error(
					'wwp_user_invalid_action',
					__( 'Invalid action. Use list, get, create, update, or delete.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
		}
	}

	/**
	 * Check permission
	 * 
	 * @inheritDoc
	 */
	public function check_permission( $input ) {
		if ( ! $this->is_enabled() ) {
			return new \WP_Error(
				'wwp_ability_disabled',
				__( 'The Manage B2B User Profiles ability is disabled in AI Assistant settings.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error(
				'wwp_ability_forbidden',
				__( 'You do not have permission to manage B2B user profiles.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Register ability with destructive annotations.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			$this->get_ability_name(),
			array(
				'label'               => $this->get_label(),
				'description'         => $this->get_description(),
				'category'            => $this->get_plugin(),
				'input_schema'        => $this->get_input_schema(),
				'output_schema'       => $this->get_output_schema(),
				'execute_callback'    => array( $this, 'execute' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'meta'                => array(
					'show_in_rest' => false,
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => false,
					),
				),
			)
		);
	}

	/**
	 * User object schema for create/update input.
	 *
	 * @return array<string, mixed>
	 */
	private function get_user_input_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'user_login'   => array( 'type' => 'string' ),
				'user_email'   => array( 'type' => 'string' ),
				'user_pass'    => array( 'type' => 'string' ),
				'display_name' => array( 'type' => 'string' ),
				'first_name'   => array( 'type' => 'string' ),
				'last_name'    => array( 'type' => 'string' ),
				'user_url'     => array( 'type' => 'string' ),
				'description'  => array( 'type' => 'string' ),
				'role'         => array( 'type' => 'string' ),
				'roles'        => array(
					'type'  => 'array',
					'items' => array( 'type' => 'string' ),
				),
				'meta'         => array(
					'type'                 => 'object',
					'additionalProperties' => true,
				),
			),
			'additionalProperties' => false,
		);
	}

	/**
	 * User object schema for list/get/create/update responses.
	 *
	 * @return array<string, mixed>
	 */
	private function get_user_output_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'ID'              => array( 'type' => 'integer' ),
				'user_login'      => array( 'type' => 'string' ),
				'user_email'      => array( 'type' => 'string' ),
				'display_name'    => array( 'type' => 'string' ),
				'first_name'      => array( 'type' => 'string' ),
				'last_name'       => array( 'type' => 'string' ),
				'user_url'        => array( 'type' => 'string' ),
				'description'     => array( 'type' => 'string' ),
				'roles'           => array(
					'type'  => 'array',
					'items' => array( 'type' => 'string' ),
				),
				'wholesale_role'  => array( 'type' => 'string' ),
				'is_wholesaler'   => array( 'type' => 'boolean' ),
				'user_status'     => array( 'type' => 'string' ),
				'registered_date' => array( 'type' => 'string' ),
				'meta'            => array(
					'type'                 => 'object',
					'additionalProperties' => true,
				),
			),
			'additionalProperties' => false,
		);
	}

	/**
	 * Resolve snapshot
	 * 
	 * @param string|int $identifier User identifier.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function resolve_snapshot( $identifier ) {
		$user = $this->user_service->get_user( $identifier );
		if ( is_wp_error( $user ) ) {
			return $user;
		}

		return $this->user_service->snapshot_user( (int) ( ( isset( $user['ID'] ) ? $user['ID'] : 0 ) ) );
	}

	/**
	 * Record a mutating change in history.
	 *
	 * @param string                    $action_type Action type.
	 * @param array<string, mixed>      $resource    Resource snapshot.
	 * @param array<string, mixed>|null $before      Before state.
	 * @param string                    $description Change description.
	 * @return void
	 */
	private function record_change( $action_type, array $resource, $before, $description ) {
		$this->history_service->record(
			array(
				'tool'               => 'b2b_user_profiles',
				'ability'            => $this->get_key(),
				'change_description' => $description,
				'action_type'        => $action_type,
				'resource_type'      => 'user',
				'resource'           => $resource,
				'before_state'       => $before,
			)
		);
	}
}
