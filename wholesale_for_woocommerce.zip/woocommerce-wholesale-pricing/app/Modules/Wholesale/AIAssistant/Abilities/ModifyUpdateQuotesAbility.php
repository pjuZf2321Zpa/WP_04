<?php
/**
 * Modify & Update Quotes ability.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\ChangeHistoryService;
use WooCommerceWholesalePricing\App\Services\Quote\WholesaleQuoteService;
use WooCommerceWholesalePricing\App\Strategies\AbstractAiAbility;

/**
 * List/get/update ability for wc-quote posts.
 */
class ModifyUpdateQuotesAbility extends AbstractAiAbility {

	/**
	 * Quote service.
	 *
	 * @var WholesaleQuoteService
	 */
	private $quote_service;

	/**
	 * Change history service.
	 *
	 * @var ChangeHistoryService
	 */
	private $history_service;

	/**
	 * Constructor.
	 *
	 * @param WholesaleQuoteService|null $quote_service    Optional service.
	 * @param ChangeHistoryService|null  $history_service Optional history service.
	 */
	public function __construct(
		$quote_service = null,
		$history_service = null
	) {
		$this->quote_service    =( isset( $quote_service ) ? $quote_service : new WholesaleQuoteService() );
		$this->history_service  =( isset( $history_service ) ? $history_service : new ChangeHistoryService() );
	}

	/**
	 * Get key
	 * 
	 * @inheritDoc
	 */
	public function get_key() {
		return 'modify_update_quotes';
	}

	/**
	 * Get label
	 * 
	 * @inheritDoc
	 */
	public function get_label() {
		return __( 'Modify & Update Quotes', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get description
	 * 
	 * @inheritDoc
	 */
	public function get_description() {
		return __( 'Reads and updates wholesale quotes under Wholesale → Quote → Quote List. Per quote: view full details, update quote status, and modify customer and order meta fields. Supports listing and filtering quotes by status, customer, or date. Read and update only — no create or delete.', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get plugin
	 * 
	 * @inheritDoc
	 */
	public function get_plugin() {
		return 'quote';
	}

	/**
	 * Get input schema
	 * 
	 * @inheritDoc
	 */
	public function get_input_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'action'            => array(
					'type'        => 'string',
					'enum'        => array( 'list', 'get', 'update' ),
					'description' => __( 'Action to perform.', 'woocommerce-wholesale-pricing' ),
				),
				'identifier'        => array(
					'type'        => array( 'string', 'integer' ),
					'description' => __( 'Quote post ID or title (required for get and update).', 'woocommerce-wholesale-pricing' ),
				),
				'quote'             => $this->get_quote_object_schema(),
				'status'            => array(
					'type'        => 'string',
					'description' => __( 'Filter list by status or set quote status on update.', 'woocommerce-wholesale-pricing' ),
				),
				'search'            => array(
					'type'        => 'string',
					'description' => __( 'Search quotes by title (list).', 'woocommerce-wholesale-pricing' ),
				),
				'customer_user_id'  => array(
					'type'        => 'integer',
					'description' => __( 'Filter list by customer user ID or reassign quote customer on update.', 'woocommerce-wholesale-pricing' ),
				),
				'per_page'          => array(
					'type'        => 'integer',
					'description' => __( 'Results per page for list (max 100).', 'woocommerce-wholesale-pricing' ),
				),
				'page'              => array(
					'type'        => 'integer',
					'description' => __( 'Page number for list.', 'woocommerce-wholesale-pricing' ),
				),
			),
			'required'             => array( 'action' ),
			'additionalProperties' => true,
		);
	}

	/**
	 * Get output schema
	 * 
	 * @inheritDoc
	 */
	public function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'quotes' => array(
					'type'  => 'array',
					'items' => $this->get_quote_object_schema(),
				),
				'quote'  => $this->get_quote_object_schema(),
				'total'  => array( 'type' => 'integer' ),
			),
		);
	}

	/**
	 * Execute
	 * 
	 * @inheritDoc
	 */
	public function execute( $input ) {
		$payload = is_array( $input ) ? $input : array();
		$action  = isset( $payload['action'] ) ? sanitize_key( (string) $payload['action'] ) : '';

		switch ( $action ) {
			case 'list':
				return $this->quote_service->list_quotes(
					array(
						'search'           => ( isset( $payload['search'] ) ? $payload['search'] : '' ),
						'status'           => ( isset( $payload['status'] ) ? $payload['status'] : '' ),
						'customer_user_id' => isset( $payload['customer_user_id'] ) ? (int) $payload['customer_user_id'] : 0,
						'per_page'         => isset( $payload['per_page'] ) ? (int) $payload['per_page'] : 20,
						'page'             => isset( $payload['page'] ) ? (int) $payload['page'] : 1,
					)
				);

			case 'get':
				$quote_id = $this->resolve_identifier( $payload );
				if ( is_wp_error( $quote_id ) ) {
					return $quote_id;
				}
				$quote = $this->quote_service->get_quote( $quote_id );
				return is_wp_error( $quote ) ? $quote : array( 'quote' => $quote );

			case 'update':
				$quote_id = $this->resolve_identifier( $payload );
				if ( is_wp_error( $quote_id ) ) {
					return $quote_id;
				}
				$quote_data = $this->build_quote_payload( $payload );
				$before     = $this->quote_service->snapshot_quote( $quote_id );
				$updated    = $this->quote_service->update_quote( $quote_id, $quote_data );
				if ( is_wp_error( $updated ) ) {
					return $updated;
				}
				$this->record_change(
					'update',
					array(
						'quote_id' => ( isset( $updated['id'] ) ? $updated['id'] : $quote_id ),
						'title'    => ( isset( $updated['title'] ) ? $updated['title'] : '' ),
						'status'   => ( isset( $updated['status'] ) ? $updated['status'] : '' ),
					),
					is_wp_error( $before ) ? null : $before,
					sprintf(
						/* translators: %s: quote title */
						__( 'Updated quote "%s".', 'woocommerce-wholesale-pricing' ),
( isset( $updated['title'] ) ? $updated['title'] : '' )
					)
				);
				return array( 'quote' => $updated );

			default:
				return new \WP_Error(
					'wwp_quote_invalid_action',
					__( 'Invalid action. Use list, get, or update.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
		}
	}

	/**
	 * Check permission
	 * 
	 * @inheritDoc
	 */
	public function check_permission( $input ) {
		if ( ! $this->is_enabled() ) {
			return new \WP_Error(
				'wwp_ability_disabled',
				__( 'The Modify & Update Quotes ability is disabled in AI Assistant settings.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error(
				'wwp_ability_forbidden',
				__( 'You do not have permission to modify quotes.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Register ability with destructive annotations.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			$this->get_ability_name(),
			array(
				'label'               => $this->get_label(),
				'description'         => $this->get_description(),
				'category'            => $this->get_plugin(),
				'input_schema'        => $this->get_input_schema(),
				'output_schema'       => $this->get_output_schema(),
				'execute_callback'    => array( $this, 'execute' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'meta'                => array(
					'show_in_rest' => false,
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => false,
					),
				),
			)
		);
	}

	/**
	 * Quote object schema for input/output.
	 *
	 * @return array<string, mixed>
	 */
	private function get_quote_object_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'id'               => array( 'type' => 'integer' ),
				'title'            => array( 'type' => 'string' ),
				'status'           => array( 'type' => 'string' ),
				'status_label'     => array( 'type' => 'string' ),
				'customer_user_id' => array( 'type' => 'integer' ),
				'customer'         => array( 'type' => 'object' ),
				'fields'           => array( 'type' => 'object' ),
				'items'            => array( 'type' => 'array' ),
				'remove_items'     => array( 'type' => 'array' ),
				'shipping'         => array( 'type' => 'number' ),
				'shipping_tax'     => array( 'type' => 'number' ),
				'totals'           => array( 'type' => 'object' ),
				'item_count'       => array( 'type' => 'integer' ),
			),
		);
	}

	/**
	 * Build service payload from ability input.
	 *
	 * @param array<string, mixed> $payload Ability input.
	 * @return array<string, mixed>
	 */
	private function build_quote_payload( array $payload ) {
		$data = is_array(( isset( $payload['quote'] ) ? $payload['quote'] : null )) ? $payload['quote'] : array();

		$top_level = array(
			'status',
			'customer_user_id',
			'fields',
			'items',
			'remove_items',
			'shipping',
			'shipping_tax',
		);

		foreach ( $top_level as $field ) {
			if ( array_key_exists( $field, $payload ) && ! array_key_exists( $field, $data ) ) {
				$data[ $field ] = $payload[ $field ];
			}
		}

		return $data;
	}

	/**
	 * Resolve quote ID from identifier.
	 *
	 * @param array<string, mixed> $payload Ability input.
	 * @return int|\WP_Error
	 */
	private function resolve_identifier( array $payload ) {
		$identifier =( isset( $payload['identifier'] ) ? $payload['identifier'] : ( ( isset( $payload['quote']['id'] ) ? $payload['quote']['id'] : null ) ) );
		if ( null === $identifier || '' === $identifier ) {
			return new \WP_Error(
				'wwp_quote_missing_identifier',
				__( 'Quote identifier is required.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( is_numeric( $identifier ) ) {
			return (int) $identifier;
		}

		$post_type = $this->quote_service->get_post_type();
		$title     = sanitize_text_field( (string) $identifier );
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$post_id = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_type = %s AND post_title = %s AND post_status != 'trash' ORDER BY ID DESC LIMIT 1",
				$post_type,
				$title
			)
		);

		if ( $post_id <= 0 ) {
			$posts = get_posts(
				array(
					'post_type'      => $post_type,
					'post_status'    => $this->quote_service->get_all_statuses(),
					's'              => $title,
					'posts_per_page' => 1,
					'fields'         => 'ids',
				)
			);
			$post_id = ! empty( $posts ) ? (int) $posts[0] : 0;
		}

		if ( $post_id <= 0 ) {
			return new \WP_Error(
				'wwp_quote_not_found',
				__( 'Quote not found.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		return $post_id;
	}

	/**
	 * Record a mutating change in history.
	 *
	 * @param string                    $action_type Action type.
	 * @param array<string, mixed>      $resource    Resource snapshot.
	 * @param array<string, mixed>|null $before      Before state.
	 * @param string                    $description Change description.
	 * @return void
	 */
	private function record_change( $action_type, array $resource, $before, $description ) {
		$this->history_service->record(
			array(
				'tool'               => 'modify_update_quotes',
				'ability'            => $this->get_key(),
				'change_description' => $description,
				'action_type'        => $action_type,
				'resource_type'      => 'quote',
				'resource'           => $resource,
				'before_state'       => $before,
			)
		);
	}
}
