<?php
/**
 * WooCommerce Categories ability.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\ChangeHistoryService;
use WooCommerceWholesalePricing\App\Services\WholesaleCategoryMetaService;
use WooCommerceWholesalePricing\App\Services\WooCommerceRestDelegate;
use WooCommerceWholesalePricing\App\Strategies\AbstractAiAbility;

/**
 * CRUD for WooCommerce product categories with wholesale extensions.
 */
class WooCommerceCategoriesAbility extends AbstractAiAbility {

	/**
	 * REST delegate.
	 *
	 * @var WooCommerceRestDelegate
	 */
	private $rest_delegate;

	/**
	 * Wholesale category meta service.
	 *
	 * @var WholesaleCategoryMetaService
	 */
	private $meta_service;

	/**
	 * Change history service.
	 *
	 * @var ChangeHistoryService
	 */
	private $history_service;

	/**
	 * Constructor.
	 *
	 * @param WooCommerceRestDelegate|null       $rest_delegate   Optional REST delegate.
	 * @param WholesaleCategoryMetaService|null  $meta_service    Optional meta service.
	 * @param ChangeHistoryService|null          $history_service Optional history service.
	 */
	public function __construct(
		$rest_delegate = null,
		$meta_service = null,
		$history_service = null
	) {
		$this->rest_delegate   =( isset( $rest_delegate ) ? $rest_delegate : new WooCommerceRestDelegate() );
		$this->meta_service    =( isset( $meta_service ) ? $meta_service : new WholesaleCategoryMetaService() );
		$this->history_service =( isset( $history_service ) ? $history_service : new ChangeHistoryService() );
	}

	/**
	 * Get key
	 * 
	 * @inheritDoc
	 */
	public function get_key() {
		return 'woocommerce_categories';
	}

	/**
	 * Get label
	 * 
	 * @inheritDoc
	 */
	public function get_label() {
		return __( 'WooCommerce Categories', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get description
	 * 
	 * @inheritDoc
	 */
	public function get_description() {
		return __( 'Full CRUD for WooCommerce product categories with wholesale configuration. Per category and per role: activation toggle, discount type (fixed/percent), discount value, step quantity, and tier pricing (min qty, max qty, value). Also manages wholesale visibility restrictions and role-based category access. Sits between product-level and global pricing in the pricing hierarchy. Use action update with a partial wholesale patch — include ONLY role_pricing fields the user asked to change; omit min_quantity, discount_type, enabled, and tier_pricing unless explicitly requested.', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get plugin
	 * 
	 * @inheritDoc
	 */
	public function get_plugin() {
		return 'wholesale';
	}

	/**
	 * Get input schema
	 * 
	 * @inheritDoc
	 */
	public function get_input_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'action'     => array(
					'type'        => 'string',
					'enum'        => array( 'list', 'get', 'create', 'update', 'delete' ),
					'description' => __( 'CRUD action to perform.', 'woocommerce-wholesale-pricing' ),
				),
				'identifier' => array(
					'type'        => 'integer',
					'description' => __( 'Category term ID (required for get, update, delete).', 'woocommerce-wholesale-pricing' ),
				),
				'category'   => array(
					'type'                 => 'object',
					'description'          => __( 'WooCommerce REST category fields for a single create.', 'woocommerce-wholesale-pricing' ),
					'additionalProperties' => true,
				),
				'categories' => array(
					'type'        => 'array',
					'description' => __( 'Multiple categories to create in one request. Each item may be category fields or { category, wholesale }.', 'woocommerce-wholesale-pricing' ),
					'items'       => array(
						'type'                 => 'object',
						'additionalProperties' => true,
					),
				),
				'wholesale'  => $this->get_wholesale_schema(),
				'per_page'   => array( 'type' => 'integer' ),
				'page'       => array( 'type' => 'integer' ),
			),
			'required'             => array( 'action' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * Get output schema
	 * 
	 * @inheritDoc
	 */
	public function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'categories' => array( 'type' => 'array' ),
				'category'   => array( 'type' => 'object' ),
				'total'      => array( 'type' => 'integer' ),
				'deleted'    => array( 'type' => 'boolean' ),
			),
		);
	}

	/**
	 * Execute
	 * 
	 * @inheritDoc
	 */
	public function execute( $input ) {
		$payload = is_array( $input ) ? $input : array();
		$action  = isset( $payload['action'] ) ? sanitize_key( (string) $payload['action'] ) : '';

		switch ( $action ) {
			case 'list':
				return $this->list_categories( $payload );

			case 'get':
				return $this->get_category( $payload );

			case 'create':
				$categories = is_array(( isset( $payload['categories'] ) ? $payload['categories'] : null )) ? $payload['categories'] : array();

				if ( ! empty( $categories ) ) {
					return $this->create_categories( $payload, $categories );
				}

				return $this->create_category( $payload );

			case 'update':
				return $this->update_category( $payload );

			case 'delete':
				return $this->delete_category( $payload );

			default:
				return new \WP_Error(
					'wwp_category_invalid_action',
					__( 'Invalid action. Use list, get, create, update, or delete.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
		}
	}

	/**
	 * Check permission
	 * 
	 * @inheritDoc
	 */
	public function check_permission( $input ) {
		if ( ! $this->is_enabled() ) {
			return new \WP_Error(
				'wwp_ability_disabled',
				__( 'The WooCommerce Categories ability is disabled in AI Assistant settings.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		$payload = is_array( $input ) ? $input : array();
		$action  = isset( $payload['action'] ) ? sanitize_key( (string) $payload['action'] ) : 'list';

		return $this->rest_delegate->check_category_permission( $action );
	}

	/**
	 * Register ability with annotations.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			$this->get_ability_name(),
			array(
				'label'               => $this->get_label(),
				'description'         => $this->get_description(),
				'category'            => $this->get_plugin(),
				'input_schema'        => $this->get_input_schema(),
				'output_schema'       => $this->get_output_schema(),
				'execute_callback'    => array( $this, 'execute' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'meta'                => array(
					'show_in_rest' => false,
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => false,
					),
				),
			)
		);
	}

	/**
	 * List categories
	 * 
	 * @param array<string, mixed> $payload Input payload.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function list_categories( array $payload ) {
		$list_input = array(
			'per_page' => isset( $payload['per_page'] ) ? (int) $payload['per_page'] : 20,
			'page'     => isset( $payload['page'] ) ? (int) $payload['page'] : 1,
		);

		$result = $this->rest_delegate->execute_categories( 'list', $list_input );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$items      = is_array(( isset( $result['data'] ) ? $result['data'] : null )) ? $result['data'] : array();
		$categories = array();

		foreach ( $items as $item ) {
			if ( ! is_array( $item ) || empty( $item['id'] ) ) {
				continue;
			}
			$term_id = (int) $item['id'];
			$wholesale = $this->meta_service->get_wholesale_settings( $term_id );
			$item['wholesale'] = is_wp_error( $wholesale ) ? array() : $wholesale;
			$categories[] = $item;
		}

		return array(
			'categories' => $categories,
			'total'      => (int) ( ( isset( $result['total'] ) ? $result['total'] : count( $categories ) ) ),
		);
	}

	/**
	 * Get category
	 * 
	 * @param array<string, mixed> $payload Input payload.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function get_category( array $payload ) {
		$term_id = $this->resolve_identifier( $payload );
		if ( is_wp_error( $term_id ) ) {
			return $term_id;
		}

		$category = $this->rest_delegate->execute_categories( 'get', array( 'identifier' => $term_id ) );
		if ( is_wp_error( $category ) ) {
			return $category;
		}

		$wholesale = $this->meta_service->get_wholesale_settings( $term_id );
		if ( ! is_wp_error( $wholesale ) ) {
			$category['wholesale'] = $wholesale;
		}

		return array( 'category' => $category );
	}

	/**
	 * Create category
	 * 
	 * @param array<string, mixed> $payload Input payload.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function create_category( array $payload ) {
		$category_data = is_array(( isset( $payload['category'] ) ? $payload['category'] : null )) ? $payload['category'] : array();
		if ( empty( $category_data['name'] ) ) {
			return new \WP_Error(
				'wwp_category_missing_name',
				__( 'Category name is required for create.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$created = $this->rest_delegate->execute_categories( 'create', array( 'category' => $category_data ) );
		if ( is_wp_error( $created ) ) {
			return $created;
		}

		$term_id = (int) ( ( isset( $created['id'] ) ? $created['id'] : 0 ) );
		if ( $term_id <= 0 ) {
			return new \WP_Error(
				'wwp_category_create_failed',
				__( 'Category was created but no ID was returned.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		if ( ! empty( $payload['wholesale'] ) && is_array( $payload['wholesale'] ) ) {
			$wholesale = $this->meta_service->update_wholesale_settings( $term_id, $payload['wholesale'] );
			if ( is_wp_error( $wholesale ) ) {
				return $wholesale;
			}
			$created['wholesale'] = $wholesale;
		} else {
			$wholesale = $this->meta_service->get_wholesale_settings( $term_id );
			if ( ! is_wp_error( $wholesale ) ) {
				$created['wholesale'] = $wholesale;
			}
		}

		$this->record_change(
			'create',
			array(
				'id'   => $term_id,
				'name' => ( isset( $created['name'] ) ? $created['name'] : '' ),
			),
			null,
			sprintf(
				/* translators: %s: category name */
				__( 'Created category "%s".', 'woocommerce-wholesale-pricing' ),
( isset( $created['name'] ) ? $created['name'] : (string) $term_id )
		   )
		);

		return array( 'category' => $created );
	}

	/**
	 * Create multiple product categories in one request.
	 *
	 * @param array<string, mixed> $payload    Input payload.
	 * @param list<array<string, mixed>> $categories Category entries.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function create_categories( array $payload, array $categories ) {
		$created_items = array();
		$default_wholesale = is_array(( isset( $payload['wholesale'] ) ? $payload['wholesale'] : null )) ? $payload['wholesale'] : null;

		foreach ( $categories as $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}

			$category_data = is_array(( isset( $entry['category'] ) ? $entry['category'] : null )) ? $entry['category'] : $entry;
			$wholesale     = is_array(( isset( $entry['wholesale'] ) ? $entry['wholesale'] : null ))
				? $entry['wholesale']
				: $default_wholesale;

			$single_payload = array(
				'action'   => 'create',
				'category' => $category_data,
			);

			if ( is_array( $wholesale ) ) {
				$single_payload['wholesale'] = $wholesale;
			}

			$result = $this->create_category( $single_payload );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			if ( is_array( $result ) && is_array(( isset( $result['category'] ) ? $result['category'] : null )) ) {
				$created_items[] = $result['category'];
			}
		}

		if ( empty( $created_items ) ) {
			return new \WP_Error(
				'wwp_category_missing_name',
				__( 'At least one valid category name is required for create.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		return array(
			'categories' => $created_items,
			'total'      => count( $created_items ),
		);
	}

	/**
	 * Update category
	 * 
	 * @param array<string, mixed> $payload Input payload.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function update_category( array $payload ) {
		$term_id = $this->resolve_identifier( $payload );
		if ( is_wp_error( $term_id ) ) {
			return $term_id;
		}

		$category_data = is_array(( isset( $payload['category'] ) ? $payload['category'] : null )) ? $payload['category'] : array();
		$wholesale     = is_array(( isset( $payload['wholesale'] ) ? $payload['wholesale'] : null )) ? $payload['wholesale'] : array();

		if ( empty( $category_data ) && empty( $wholesale ) ) {
			return new \WP_Error(
				'wwp_category_missing_data',
				__( 'Provide category and/or wholesale fields to update.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$before = $this->build_before_snapshot( $term_id );

		if ( ! empty( $category_data ) ) {
			$updated = $this->rest_delegate->execute_categories(
				'update',
				array(
					'identifier' => $term_id,
					'category'   => $category_data,
				)
			);
			if ( is_wp_error( $updated ) ) {
				return $updated;
			}
		} else {
			$updated = $this->rest_delegate->execute_categories( 'get', array( 'identifier' => $term_id ) );
			if ( is_wp_error( $updated ) ) {
				return $updated;
			}
		}

		if ( ! empty( $wholesale ) ) {
			$wholesale_result = $this->meta_service->update_wholesale_settings( $term_id, $wholesale );
			if ( is_wp_error( $wholesale_result ) ) {
				return $wholesale_result;
			}
			$updated['wholesale'] = $wholesale_result;
		} else {
			$wholesale_get = $this->meta_service->get_wholesale_settings( $term_id );
			if ( ! is_wp_error( $wholesale_get ) ) {
				$updated['wholesale'] = $wholesale_get;
			}
		}

		$this->record_change(
			'update',
			array(
				'id'   => $term_id,
				'name' => ( isset( $updated['name'] ) ? $updated['name'] : '' ),
			),
			$before,
			sprintf(
				/* translators: %s: category name */
				__( 'Updated category "%s".', 'woocommerce-wholesale-pricing' ),
( isset( $updated['name'] ) ? $updated['name'] : (string) $term_id )
		   )
		);

		return array( 'category' => $updated );
	}

	/**
	 * Delete category
	 * 
	 * @param array<string, mixed> $payload Input payload.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function delete_category( array $payload ) {
		$term_id = $this->resolve_identifier( $payload );
		if ( is_wp_error( $term_id ) ) {
			return $term_id;
		}

		$before = $this->build_before_snapshot( $term_id );

		$deleted = $this->rest_delegate->execute_categories( 'delete', array( 'identifier' => $term_id ) );
		if ( is_wp_error( $deleted ) ) {
			return $deleted;
		}

		$this->record_change(
			'delete',
			array( 'id' => $term_id ),
			$before,
			sprintf(
				/* translators: %d: category ID */
				__( 'Deleted category #%d.', 'woocommerce-wholesale-pricing' ),
				$term_id
			)
		);

		return array(
			'deleted' => true,
			'id'      => $term_id,
		);
	}

	/**
	 * Resovle indentifier
	 * 
	 * @param array<string, mixed> $payload Input payload.
	 * @return int|\WP_Error
	 */
	private function resolve_identifier( array $payload ) {
		$term_id = isset( $payload['identifier'] ) ? (int) $payload['identifier'] : 0;

		if ( $term_id <= 0 ) {
			return new \WP_Error(
				'wwp_category_missing_identifier',
				__( 'Category identifier is required.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		return $term_id;
	}

	/**
	 * Build before snapshot
	 * 
	 * @param int $term_id Category term ID.
	 * @return array<string, mixed>|null
	 */
	private function build_before_snapshot( $term_id ) {
		$category = $this->rest_delegate->execute_categories( 'get', array( 'identifier' => $term_id ) );
		$meta     = $this->meta_service->snapshot_wholesale_settings( $term_id );

		if ( is_wp_error( $category ) ) {
			return is_wp_error( $meta ) ? null : array( 'wholesale_snapshot' => $meta );
		}

		$snapshot = $category;
		if ( ! is_wp_error( $meta ) ) {
			$snapshot['wholesale_snapshot'] = $meta;
		}

		return $snapshot;
	}

	/**
	 * Get wholesale schema
	 * 
	 * @return array<string, mixed>
	 */
	private function get_wholesale_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'role_pricing'           => array( 'type' => 'array' ),
				'tier_pricing'           => array( 'type' => 'object' ),
				'hide_for_roles'         => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				'hide_for_non_wholesale' => array( 'type' => 'boolean' ),
			),
		);
	}

	/**
	 * Record change
	 * 
	 * @param string                    $action_type Action type.
	 * @param array<string, mixed>      $resource    Resource data.
	 * @param array<string, mixed>|null $before      Before state.
	 * @param string                    $description Description.
	 * @return void
	 */
	private function record_change( $action_type, array $resource, $before, $description ) {
		$this->history_service->record(
			array(
				'tool'               => 'woocommerce_categories',
				'ability'            => $this->get_key(),
				'change_description' => $description,
				'action_type'        => $action_type,
				'resource_type'      => 'product_category',
				'resource'           => $resource,
				'before_state'       => $before,
			)
		);
	}
}
