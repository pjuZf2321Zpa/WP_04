<?php
/**
 * REST API controller for AI Assistant settings.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Apis
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Apis;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\ChangeHistoryService;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\ChatOrchestratorService;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\ConnectorService;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\ModelsService;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\PendingActionService;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\SettingsService;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\UndoService;

/**
 * Registers wholesale/v1/ai-assistant endpoints.
 */
class AI_Assistant_V1_Controller {

	/**
	 * REST API namespace.
	 *
	 * @var string
	 */
	protected $namespace = 'wholesale/v1';

	/**
	 * REST API base route.
	 *
	 * @var string
	 */
	protected $rest_base = 'ai-assistant';

	/**
	 * Settings service.
	 *
	 * @var SettingsService
	 */
	private $settings_service;

	/**
	 * Connector service.
	 *
	 * @var ConnectorService
	 */
	private $connector_service;

	/**
	 * Models service.
	 *
	 * @var ModelsService
	 */
	private $models_service;

	/**
	 * Change history service.
	 *
	 * @var ChangeHistoryService
	 */
	private $history_service;

	/**
	 * Undo service.
	 *
	 * @var UndoService
	 */
	private $undo_service;

	/**
	 * Chat orchestrator service.
	 *
	 * @var ChatOrchestratorService
	 */
	private $chat_service;

	/**
	 * Pending action service.
	 *
	 * @var PendingActionService
	 */
	private $pending_service;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->settings_service  = new SettingsService();
		$this->connector_service = new ConnectorService( $this->settings_service );
		$this->models_service    = new ModelsService( $this->connector_service );
		$this->history_service   = new ChangeHistoryService( $this->settings_service );
		$this->undo_service      = new UndoService( $this->history_service );
		$this->chat_service      = new ChatOrchestratorService( $this->settings_service );
		$this->pending_service   = new PendingActionService();

		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_item' ),
					'permission_callback' => array( $this, 'permissions_check' ),
				),
				array(
					'methods'             => \WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_item' ),
					'permission_callback' => array( $this, 'permissions_check' ),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/disconnect',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'deactivate_provider' ),
					'permission_callback' => array( $this, 'permissions_check' ),
					'args'                => array(
						'provider_id' => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/activate',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'activate_provider' ),
					'permission_callback' => array( $this, 'permissions_check' ),
					'args'                => array(
						'provider_id' => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/history',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_history' ),
					'permission_callback' => array( $this, 'permissions_check' ),
				),
				array(
					'methods'             => \WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'clear_history' ),
					'permission_callback' => array( $this, 'permissions_check' ),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/history/(?P<id>\d+)/undo',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'undo_history_item' ),
					'permission_callback' => array( $this, 'permissions_check' ),
					'args'                => array(
						'id' => array(
							'required'          => true,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/chat',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'post_chat_message' ),
					'permission_callback' => array( $this, 'permissions_check' ),
					'args'                => array(
						'message'    => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_textarea_field',
						),
						'session_id' => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/chat/approve',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'approve_chat_action' ),
					'permission_callback' => array( $this, 'permissions_check' ),
					'args'                => array(
						'pending_id' => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'session_id' => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/chat/deny',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'deny_chat_action' ),
					'permission_callback' => array( $this, 'permissions_check' ),
					'args'                => array(
						'pending_id' => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'session_id' => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/chat/session',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_chat_session' ),
					'permission_callback' => array( $this, 'permissions_check' ),
					'args'                => array(
						'session_id' => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_chat_session' ),
					'permission_callback' => array( $this, 'permissions_check' ),
					'args'                => array(
						'session_id' => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);
	}

	/**
	 * GET /wholesale/v1/ai-assistant
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response
	 */
	public function get_item( $request ) {
		$configured_ids = $this->connector_service->get_configured_provider_ids();
		$settings       = $this->settings_service->maybe_migrate_active_providers( $configured_ids );
		$connectors     = $this->connector_service->get_connectors();

		return new \WP_REST_Response(
			array(
				'settings'           => $settings,
				'connectors'         => $connectors,
				'connectedProviders' => $this->connector_service->get_connected_providers(),
				'models'             => $this->models_service->get_connected_text_generation_models(),
				'onboardingComplete' => $this->connector_service->has_any_active_provider(),
			),
			200
		);
	}

	/**
	 * PUT /wholesale/v1/ai-assistant
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function update_item( $request ) {
		$params = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			$params = $request->get_params();
		}

		$settings = isset( $params['settings'] ) && is_array( $params['settings'] )
			? $params['settings']
			: $params;

		$saved = $this->settings_service->save_settings( $settings );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		return new \WP_REST_Response(
			array(
				'settings' => $saved,
				'message'  => __( 'AI Assistant settings saved.', 'woocommerce-wholesale-pricing' ),
			),
			200
		);
	}

	/**
	 * POST /wholesale/v1/ai-assistant/disconnect
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function deactivate_provider( $request ) {
		$provider_id = (string) $request->get_param( 'provider_id' );
		$result      = $this->connector_service->deactivate_provider( $provider_id );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return new \WP_REST_Response(
			$this->build_provider_state_response(),
			200
		);
	}

	/**
	 * POST /wholesale/v1/ai-assistant/activate
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function activate_provider( $request ) {
		$provider_id = (string) $request->get_param( 'provider_id' );
		$result      = $this->connector_service->activate_provider( $provider_id );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return new \WP_REST_Response(
			$this->build_provider_state_response(),
			200
		);
	}

	/**
	 * GET /wholesale/v1/ai-assistant/history
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response
	 */
	public function get_history( $request ) {
		return new \WP_REST_Response(
			array(
				'items' => $this->history_service->list_records(),
			),
			200
		);
	}

	/**
	 * DELETE /wholesale/v1/ai-assistant/history
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function clear_history( $request ) {
		$cleared = $this->history_service->clear_all();

		if ( ! $cleared ) {
			return new \WP_Error(
				'wwp_ai_history_clear_failed',
				__( 'Failed to clear change history.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => __( 'Change history cleared.', 'woocommerce-wholesale-pricing' ),
			),
			200
		);
	}

	/**
	 * POST /wholesale/v1/ai-assistant/history/{id}/undo
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function undo_history_item( $request ) {
		$id     = (int) $request->get_param( 'id' );
		$result = $this->undo_service->undo( $id );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return new \WP_REST_Response(
			array(
				'item'    => $result,
				'message' => __( 'Change undone successfully.', 'woocommerce-wholesale-pricing' ),
			),
			200
		);
	}

	/**
	 * POST /wholesale/v1/ai-assistant/chat
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function post_chat_message( $request ) {
		$message    = (string) $request->get_param( 'message' );
		$session_id = (string) $request->get_param( 'session_id' );
		$result     = $this->chat_service->handle_message( $session_id, $message );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return new \WP_REST_Response( $result, 200 );
	}

	/**
	 * POST /wholesale/v1/ai-assistant/chat/approve
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function approve_chat_action( $request ) {
		$pending_id = (string) $request->get_param( 'pending_id' );
		$session_id = (string) $request->get_param( 'session_id' );
		$result     = $this->pending_service->approve( $pending_id, $session_id );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$session = $this->chat_service->get_session( $session_id );

		return new \WP_REST_Response(
			array_merge(
				$result,
				array(
					'messages' => is_array(( isset( $session['messages'] ) ? $session['messages'] : null )) ? $session['messages'] : array(),
				)
			),
			200
		);
	}

	/**
	 * POST /wholesale/v1/ai-assistant/chat/deny
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function deny_chat_action( $request ) {
		$pending_id = (string) $request->get_param( 'pending_id' );
		$session_id = (string) $request->get_param( 'session_id' );
		$result     = $this->pending_service->deny( $pending_id, $session_id );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$session = $this->chat_service->get_session( $session_id );

		return new \WP_REST_Response(
			array_merge(
				$result,
				array(
					'messages' => is_array(( isset( $session['messages'] ) ? $session['messages'] : null )) ? $session['messages'] : array(),
				)
			),
			200
		);
	}

	/**
	 * GET /wholesale/v1/ai-assistant/chat/session
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response
	 */
	public function get_chat_session( $request ) {
		$session_id = (string) $request->get_param( 'session_id' );

		return new \WP_REST_Response(
			$this->chat_service->get_session( $session_id ),
			200
		);
	}

	/**
	 * DELETE /wholesale/v1/ai-assistant/chat/session
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response
	 */
	public function delete_chat_session( $request ) {
		$session_id = (string) $request->get_param( 'session_id' );
		$cleared    = $this->chat_service->clear_session( $session_id );

		return new \WP_REST_Response(
			array(
				'success'    => $cleared,
				'session_id' => $session_id,
			),
			200
		);
	}

	/**
	 * Build a standard provider-state payload for activate/deactivate responses.
	 *
	 * @return array<string, mixed>
	 */
	private function build_provider_state_response() {
		return array(
			'success'            => true,
			'settings'           => $this->settings_service->get_settings(),
			'connectors'         => $this->connector_service->get_connectors(),
			'connectedProviders' => $this->connector_service->get_connected_providers(),
			'onboardingComplete' => $this->connector_service->has_any_active_provider(),
		);
	}

	/**
	 * Permission check.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return bool|\WP_Error
	 */
	public function permissions_check( $request ) {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		return new \WP_Error(
			'wholesale_ai_assistant_permission_failed',
			__( 'You do not have permission to manage AI Assistant settings.', 'woocommerce-wholesale-pricing' ),
			array( 'status' => rest_authorization_required_code() )
		);
	}
}
