<?php

namespace WooCommerceWholesalePricing\App\Modules\Wholesale;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

class PriceService {

	use WholesaleSettings;

	public function __construct() {
		add_filter( 'wwp_wholesale_apply_on_sale_price', array( $this, 'discount_apply_on' ), 100 );
	}

	public function discount_apply_on( $key ) {
		$settings = self::get_pricing_settings();
		
		if ( ! isset( $settings['wholesale_price_application'] ) || '_price' !== $settings['wholesale_price_application'] ) {
			return $key;
		}

		return '_price';
	}
}   
