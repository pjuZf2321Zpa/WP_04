<?php
/**
 * ProductVisibility class for managing which products are visible to a wholesale user.
 *
 * This class applies product filtering rules to the main WordPress query, shortcodes,
 * widgets, cross-sells, and sets variation quantity constraints based on the
 * currently logged-in user's wholesale role or settings.
 *
 * @package    WooCommerceWholesalePricing\App\Modules\Wholesale
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale;

use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\IsWholesale;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

/**
 * Class ProductVisibility
 *
 * Implements logic to restrict product visibility in shop and query results
 * based on whether a wholesale price is configured for the current user.
 */
class ProductVisibility {


   
	/**
	 * Includes methods for retrieving general wholesale settings and checking wholesale status.
	 */
	use WholesaleSettings;
	use IsWholesale;

	/**
	 * An array of product IDs that should be excluded from the query results.
	 * Populated by default_wholesaler_products_only() after the main query runs.
	 *
	 * @var array
	 */
	private $exclude_ids = array();

	/**
	 * ProductVisibility constructor.
	 *
	 * Hooks into various WordPress and WooCommerce actions and filters to manage
	 * product visibility and quantity fields.
	 */
	public function __construct() {
		// Query modification hooks
		add_action('pre_get_posts', array( $this, 'default_wholesaler_products_only' ), 10, 1);
		add_action('woocommerce_shortcode_products_query', array( $this, 'woocommerce_shortcode_products_query' ), 200, 1);
		add_action('woocommerce_products_widget_query_args', array( $this, 'woocommerce_shortcode_products_query' ), 200, 1);
		add_filter('woocommerce_product_subcategories_args', array( $this, 'hide_excluded_categories_from_shop' ), 999 );
		// Product data and visibility hooks
		add_filter('woocommerce_available_variation', array( $this, 'filter_woocommerce_available_variation' ), 200, 3);
		add_filter('woocommerce_cart_crosssell_ids', array( $this, 'remove_non_wholesale_product_crosssell' ), 200, 2);
	}

	/**
	 * Restricts the main query to only show products that have wholesale pricing
	 * configured for the current user's role.
	 *
	 * This method runs only if 'wholesaler_prodcut_only' setting is enabled and the
	 * current user is a wholesaler (and not in the admin area).
	 *
	 * @hook pre_get_posts
	 *
	 * @param  \WP_Query $q The current WP_Query object by reference.
	 * @return void
	 */
	public function default_wholesaler_products_only( $q ) {
		$settings             = self::get_pricing_settings();
		$wholesaler_prod_only = ( isset($settings['wholesaler_prodcut_only']) && 'yes' == $settings['wholesaler_prodcut_only'] ) ? 'yes' : 'no';

		if ('yes' == $wholesaler_prod_only && $q->is_main_query() && ! is_admin() ) {
			
			if (is_wholesaler_user(get_current_user_id()) ) {

				// Global price get
				$data = get_option('wholesale_multi_user_pricing');

				$role = get_current_user_role_id();

				$total_ids = array();
				if (! isset($data[ $role ]) ) {
					
					$cate = array();

					$categories = get_terms(array( 'taxonomy' => 'product_cat' ));

					if (is_array($categories) ) {

						foreach ( $categories as $category ) {

							$data = get_term_meta($category->term_id, 'wholesale_multi_user_pricing', true);

							if (isset($data[ $role ]['wholesale_price']) ) {

								$cate[] = $category->term_id;

							}
						}
						$args = array(
							'post_type'   => 'product',
							'numberposts' => -1,
							'fields'      => 'ids',
							'tax_query'   => array(
								array(
									'taxonomy' => 'product_cat',
									'field'    => 'term_id',
									'terms'    => $cate,
									'operator' => 'IN',

								),
							),
						);

						$ids = get_posts($args);

						if (is_array($ids) ) {

							foreach ( $ids  as $id ) {
									$total_ids[] = $id;
							}
						}
					}

					$all_ids = get_products_by_meta();
					
					foreach ( $all_ids as $id ) {

						$data = get_post_meta($id, 'wholesale_multi_user_pricing', true);

						if (isset($data[ $role ]) ) {
							$total_ids[] = $id;
						}
					}

					if (is_array($ids) ) {
						foreach ( $ids  as $id ) {
							$total_ids[] = $id;
						}
					}

					if (! empty($total_ids) && is_array($total_ids) ) {

						$total_ids   = array_unique($total_ids);
						$exclude_ids = array_diff($all_ids, $total_ids);
						$q->set('post__not_in', $exclude_ids);
						$this->exclude_ids = $exclude_ids;
						add_filter('woocommerce_related_products', array( $this, 'exclude_related_products' ), 10, 3);
						
					} else {
						$q->set('post__not_in', $all_ids);
					}
				}
			}

			$role_hidden_ids = $this->get_role_hidden_product_ids();
			if ( ! empty( $role_hidden_ids ) ) {
				$post__not_in = (array) $q->get( 'post__not_in' );
				$q->set( 'post__not_in', array_unique( array_merge( $post__not_in, $role_hidden_ids ) ) );
			}
		}
	}

	/**
	 * Filters WooCommerce related products to exclude those that the current
	 * wholesale user is not authorized to see.
	 *
	 * @hook woocommerce_related_products
	 *
	 * @param  array $related_posts Array of related product IDs.
	 * @param  int   $product_id    The current product ID.
	 * @param  array $args          Query arguments for related products.
	 * @return array Filtered array of related product IDs.
	 */
	public function exclude_related_products( $related_posts, $product_id, $args ) {
			return array_diff($related_posts, $this->exclude_ids);
	}

	/**
	 * Modifies the query arguments for WooCommerce shortcodes (e.g., [products])
	 * and product widgets to apply wholesale visibility rules.
	 *
	 * @hook woocommerce_shortcode_products_query
	 * @hook woocommerce_products_widget_query_args
	 *
	 * @param  array $q The query arguments array.
	 * @return array The modified query arguments array.
	 */
	public function woocommerce_shortcode_products_query( $q ) {
		$settings             = self::get_pricing_settings();
		$wholesaler_prod_only = ( isset($settings['wholesaler_prodcut_only']) && 'yes' == $settings['wholesaler_prodcut_only'] ) ? 'yes' : 'no';

		if ('yes' == $wholesaler_prod_only && ! is_admin() ) {
			if (is_wholesaler_user(get_current_user_id()) ) {
				$q = $this->wwp_hide_product_ids($q);
			}
		}
		return $q;
	}

	public function hide_excluded_categories_from_shop( $args ) {
		$settings             = self::get_pricing_settings();
				
		$wholesaler_prod_only = ( isset( $settings['wholesaler_prodcut_only'] ) && 'yes' === $settings['wholesaler_prodcut_only'] ) ? 'yes' : 'no';

		// Only apply for wholesaler users on the frontend
		if ( is_user_logged_in() && 'yes' === $wholesaler_prod_only && ! is_admin() && is_wholesaler_user( get_current_user_id() ) ) {

			$all_categories = get_terms( array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
				'fields'     => 'ids',
			) );

			$categories_to_hide = array();

			if ( ! empty( $all_categories ) && ! is_wp_error( $all_categories ) ) {
				foreach ( $all_categories as $cat_id ) {

					// Get all product IDs in this category
					$products_in_cat = get_posts( array(
						'post_type'      => 'product',
						'posts_per_page' => -1,
						'fields'         => 'ids',
						'tax_query'      => array(
							array(
								'taxonomy' => 'product_cat',
								'field'    => 'term_id',
								'terms'    => $cat_id,
							),
						),
					) );

					// Check if at least one product in this category is a wholesale product
					$has_wholesale = false;
					if ( ! empty( $products_in_cat ) ) {
						foreach ( $products_in_cat as $product_id ) {
							if ( is_wholesale_product( $product_id ) ) {
								$has_wholesale = true;
								break;
							}
						}
					}

					// If no wholesale product found, mark category for hiding
					if ( ! $has_wholesale ) {
						$categories_to_hide[] = $cat_id;
					}
				}
			}

			// Exclude categories with no wholesale products
			if ( ! empty( $categories_to_hide ) ) {
				$args['exclude'] = isset( $args['exclude'] )
					? array_merge( (array) $args['exclude'], $categories_to_hide )
					: $categories_to_hide;
			}
		}

		return $args;
	}

	/**
	 * Core logic to determine which product IDs should be excluded from a given
	 * query array based on wholesale pricing rules for the current user's role.
	 *
	 * @param  array $q The query arguments array.
	 * @return array The modified query arguments array with 'post__not_in' set.
	 */
	public function wwp_hide_product_ids( $q ) {
	
		$data = get_option('wholesale_multi_user_pricing');
		$role = get_current_user_role_id();

		if (! isset($data[ $role ]) ) {
			$total_ids = array();
			$cate      = array();

			$categories = get_terms(array( 'taxonomy' => 'product_cat' ));

			if (is_array($categories) ) {

				foreach ( $categories as $category ) {

					$data = get_term_meta($category->term_id, 'wholesale_multi_user_pricing', true);

					if (isset($data[ $role ]['wholesale_price']) ) {

						$cate[] = $category->term_id;

					}
				}

				$args = array(
					'post_type' => 'product',
					'fields'    => 'ids',
					'tax_query' => array(
						array(
							'taxonomy' => 'product_cat',
							'field'    => 'term_id',
							'terms'    => $cate,
							'operator' => 'IN',

						),
					),
				);

				$ids = get_posts($args);

				if (is_array($ids) ) {

					foreach ( $ids  as $id ) {
							$total_ids[] = $id;
					}
				}
			}

			$all_ids = get_posts(
				array(
					'post_type'        => 'product',
					'numberposts'      => -1,
					'suppress_filters' => false,
					'post_status'      => 'publish',
					'fields'           => 'ids',
				)
			);
			foreach ( $all_ids as $id ) {

				$data = get_post_meta($id, 'wholesale_multi_user_pricing', true);

				if (isset($data[ $role ]) ) {
					$total_ids[] = $id;
				}
			}
			
			if (is_array($ids) ) {
				foreach ( $ids  as $id ) {
					$total_ids[] = $id;
				}
			}
			unset($q['post__in']);
			
			
			if (is_array($total_ids) ) {

				$total_ids         = array_unique($total_ids);
				$exclude_ids       = array_diff($all_ids, $total_ids);
				$post__not_in      = isset($q['post__not_in']) ? (array) $q['post__not_in'] : array();
				$q['post__not_in'] = array_merge($post__not_in, $exclude_ids);

			} else {

				$q['post__not_in'] = $all_ids;

			}
		}

		$role_hidden_ids = $this->get_role_hidden_product_ids();
		if ( ! empty( $role_hidden_ids ) ) {
			$post__not_in      = isset( $q['post__not_in'] ) ? (array) $q['post__not_in'] : array();
			$q['post__not_in'] = array_unique( array_merge( $post__not_in, $role_hidden_ids ) );
		}
		return $q;
	}

	/**
	 * Gets products explicitly hidden for the current wholesale role.
	 *
	 * @return array<int> Product IDs hidden from the current role.
	 */
	private function get_role_hidden_product_ids() {
		static $is_loading = false;

		if ( $is_loading ) {
			return array();
		}

		$user = wp_get_current_user();
		$roles = array_values( (array) $user->roles );
		if ( empty( $roles ) ) {
			return array();
		}

		$meta_query = array( 'relation' => 'OR' );
		foreach ( $roles as $role ) {
			if ( ! term_exists( $role, 'wholesale_user_roles' ) ) {
				continue;
			}

			$meta_query[] = array(
				'key'     => 'wholesale_product_visibility_multi',
				'value'   => sprintf( ':"%s";', $role ),
				'compare' => 'LIKE',
			);
		}
		if ( 1 === count( $meta_query ) ) {
			return array();
		}

		$is_loading = true;
		try {
			return get_posts(
				array(
					'post_type'      => 'product',
					'posts_per_page' => -1,
					'post_status'    => 'publish',
					'fields'         => 'ids',
					'meta_query'     => $meta_query,
				)
			);
		} finally {
			$is_loading = false;
		}
	}

	/**
	 * Filters variable product data to set minimum and step quantities for
	 * wholesale variations. Also adds an availability message if a minimum
	 * quantity is required.
	 *
	 * Hierarchy of quantity rules: Variation > Category > Global.
	 *
	 * @hook woocommerce_available_variation
	 *
	 * @param  array       $variation_data Array of data for the available variation.
	 * @param  \WC_Product    $instance             The parent variable
	 *                                        product
 object.
	 * @param  \WC_Product    $variation           The variation
	 *                                        product
 object.
	 * @return array The filtered variation data array.
	 */
	public function filter_woocommerce_available_variation( $variation_data, $instance, $variation ) {
		$role       = get_current_user_role_id();
		if (wwp_guest_wholesale_pricing_enabled() ) {
			if (( is_product() && ! wwp_guest_wholesale_pricing_enabled('display_on_single') ) ) {
				return $variation_data;
			}
			$role = wwp_guest_wholesale_pricing_enabled('role');
		}
		$product_id = wp_get_post_parent_id($variation_data['variation_id']);
		$data       = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
		if ($this->is_wholesale($product_id) ) {
				
			$terms = get_the_terms($product_id, 'product_cat');
				
			if (! is_wp_error($terms) && ! empty($terms) ) {
				foreach ( $terms as $term ) {

					$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
					
					if (isset($data[$role]['min_quatity']) && !empty($data[$role]['min_quatity']) ) {
						$variation_data['input_value']  = (int) $data[$role]['min_quatity'];
						$variation_data['is_wholesale'] = true;
					}
					
					if (isset($data[$role]['step_quantity']) && !empty($data[$role]['step_quantity']) ) {
						$variation_data['step'] = (int) $data[$role]['step_quantity'];
						if (isset($data[$role]['min_quatity']) && !empty($data[$role]['min_quatity']) ) {
							$variation_data['min_value']    = (int) $data[$role]['min_quatity'];
							$variation_data['is_wholesale'] = true;
						}
					}
				}
				
			}
			$data = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
			if (isset($data[$role][$variation_data['variation_id']]['qty']) && !empty($data[$role][$variation_data['variation_id']]['qty']) ) {
				$variation_data['input_value']  = (int) $data[$role][$variation_data['variation_id']]['qty'];
				$variation_data['is_wholesale'] = true;
			}
			if (isset($data[$role][$variation_data['variation_id']]['step']) && !empty($data[$role][$variation_data['variation_id']]['step']) ) {
				$variation_data['step'] =  (int) $data[$role][$variation_data['variation_id']]['step'];
				if (isset($data[$role][$variation_data['variation_id']]['qty']) && !empty($data[$role]['qty']) ) {
					$variation_data['min_value']    =  (int) $data[$role][$variation_data['variation_id']]['qty'];
					$variation_data['is_wholesale'] = true;
				}
			}
		}

		$settings = self::get_pricing_settings();
		$restrict_store_access = isset($settings['restrict_store_access']) ? $settings['restrict_store_access'] : '';
		if ('yes' != $restrict_store_access ) {
			if (! is_wholesaler_user(get_current_user_id()) && ( ! wwp_guest_wholesale_pricing_enabled() ) ) {
				return $variation_data;
			}
		}
		/*
		Wholesale Version 1.6.0
		Minimum  Quantity Set by Product
		*/
		if (isset($data[ $role ][ $variation_data['variation_id'] ]['qty']) ) {

			$min_quantity = (int) $data[ $role ][ $variation_data['variation_id'] ]['qty'];

			if ($min_quantity && 1 != $min_quantity ) {
				/* translators: %s: wholesale price on minmum */
				$textqty = sprintf(esc_html__('Wholesale price will only be applied to a minimum quantity of %1$s products', 'woocommerce-wholesale-pricing'), $min_quantity);
				
				/**
				* Hooks
				*
				* @since 3.0
				*/
				$variation_data['availability_html'] .= apply_filters('wwp_product_minimum_quantity_text', '<p style="font-size: 10px;">' . $textqty . '</p>', $min_quantity);
				return $variation_data;
			} else {
				return $variation_data;
			}
		}

		/*
		Wholesale Version 1.6.0
		Minimum  Quantity Set by Category
		*/

		$terms = get_the_terms($product_id, 'product_cat');
		if (! is_wp_error($terms) && ! empty($terms) ) {
			foreach ( $terms as $term ) {
				$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
				if (isset($data[ $role ]) ) {

					$min_quantity = (int) $data[ $role ]['min_quatity'];
					if ($min_quantity && 1 != $min_quantity ) {
						/* translators: %s: wholesale price on minmum */
						$textqty = sprintf(esc_html__('Wholesale price will only be applied to a minimum quantity of %1$s products', 'woocommerce-wholesale-pricing'), $data[ $role ]['min_quatity']);
						
						/**
						* Hooks
						*
						* @since 3.0
						*/
						$variation_data['availability_html'] .= apply_filters('wwp_product_minimum_quantity_text', '<p style="font-size: 10px;">' . $textqty . '</p>', $data[ $role ]['min_quatity']);
						return $variation_data;

					} else {
						return $variation_data;
					}
				}
			}
		}

		/*
		Wholesale Version 1.6.0
		Minimum  Quantity Set by Globaly
		*/

		$data = get_option('wholesale_multi_user_pricing');
		if (isset($data[ $role ]) ) {

			$min_quantity = (int) $data[ $role ]['min_quatity'];
			if ($min_quantity && 1 != $min_quantity ) {
				/* translators: %s: wholesale price on minmum */
				$textqty = sprintf(esc_html__('Wholesale price will only be applied to a minimum quantity of %1$s products', 'woocommerce-wholesale-pricing'), $data[ $role ]['min_quatity']);
				
				/**
				* Hooks
				*
				* @since 3.0
				*/
				$variation_data['availability_html'] .= apply_filters('wwp_product_minimum_quantity_text', '<p style="font-size: 10px;">' . $textqty . '</p>', $data[ $role ]['min_quatity']);
				return $variation_data;

			} else {
				return $variation_data;
			}
		}

		return $variation_data;
	}

	/**
	 * Filters WooCommerce cross-sell product IDs to remove products that the current
	 * wholesale user is not authorized to see, based on the exclusion list compiled
	 * during the main query.
	 *
	 * @hook woocommerce_cart_crosssell_ids
	 *
	 * @param  array   $cross_sells Array of cross-sell product IDs.
	 * @param  \WC_Cart $cart              The WooCommerce Cart object (not used in
	 *                               logic).
	 * @return array The filtered array of cross-sell product IDs.
	 */
	public function remove_non_wholesale_product_crosssell( $cross_sells, $cart ) {
		if (! empty($cross_sells) ) {
			return array_diff($cross_sells, $this->exclude_ids);
		}
		return $cross_sells;
	}
}
