<?php
/**
 * Wholesale Payment Method Class
 *
 * Registers a custom payment method for wholesale customers in WooCommerce.
 * Handles admin settings, thank-you page output, email instructions, and
 * payment processing logic.
 *
 * @package WooCommerceWholesalePricing\App\Modules\PaymentGateway
 */
namespace WooCommerceWholesalePricing\App\Modules\PaymentGateway;

/**
 * Class PaymentMethod
 *
 * Implements a custom WooCommerce payment gateway tailored for wholesale users.
 * Allows admins to configure the gateway per wholesale role, including title,
 * description, and custom instructions.
 *
 * @extends \WC_Payment_Gateway
 */
class PaymentMethod extends \WC_Payment_Gateway {

	/**
	 * Instructions shown on thank-you page and emails.
	 *
	 * @var string
	 */
	public $instructions = '';

	/**
	 * Constructor for the wholesale payment gateway.
	 *
	 * @param string $wholesale_custom_gateway Gateway Name.
	 */
	public function __construct( $wholesale_custom_gateway ) {
		
		$this->id           = strtolower(str_replace(' ', '_', $wholesale_custom_gateway));
		/**
		* Hooks
		*
		* @since 2.0
		*/
		$this->icon         = apply_filters('wwp_payment_gateway_icon', '');
		$this->has_fields   = true;
		$this->method_title = $wholesale_custom_gateway;

		// Load the settings.
		$this->init_form_fields();
		$this->init_settings();

		// Define user set variables.
		$this->title        = $this->get_option('title');
		$this->description  = $this->get_option('description');
		$this->instructions = $this->get_option('instructions', $this->description);

		// Actions.
		add_action('woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ));
		add_action('woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ));

		// Customer Emails.
		add_action('woocommerce_email_before_order_table', array( $this, 'email_instructions' ), 10, 3);
	}

	/**
	 * Initialize Gateway Settings Form Fields (Admin Options).
	 *
	 * @return void
	 */
	public function init_form_fields() {
	
		/**
		* Hooks
		*
		* @since 3.0
		*/
		$this->form_fields = apply_filters(
			'wwp_payment_form_fields',
			array(
				'enabled'     => array(
					'title'   => __('Enable/Disable', 'woocommerce-wholesale-pricing'),
					'type'    => 'checkbox',
					'label'   => 'Enable ' . $this->method_title,
					'default' => 'yes',
				),
				'title'       => array(
					'title'       => __('Title', 'woocommerce-wholesale-pricing'),
					'type'        => 'text',
					'description' => __('This controls the title for the payment method the customer sees during checkout.', 'woocommerce-wholesale-pricing'),
					'default'     => $this->method_title,
					'desc_tip'    => true,
				),
				'description' => array(
					'title'       => __('Description', 'woocommerce-wholesale-pricing'),
					'type'        => 'textarea',
					'description' => __('Payment method description that the customer will see on your checkout.', 'woocommerce-wholesale-pricing'),
					'default'     => null,
					'desc_tip'    => true,
				),
			)
		);
	}

	/**
	 * Output instructions on the thank-you page after order is placed.
	 *
	 * @return void
	 */
	public function thankyou_page() {
		if ($this->instructions ) {
			echo wp_kses_post(wpautop(wptexturize($this->instructions)));
		}
	}

	 /**
	  * Add custom instructions to WooCommerce email notifications.
	  *
	  * @param WC_Order $order         Order object.
	  * @param bool     $sent_to_admin Whether it's being sent to admin.
	  * @param bool     $plain_text    Whether email is plain text.
	  *
	  * @return void
	  */
	public function email_instructions( $order, $sent_to_admin, $plain_text = false ) {

		if ($this->instructions && ! $sent_to_admin && $this->id === $order->payment_method && $order->has_status('on-hold') ) {
			echo wp_kses_post(wpautop(wptexturize($this->instructions))) . PHP_EOL;
		}
	}

	/**
	 * Process the payment and return the result.
	 *
	 * @param int $order_id Order ID.
	 *
	 * @return array
	 */
	public function process_payment( $order_id ) {

		$order = wc_get_order($order_id);

		// Mark as on-hold (we're awaiting the payment).
		$order->update_status('processing', $this->method_title);

		// Reduce stock levels.
		$order->reduce_order_stock();

		// Remove cart.
		WC()->cart->empty_cart();
		return array(
			'result'   => 'success',
			'redirect' => $this->get_return_url($order),
		);
	}
}
