<?php

namespace WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits;

use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\DateRangeFilter;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\WholesaleUserIDs;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\WholesaleOrders;
	
trait ScoreCards {

	use DateRangeFilter;
	use WholesaleUserIDs;
	use WholesaleOrders;

	public function get_score_cards( $request ) {

		// Build ranges from request filter (default: last 30 days)
		$ranges = $this->get_date_ranges_from_request($request);

		$current_range    = $ranges['current'];
		$previous_range   = $ranges['previous'];
		$comparison_label = $ranges['label'];

		// Get wholesale orders for current and previous ranges.
		$current_orders  = $this->get_wholesale_orders_by_date_range($current_range, array( 'processing', 'completed' ));
		$previous_orders = $this->get_wholesale_orders_by_date_range($previous_range, array( 'processing', 'completed' ));

		// Calculate current metrics.
		$current_net_total    = $this->calculate_net_total($current_orders);
		$current_gross_total  = $this->calculate_gross_total($current_orders);
		$current_orders_count = $this->calculate_orders_count($current_orders);
		$current_aov          = $this->calculate_aov($current_net_total, $current_orders_count);

		// Calculate previous metrics.
		$previous_net_total    = $this->calculate_net_total($previous_orders);
		$previous_gross_total  = $this->calculate_gross_total($previous_orders);
		$previous_orders_count = $this->calculate_orders_count($previous_orders);
		$previous_aov          = $this->calculate_aov($previous_net_total, $previous_orders_count);

		// Calculate comparisons.
		$net_comparison   = $this->calculate_percentage_difference($current_net_total, $previous_net_total, $comparison_label);
		$gross_comparison = $this->calculate_percentage_difference($current_gross_total, $previous_gross_total, $comparison_label);
		$count_comparison = $this->calculate_percentage_difference($current_orders_count, $previous_orders_count, $comparison_label);
		$aov_comparison   = $this->calculate_percentage_difference($current_aov, $previous_aov, $comparison_label);

		return array(
			'net' => array(
				'value' => $current_net_total,
				'comparison' => $net_comparison,
			),
			'gross' => array(
				'value' => $current_gross_total,
				'comparison' => $gross_comparison,
			),
			'count' => array(
				'value' => $current_orders_count,
				'comparison' => $count_comparison,
			),
			'aov' => array(
				'value' => $current_aov,
				'comparison' => $aov_comparison,
			),
		);
	}

	

	/**
	 * Calculate net total from orders (total minus refunds).
	 *
	 * @param array $orders Array of WC_Order objects.
	 * @return float Net total.
	 */
	private function calculate_net_total( $orders ) {
		$net_total = 0;

		foreach ($orders as $order) {
			// get_total() returns the order total after refunds.
			$net_total += ( (float) $order->get_total() - (float) $order->get_total_refunded() );
		}

		return $net_total;
	}

	/**
	 * Calculate gross total from orders (total before refunds).
	 * Gross represents the original order total before any refunds were issued.
	 *
	 * @param array $orders Array of WC_Order objects.
	 * @return float Gross total.
	 */
	private function calculate_gross_total( $orders ) {
		$gross_total = 0;

		foreach ($orders as $order) {
			// Gross = current total + refunded amount.
			// This gives us the original order total before refunds.
			// Note: This includes discounts as they were part of the original transaction.
			$order_total = (float) $order->get_total();
			$gross_total += $order_total;
		}

		return $gross_total;
	}

	/**
	 * Calculate orders count.
	 *
	 * @param array $orders Array of WC_Order objects.
	 * @return int Orders count.
	 */
	private function calculate_orders_count( $orders ) {
		return count($orders);
	}

	/**
	 * Calculate average order value (AOV).
	 *
	 * @param float $net_total Net total.
	 * @param int $orders_count Orders count.
	 * @return float Average order value.
	 */
	private function calculate_aov( $net_total, $orders_count ) {
		if ($orders_count <= 0) {
			return 0;
		}

		return $net_total / $orders_count;
	}

	/**
	 * Calculate percentage difference between two values.
	 *
	 * @param float $current Current value.
	 * @param float $previous Previous value.
	 * @return array Array with 'type' (top/bottom), 'value' (percentage as string), and 'label'.
	 */
	private function calculate_percentage_difference( $current, $previous, $label = 'Since Previous Period' ) {

		// If previous is 0, handle special case.
		if (0 == $previous) {
			if ($current > 0) {
				return array(
					'type'  => 'top',
					'value' => '100',
					'label' => $label,
				);
			} else {
				return array(
					'type'  => 'bottom',
					'value' => '0',
					'label' => $label,
				);
			}
		}

		$percentage = ( ( $current - $previous ) / $previous ) * 100;
		$type = $percentage >= 0 ? 'top' : 'bottom';

		// Format percentage to remove decimals if whole number, otherwise round to 2 decimals.
		$percentage_value = abs($percentage);
		if (floor($percentage_value) == $percentage_value) {
			$value = (string) (int) $percentage_value;
		} else {
			$value = (string) round($percentage_value, 2);
		}

		return array(
			'type'  => $type,
			'value' => $value,
			'label' => $label,
		);
	}
}
