<?php

namespace WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits;

trait RecentRequests {

	public function get_recent_requests() {
		return array(
			'pending' => $this->get_pending_requests_count(),
			'items' => $this->get_requests(),
		);
	}

	public function get_requests() {
		$response = array();
		$requests = get_posts($this->get_query());
		if ( is_iterable( $requests ) && count( $requests ) > 0 ) {
			foreach ( $requests as $request ) {
				$role = '-';
				$user_id        = get_post_meta( $request->ID, '_user_id', true );
				$user           = get_userdata( $user_id );

				$roles = wp_get_post_terms($request->ID, wwp_env()->get('role_taxonomy'));
				if ( isset($roles[0]) && isset($roles[0]->name) ) {
					$role = $roles[0]->name;
				}

				if ( get_user_meta( $user_id, 'first_name', true ) && get_user_meta( $user_id, 'last_name', true ) ) {
					$display_name = sprintf( '%s %s', get_user_meta( $user_id, 'first_name', true ), get_user_meta( $user_id, 'last_name', true ) );
				} else if ( $user ) {
					$display_name = $user->data->display_name;
				} else {
					$display_name = $request->post_title;
				}

				$user_email = $user->data->user_email;

				$response[] = array(
					'id'    => $request->ID,
					'name'  => ! empty($display_name) ? $display_name : '-',
					'email' => $user_email ? $user_email : '-',
					'role'  => $role,
					'date'  => gmdate('M d, Y', strtotime($request->post_date)),
					'status'    => ucfirst(get_post_meta($request->ID, '_user_status', true)),
				);
			}
		}

		return $response;
	}

	public function get_pending_requests_count() {
		$args = array(
			'post_type'      => 'wwp_requests',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_query'     => array(
				array(
					'key'   => '_user_status',
					'value' => 'waiting',
				),
			),
		);

		$query = new \WP_Query($args);
		return sprintf( '%s Pending Requests', $query->found_posts );
	}

	public function get_query() {
		return array(
			'post_type'  => wwp_env()->get('request_slug'),
			'order'      => 'DESC',
			'orderby'    => 'id',
			'numberposts'=> 5,
		);
	}
}
