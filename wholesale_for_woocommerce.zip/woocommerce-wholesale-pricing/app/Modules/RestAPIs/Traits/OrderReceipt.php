<?php

namespace WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits;

use Dompdf\Dompdf;
use Dompdf\Options;

trait OrderReceipt {

	/**
	 * Get or generate PDF invoice for an order.
	 *
	 * @param \WC_Order $order Order object.
	 * @return array Array with 'url' (PDF URL) and 'fileName' (file name).
	 */
	public function get_order_invoice_pdf( $order ) {
		$order_id = $order->get_id();
		$file_name = sprintf( 'order-%s-invoice.pdf', $order->get_order_number() );
		$upload_dir = wp_upload_dir();
		$pdf_dir = $upload_dir['basedir'] . '/wholesale-invoices';
		$pdf_url_dir = $upload_dir['baseurl'] . '/wholesale-invoices';
		$file_path = $pdf_dir . '/' . $file_name;
		$file_url = $pdf_url_dir . '/' . $file_name;

		// Check if PDF already exists
		if ( file_exists( $file_path ) ) {
			return array(
				'url'      => $file_url,
				'fileName' => $file_name,
			);
		}

		// Create directory if it doesn't exist
		if ( ! file_exists( $pdf_dir ) ) {
			wp_mkdir_p( $pdf_dir );
			// Add .htaccess to protect directory (optional)
			$htaccess_file = $pdf_dir . '/.htaccess';
			if ( ! file_exists( $htaccess_file ) ) {
				file_put_contents( $htaccess_file, 'Options -Indexes' );
			}
		}

		// Generate PDF
		$html = $this->build_order_invoice_html( $order );
		$pdf_content = $this->quote_generate_pdf( $html );

		// Save PDF to file
		if ( false !== file_put_contents( $file_path, $pdf_content ) ) {
			return array(
				'url'      => $file_url,
				'fileName' => $file_name,
			);
		}

		return new \WP_Error( 'wwp_pdf_generation_failed', __( 'Failed to generate PDF invoice.', 'woocommerce-wholesale-pricing' ), array( 'status' => 500 ) );
	}

	/**
	 * Build HTML content for order invoice.
	 *
	 * @param \WC_Order $order Order object.
	 * @return string HTML content.
	 */
	private function build_order_invoice_html( $order ) {
		$order_number = $order->get_order_number();
		$order_date = $order->get_date_created() ? $order->get_date_created()->date_i18n( get_option( 'date_format', 'M j, Y' ) ) : '-';
		$customer_name = trim( $order->get_formatted_billing_full_name() ) ? trim( $order->get_formatted_billing_full_name() ) : __( 'Wholesale Customer', 'woocommerce-wholesale-pricing' );
		$customer_email = $order->get_billing_email() ? $order->get_billing_email() : '-';
		$currency = $order->get_currency();

		$html = '<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<style>
		@charset "UTF-8";
		body {
			font-family: DejaVu Sans, Arial, sans-serif;
			font-size: 12px;
			line-height: 1.6;
			margin: 20px;
			color: #333;
		}
		h1 {
			font-size: 20px;
			margin-bottom: 10px;
			color: #000;
		}
		.invoice-header {
			margin-bottom: 30px;
		}
		.invoice-info {
			margin-bottom: 20px;
		}
		.invoice-info p {
			margin: 5px 0;
		}
		table {
			width: 100%;
			border-collapse: collapse;
			margin: 20px 0;
		}
		table th,
		table td {
			padding: 10px;
			text-align: left;
			border-bottom: 1px solid #ddd;
		}
		table th {
			background-color: #f5f5f5;
			font-weight: bold;
		}
		.text-right {
			text-align: right;
		}
		.total-section {
			margin-top: 20px;
			border-top: 2px solid #000;
			padding-top: 10px;
		}
		.total-row {
			display: flex;
			justify-content: space-between;
			margin: 5px 0;
		}
		.total-row.final {
			font-weight: bold;
			font-size: 14px;
			margin-top: 10px;
		}
	</style>
</head>
<body>
	<div class="invoice-header">
		<h1>' . /* translators: %s: order number */ esc_html( sprintf( __( 'Order Invoice #%s', 'woocommerce-wholesale-pricing' ), $order_number ) ) . '</h1>
	</div>
	
	<div class="invoice-info">
		<p><strong>' . esc_html( __( 'Date:', 'woocommerce-wholesale-pricing' ) ) . '</strong> ' . esc_html( $order_date ) . '</p>
		<p><strong>' . esc_html( __( 'Customer:', 'woocommerce-wholesale-pricing' ) ) . '</strong> ' . esc_html( $customer_name ) . '</p>
		<p><strong>' . esc_html( __( 'Email:', 'woocommerce-wholesale-pricing' ) ) . '</strong> ' . esc_html( $customer_email ) . '</p>
	</div>
	
	<h2>' . esc_html( __( 'Items:', 'woocommerce-wholesale-pricing' ) ) . '</h2>
	<table>
		<thead>
			<tr>
				<th>' . esc_html( __( 'Product', 'woocommerce-wholesale-pricing' ) ) . '</th>
				<th class="text-right">' . esc_html( __( 'Quantity', 'woocommerce-wholesale-pricing' ) ) . '</th>
				<th class="text-right">' . esc_html( __( 'Total', 'woocommerce-wholesale-pricing' ) ) . '</th>
			</tr>
		</thead>
		<tbody>';

		foreach ( $order->get_items( 'line_item' ) as $item ) {
			$product_name = $item->get_name();
			$quantity = (int) $item->get_quantity();
			$total = wp_strip_all_tags( wc_price( $item->get_total(), array( 'currency' => $currency ) ) );

			$html .= '
			<tr>
				<td>' . esc_html( $product_name ) . '</td>
				<td class="text-right">' . esc_html( $quantity ) . '</td>
				<td class="text-right">' . esc_html( $total ) . '</td>
			</tr>';
		}

		$subtotal = wp_strip_all_tags( wc_price( $order->get_subtotal(), array( 'currency' => $currency ) ) );
		$shipping = wp_strip_all_tags( wc_price( $order->get_shipping_total(), array( 'currency' => $currency ) ) );
		$tax = wp_strip_all_tags( wc_price( $order->get_total_tax(), array( 'currency' => $currency ) ) );
		$total = wp_strip_all_tags( wc_price( $order->get_total(), array( 'currency' => $currency ) ) );

		$html .= '
		</tbody>
	</table>
	
	<div class="total-section">
		<div class="total-row">
			<span><strong>' . esc_html( __( 'Subtotal:', 'woocommerce-wholesale-pricing' ) ) . '</strong></span>
			<span>' . esc_html( $subtotal ) . '</span>
		</div>
		<div class="total-row">
			<span><strong>' . esc_html( __( 'Shipping:', 'woocommerce-wholesale-pricing' ) ) . '</strong></span>
			<span>' . esc_html( $shipping ) . '</span>
		</div>
		<div class="total-row">
			<span><strong>' . esc_html( __( 'Tax:', 'woocommerce-wholesale-pricing' ) ) . '</strong></span>
			<span>' . esc_html( $tax ) . '</span>
		</div>
		<div class="total-row final">
			<span><strong>' . esc_html( __( 'Total:', 'woocommerce-wholesale-pricing' ) ) . '</strong></span>
			<span>' . esc_html( $total ) . '</span>
		</div>
	</div>
</body>
</html>';

		return $html;
	}

	/**
	 * Generate PDF from HTML using dompdf.
	 *
	 * @param string $html HTML content.
	 * @return string PDF content.
	 */
	private function quote_generate_pdf( $html ) {
		$options = new Options();
		$options->set( 'isHtml5ParserEnabled', true );
		$options->set( 'isRemoteEnabled', true );
		$options->set( 'defaultFont', 'DejaVu Sans' );
		$options->set( 'isFontSubsettingEnabled', true );
		$options->set( 'isPhpEnabled', false );

		$dompdf = new Dompdf( $options );
		$dompdf->loadHtml( $html, 'UTF-8' );
		$dompdf->setPaper( 'A4', 'portrait' );
		$dompdf->render();

		return $dompdf->output();
	}
}
