<?php

namespace WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits;

use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\DateRangeFilter;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\WholesaleOrders;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\WholesaleUserIDs;

trait WholesaleChart {

	use DateRangeFilter;
	use WholesaleOrders {
		get_wholesale_orders_by_date_range as protected get_chart_orders_by_range;
	}
	use WholesaleUserIDs;

	/**
	 * Get chart data based on filter type and date range.
	 *
	 * @param \WP_REST_Request $request Request object with filter and period parameters.
	 * @param string           $filter_type Chart filter type: 'group-users', 'orders', 'refund', 'customers'.
	 * @return array Array with 'data' (y-axis values) and 'series' (x-axis labels).
	 */
	public function get_chart_data( $request, $filter_type = 'group-users' ) {
		$ranges = $this->get_date_ranges_from_request( $request );
		$date_range = $ranges['current'];
		$group_by = $this->determine_group_by_period( $date_range );

		$chart_data = array();
		switch ( $filter_type ) {
			case 'group-users':
				$chart_data = $this->get_revenue_over_time( $date_range, $group_by );
				break;
			case 'orders':
				$chart_data = $this->get_orders_over_time( $date_range, $group_by );
				break;
			case 'refund':
				$chart_data = $this->get_refunds_over_time( $date_range, $group_by );
				break;
			case 'customers':
				$chart_data = $this->get_customers_over_time( $date_range, $group_by );
				break;
			default:
				$chart_data = $this->get_revenue_over_time( $date_range, $group_by );
				break;
		}

		return $chart_data;
	}

	/**
	 * Get revenue over time grouped by time periods.
	 *
	 * @param string $date_range Date range in YYYY-MM-DD...YYYY-MM-DD format.
	 * @param string $group_by Grouping strategy: 'day', 'week', or 'month'.
	 * @return array Array with 'data' and 'series'.
	 */
	private function get_revenue_over_time( $date_range, $group_by ) {
		$orders = $this->get_chart_orders_by_range( $date_range, array( 'processing', 'completed' ) );
		
		if ( empty( $orders ) ) {
			return $this->get_empty_chart_data( $date_range, $group_by );
		}

		$grouped_data = $this->group_data_by_period(
			$orders,
			$date_range,
			$group_by,
			function ( $order ) {
				return (float) $order->get_total();
			},
			'sum'
		);

		$series = $this->format_chart_series( $date_range, $group_by );
		$data = $this->align_data_with_series( $grouped_data, $series, $group_by, $date_range );

		return array(
			'data'   => $data,
			'series' => $series,
		);
	}

	/**
	 * Get orders count over time grouped by time periods.
	 *
	 * @param string $date_range Date range in YYYY-MM-DD...YYYY-MM-DD format.
	 * @param string $group_by Grouping strategy: 'day', 'week', or 'month'.
	 * @return array Array with 'data' and 'series'.
	 */
	private function get_orders_over_time( $date_range, $group_by ) {
		$orders = $this->get_chart_orders_by_range( $date_range );

		if ( empty( $orders ) ) {
			return $this->get_empty_chart_data( $date_range, $group_by );
		}

		$grouped_data = $this->group_data_by_period(
			$orders,
			$date_range,
			$group_by,
			function ( $order ) {
				return 1;
			},
			'count'
		);

		$series = $this->format_chart_series( $date_range, $group_by );
		$data = $this->align_data_with_series( $grouped_data, $series, $group_by, $date_range );

		return array(
			'data'   => $data,
			'series' => $series,
		);
	}

	/**
	 * Get refunds over time grouped by time periods.
	 *
	 * @param string $date_range Date range in YYYY-MM-DD...YYYY-MM-DD format.
	 * @param string $group_by Grouping strategy: 'day', 'week', or 'month'.
	 * @return array Array with 'data' and 'series'.
	 */
	private function get_refunds_over_time( $date_range, $group_by ) {
		$wholesale_user_ids = $this->get_wholesale_user_ids();

		if ( empty( $wholesale_user_ids ) ) {
			return $this->get_empty_chart_data( $date_range, $group_by );
		}

		$bounds = $this->get_date_bounds_from_range( $date_range );
		if ( ! $bounds ) {
			return $this->get_empty_chart_data( $date_range, $group_by );
		}

		// Get all orders with refunds (status refunded or with refunded amount > 0).
		$query_args = array(
			'customer_id'  => $wholesale_user_ids,
			'status'       => array( 'wc-refunded' ),
			'date_created' => $date_range,
			'limit'        => -1,
			'orderby'      => 'date',
			'order'        => 'ASC',
		);
		$orders = wc_get_orders( $query_args );

		if ( empty( $orders ) ) {
			return $this->get_empty_chart_data( $date_range, $group_by );
		}

		$grouped_data = $this->group_data_by_period(
			$orders,
			$date_range,
			$group_by,
			function ( $order ) {
				return (float) $order->get_total();
			},
			'sum'
		);
		
		$series = $this->format_chart_series( $date_range, $group_by );
		$data = $this->align_data_with_series( $grouped_data, $series, $group_by, $date_range );

		return array(
			'data'   => $data,
			'series' => $series,
		);
	}

	/**
	 * Get customers count over time grouped by time periods.
	 * Counts wholesale users based on their registration date.
	 *
	 * @param string $date_range Date range in YYYY-MM-DD...YYYY-MM-DD format.
	 * @param string $group_by Grouping strategy: 'day', 'week', or 'month'.
	 * @return array Array with 'data' and 'series'.
	 */
	private function get_customers_over_time( $date_range, $group_by ) {
		$wholesale_role_slugs = $this->get_wholesale_role_slugs();

		if ( empty( $wholesale_role_slugs ) ) {
			return $this->get_empty_chart_data( $date_range, $group_by );
		}

		$bounds = $this->get_date_bounds_from_range( $date_range );
		if ( ! $bounds ) {
			return $this->get_empty_chart_data( $date_range, $group_by );
		}

		// Get all wholesale users within the date range
		$args = array(
			'role__in'     => $wholesale_role_slugs,
			'fields'       => 'all',
			'number'       => -1,
			'date_query'   => array(
				array(
					'after'     => $bounds['start'],
					'before'    => $bounds['end'],
					'inclusive' => true,
					'column'    => 'user_registered',
				),
			),
		);

		$user_query = new \WP_User_Query( $args );
		$users = $user_query->get_results();

		if ( empty( $users ) ) {
			return $this->get_empty_chart_data( $date_range, $group_by );
		}

		// Group users by time period based on registration date
		$grouped_data = array();
		$timezone = wp_timezone();

		foreach ( $users as $user ) {
			if ( empty( $user->user_registered ) ) {
				continue;
			}

			try {
				$reg_date = new \DateTime( $user->user_registered, $timezone );
				$period_key = $this->get_period_key_from_datetime( $reg_date, $group_by );

				if ( ! isset( $grouped_data[ $period_key ] ) ) {
					$grouped_data[ $period_key ] = 0;
				}
				$grouped_data[ $period_key ]++;
			} catch ( \Exception $e ) {
				continue;
			}
		}

		$series = $this->format_chart_series( $date_range, $group_by );
		$data = $this->align_data_with_series( $grouped_data, $series, $group_by, $date_range );

		return array(
			'data'   => $data,
			'series' => $series,
		);
	}

	/**
	 * Determine grouping strategy based on date range length.
	 *
	 * @param string $date_range Date range in YYYY-MM-DD...YYYY-MM-DD format.
	 * @return string 'day', 'week', or 'month'.
	 */
	private function determine_group_by_period( $date_range ) {
		if ( empty( $date_range ) || false === strpos( $date_range, '...' ) ) {
			return 'day';
		}

		list( $start, $end ) = explode( '...', $date_range );

		try {
			$timezone = wp_timezone();
			$start_dt = new \DateTime( $start, $timezone );
			$end_dt = new \DateTime( $end, $timezone );
			$days = (int) $start_dt->diff( $end_dt )->format( '%a' );
		} catch ( \Exception $e ) {
			return 'day';
		}

		// Today, Last 7 Days, Last 30 Days: group by day.
		if ( $days <= 30 ) {
			return 'day';
		}

		// Bi Annual (6 months): group by week.
		if ( $days <= 180 ) {
			return 'week';
		}

		// Annual (12 months) and longer: group by month.
		return 'month';
	}

	/**
	 * Format chart series (x-axis labels) based on date range and grouping.
	 *
	 * @param string $date_range Date range in YYYY-MM-DD...YYYY-MM-DD format.
	 * @param string $group_by Grouping strategy: 'day', 'week', or 'month'.
	 * @return array Array of formatted date labels.
	 */
	private function format_chart_series( $date_range, $group_by ) {
		if ( empty( $date_range ) || false === strpos( $date_range, '...' ) ) {
			return array();
		}

		list( $start, $end ) = explode( '...', $date_range );

		try {
			$timezone = wp_timezone();
			$start_dt = new \DateTime( $start, $timezone );
			$end_dt = new \DateTime( $end, $timezone );
		} catch ( \Exception $e ) {
			return array();
		}

		$series = array();
		$current = clone $start_dt;

		switch ( $group_by ) {
			case 'day':
				while ( $current <= $end_dt ) {
					$series[] = $current->format( 'M j' );
					$current->modify( '+1 day' );
				}
				break;

			case 'week':
				$week_num = 1;
				while ( $current <= $end_dt ) {
					$week_start = clone $current;
					$week_end = clone $current;
					$week_end->modify( '+6 days' );
					if ( $week_end > $end_dt ) {
						$week_end = clone $end_dt;
					}
					$series[] = sprintf( '%s %d-%d', $week_start->format( 'M' ), $week_start->format( 'j' ), $week_end->format( 'j' ) );
					$current->modify( '+7 days' );
					$week_num++;
				}
				break;

			case 'month':
				while ( $current <= $end_dt ) {
					$series[] = $current->format( 'M Y' );
					$current->modify( 'first day of next month' );
				}
				break;
		}

		return $series;
	}

	/**
	 * Group data by time period.
	 *
	 * @param array    $data Array of data items (orders).
	 * @param string   $date_range Date range in YYYY-MM-DD...YYYY-MM-DD format.
	 * @param string   $group_by Grouping strategy: 'day', 'week', or 'month'.
	 * @param callable $value_callback Callback to extract value from each item.
	 * @param string   $aggregation Aggregation type: 'sum', 'count', or 'unique_count'.
	 * @return array Associative array with period keys and aggregated values.
	 */
	private function group_data_by_period( $data, $date_range, $group_by, $value_callback, $aggregation = 'sum' ) {
		$grouped = array();

		foreach ( $data as $item ) {
			$date = $item->get_date_created();
			if ( ! $date ) {
				continue;
			}
			
			$period_key = $this->get_period_key( $date, $group_by );
			
			if ( ! isset( $grouped[ $period_key ] ) ) {
				$grouped[ $period_key ] = array();
			}

			$value = call_user_func( $value_callback, $item );
			
			if ( 'unique_count' === $aggregation ) {
				if ( null !== $value && ! in_array( $value, $grouped[ $period_key ], true ) ) {
					$grouped[ $period_key ][] = $value;
				}
			} else {
				$grouped[ $period_key ][] = $value;
			}
		}
		
		// Aggregate the grouped data.
		$result = array();
		foreach ( $grouped as $key => $values ) {
			if ( 'unique_count' === $aggregation ) {
				$result[ $key ] = count( $values );
			} elseif ( 'count' === $aggregation ) {
				$result[ $key ] = count( $values );
			} else {
				$result[ $key ] = array_sum( $values );
			}
		}

		return $result;
	}

	/**
	 * Get period key for grouping (for orders with WC_DateTime).
	 *
	 * @param \WC_DateTime $date Order date.
	 * @param string       $group_by Grouping strategy: 'day', 'week', or 'month'.
	 * @return string Period key.
	 */
	private function get_period_key( $date, $group_by ) {
		$timezone = wp_timezone();
		$dt = new \DateTime( $date->date( 'Y-m-d H:i:s' ), $timezone );

		switch ( $group_by ) {
			case 'day':
				return $dt->format( 'Y-m-d' );

			case 'week':
				// Get the start of the week (Monday).
				$week_start = clone $dt;
				$day_of_week = (int) $dt->format( 'N' );
				if ( $day_of_week > 1 ) {
					$week_start->modify( '-' . ( $day_of_week - 1 ) . ' days' );
				}
				return $week_start->format( 'Y-m-d' );

			case 'month':
				return $dt->format( 'Y-m' );

			default:
				return $dt->format( 'Y-m-d' );
		}
	}

	/**
	 * Get period key from DateTime object (for user registration dates).
	 *
	 * @param \DateTime $date DateTime object.
	 * @param string    $group_by Grouping strategy: 'day', 'week', or 'month'.
	 * @return string Period key.
	 */
	private function get_period_key_from_datetime( $date, $group_by ) {
		$dt = clone $date;

		switch ( $group_by ) {
			case 'day':
				return $dt->format( 'Y-m-d' );

			case 'week':
				// Get the start of the week (Monday).
				$week_start = clone $dt;
				$day_of_week = (int) $dt->format( 'N' );
				if ( $day_of_week > 1 ) {
					$week_start->modify( '-' . ( $day_of_week - 1 ) . ' days' );
				}
				return $week_start->format( 'Y-m-d' );

			case 'month':
				return $dt->format( 'Y-m' );

			default:
				return $dt->format( 'Y-m-d' );
		}
	}

	/**
	 * Align grouped data with series labels.
	 *
	 * @param array  $grouped_data Associative array with period keys and values.
	 * @param array  $series Array of series labels.
	 * @param string $group_by Grouping strategy: 'day', 'week', or 'month'.
	 * @param string $date_range Date range in YYYY-MM-DD...YYYY-MM-DD format.
	 * @return array Array of values aligned with series.
	 */
	private function align_data_with_series( $grouped_data, $series, $group_by, $date_range ) {
		if ( empty( $series ) ) {
			return array();
		}

		if ( empty( $date_range ) || false === strpos( $date_range, '...' ) ) {
			return array_fill( 0, count( $series ), 0 );
		}

		list( $start_str, $end_str ) = explode( '...', $date_range );
		$timezone = wp_timezone();
		
		try {
			$start_dt = new \DateTime( $start_str, $timezone );
			$end_dt = new \DateTime( $end_str, $timezone );
		} catch ( \Exception $e ) {
			return array_fill( 0, count( $series ), 0 );
		}

		$data = array();
		$current = clone $start_dt;

		switch ( $group_by ) {
			case 'day':
				while ( $current <= $end_dt ) {
					$key = $current->format( 'Y-m-d' );
					$data[] = isset( $grouped_data[ $key ] ) ? $grouped_data[ $key ] : 0;
					$current->modify( '+1 day' );
				}
				break;

			case 'week':
				while ( $current <= $end_dt ) {
					$week_start = clone $current;
					$day_of_week = (int) $current->format( 'N' );
					if ( $day_of_week > 1 ) {
						$week_start->modify( '-' . ( $day_of_week - 1 ) . ' days' );
					}
					$key = $week_start->format( 'Y-m-d' );
					$data[] = isset( $grouped_data[ $key ] ) ? $grouped_data[ $key ] : 0;
					$current->modify( '+7 days' );
				}
				break;

			case 'month':
				while ( $current <= $end_dt ) {
					$key = $current->format( 'Y-m' );
					$data[] = isset( $grouped_data[ $key ] ) ? $grouped_data[ $key ] : 0;
					$current->modify( 'first day of next month' );
				}
				break;
		}

		return $data;
	}

	/**
	 * Get empty chart data structure.
	 *
	 * @param string $date_range Date range in YYYY-MM-DD...YYYY-MM-DD format.
	 * @param string $group_by Grouping strategy: 'day', 'week', or 'month'.
	 * @return array Array with empty 'data' and 'series'.
	 */
	private function get_empty_chart_data( $date_range, $group_by ) {
		$series = $this->format_chart_series( $date_range, $group_by );
		return array(
			'data'   => array_fill( 0, count( $series ), 0 ),
			'series' => $series,
		);
	}

	/**
	 * Get date bounds from range string.
	 *
	 * @param string $date_range Date range in YYYY-MM-DD...YYYY-MM-DD format.
	 * @return array|null Array with 'start' and 'end' or null.
	 */
	private function get_date_bounds_from_range( $date_range ) {
		if ( empty( $date_range ) || false === strpos( $date_range, '...' ) ) {
			return null;
		}

		list( $start, $end ) = explode( '...', $date_range );

		try {
			$timezone = wp_timezone();
			$start_dt = new \DateTime( $start . ' 00:00:00', $timezone );
			$end_dt = new \DateTime( $end . ' 23:59:59', $timezone );
		} catch ( \Exception $e ) {
			return null;
		}

		return array(
			'start' => $start_dt->format( 'Y-m-d H:i:s' ),
			'end'   => $end_dt->format( 'Y-m-d H:i:s' ),
		);
	}
}
