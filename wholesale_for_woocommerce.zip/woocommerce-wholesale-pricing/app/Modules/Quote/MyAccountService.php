<?php
namespace WooCommerceWholesalePricing\App\Modules\Quote;

use WooCommerceWholesalePricing\App\Modules\Quote\QuoteProcess;


class MyAccountService {

	public function __construct() {
		add_action('init', array( $this, 'wc_quote_add_endpoints' ));
		add_filter('woocommerce_account_menu_items', array( $this, 'wc_quote_new_menu_items' ));
		add_action('woocommerce_account_my-quotes_endpoint', array( $this, 'wc_quote_endpoint_content' ));
		add_action('wp_loaded', array( $this, 'wc_quote_convert_to_order_customer' ));
		add_action('wp_loaded', array( $this, 'wc_quote_convert_to_checkout_customer' ));
		add_action('wp_loaded', array( $this, 'wc_quote_requote_customer' ));
	}
			
	/**
	 * Add quote menu items in My Account page
	 *
	 * @param  mixed $items
	 * @return void
	 */
	public function wc_quote_new_menu_items( $items ) {
		// Remove the logout menu item.
		$logout = $items['customer-logout'];
		unset($items['customer-logout']);
		// Insert your custom endpoint.
		$items['my-quotes'] = esc_html__('Quotes', 'woocommerce-wholesale-pricing');
		// Insert back the logout item.
		$items['customer-logout'] = $logout;
		return $items;
	}
	
	/**
	 * Show quote endpoint content in My Account page
	 *
	 * @return void
	 */
	public function wc_quote_endpoint_content() {
		global $wp_post_statuses;
		//Quote statuses
		$statuses = array( 'quote_new', 'quote_quoted', 'quote_accepted', 'quote_rejected', 'quote_converted', 'quote_expired' );

		if ( check_quote_status()) {
			// Fetch dynamic statuses
			$custom_posts = get_posts(array(
				'post_type'   => 'wc-quote-status',
				'post_status' => 'any',
				'numberposts' => -1,
				'orderby'     => array(
					'menu_order' => 'DESC', // Sort by priority (menu_order) first
					'modified'   => 'ASC', // In case of ties, sort by last modified date
				),
			));
			$quote_statuses = array();
			foreach ($custom_posts as $post) {
				$quote_meta_status = get_post_meta($post->ID, 'wc_quote_status', true);
				$quote_status = isset($quote_meta_status['quote_status']) ? $quote_meta_status['quote_status'] : $post->post_name;
				$quote_statuses[$quote_status] = array( 'label' => $post->post_title );
			}

			// Merge statuses
			$statuses = array_merge($statuses, array_keys($quote_statuses));
		}
		/**
		 * Filter wc_quote_statuses_array
		 * 
		 * @since 1.0
		**/
		$statuses = apply_filters('wc_quote_statuses_array', $statuses);

		$wcquote_id = get_query_var('my-quotes');

		$quote = get_post($wcquote_id);

		$wc_quote = new QuoteProcess();

		if (! empty($wcquote_id) && is_a($quote, 'WP_Post') ) {

			wwp_view( 'quote.quote-details-my-account', compact( 'quote', 'wcquote_id', 'wp_post_statuses', 'wc_quote' ), true );

		} else {

			$customer_quotes = get_posts(
				array(
				'numberposts' => -1,
				'author'    => get_current_user_id(),
				'post_type'   => 'wc-quote',
				'post_status' => $statuses,
				)
			);

			wwp_view( 'quote.quote-list-table', compact( 'customer_quotes', 'wp_post_statuses' ), true );

		}
	}
	
	/**
	 * Add quote endpoint
	 *
	 * @return void
	 */
	public function wc_quote_add_endpoints() {
		add_rewrite_endpoint( 'my-quotes', EP_ROOT | EP_PAGES );

		// Flush once when the endpoint is first registered — not on every request.
		if ( ! get_option( 'wwp_my_quotes_endpoint_rewrite_flushed', false ) ) {
			flush_rewrite_rules( false );
			update_option( 'wwp_my_quotes_endpoint_rewrite_flushed', true, false );
		}
	}
	
	/**
	 * Quote convert to order from My Account
	 *
	 * @return void
	 */
	public function wc_quote_convert_to_order_customer() {

		if (isset($_REQUEST['_wcquote__wpnonce']) ) {
			check_ajax_referer('_wcquote__wpnonce', '_wcquote__wpnonce');
		}

		if (isset($_POST['wc_quote_convert_to_order_customer']) ) {

			$quote_id = sanitize_text_field(wp_unslash($_POST['wc_quote_convert_to_order_customer']));

			if (empty(intval($quote_id)) ) {
				return;
			}

			$wc_quote = new QuoteProcess();

			$wc_quote->convert_quote_to_order($quote_id);
			

		} else {
			return;
		}
	}
	
	/**
	 * Quote convert to checkout from My Account
	 *
	 * @return void
	 */
	public function wc_quote_convert_to_checkout_customer() {
		if (isset($_REQUEST['_wcquote__wpnonce'])) {
			check_ajax_referer('_wcquote__wpnonce', '_wcquote__wpnonce');
		}


		if (isset($_POST['wc_quote_send_to_checkout'])) {
			$quote_id = sanitize_text_field(wp_unslash($_POST['wc_quote_send_to_checkout']));

			if (empty(intval($quote_id))) {
				return;
			}

			$wc_quote = new QuoteProcess();
			$wc_quote->convert_quote_to_checkout($quote_id);
		} else {
			return;
		}
	}
	
	/**
	 * Requote from My Account
	 *
	 * @return void
	 */
	public function wc_quote_requote_customer() {
		$data = $_REQUEST;
		if (isset($data['_wcquote__wpnonce']) ) {
			check_ajax_referer('_wcquote__wpnonce', '_wcquote__wpnonce');
		}

		$quote_page = isset(get_option('wc_quote_general', false)['quote_page']) ? get_option('wc_quote_general', false)['quote_page'] : '';

		if (isset($data['wc_quote_requote']) ) {

			$quote_id = $data['wc_quote_requote'];
			$quote_contents =  get_post_meta($quote_id, 'quote_contents', true);
			$quotes = WC()->session->get('wc_quotes');
			if (empty($quotes) || !is_array($quotes)) {
				$quotes = array(); 
			}
			$final_quotes =  array_merge($quotes, $quote_contents);
			WC()->session->set('wc_quotes', $final_quotes);
			/**
			 * Action wc_quote_session_changed
			 *
			 * @since 1.0
			 */
			do_action( 'wc_quote_session_changed' );
			wp_safe_redirect(esc_url(get_page_link($quote_page)));
			exit;

		} 
	}
}
