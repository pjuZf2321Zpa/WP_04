<?php
namespace WooCommerceWholesalePricing\App\Modules\Quote\Admin\PDF;

use WooCommerceWholesalePricing\App\Strategies\Init;
use WooCommerceWholesalePricing\App\Modules\Quote\QuoteProcess;

class LightBluePDF extends Init {

	public $defaultImageUrl;
	public $quote_id;

	public function __construct() {

		parent::__construct();
		$this->defaultImageUrl = WWP_PUBLIC_URL . 'images/quote/products/defaultImage.jpg';
		$this->quote_id = isset($_REQUEST['quote_id']) ? sanitize_text_field($_REQUEST['quote_id']) : 0;
		add_action('current_screen', array( $this, 'wc_quote_register_lightblue_block_pattern' ));
	}

	public function register() {

		$blocks = array(
			'wc-quote/lightblue-image' => array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'lightblue_image_block_render_html' ),
				'attributes'      => array(
					'imageUrl' => array( 'type' => 'string', 'default' => $this->defaultImageUrl ),
					'altText' => array( 'type' => 'string', 'default' => 'Default Image' ),
					'caption' => array( 'type' => 'string', 'default' => '' ),
					'alignment' => array( 'type' => 'string', 'default' => 'center' ),
					'size' => array( 'type' => 'string', 'default' => 'medium' ),
				),
			),
			'wc-quote/lightblue-tagline' => array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'lightblue_tagline_block_render_html' ),
				'attributes' => array(
					'content' => array(
						'type' => 'string',
						'default' => 'Your Tagline Here',
					),
					'fontSize' => array(
						'type' => 'string',
						'default' => 'M',
					),
					'customFontSize' => array(
						'type' => 'number',
						'default' => 18,
					),
					'isBold' => array(
						'type' => 'boolean',
						'default' => false,
					),
					'textColor' => array(
						'type' => 'string',
						'default' => '#000000',
					),
					'backgroundColor' => array(
					'type' => 'string',
					'default' => '#ffffff',
					),
					'textTransform' => array(
						'type' => 'string',
						'default' => 'none',
					),
				),
			),
	
			'wc-quote/lightblue-quotation-number' => array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'lightblue_quotationNo_block_render_html' ),
				'attributes' => array(
				'textColor' => array(
				'type' => 'string',
				'default' => '#000',
				),
				'backgroundColor' => array(
				'type' => 'string',
				'default' => '',
				),
				'fontSize' => array(
				'type' => 'number',
				'default' => 16,
				),
				'textAlign' => array(
				'type' => 'string',
				'default' => 'left',
				),
				'quotationNoHeading' => array(
				'type' => 'string',
				'default' => __('Quotation Number :', 'woocommerce-wholesale-pricing'),
				),
				),
			),
	
			'wc-quote/lightblue-quotation-date' => array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'lightblue_quotationDate_block_render_html' ),
				'attributes' => array(
				'textColor' => array(
				'type' => 'string',
				'default' => '#000',
				),
				'backgroundColor' => array(
				'type' => 'string',
				'default' => '',
				),
				'fontSize' => array(
				'type' => 'number',
				'default' => 16,
				),
				'textAlign' => array(
				'type' => 'string',
				'default' => 'left',
				),
				'quotationDate' => array(
				'type' => 'string',
				'default' => __('Quotation Date :', 'woocommerce-wholesale-pricing'),
				),
				),
			),
	
			'wc-quote/lightblue-product-details' => array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'lightblue_product_details_render_html' ),
				'attributes'      => array(
				'productHeader' => array(
				'type' => 'string',
				'default' => 'Product',
				),
				'quantityHeader' => array(
				'type' => 'string',
				'default' => 'Quantity',
				),
				'imageHeader' => array(
				'type' => 'string',
				'default' => 'Image',
				),
				'priceHeader' => array(
				'type' => 'string',
				'default' => 'Price',
				),
				'offeredPriceHeader' => array(
				'type' => 'string',
				'default' => 'Offered Price',
				),
				'subtotalHeader' => array(
				'type' => 'string',
				'default' => 'Subtotal',
				),
				'showQuantityColumn' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'showImageColumn' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'showPriceColumn' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'offeredPriceColumn' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'tableStyle' => array(
				'type' => 'object',
				'default' => array(
				'textTransform' => 'none',
				),
				),
				'backgroundColor' => array(
				'type' => 'string',
				'default' => '#03213F',
				),
				'borderWidth' => array(
				'type' => 'string',
				'default'=> '0px 0px 1px 0px',
				),
				'borderColor' => array(
				'type' => 'string',
				'default' => '#fff',
				),
				'padding' => array(
				'type' => 'string',
				'default' => '8px 15px',
				),
				// items style setting
				'titleColor' => array(
				'type' => 'string',
				'default' => '#fff',
				),
				'titleFontSize' => array(
				'type' => 'number',
				'default' => 16,
				),
				'titleTextTransform' => array(
				'type' => 'string',
				'default' => 'none',
				),
				'itemColor' => array(
				'type' => 'string',
				'default' => '#000',
				),
				'itemFontSize' => array(
				'type' => 'number',
				'default' => 16,
				),
				'itemTextTransform' => array(
				'type' => 'string',
				'default' => 'none',
				),
				),
			),
			'wc-quote/lightblue-total' => array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'lightblue_total_render_html' ),
				'attributes'      => array(
				'subtotal' => array(
				'type' => 'string',
				'default' => __('Subtotal(standard):', 'woocommerce-wholesale-pricing'),
				),
				'subtotalOffered' => array(
				'type' => 'string',
				'default' => __('Subtotal(offered):', 'woocommerce-wholesale-pricing'),
				),
				'shipping' => array(
				'type' => 'string',
				'default' => __('Shipping :', 'woocommerce-wholesale-pricing'),
				),
				'tax' => array(
				'type' => 'string',
				'default' => __('Tax(standard):', 'woocommerce-wholesale-pricing'),
				),
				'taxOffered' => array(
				'type' => 'string',
				'default' => __('Tax(offered):', 'woocommerce-wholesale-pricing'),
				),
				'total' => array(
				'type' => 'string',
				'default' => __('Total(standard):', 'woocommerce-wholesale-pricing'),
				),
				'totalOffered' => array(
				'type' => 'string',
				'default' => __('Total(offered):', 'woocommerce-wholesale-pricing'),
				),
				'showShipping' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'showTax' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'showTaxOffered' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'showsubtotalOffered' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'tableHeadingBgColor' => array(
				'type' => 'string',
				'default' => '#03213F',
				), 'tableItemBgColor' => array(
				'type' => 'string',
				'default' => '#03213F',
				),
				'showTotal' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'showTotalOffered' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'tableStyle' => array(
				'type' => 'object',
				'default' => array(
				'textTransform' => 'none',
				),
				),
				'backgroundColor' => array(
				'type' => 'string',
				'default' => '#03213F',
				),
				'titleColor' => array(
				'type' => 'string',
				'default' => '#fff',
				),
				'titleFontSize' => array(
				'type' => 'number',
				'default' => 16,
				),
				'titleTextTransform' => array(
				'type' => 'string',
				'default' => 'none',
				),
				'itemColor' => array(
				'type' => 'string',
				'default' => '#fff',
				),
				'itemFontSize' => array(
				'type' => 'number',
				'default' => 16,
				),
				'align' => array(
				'type' => 'string',
				'default' => 'left',
				),
				'borderWidth' => array(
				'type' => 'string',
				'default'=> '0px 0px 1px 0px',
				),
				'borderColor' => array(
				'type' => 'string',
				'default' => '#03213F',
				),
				'padding' => array(
				'type' => 'string',
				'default' => '8px 15px',
				),
				),
			),
	
			'wc-quote/lightblue-customer-info' => array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'lightblue_customer_info_render_html' ),
			),
	
			'wc-quote/lightblue-footer-block' => array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'lightblue_footer_render_html' ),
			),
	
			'wc-quote/lightblue-shipping-method' => array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'lightblue_shipping_method_render_html' ),
				'attributes' => array(
				'textColor' => array(
				'type' => 'string',
				'default' => '#000',
				),
				'backgroundColor' => array(
				'type' => 'string',
				'default' => '',
				),
				'fontSize' => array(
				'type' => 'number',
				'default' => 16,
				),
				'textAlign' => array(
				'type' => 'string',
				'default' => 'left',
				),
				'shippingMethod' => array(
				'type' => 'string',
				'default' => __('Shipping Method', 'woocommerce-wholesale-pricing'),
				),
				),
			),
	
			'wc-quote/lightblue-terms-condition-block' => array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'lightblue_terms_condition_render_html' ),
			),

			'wc-quote/lightblue-author-info' => array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'lightblue_author_info_render_html' ),
	
				'attributes' => array(
				'headingBgColor' => array( 'type' => 'string', 'default' => '#fff' ),
				'headingTextColor' => array( 'type' => 'string', 'default' => '#333' ),
				'itemBgColor' => array( 'type' => 'string', 'default' => '#ffffff' ),
				'itemTextColor' => array( 'type' => 'string', 'default' => '#333' ),
				'headingFontSize' => array( 'type' => 'number', 'default' => 14 ),
				'itemFontSize' => array( 'type' => 'number', 'default' => 12 ),
				'columnSpacing' => array( 'type' => 'number', 'default' => 0 ),
				'borderColor' => array( 'type' => 'string', 'default' => '#E9E9E9' ),
				'fields' => array(
				'type' => 'object',
				'default' => array(
				'countryName' => true,
				// 'yourBusiness' => true,
				'address' => true,
				'city' => true,
				'zipCode' => true,
				'state' => true,
				'email' => true,
				'phoneNumber' => true,
				),
				),
				),
			),
	
			'wc-quote/lightblue-signature' => array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'lightblue_signature_render_html' ),
				'signature' => array(
				'signatureData' => array(
				'type' => 'string',
				'default' => '',
				),
				),
			),
		);

		foreach ( $blocks as $block_type => $args ) {
			if ( ! \WP_Block_Type_Registry::get_instance()->is_registered( $block_type ) ) {
				register_block_type( $block_type, $args );
			}
		}
	}

	// Server-side render callback function
	public function lightblue_image_block_render_html( $attributes ) {
		// Extract attributes
		$imageUrl = isset($attributes['imageUrl']) ? esc_url($attributes['imageUrl']) : $this->defaultImageUrl;
		$altText = isset($attributes['altText']) ? esc_attr($attributes['altText']) : 'Default Image';
		$alignment = isset($attributes['alignment']) ? esc_attr($attributes['alignment']) : 'center';
		$size = isset($attributes['size']) ? esc_attr($attributes['size']) : 'medium';

		$sizeStyle = 'small' === $size ? '150px' : ( 'medium' === $size ? '300px' : '600px' );

		ob_start();
		?>
		<div class="wp-block-custom-image-block align<?php echo esc_attr($alignment); ?>" style="text-align: <?php echo esc_attr($alignment); ?>;">
			<?php if ($imageUrl) : ?>
				<img src="<?php echo esc_attr($imageUrl); ?>" alt="<?php echo esc_attr($altText); ?>" style="width: <?php echo esc_attr($sizeStyle); ?>; max-width: 100%;" />
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	public function lightblue_tagline_block_render_html( $attributes ) {
		$content = isset($attributes['content']) ? $attributes['content'] : 'Your Tagline Here';
		$fontSizeMap = array(
		'S' => '14px',
		'M' => '18px',
		'L' => '24px',
		'XL' => '32px',
		'XXXL' => '48px',
		'Custom' => isset($attributes['customFontSize']) ? $attributes['customFontSize'] . 'px' : '18px',
		);

		$fontSize = isset($attributes['fontSize']) ? $fontSizeMap[ $attributes['fontSize'] ] : '18px';
		$textColor = isset($attributes['textColor']) ? $attributes['textColor'] : '#000000';
		$backgroundColor = isset($attributes['backgroundColor']) ? $attributes['backgroundColor'] : '#ffffff';
		$isBold = isset($attributes['isBold']) && $attributes['isBold'] ? 'bold' : 'normal';
		$textTransform = isset($attributes['textTransform']) ? $attributes['textTransform'] : 'none';

		ob_start();
		?>
		<p style="
			color: <?php echo esc_attr($textColor); ?>;
			background-color: <?php echo esc_attr($backgroundColor); ?>;
			font-size: <?php echo esc_attr($fontSize); ?>;
			font-weight: <?php echo esc_attr($isBold); ?>;
			text-transform: <?php echo esc_attr($textTransform); ?>;
			padding: 0px;
			
		">
			<?php echo esc_html($content); ?>
		</p>
		<?php
		return ob_get_clean();
	}

	// Dynamic Done 
	public function lightblue_quotationNo_block_render_html( $attributes ) {

		$styles = '';
		$quotationNoHeading = $attributes['quotationNoHeading'];
		if (!empty($attributes['textColor'])) {
			$styles .= 'color:' . esc_attr($attributes['textColor']) . ';';
		}
		if (!empty($attributes['backgroundColor'])) {
			$styles .= 'background-color:' . esc_attr($attributes['backgroundColor']) . ';';
		}
		if (!empty($attributes['fontSize'])) {
			$styles .= 'font-size:' . esc_attr($attributes['fontSize']) . 'px;';
		}
		if (!empty($attributes['textAlign'])) {
			$styles .= 'text-align:' . esc_attr($attributes['textAlign']) . ';';
		}
		ob_start();
		?>
		<div class="invoice-number" style="<?php echo esc_attr($styles); ?>">
			<p><strong><?php echo esc_html($quotationNoHeading); ?></strong>  &nbsp; <span><?php echo isset($this->quote_id) ?  esc_html($this->quote_id) : esc_html('[quotation_number]'); ?></span></p>
		</div>
		<?php
		return ob_get_clean();
	}

	// Dynamic Done 
	public function lightblue_quotationDate_block_render_html( $attributes ) {

		// Get the creation date for the quote ID
		$date = get_the_date('F j, Y', $this->quote_id);

		$styles = '';
		$quotationDate = $attributes['quotationDate'];
		if (!empty($attributes['textColor'])) {
			$styles .= 'color:' . esc_attr($attributes['textColor']) . ';';
		}
		if (!empty($attributes['backgroundColor'])) {
			$styles .= 'background-color:' . esc_attr($attributes['backgroundColor']) . ';';
		}
		if (!empty($attributes['fontSize'])) {
			$styles .= 'font-size:' . esc_attr($attributes['fontSize']) . 'px;';
		}
		if (!empty($attributes['textAlign'])) {
			$styles .= 'text-align:' . esc_attr($attributes['textAlign']) . ';';
		}
		ob_start();
		?>
		<div class="invoice-number" style="<?php echo esc_attr($styles); ?>">
			<p><strong><?php echo esc_html($quotationDate); ?></strong> &nbsp; <span><?php echo esc_html( ! empty($date) ? $date : '[quotation_date]' ); ?></span></p>
		</div>
		<?php
		return ob_get_clean();
	}

	// Dynamic Done 
	public function lightblue_product_details_render_html( $attributes ) {

		$quote_contents = get_post_meta($this->quote_id, 'quote_contents', true);
		$productHeader = $attributes['productHeader'];
		$quantityHeader = $attributes['quantityHeader'];
		$priceHeader = $attributes['priceHeader'];
		$imageHeader = $attributes['imageHeader'];
		$subtotalHeader = $attributes['subtotalHeader'];
		$offeredPriceHeader = $attributes['offeredPriceHeader'];
		$showQuantityColumn = $attributes['showQuantityColumn'];
		$showPriceColumn = $attributes['showPriceColumn'];
		$showImageColumn = $attributes['showImageColumn'];
		$offeredPriceColumn = $attributes['offeredPriceColumn'];
		$textTransform = $attributes['tableStyle']['textTransform'];
		$backgroundColor = $attributes['backgroundColor'];
		$borderColor = $attributes['borderColor'];
		$borderWidth = $attributes['borderWidth'];
		$padding = $attributes['padding'];
		$titleColor = $attributes['titleColor'];
		$titleFontSize = $attributes['titleFontSize'];
		$titleTextTransform = $attributes['titleTextTransform'];
		$itemColor = $attributes['itemColor'];
		$itemFontSize = $attributes['itemFontSize'];
		$itemTextTransform = $attributes['itemTextTransform'];        
		$columnSpacing = isset($attributes['columnSpacing']) ? $attributes['columnSpacing'] : 0;
		ob_start();
		?>
		<table class="invoice-product-table" style="background-color: white; width: 100%;  border-spacing: <?php echo esc_attr($columnSpacing); ?>px;"   >
		<thead>
		<tr style="background-color: <?php echo esc_attr($backgroundColor); ?>; color: <?php echo esc_attr($titleColor); ?>; font-size: <?php echo esc_attr($titleFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($titleTextTransform); ?>">

		<th style=" background-color: <?php echo esc_attr($backgroundColor); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>" ><?php echo esc_attr($productHeader); ?></th>

		<?php if ($showPriceColumn) : ?>
			<th style=" background-color: <?php echo esc_attr($backgroundColor); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>" ><?php echo esc_attr($priceHeader); ?></th>
		<?php endif; ?>

		<?php if ($showQuantityColumn) : ?>
			<th style=" background-color: <?php echo esc_attr($backgroundColor); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>" ><?php echo esc_attr($quantityHeader); ?></th>
		<?php endif; ?>
		
		<?php if ($offeredPriceColumn) : ?>
			<th style=" background-color: <?php echo esc_attr($backgroundColor); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>" ><?php echo esc_attr($offeredPriceHeader); ?></th>
		<?php endif; ?>

		</tr>
		</thead>
		<tbody style="background-color: white;">

		<?php
		
		if (isset( $quote_contents) && !empty( $quote_contents)) {

			foreach ( $quote_contents as $content) {
	 
				$sku = $content['data']->get_sku() ?  $content['data']->get_sku() : 'N/A'; // Get SKU
				$product_name = $content['data'] ? $content['data']->get_name() : 'N/A';
				$quantity = $content['quantity']; // Quantity
				// $product_price = $content['offered_price'] ? $content['data']->get_regular_price()  : 0; // Offered price
				$product_price = $content['offered_price'] ? $content['data']->get_price()  : 0; // Standard price
				$offered_price = $content['data'] ?  $content['offered_price'] : 0;
				$image_id = $content['data']->get_image_id(); // Image ID
				$image_url = wp_get_attachment_url($image_id); // Image URL
				if ( empty( $image_url ) ) {
					$image_url = wc_placeholder_img_src('woocommerce_thumbnail');
				}


				?>

				<tr style="background-color: white; color: <?php echo esc_attr($itemColor); ?>; font-size: <?php echo esc_attr($itemFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($itemTextTransform); ?>">
				<?php //if ( $showImageColumn) : ?>
				<!-- <td style="padding: <?php echo esc_attr($padding); ?>; border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>; -webkit-padding: <?php echo esc_attr($padding); ?>; -webkit-border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>"><img src=<?php echo esc_url($image_url); ?> alt="Product Thumbnail" style="margin-right: 8px; width: 70px; height: 70px;"></td> -->
				<?php //endif; ?>

				<td style="padding: <?php echo esc_attr($padding); ?>; border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>; -webkit-padding: <?php echo esc_attr($padding); ?>; -webkit-border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>">
					<?php //echo esc_html($product_name); ?>
					<div style= "display:flex;">
							<?php if ($showImageColumn) : ?>
								<div style="padding: <?php echo esc_attr($padding); ?>; border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>; -webkit-padding: <?php echo esc_attr($padding); ?>; -webkit-border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>">
									<img src=<?php echo esc_url($image_url); ?> alt="<?php echo esc_attr( $product_name ); ?>" style="margin-right: 8px; width: 70px; height: 70px;">    
								</div>
							<?php endif; ?>
						<div>
							<div><?php echo wp_kses_post($product_name); ?></div>
							<div><strong>SKU:</strong> <?php echo wp_kses_post($sku); ?></div>
						</div>
					</div>
				</td>
				<?php if ($showPriceColumn) : ?>
					<td style="padding: <?php echo esc_attr($padding); ?>; border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>; -webkit-padding: <?php echo esc_attr($padding); ?>; -webkit-border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>"><?php echo wp_kses_post(wc_price($product_price)); ?></td>
				<?php
				endif;
				?>
				<?php if ($showQuantityColumn) : ?>
					<td style="padding: <?php echo esc_attr($padding); ?>; border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>; -webkit-padding: <?php echo esc_attr($padding); ?>; -webkit-border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>"><?php echo esc_html($quantity); ?></td>
				<?php endif; ?>
				<?php if ($offeredPriceColumn) : ?>
					<td style="padding: <?php echo esc_attr($padding); ?>; border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>; -webkit-padding: <?php echo esc_attr($padding); ?>; -webkit-border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>"><?php echo wp_kses_post(wc_price($offered_price)); ?></td>
				<?php
				endif;
				?>
						</tr>

				<?php 
			}
		} else {
			echo '<tr style="background-color: white; color:' . esc_attr($itemColor) . '; font-size: ' . esc_attr($itemFontSize) . 'px; text-transform: ' . esc_attr($itemTextTransform) . ';">';
			echo '<td colspan="5" style="padding: 8px 15px; border-bottom: 1px solid ' . esc_attr($borderColor) . ';">No Products Found</td>';
			echo '</tr>';
		}
		?>

			</tbody>
		</table>
		<?php
		return ob_get_clean();
	}

	// Dynamic Done 
	public function lightblue_total_render_html( $attributes ) {

		$quote_contents = get_post_meta($this->quote_id, 'quote_contents', true);
		$getCalTotal = new QuoteProcess();
		$calculatedTotal = $getCalTotal->get_calculated_totals($quote_contents, $this->quote_id);

		$subtotal = $attributes['subtotal'];
		$subtotalOffered = $attributes['subtotalOffered'];
		$tax = $attributes['tax'];
		$taxOffered = $attributes['taxOffered'];
		$shipping = $attributes['shipping'];
		$showShipping = $attributes['showShipping'];
		$total = $attributes['total'];
		$totalOffered = $attributes['totalOffered'];

		// heading & item bg color 
		$tableHeadingBgColor = $attributes['tableHeadingBgColor'];
		$tableItemBgColor = $attributes['tableItemBgColor'];

		$backgroundColor = $attributes['backgroundColor'];
		$titleColor = $attributes['titleColor'];
		$titleFontSize = $attributes['titleFontSize'];
		$titleTextTransform = $attributes['titleTextTransform'];
		$itemColor = $attributes['itemColor'];
		$itemFontSize = $attributes['itemFontSize'];
		$align = $attributes['align'];
		$borderColor = $attributes['borderColor'];
		$borderWidth = $attributes['borderWidth'];
		$padding = $attributes['padding'];
		ob_start();
		 
		if (! empty( $quote_contents)) {

			$sub_total_amount = $calculatedTotal['_subtotal'];
			$sub_total_offered_amount = $calculatedTotal['_offered_total'];
			$tax_total = $calculatedTotal['_tax_total'];
			$tax_offered = $calculatedTotal['_tax_total_offered'];
			$shipping_total = $calculatedTotal['_shipping'];
			$total_standard = $calculatedTotal['_total'];
			$total_offered_amount = $calculatedTotal['cal_offered_total'];      
		} else {
			$sub_total_amount = 0;
			$sub_total_offered_amount = 0;
			$tax_total = 0;
			$tax_offered = 0;
			$shipping_total = 0;
			$total_standard = 0;
			$total_offered_amount = 0;
		}
		?>
		 
		<table class="invoice-product-table total-table-invoice" style="border-collapse: collapse; width: 100%; margin-bottom: 20px; background-color: <?php //echo esc_attr($backgroundColor); ?>">
			<tr>
				<th style="vertical-align: middle; background-color: <?php echo esc_attr($tableHeadingBgColor); ?>; color: <?php echo esc_attr($titleColor); ?>; font-size: <?php echo esc_attr($titleFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($titleTextTransform); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo esc_html($subtotal); ?></th>
				<td style="background-color: <?php echo esc_attr($tableItemBgColor); ?>; color: <?php echo esc_attr($itemColor); ?>; font-size: <?php echo esc_attr($itemFontSize . 'px'); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo wp_kses_post(wc_price($sub_total_amount)); ?></td>
			</tr>

		<?php if ($attributes['showsubtotalOffered']) : ?>
			<tr>
				<th style="vertical-align: middle; background-color: <?php echo esc_attr($tableHeadingBgColor); ?>; color: <?php echo esc_attr($titleColor); ?>; font-size: <?php echo esc_attr($titleFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($titleTextTransform); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo esc_html($subtotalOffered); ?></th>
				<td style="background-color: <?php echo esc_attr($tableItemBgColor); ?>; color: <?php echo esc_attr($itemColor); ?>; font-size: <?php echo esc_attr($itemFontSize . 'px'); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo wp_kses_post(wc_price($sub_total_offered_amount)); ?></td>
			</tr>
		<?php endif; ?>

		<?php if ($attributes['showTax']) : ?>
			<tr>
				<th style="vertical-align: middle; background-color: <?php echo esc_attr($tableHeadingBgColor); ?>; color: <?php echo esc_attr($titleColor); ?>; font-size: <?php echo esc_attr($titleFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($titleTextTransform); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo esc_html(isset($calculatedTotal['_tax_label']) ? $calculatedTotal['_tax_label'] : $tax); ?></th>
				<td style="background-color: <?php echo esc_attr($tableItemBgColor); ?>; color: <?php echo esc_attr($itemColor); ?>; font-size: <?php echo esc_attr($itemFontSize . 'px'); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo wp_kses_post(wc_price($tax_total)); ?></td>
			</tr>
		<?php endif; ?>

		<?php if ($attributes['showTaxOffered']) : ?>
			<tr>
				<th style="vertical-align: middle; background-color: <?php echo esc_attr($tableHeadingBgColor); ?>; color: <?php echo esc_attr($titleColor); ?>; font-size: <?php echo esc_attr($titleFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($titleTextTransform); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo esc_html($taxOffered); ?></th>
				<td style="background-color: <?php echo esc_attr($tableItemBgColor); ?>; color: <?php echo esc_attr($itemColor); ?>; font-size: <?php echo esc_attr($itemFontSize . 'px'); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo wp_kses_post(wc_price($tax_offered)); ?></td>
			</tr>
		<?php endif; ?>

		<?php if ($attributes['showShipping']) : ?>
			<tr>
				<th style="vertical-align: middle; background-color: <?php echo esc_attr($tableHeadingBgColor); ?>; color: <?php echo esc_attr($titleColor); ?>; font-size: <?php echo esc_attr($titleFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($titleTextTransform); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo esc_html($shipping); ?></th>
				<td style="background-color: <?php echo esc_attr($tableItemBgColor); ?>; color: <?php echo esc_attr($itemColor); ?>; font-size: <?php echo esc_attr($itemFontSize . 'px'); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo wp_kses_post(wc_price($shipping_total)); ?></td>
			</tr>
		<?php endif; ?>

		<?php if ($attributes['showTotal']) : ?>
			<tr>
				<th style="vertical-align: middle; background-color: <?php echo esc_attr($tableHeadingBgColor); ?>; color: <?php echo esc_attr($titleColor); ?>; font-size: <?php echo esc_attr($titleFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($titleTextTransform); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo esc_html($total); ?></th>
				<td style="background-color: <?php echo esc_attr($tableItemBgColor); ?>; color: <?php echo esc_attr($itemColor); ?>; font-size: <?php echo esc_attr($itemFontSize . 'px'); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo wp_kses_post(wc_price($total_standard)); ?></td>
			</tr>
		<?php endif; ?>

		<?php if ($attributes['showTotalOffered']) : ?>
			<tr>
				<th style="vertical-align: middle; background-color: <?php echo esc_attr($tableHeadingBgColor); ?>; color: <?php echo esc_attr($titleColor); ?>; font-size: <?php echo esc_attr($titleFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($titleTextTransform); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo esc_html($totalOffered); ?></th>
				<td style="background-color: <?php echo esc_attr($tableItemBgColor); ?>; color: <?php echo esc_attr($itemColor); ?>; font-size: <?php echo esc_attr($itemFontSize . 'px'); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo wp_kses_post(wc_price($total_offered_amount)); ?></td>
			</tr>
		<?php endif; ?>            
		</table>
		<?php
		return ob_get_clean();
	}

	// Dynamic Done 
	public function lightblue_customer_info_render_html( $attributes ) {

		$quote_fields = ( get_post_meta($this->quote_id, 'quote_fields', true) ); 
		$form_config = json_decode(str_replace('"false"', 'false', wp_unslash(get_option('wc_quote_form_builder'))), true);

		if (isset($quote_fields)) {
		  $date = get_the_date('F j, Y', $this->quote_id);
		} else {
			// echo "No quote contents founds.";
			$date = '[quote_date]';
		} 

		$topHeadingText = esc_html($attributes['topHeadingText'] ? $attributes['topHeadingText'] : 'Customer Information');
		$headingFontSize = intval($attributes['headingFontSize'] ? $attributes['headingFontSize'] : 14);
		$itemFontSize = intval($attributes['itemFontSize'] ? $attributes['itemFontSize'] : 12);
		$columnSpacing = intval($attributes['columnSpacing'] ? $attributes['columnSpacing'] : 0);
	 
		// Updated ================

		$rows = array();
		// Check for visibility of each field before adding it to the rows
		if (!array_key_exists('quoteNumberVisible', $attributes)) {
			$rows[] = array( 'label' => esc_html($attributes['quoteNumber'] ? $attributes['quoteNumber'] : 'Quote Number'), 'value' =>  $this->quote_id || 0 !== $this->quote_id ? $this->quote_id : '[quote_number]' );
		}

		if (!array_key_exists('quoteDateVisible', $attributes)) {
			$rows[] = array( 'label' => esc_html($attributes['quoteDate'] ? $attributes['quoteDate'] : 'Quote Date'), 'value' =>  $date ? $date : '[quote_date]' );
		}

		// Add dynamic fields
		if (!empty($form_config['components']) && is_array($form_config['components'])) {
			foreach ($form_config['components'] as $component) {
				$key = $component['key'] ? $component['key'] : '';
				$label = $component['label'] ? $component['label'] : ucfirst($key);


				$value = !empty($quote_fields[$key]) ? sanitize_text_field($quote_fields[$key]) : '';

				if ( empty($value) ) {
					continue;
				}

				$rows[] = array(
					'label' => esc_html($label),
					'value' => $value,
				);
			}
		}

		ob_start();
		?>

		<div class="customer-info-block-preview">
			<table style="width: 100%; border-spacing: <?php echo esc_attr($columnSpacing); ?>px;">
				<thead>
					<tr>
						<th colspan="2" style="
							background-color: <?php echo esc_attr($attributes['topHeadingBgColor'] ? $attributes['topHeadingBgColor'] : '#03213F'); ?>;
							color: <?php echo esc_attr($attributes['topHeadingFontColor'] ? $attributes['topHeadingFontColor'] : '#fff'); ?>;
							font-size: <?php echo esc_attr($attributes['topHeadingFontSize'] ? $attributes['topHeadingFontSize'] : '16'); ?>px;
							border: 1px solid <?php echo esc_attr($attributes['borderColor'] ? $attributes['borderColor'] : '#E9E9E9'); ?>;
						">
							<?php echo esc_html($topHeadingText); ?>
						</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($rows as $row) : ?>
						<tr>
							<th style="
								background-color: <?php echo esc_attr($attributes['headingBgColor'] ? $attributes['headingBgColor'] : '#ffffff'); ?>;
								color: <?php echo esc_attr($attributes['headingTextColor'] ? $attributes['headingTextColor'] : '#333'); ?>;
								font-size: <?php echo esc_attr($headingFontSize); ?>px;
								border: 1px solid <?php echo esc_attr($attributes['borderColor'] ? $attributes['borderColor'] : '#E9E9E9'); ?>;
							">
								<?php echo esc_html($row['label']); ?>
							</th>
							<td style="
								background-color: <?php echo esc_attr($attributes['itemBgColor'] ? $attributes['itemBgColor'] : '#ffffff'); ?>;
								color: <?php echo esc_attr($attributes['itemTextColor'] ? $attributes['itemTextColor'] : '#333'); ?>;
								font-size: <?php echo esc_attr($itemFontSize); ?>px;
								border: 1px solid <?php echo esc_attr($attributes['borderColor'] ? $attributes['borderColor'] : '#E9E9E9'); ?>;
							">
								<!-- Old One   -->
								<!-- add php tag echo esc_html($row['value']);  -->
								<p style="max-width: 300px; "><?php echo esc_html($row['value']); ?></p>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<?php
		return ob_get_clean();
	}

	public function lightblue_footer_render_html( $attributes ) {
		// Extract block attributes
		$footerText = isset($attributes['footerText']) ? $attributes['footerText'] : 'Footer content goes here';
		$fontSize = isset($attributes['fontSize']) ? $attributes['fontSize'] : 16;
		$fontColor = isset($attributes['fontColor']) ? $attributes['fontColor'] : '#ffffff';
		$backgroundColor = isset($attributes['backgroundColor']) ? $attributes['backgroundColor'] : '#03213F';
		$textAlignment = isset($attributes['textAlignment']) ? $attributes['textAlignment'] : 'center';
		$isBold = isset($attributes['isBold']) ? $attributes['isBold'] : false;
		$padding = isset($attributes['padding']) ? $attributes['padding'] : 10;
		$borderRadius = isset($attributes['borderRadius']) ? $attributes['borderRadius'] : 5;

		// Output the block's HTML with dynamic styles
		ob_start();
		?>
		<div style="
			font-size: <?php echo esc_attr($fontSize); ?>px;
			color: <?php echo esc_attr($fontColor); ?>;
			background-color: <?php echo esc_attr($backgroundColor); ?>;
			padding: <?php echo esc_attr($padding); ?>px;
			text-align: <?php echo esc_attr($textAlignment); ?>;
			font-weight: <?php echo $isBold ? 'bold' : 'normal'; ?>;
			border-radius: <?php echo esc_attr($borderRadius); ?>px;
		">
				<?php echo esc_html($footerText); ?>
		</div>
		<?php
		return ob_get_clean();
	}

	public function lightblue_terms_condition_render_html( $attributes ) {

		// Extract block attributes
		$termsConditionText = isset($attributes['termsConditionText']) ? $attributes['termsConditionText'] : 'Terms Conditions';
		$fontSize = isset($attributes['fontSize']) ? $attributes['fontSize'] : 16;
		$fontColor = isset($attributes['fontColor']) ? $attributes['fontColor'] : '#ffffff';
		$backgroundColor = isset($attributes['backgroundColor']) ? $attributes['backgroundColor'] : '#03213F';
		$textAlignment = isset($attributes['textAlignment']) ? $attributes['textAlignment'] : 'center';
		$isBold = isset($attributes['isBold']) ? $attributes['isBold'] : false;
		$padding = isset($attributes['padding']) ? $attributes['padding'] : 10;
		$borderRadius = isset($attributes['borderRadius']) ? $attributes['borderRadius'] : 5;

		// Output the block's HTML with dynamic styles
		ob_start();
		?>
		<div style="
			font-size: <?php echo esc_attr($fontSize); ?>px;
			color: <?php echo esc_attr($fontColor); ?>;
			background-color: <?php echo esc_attr($backgroundColor); ?>;
			padding: <?php echo esc_attr($padding); ?>px;
			text-align: <?php echo esc_attr($textAlignment); ?>;
			font-weight: <?php echo $isBold ? 'bold' : 'normal'; ?>;
			border-radius: <?php echo esc_attr($borderRadius); ?>px;
			margin-top:10px;
		">

			<style>
				li.custom-bullet-list {
					list-style: none!important;
				}
				li.custom-bullet-list:before {
					content: '\2022';
					font-size: 24px;
					display: inline-block;
					line-height: 1;
					margin-right: 10px;
				}
			</style>
		
			<?php echo wp_kses_post($termsConditionText); // nosemgrep ?>
		</div>
		<?php
		return ob_get_clean();
	}

	public function lightblue_shipping_method_render_html( $attributes ) {

		$quote_contents = get_post_meta($this->quote_id, 'quote_contents', true);
		$getCalTotal = new QuoteProcess();
		$calculatedTotal = $getCalTotal->get_calculated_totals( $quote_contents, $this->quote_id);

		if (isset( $quote_contents)) {
			// Retrieve and format the shipping method in one step if not formatted. 
			$shipping_method = isset($calculatedTotal['shipping_method'])
			? ucwords(str_replace('_', ' ', explode(':', $calculatedTotal['shipping_method'])[0]))
			: '';
		}

		$styles = '';
		$shippingMethod = $attributes['shippingMethod'];
		if (!empty($attributes['textColor'])) {
			$styles .= 'color:' . esc_attr($attributes['textColor']) . ';';
		}
		if (!empty($attributes['backgroundColor'])) {
			$styles .= 'background-color:' . esc_attr($attributes['backgroundColor']) . ';';
		}
		if (!empty($attributes['fontSize'])) {
			$styles .= 'font-size:' . esc_attr($attributes['fontSize']) . 'px;';
		}
		if (!empty($attributes['textAlign'])) {
			$styles .= 'text-align:' . esc_attr($attributes['textAlign']) . ';';
		}
		ob_start();
		?>
		<div class="invoice-number" style="<?php echo esc_attr($styles); ?>">
			<p><strong><?php echo esc_html($shippingMethod); ?></strong> <span> &nbsp; <?php echo $shipping_method ? esc_html($shipping_method) : esc_html('[shipping_method]'); ?></span></p>

		</div>
		<?php
		return ob_get_clean();
	}

	public function lightblue_author_info_render_html( $attributes ) {
	
		$topHeadingText = esc_html($attributes['topHeadingText'] ? $attributes['topHeadingText'] : 'Author Information');
		$headingFontSize = intval($attributes['headingFontSize'] ? $attributes['headingFontSize'] : 14);
		$itemFontSize = intval($attributes['itemFontSize'] ? $attributes['itemFontSize'] : 12);
		$columnSpacing = intval($attributes['columnSpacing'] ? $attributes['columnSpacing'] : 0);

		$fields = array(
			'countryName'  => array( 
				'label' => esc_html($attributes['fieldLabels']['countryName'] ? $attributes['fieldLabels']['countryName'] : __('Country Name', 'woocommerce-wholesale-pricing')), 
				'value' => '[country_name]', 
			),
			'address'      => array( 
				'label' => esc_html($attributes['fieldLabels']['address'] ? $attributes['fieldLabels']['address'] : __('Address', 'woocommerce-wholesale-pricing')), 
				'value' => '[address]', 
			),
			'city'         => array( 
				'label' => esc_html($attributes['fieldLabels']['city'] ? $attributes['fieldLabels']['city'] : __('City', 'woocommerce-wholesale-pricing')), 
				'value' => '[city]', 
			),
			'zipCode'      => array( 
				'label' => esc_html($attributes['fieldLabels']['zipCode'] ? $attributes['fieldLabels']['zipCode'] : __('ZIP Code', 'woocommerce-wholesale-pricing')), 
				'value' => '[zip_code]', 
			),
			'state'        => array( 
				'label' => esc_html($attributes['fieldLabels']['state'] ? $attributes['fieldLabels']['state'] : __('State', 'woocommerce-wholesale-pricing')), 
				'value' => '[state]', 
			),
			'email'        => array( 
				'label' => esc_html($attributes['fieldLabels']['email'] ? $attributes['fieldLabels']['email'] : __('Email', 'woocommerce-wholesale-pricing')), 
				'value' => '[email]', 
			),
			'phoneNumber'  => array( 
				'label' => esc_html($attributes['fieldLabels']['phoneNumber'] ? $attributes['fieldLabels']['phoneNumber'] : __('Phone Number', 'woocommerce-wholesale-pricing')), 
				'value' => '[phone_number]', 
			),
		);

		ob_start();
		?>
		<div class="author-info-block-preview">
			<table style="width: 100%; border-spacing: <?php echo esc_attr($columnSpacing); ?>px;">
				<thead>
					<tr>
						<th colspan="2" style="
							background-color: <?php echo esc_attr($attributes['topHeadingBgColor'] ? $attributes['topHeadingBgColor'] : '#03213F'); ?>;
							color: <?php echo esc_attr($attributes['topHeadingFontColor'] ? $attributes['topHeadingFontColor'] : '#fff'); ?>;
							font-size: <?php echo esc_attr($attributes['topHeadingFontSize'] ? $attributes['topHeadingFontSize'] : '16'); ?>px;
							border: 1px solid <?php echo esc_attr($attributes['borderColor'] ? $attributes['borderColor'] : '#E9E9E9'); ?>;
						">
							<?php echo esc_html($topHeadingText); ?>
						</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($fields as $key => $field) : ?>
						<?php if (!empty($attributes['fields'][$key]) && 1 == $attributes['fields'][$key]) : // Check if the field is set to 1 ?>
							<tr>
								<th style="
									background-color: <?php echo esc_attr($attributes['headingBgColor'] ? $attributes['headingBgColor'] : '#ffffff'); ?>;
									color: <?php echo esc_attr($attributes['headingTextColor'] ? $attributes['headingTextColor'] : '#333'); ?>;
									font-size: <?php echo esc_attr($headingFontSize); ?>px;
									border: 1px solid <?php echo esc_attr($attributes['borderColor'] ? $attributes['borderColor'] : '#E9E9E9'); ?>;
								">
									<?php echo esc_html($field['label']); ?>
								</th>
								<td style="
									background-color: <?php echo esc_attr($attributes['itemBgColor'] ? $attributes['itemBgColor'] : '#ffffff'); ?>;
									color: <?php echo esc_attr($attributes['itemTextColor'] ? $attributes['itemTextColor'] : '#333'); ?>;
									font-size: <?php echo esc_attr($itemFontSize); ?>px;
									border: 1px solid <?php echo esc_attr($attributes['borderColor'] ? $attributes['borderColor'] : '#E9E9E9'); ?>;
								">
									<!-- Old One -->
									<!-- echo esc_html($field['value']); -->
									<p style="max-width: 300px; "><?php echo esc_html($field['value']); ?></p>
								</td>
							</tr>
						<?php endif; ?>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
		return ob_get_clean();
	}

	public function lightblue_signature_render_html( $attributes ) {
		ob_start();
		?>
		<div class="lightblue-signature">
			<?php if (!empty($attributes['signature'])) : ?>
				<img 
					src="<?php echo esc_attr($attributes['signature']); ?>" 
					alt="Signature" 
					style="width:100%; max-width: 400px; border: 0px solid #ccc; padding: 10px;"
				/>
			<?php else : ?>
				<p style="font-style: italic; color: #666;"><?php echo esc_html__('No signature available.', 'woocommerce-wholesale-pricing'); ?></p>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	// TEMPLATE
	public function wc_quote_register_lightblue_block_pattern() {
		$screen = get_current_screen();
		$screen_id = $screen ? $screen->id : '';

		if (in_array($screen_id, array( 'custom_pdf' ))) {
		 
			register_block_pattern_category(
				'Wc quote Custom PDF',
				array( 'label' => __('B2B Request a Quote', 'woocommerce-wholesale-pricing') )
			);

			// Register Light blue block pattern
			register_block_pattern(
				'wc-quote-custom-pdf/lightBlue',
				array(
				'categories'    => array( 'Wc quote Custom PDF' ),
				'title'         => 'Light Blue',
				'description'   => 'Create PDF template for light blue',
				'content'       => '
                
				<!-- wp:columns {"verticalAlignment":null} -->
				<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center"} -->
				<div class="wp-block-column is-vertically-aligned-center"><!-- wp:wc-quote/lightblue-image {"imageUrl":"http://local-projects.local/wp-content/uploads/2024/11/images-1.jpg","altText":"Selected Image"} /--></div>
				<!-- /wp:column -->

				<!-- wp:column {"verticalAlignment":"center"} -->
				<div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"style":{"color":{"text":"#03213f"},"elements":{"link":{"color":{"text":"#03213f"}}}}} -->
				<h2 class="wp-block-heading has-text-color has-link-color" style="color:#03213f"><strong>Dev</strong></h2>
				<!-- /wp:heading -->

				<!-- wp:wc-quote/lightblue-tagline /--></div>
				<!-- /wp:column -->

				<!-- wp:column {"verticalAlignment":"center"} -->
				<div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"style":{"color":{"text":"#03213f"},"elements":{"link":{"color":{"text":"#03213f"}}}}} -->
				<h2 class="wp-block-heading has-text-color has-link-color" style="color:#03213f"><strong>QUOTATION</strong></h2>
				<!-- /wp:heading -->

				<!-- wp:wc-quote/lightblue-quotation-number {"fontSize":12} /-->

				<!-- wp:wc-quote/lightblue-quotation-date {"fontSize":12} /-->

				<!-- wp:wc-quote/lightblue-shipping-method {"fontSize":12} /--></div>
				<!-- /wp:column --></div>
				<!-- /wp:columns -->

				<!-- wp:wc-quote/lightblue-product-details /-->

				<!-- wp:columns -->
				<div class="wp-block-columns"><!-- wp:column -->
				<div class="wp-block-column"><!-- wp:wc-quote/lightblue-customer-info /--></div>
				<!-- /wp:column -->

				<!-- wp:column -->
				<div class="wp-block-column"><!-- wp:wc-quote/lightblue-author-info {"fields":{"countryName":true,"address":true,"city":true,"zipCode":true,"state":true,"email":true,"phoneNumber":false}} /--></div>
				<!-- /wp:column --></div>
				<!-- /wp:columns -->

				<!-- wp:columns -->
				<div class="wp-block-columns"><!-- wp:column -->
				<div class="wp-block-column"><!-- wp:wc-quote/lightblue-terms-condition-block /-->

				<!-- wp:wc-quote/lightblue-signature {"signature":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA4QAAAEsCAMAAACsQI2jAAAAS1BMVEX///8AAADf39+/v79/f39fX18/Pz8fHx+fn59TU1MXFxcbGxuLi4sPDw+np6cnJydvb283NzcHBwdHR0dPT08LCwvDw8NjY2MTExO4uwOWAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAOI0lEQVR4nO3d6YKjNhZA4bL2pGcmmX3e/0nHkgCzSCBssRjO9yPpdLkMdnSRdLX9/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkpw4+g6Ae1MPe/QtALcmH4+HPPomgDszzyBUR98EcGO+Inzoo+8CuDFfERqao8BhfEVIXgY4kHoGoTv6JoA7s88gPPoegDuTZGWAY2kGCYFjWdIywKFojeJkhHf0TexKkxvFOQiptPFpwsio25RL/6Hv9djBCQmnX+HXseoWRVP4R87RN4F7k6oXgNZo9aRjUNo75Awdc7dxKNlVgdYo2a/5hLP36CsxQIEDia4ONMl15eoWxZPpMjiMNE0VqLOB5m7QW6JLiKM4uxSBnr5+Veju0ejG2bTtULNU+sT1h7E1AxTYn9DlIxD28k015qxhd20IljXBzNVLqFics3a7GUTYmFBrQvAiQSicTnd9n+Hlu4Raei5SkdbaGGvb9DEDiahlZQj6IPz+5qiMEw+M0SGyQmzZxAyhvIX0FVCsyYiueapfIX2/Kt4ePkBNCNhnfejcs4qkMYpaRBwXNGvKlLxC+t6No/AVZ1qHHLEPNUnfD1trWqLr2lXmIul70Rn/4HGFxwy+gljfEv0JgXvxYUKfl7nEYwanp9a3RH9CCbUXL6H+izn6HnAHTW9wbZr9DvO39RUyTzg/8dbawDC/++ox6DOnF29w4wziMNnapqh543e+EHkZ7MCFpujax730c0s3uZ9TkeRlsL1w6NcbT3t5+Zao58jLYHPvxuBNaJZQYGsxJ0MM5hjyMtiaIQZnWdZHYGPqneHBG2HSGrYmwtjE0XdxYvIOQ6E4lG+MXn3e2UdIjmJjoSLkQT9DkRzFtjSN0QXMHMW2QkVIY3QOIxTYlntjttrNMEKBbXH25SK+IWyLg06WCBJX2BQHnSzaaA0F/XA0JF3CJVsME/oNzm9xtioKSGasLVH12wpx9SZJaQQc+bVIV28ryLAfgeLph4AgXGSqtxXiljWaLx5B/ebo5TaotrUfUy5Og7M0RxEsn/m19g3t1R7w1UcodIhqRVYajdpDFJfbCkJUz6BY/w1J8jJo6coJeHO1wX9Z/QP5c43dujYuhz5dmqvc2rrcbGdXvWp/BqFaE4P/0bZge1dHH/N7Ve4Uuqt1dVz1YUK9bqfz//qXLz3bHLPMv5mq3Oe52jyQ+mP1/1r1jT/D73fnnwUz9bHyIUg9+L0EBy3MKhyrLx6Zkfbxb9/6KHxYPf/v/Ob/nQ9CQQh+v9pV4cXoZDtP2WGfThX2rP2kUeP/4Y/+LXj5/5oYzI5oCP+/jxD8eoaFFDOe344TepQWGbdRdeGDrO26xTBc3F5L/mqzQiLd5QvvQwhegLjLJG6htF79QZ9B+M9xi1SOJvvpsuzWYO1EwZYG6rUHl04FOSF4IbWHKYoIZezDlrTJKvnLXx/v7LBqE7nMUTe6Fyxz3PDXlqbDNYfVtVeYvFYSgpei9995VD8aK5fVvXubf/s9nP2mzMoslH9A/Tn6u9EeiGFh0uJYohhtJLI0CcBf5M8mttW00gyns2pC8EL27haGp7xyQjqffDSmJFconQqj1r/eud4fPlD+9GXWrMlCuVAbjf/WDuq9ZzQVLLTwn3jQsUwnfLqXh4FBE2NbTV5KCF7RvlEoX0VINRXi/IQQ4UL8vbkW1oUTb/7e/J4prnp9CP6aVnLDmBD2oZM9tgE96XfPfZC28xgqQDEJcULwmvYcLRS/dQ2zeCib8RGWfQZ0AWiNVm9MIlPht3+t7nz6ELROTu/MDm7BPp8fS08wXw2Omt1u5vtWTYwJ/zU9b3/42HAlk9jwjapE4W8F1WmslmKxiq1S/6dEryfelmoCULtQ7OTwdc83s7N3LdSkopWqJEMairoS4wvGW+gFxfMGxNJsbJVIhNpsReivHMPOX3s8HS2G4NWmJSH6NAqFMsu5xxBTv9oy63p5GZUolE0EtgHY/MqrTDYBlr/rOBz3j/5Lwlsu1optCI4uGOh+RRgaomY2xRKqwfEVExXs68rtq/3Y0eA3m1F+QvCyPolC6cv270vFO/RlrGtnYLlBDTW5eKwy7TAJr1/VUKwTbH50IFzuofujfDHRsjScoLoQ/JmuORoMm4fbmVaWgzdLNh51+qsK9/fq7dlBpMYvhBC8tHejUPo2k1VSzSbdY7Xmi5DuWqD9SkYPflnqRAT+hFZc/ENbXMfj5p1YZLXorYIIv7O027Hoh2BihM71quz4Qz0T1T6rkro/m+jaxiv3Ey69i8vYKiAdc3ViLj+SESLQqJj8z8dwDKpYhGIQjvffd72i3NRh06LdpkB6NcYk7fjTvcCHkugyObGJ2fuLlNiH7MX+JMJ6A41NjKQC6vWKZA5FTL+q9qExeJl/LDop29QUIXgDYjyYtSCElmmLrM3WCKGAddWaenYE3TRf2AVTrLBc6j5iD23QaEt0CmMkxeu1M6u7tH6i/A8/z3AWymT04fXoaJqU+TcM1WAyCyRH1WO88HT+i3gNzCSaBbgmUz53ZhiBMY2Qel3TDn0VOjFJWAZNB6hrtab4emmUH5wEYaxG24SGDT/tjazJ7CB5V3v2jZMusvtv0wRSNjeqHtn5QP2bELEOzKyq6LLDdAXvo3B/9hCBw2dzOuGXaln6GmIaZmF6yGwIxh1sRi8YBmGTUH0VaL8GIuZtZXebyfUI4Rentc04CNslRf4zdHOrU7cahl9yda4InWjnnDaL1Zx8yv0M16SXs4chSTApNonh56Zkl42T+3lcS4Ngbpof7PVjY7QNQr6pdXu/kwzCJvFYkEHR8UM+Q8x2rfBUP3qmGmzuutfQpJrDkMrlG6MmhzctNpMZji6XXslfdzEDL9w49tulfLKdVzN8gZq86SQx03TI0jc6DsKYl1GvVntypd9sNRhe0EWgUUQgJma2xo/9l0zvZTituXj1ePvWprzS7ItrGPLJC+HcpJdnej/V883BcT2nn9En+2M5bjrLQBRs5eTXNmqVzD4BsVyn+k3DJOdYLwhjrWTWpPNCLL01V8CsrFNk+BBSCqnaHtlMbT2+qVhf9x4W0y5hHOUo/wBAQurUwpiKmSmuzcQRqVIzXRaIGA3vrfB1xto1jbp24UYbu7PVUWpR/SCxq0ftVeZXo45JFM40Qzu2mUW2PtMQJpGu2hD3I/KVFtFLl5wu5dPDD2cG7dU4M49eHiqQ/ckzojfdZYZ4d0grDDgKseMhbbK0R5bZYKmnn7lxK5LBwBIfUTEB6MozJtK9kWqQzbqGPYOwWEkQtn3COERJZxDVxCjcfvFMt55JHLDb1KLx/LIpHdoIbZaV2Z2oSSxP5qjgNcVZfmcQvkb8aIiiOrdDwertvXLKE/uWg7DbN46FfqhNNhXhpkWrv8wgMep9PFfwBUhtNNNeUF2c9BFyMhsWr8GKV3XG00VLghDYgmt3YNo0CodvThACHdHb13LFAsO1Rjs/mDMedk8Q4hCqn495jRfWNt7fIr0k6GClR54BFY1X4YQo3OA6kxVTpzyrlCDE7sR07qMfCKtfR01WaizPTTlCajtUYEuvLbH7f/nuIqO5C03es2BE7gAEIXam06twFtbavyGxueI5G34EIXYlsjvE+zZq1bKYyPbM7yV/lOXzloB6worzdIl7Z1fgOalDSWe20D0QQYgdzZ6hnt1s/u1LjZuec3vyHojmKPYzHrWb/rjaaKFMrbqbnn50CgQhdrO052/FQ0TTbdu5U1UOdM50Ea5ouaLzTcg610pPhLOnzMswbQ170QV5l/GRse9KdQhfxy2dzdIhvEAdJTEYNp2ucC2R3oZl7gj3I51zCgEuxxXVQqLOWKFJXyxzcu3hzjmZDlcjChOfpkacuEwo27NmIU9aQ+Na8md7DqkK5THTGM0cq3YGliDE5iaHKeWUtVrn6UzHUp+21XfKpca4lvkj3Pvk55kZmdss47StUeatYXvlJ0DkjsNewWRatBXieyun3A0V11Je/D+PlFxWJuxi/dlbb8eetaGMq8ic4J556YdBmB3v33p700+o8z4fcA0r5kZ+nJhxuSjO/uAUOE0X21qxlDbXoSuWrQjNaXOjwPZWzJv+9NivbH0na6/bB75JeRCqT0MlW98VTV0FrsqURpb4dOPDbH0nzpyWATZXPEz48aEU2WEIKkLcW+m4g/l479FcEIvq+ykC38UWhUA4q/CjHmF2inZuOilwF+mF7kNhX+4P+225Kdp193EDvtFyZ0/VOLE3N0W78o6mwDcy8wOA4bzQj2Mwt1ijpCIGri7sfm/SkSBUDMHEARXrZLYVFRucNQN8Ib/x78OqcaAJFfIxn86UCTJDIdUPuQC+VNPktFo5KYSQUirdBmB3cPZH0pMC6h/3BHytJgynphXkW5LT47Y5fhT4VlJP49CoWkmTVLSFziiNUaBHuGcr1B8d+GS0khUDJBWEhsYosJ9EElRXyfgAKDMNQk2HENiTHQccMQjsa7SHrjDEILCv4Ym3YUb4x7NwAKwwOJI+zAhnthqwr+7ICxHnBZAXBfbmDyZUTuk4D4eVE8D+dG8q3NH3AtxTnBhnNbUgcCAyogAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANjR/wEQWDVpOu4+iwAAAABJRU5ErkJggg=="} /--></div>
				<!-- /wp:column -->

				<!-- wp:column -->
				<div class="wp-block-column"><!-- wp:wc-quote/lightblue-total {"align":"wide"} /--></div>
				<!-- /wp:column --></div>
				<!-- /wp:columns -->

				<!-- wp:wc-quote/lightblue-footer-block /-->

				<!-- wp:paragraph -->
				<p></p>
				<!-- /wp:paragraph -->

                ',
				)
			);
		}
	}
}