<?php

namespace WooCommerceWholesalePricing\App\Modules\Quote\Admin;

class OrderHandler {
	public function __construct() {
		add_action( 'wc_quote_converted_to_order', array( $this, 'wc_quote_converted_to_order' ), 90, 2 );
	}

	public function wc_quote_converted_to_order( $order, $quote_id ) {
		$quote_general = get_option('wc_quote_general');
		if ( ! isset( $quote_general['custom_tax_shipping'] ) && '1' != $quote_general['custom_tax_shipping'] ) {
			return;
		}

		if ( empty( $quote_id ) || ! is_numeric( $quote_id ) ) {
			return;
		}
		if ( ! is_object( $order ) ) {
			return;
		}
			
		$has_maunall_revision = get_post_meta( $quote_id, '_shipping_tax_manually_updated', true );
		if ( ! $has_maunall_revision ) {
			return;
		}
		
		$target_rate_id = 1;
		$tax_label = get_post_meta( $quote_id, 'quote_content_tax_label', true );
		if ( empty( $tax_label ) ) {
			$tax_label = __('Tax', 'woocommerce');
		} else {
			$tax_label = str_replace('(standard)', '', $tax_label);
		}

		$new_tax_amount = floatval( get_post_meta( (int) $quote_id, 'quote_content_shipping_tax', true ) );
		if ( $new_tax_amount < 0 ) {
			$new_tax_amount = 0;
		}
				
		$items = $order->get_items();
		
		if ( ! empty( $items ) ) {
			$first_item = reset( $items );
			foreach ( $items as $item ) {
				if ( $item->get_id() === $first_item->get_id() ) {
					$item->set_taxes( array(
						'total'    => array( $target_rate_id => $new_tax_amount ),
						'subtotal' => array( $target_rate_id => $new_tax_amount ),
					) );
					$item->set_total_tax( $new_tax_amount );
				} else {
					$item->set_taxes( array( 'total' => array(), 'subtotal' => array() ) );
					$item->set_total_tax( 0 );
				}
				$item->save();
			}
		}

		foreach ( $order->get_items( 'tax' ) as $tax_id => $tax_item ) {
			$order->remove_item( $tax_id );
		}
		$order->save(); 
		$new_tax_item = new \WC_Order_Item_Tax();
		$new_tax_item->set_rate_id( $target_rate_id );
		$new_tax_item->set_tax_total( $new_tax_amount );
		$new_tax_item->set_label( $tax_label );
		$order->add_item( $new_tax_item );
		$new_tax_item->save();

		$subtotal       = (float) $order->get_subtotal();
		$shipping_total = (float) $order->get_shipping_total();
		$discount_total = (float) $order->get_discount_total();

		$final_total = ( $subtotal - $discount_total ) + $shipping_total + $new_tax_amount + $new_shipping_tax;

		$order->set_cart_tax( $new_tax_amount );

		$order->set_total( $final_total );

		$order->save();
	}
}
