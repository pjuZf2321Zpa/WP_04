<?php
namespace WooCommerceWholesalePricing\App\Modules\Quote;

use WooCommerceWholesalePricing\App\Modules\Quote\QuoteProcess;

class QuoteBasketService {

	/**
	 * Cached wc_quote_general option.
	 *
	 * @var array|false|null
	 */
	private $quote_general = null;

	public function __construct() {
		add_action('wp_nav_menu_items', array( $this, 'wc_quote_mini_basket' ), 10, 2);
		add_shortcode('wc-quote-mini-cart', array( $this, 'wc_quote_mini_cart_shortcode_function' ));
	}

	/**
	 * Load quote general settings once per request.
	 *
	 * @return array
	 */
	private function get_quote_general_settings() {
		if ( null === $this->quote_general ) {
			$this->quote_general = get_option( 'wc_quote_general', false );
			if ( ! is_array( $this->quote_general ) ) {
				$this->quote_general = array();
			}
		}

		return $this->quote_general;
	}
		
	/**
	 * Quote Mini Basket in Menu
	 *
	 * @param  mixed $items
	 * @param  mixed $args
	 * @return void
	 */
	public function wc_quote_mini_basket( $items, $args ) {
		$quote_general        = $this->get_quote_general_settings();
		$disable_basket_roles = isset( $quote_general['disable_basket_roles'] ) ? $quote_general['disable_basket_roles'] : array();
		$current_user_role    = is_user_logged_in() ? wp_get_current_user()->roles : array( 'guest' );
		$quote_basket_menu    = isset( $quote_general['quote_basket_menu'] ) ? $quote_general['quote_basket_menu'] : array( 0 => 0 );
		$mini_cart            = isset( $quote_general['mini_cart'] ) ? $quote_general['mini_cart'] : '0';
		$quote_basket_style   = isset( $quote_general['quote_basket_style'] ) ? $quote_general['quote_basket_style'] : 'dropdown';

		if (array_intersect($current_user_role, $disable_basket_roles) ) {
			return $items;
		}
		
		if (isset($args->menu->term_id) ) {

			$menu_id = $args->menu->term_id;

		} elseif (isset($args->term_id) ) {

			$menu_id = $args->term_id;

		} elseif (isset($args->menu) ) {

			$menu_id = $args->menu;

		} else {

			$menu_id = 0;
		}
		
		$menu_match = in_array((string) $menu_id, (array) $quote_basket_menu, true) ? true : false;

		if (! $menu_match ) {
			return $items;
		}

		$quote_page = get_quote_page_id();
		$wc_quote   = new QuoteProcess();

		ob_start();

		wwp_view('quote.mini-quote', compact( 'quote_page', 'mini_cart', 'quote_basket_style', 'wc_quote' ));

		return $items . ob_get_clean();
	}
	
	/**
	 * Quote Mini Cart Shortcode
	 *
	 * @return void
	 */
	public function wc_quote_mini_cart_shortcode_function() {
		$quote_general      = $this->get_quote_general_settings();
		$quote_page         = get_quote_page_id();
		$mini_cart          = isset( $quote_general['mini_cart'] ) ? $quote_general['mini_cart'] : '0';
		$quote_basket_style = isset( $quote_general['quote_basket_style'] ) ? $quote_general['quote_basket_style'] : 'dropdown';
		$wc_quote           = new QuoteProcess();
		 
		ob_start();

		wwp_view('quote.mini-quote', compact( 'quote_page', 'mini_cart', 'quote_basket_style', 'wc_quote' ));

		return ob_get_clean();
	}
}
