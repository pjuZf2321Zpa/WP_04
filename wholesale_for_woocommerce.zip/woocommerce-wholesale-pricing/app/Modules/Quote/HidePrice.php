<?php
namespace WooCommerceWholesalePricing\App\Modules\Quote;

class HidePrice {

	public static $price_rule_applied;

	/**
	 * Whether any active quote rule has hide-price enabled.
	 *
	 * @var bool|null
	 */
	private static $has_hide_price_rules = null;

	public function __construct() {

		self::$price_rule_applied = array();
		add_filter('woocommerce_get_price_html', array( $this, 'wc_quote_remove_woocommerce_price_html' ), 300, 2);
		add_filter('woocommerce_variable_price_html', array( $this, 'wc_quote_remove_woocommerce_price_html' ), 300, 2);
		add_filter('woocommerce_subscription_price_string', array( $this, 'wc_quote_remove_woocommerce_price_html' ), 300, 2);
		add_filter('woocommerce_subscriptions_product_price_string', array( $this, 'wc_quote_remove_woocommerce_price_html' ), 300, 2);
	}

	/**
	 * Check whether any enabled quote rule hides product prices.
	 *
	 * @return bool
	 */
	private static function quote_has_hide_price_rules() {
		if ( null !== self::$has_hide_price_rules ) {
			return self::$has_hide_price_rules;
		}

		self::$has_hide_price_rules = false;

		foreach ( get_quote_rules() as $rule ) {
			$quote_rules = get_post_meta( $rule->ID, 'wc_quote_rules', true );
			$hide_price  = isset( $quote_rules['hide_price'] ) ? $quote_rules['hide_price'] : '0';

			if ( '1' === $hide_price ) {
				self::$has_hide_price_rules = true;
				break;
			}
		}

		return self::$has_hide_price_rules;
	}

	public function wc_quote_remove_woocommerce_price_html( $price, $product ) {

		if ( ! self::quote_has_hide_price_rules() ) {
			return $price;
		}

		if (isset($_REQUEST['quote_id']) || ( is_admin() && ! wp_doing_ajax() ) || is_checkout() || !is_object($product) || is_account_page() || is_cart() ) {
			return $price;
		}
		if ('subscription_variation' === $product->get_type() || 'variation' === $product->get_type() ) {
			$product = wc_get_product($product->get_parent_id());
		}

		foreach ( get_quote_rules() as $rule ) {

			$quote_rules = get_post_meta($rule->ID, 'wc_quote_rules', true);
			$hide_price = isset($quote_rules['hide_price']) ? $quote_rules['hide_price'] : '0';
			$hide_price_msg = isset($quote_rules['hide_price_msg']) ? $quote_rules['hide_price_msg'] : '' ;

			if (!quote_check_rule_for_product($product->get_id(), $rule->ID) ) {
				continue;
			}

			if ('1' !== $hide_price  ) {
				array_push(self::$price_rule_applied, $rule->ID);
				break;
			}

			if (in_array($rule->ID, self::$price_rule_applied) ) {
				break;
			}

			return $hide_price_msg;
		}

			return $price;
	}
}
