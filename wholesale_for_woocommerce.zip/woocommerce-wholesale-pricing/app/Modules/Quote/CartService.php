<?php
namespace WooCommerceWholesalePricing\App\Modules\Quote;

use WooCommerceWholesalePricing\App\Modules\Quote\QuoteProcess;

class CartService {

	public function __construct() {
		add_filter('woocommerce_blocks_product_grid_item_html', array( $this, 'wc_quote_hide_cart_related_products' ), 10, 3);
		add_action('woocommerce_before_calculate_totals', array( $this, 'wc_quote_cart_price_override' ), 900);
		add_filter('wwp_cart_quantity', array( $this, 'wc_quote_override_cart_qty' ), 400, 2);
		add_action('woocommerce_after_cart_totals', array( $this, 'wc_quote_build_quote_button' ));
		add_filter('wwp_is_cart_or_checkout_page', array( $this, 'wc_quote_is_quote_page' ), 400);
		add_filter('wwp_is_admin_product_price', array( $this, 'wc_quote_tier_pricing_bypass' ), 400);
		add_action('wp_loaded', array( $this, 'wc_quote_convert_to_cart' ));
	}
	
	/**
	 * Hide Add to cart button in cart related products
	 *
	 * @param  mixed $html
	 * @param  mixed $data
	 * @param  mixed $product
	 * @return void
	 */
	public function wc_quote_hide_cart_related_products( $html, $data, $product ) {
		 
		foreach ( get_quote_rules() as $rule ) {
			$quote_rules = get_post_meta($rule->ID, 'wc_quote_rules', true);
			$hide_cart_all = isset($quote_rules['hide_cart_all']) ? $quote_rules['hide_cart_all'] : '0' ;
			if ('1' == $hide_cart_all) {
				$html = "<li class=\"wc-block-grid__product\">
                    <a href=\"{$data->permalink}\" class=\"wc-block-grid__product-link\">
                        {$data->badge}
                        {$data->image}
                        {$data->title}
                    </a>
                    {$data->price}
                    {$data->rating}
                </li>";
				return $html;
			}
		}

		return $html;
	}
	
	/**
	 * Quote Cart Price Override
	 *
	 * @param  mixed $cart_object
	 * @return void
	 */
	public function wc_quote_cart_price_override( $cart_object ) {

		$data = $_REQUEST;

		$quote_contents = WC()->session->get('wc_quotes_temp');
		if (!empty($quote_contents) ) {
			
			foreach ( (array) $quote_contents as $quote_item_key => $quote_item ) {
				foreach ( $cart_object->cart_contents as $key => $value ) {
					if (isset($quote_item['data']) ) {
							$product = $quote_item['data'];
					} else {
						continue;
					}

					if (! is_object($product) ) {
						continue;
					}
					$product_id = $value['product_id'];
					$temp_id = $quote_item['product_id'];
					
					if ($product_id === $temp_id ) {
						$value['data']->price = $quote_item['offered_price'];
						$value['data']->set_price($quote_item['offered_price']);
						if (isset($quote_item['offered_signup']) && !empty($quote_item['offered_signup']) ) :
							$value['data']->update_meta_data('_subscription_sign_up_fee', $quote_item['offered_signup']);
						endif;
					}
				}
			}
			WC()->session->set('wc_quotes_temp', null);
		}
		// --- Handle offered price from quote to checkout conversion ---
		// Check if any cart item has offered_price in cart item data (set when convert_quote_to_checkout is called)
		foreach ($cart_object->cart_contents as $cart_item_key => $cart_item) {
			if (isset($cart_item['offered_price']) && !empty($cart_item['offered_price'])) {
				$offered_price = floatval($cart_item['offered_price']);
				if ($offered_price > 0) {
					$cart_item['data']->set_price($offered_price);
				}
				
				// Handle subscription signup fee if present
				if (isset($cart_item['offered_signup']) && !empty($cart_item['offered_signup'])) {
					$cart_item['data']->update_meta_data('_subscription_sign_up_fee', floatval($cart_item['offered_signup']));
				}
			}
		}
	}
	
	/**
	 * Quote Override Cart Quantity
	 *
	 * @param  mixed $qty
	 * @param  mixed $product_id
	 * @return void
	 */
	public function wc_quote_override_cart_qty( $qty, $product_id ) {
		$url     = wp_get_referer();
		$post_id = 0 !== get_queried_object_id() ? get_queried_object_id() : url_to_postid($url);
		$quote_contents = isset(WC()->session) ? WC()->session->get('wc_quotes') : get_post_meta(get_the_ID(), 'quote_contents', true);
		$quote_page = isset(get_option('wc_quote_general', false)['quote_page']) ? get_option('wc_quote_general', false)['quote_page'] : '';
		$post_content = isset(get_post($post_id)->post_content) ? get_post($post_id)->post_content : '';
		$quote_id = isset($_REQUEST['post_id']) ? sanitize_text_field($_REQUEST['post_id']) : get_the_ID();
		if (( !empty($quote_contents) && $post_id === (int) $quote_page ) || ( !empty($quote_contents) && has_shortcode($post_content, 'wc-quote-request-page') ) || ( !empty($quote_contents) && get_post_type($quote_id) === 'wc-quote' ) || ( !empty($quote_contents) && isset($_REQUEST['action']) && 'wcquote_add_to_quote' === sanitize_text_field($_REQUEST['action']) ) || ( isset($_REQUEST['action']) && ( 'wcquote_add_to_quote_single' === sanitize_text_field($_REQUEST['action']) || 'wcquote_add_to_quote_variable' === sanitize_text_field($_REQUEST['action']) || 'wcquote_update_quote_items' === sanitize_text_field($_REQUEST['action']) ) ) ) :
			foreach ( (array) $quote_contents as $quote_item_key => $quote_item ) {

				if (isset($quote_item['data']) ) {

					$_product = $quote_item['data'];

				} else {

					continue;
				}

				if (! is_object($_product) ) {
						continue;
				}

				if ($product_id === $_product->get_id() ) {
					$qty = $quote_item['quantity'];
					return $qty;
				}
			}
		endif;
		return $qty;
	}
	
	/**
	 * Quote Build Quote Button
	 *
	 * @return void
	 */
	public function wc_quote_build_quote_button() {

		$enable_build_quote = isset(get_option('wc_quote_general')['enable_build_quote']) ? get_option('wc_quote_general')['enable_build_quote'] : '0';
		$quote_page = get_quote_page_id();
		$build_quote_text = ! empty(get_option('wc_quote_customization', false)['build_quote_text']) ? get_option('wc_quote_customization', false)['build_quote_text'] : 'Build Quote';

		if ('1' === $enable_build_quote ) {
			echo '<div class="wc-proceed-to-checkout"><a href="javascript:void(0)" class="wp-element-button checkout-button build-quote-button button alt wc-forward" data-url="' . esc_url(get_page_link($quote_page)) . '">' . esc_attr($build_quote_text) . '</a></div>';
		}
	}

	public function wc_quote_is_quote_page( $is_cart_or_checkout_page ) {
		$url     = wp_get_referer();
		$post_id = 0 !== get_queried_object_id() ? get_queried_object_id() : url_to_postid($url);
		$quote_contents = isset(WC()->session) ? WC()->session->get('wc_quotes') : get_post_meta(get_the_ID(), 'quote_contents', true);
		$quote_page = isset(get_option('wc_quote_general', false)['quote_page']) ? get_option('wc_quote_general', false)['quote_page'] : '';
		$post_content = isset(get_post($post_id)->post_content) ? get_post($post_id)->post_content : '';
		$quote_id = isset($_REQUEST['post_id']) ? sanitize_text_field($_REQUEST['post_id']) : get_the_ID();
		if (( !empty($quote_contents) && $post_id === (int) $quote_page ) || ( !empty($quote_contents) && has_shortcode($post_content, 'wc-quote-request-page') ) || ( !empty($quote_contents) && get_post_type($quote_id) === 'wc-quote' ) || ( !empty($quote_contents) && isset($_REQUEST['action']) &&  'wcquote_add_to_quote' === sanitize_text_field($_REQUEST['action']) )  || ( isset($_REQUEST['action']) && ( 'wcquote_add_to_quote_single' === sanitize_text_field($_REQUEST['action']) || 'wcquote_add_to_quote_variable' === sanitize_text_field($_REQUEST['action']) || 'wcquote_update_quote_items' === sanitize_text_field($_REQUEST['action']) ) ) ) :
			return true;
		endif;
		return $is_cart_or_checkout_page;
	}

	public function wc_quote_tier_pricing_bypass( $is_admin ) {
		$url     = wp_get_referer();
		$post_id = 0 !== get_queried_object_id() ? get_queried_object_id() : url_to_postid($url);
		$quote_contents = isset(WC()->session) ? WC()->session->get('wc_quotes') : get_post_meta(get_the_ID(), 'quote_contents', true);
		$quote_page = isset(get_option('wc_quote_general', false)['quote_page']) ? get_option('wc_quote_general', false)['quote_page'] : '';
		$post_content = isset(get_post($post_id)->post_content) ? get_post($post_id)->post_content : '';
		$quote_id = isset($_REQUEST['post_id']) ? sanitize_text_field($_REQUEST['post_id']) : get_the_ID();
		if (( !empty($quote_contents) && $post_id === (int) $quote_page ) || ( !empty($quote_contents) && has_shortcode($post_content, 'wc-quote-request-page') ) || ( !empty($quote_contents) && get_post_type($quote_id) === 'wc-quote' ) || ( !empty($quote_contents) && isset($_REQUEST['action']) && 'wcquote_add_to_quote' === sanitize_text_field($_REQUEST['action']) ) || ( isset($_REQUEST['action']) && ( 'wcquote_add_to_quote_single' === sanitize_text_field($_REQUEST['action']) || 'wcquote_add_to_quote_variable' === sanitize_text_field($_REQUEST['action']) || 'wcquote_update_quote_items' === sanitize_text_field($_REQUEST['action']) ) ) ) :
			return false;
		endif;
		return $is_admin;
	}

	public function wc_quote_convert_to_cart() {
		if (isset($_REQUEST['status']) && 'quote_accepted' === $_REQUEST['status'] ) {
			// check_ajax_referer('wc_quote_status_nonce', 'accept_nonce');
			$data = $_REQUEST;
			$quote_id = base64_decode($data['quote_id']);
			$quote_id = sanitize_text_field(wp_unslash($quote_id));
			$quote_status = sanitize_text_field(wp_unslash($_REQUEST['status']));

			if (empty(intval($quote_id)) ) {
				return;
			}

			$wc_quote = new QuoteProcess();

			$wc_quote->convert_quote_to_cart($quote_id, $quote_status);

		} elseif (isset($_REQUEST['status']) && 'quote_rejected' === $_REQUEST['status'] ) {

			$data = $_REQUEST;
			$quote_id = base64_decode($data['quote_id']);
			$quote_id = sanitize_text_field(wp_unslash($quote_id));
			$quote_status = sanitize_text_field(wp_unslash($_REQUEST['status']));

			if (empty(intval($quote_id)) ) {
				return;
			}

			$wc_quote = new QuoteProcess();

			$wc_quote->reject_quote($quote_id, $quote_status);
			
		} else {
			return;
		}
	}
}
