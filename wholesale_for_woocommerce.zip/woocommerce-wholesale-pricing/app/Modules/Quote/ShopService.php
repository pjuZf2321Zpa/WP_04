<?php
namespace WooCommerceWholesalePricing\App\Modules\Quote;

class ShopService {

	private $quote_settings;

	public function __construct() {

		$this->quote_settings['customization'] = get_option('wc_quote_customization', false);
		$this->quote_settings['general'] = get_option('wc_quote_general', false);


		add_action('woocommerce_after_shop_loop_item', array( $this, 'wc_quote_shop_page_counter' ), 15);
		add_action('woocommerce_after_add_to_cart_form', array( $this, 'wc_quote_shop_page_counter' ), 15);
		add_filter('woocommerce_loop_add_to_cart_link', array( $this, 'wc_quote_replace_loop_add_to_cart_link' ), 12, 2);
	}

	public function wc_quote_replace_loop_add_to_cart_link( $html, $product ) {
		if ('simple' !== $product->get_type() && 'subscription' !== $product->get_type() ) {
			return $html;
		}
		
		$add_quote_text = isset($this->quote_settings['customization']['add_quote_text']) && !empty($this->quote_settings['customization']['add_quote_text']) ? $this->quote_settings['customization']['add_quote_text'] : esc_html__('Add To Quote', 'woocommerce-wholesale-pricing');
		$quote_btn_color = isset($this->quote_settings['customization']['add_quote_btn_color']) ? $this->quote_settings['customization']['add_quote_btn_color'] : '';
		$quote_text_color = isset($this->quote_settings['customization']['add_quote_text_color']) ? $this->quote_settings['customization']['add_quote_text_color'] : '';
		$quote_button_position  = isset($this->quote_settings['customization']['quote_btn_positioning']) ? $this->quote_settings['customization']['quote_btn_positioning'] : 'inline';
		$quote_button = false;

		foreach ( get_quote_rules() as $rule ) {

			$quote_rules = get_post_meta($rule->ID, 'wc_quote_rules', true);
			$show_shop = isset($quote_rules['show_shop']) ? $quote_rules['show_shop'] : '0' ;
			$show_single = isset($quote_rules['show_single']) ? $quote_rules['show_single'] : '0' ;

			if (!quote_check_rule_for_product($product->get_id(), $rule->ID) ) {
				$quote_button = false;
				continue;
			}

			// Check if conditions are met to add the Quote button alongside/inline
			if (( is_single() && '1' == $show_single && !$quote_button ) || ( !$quote_button && !is_single() && '1' == $show_shop )) {
				$quote_button = true;
				$html .= ( 'underneath' == $quote_button_position ) ? '<div data-block-name="woocommerce/product-button" data-text-align="center" data-is-descendent-of-query-loop="true" data-font-size="small" class="wp-block-button wc-block-components-product-button has-text-align-center">' : '';
				$quote_button_html = '<a href="javascript:void(0)" rel="nofollow" data-product_id="' . intval($product->get_ID()) . '" data-product_sku="' . esc_attr($product->get_sku()) . '" class="wp-block-button__link wp-element-button wc-block-components-product-button__button has-font-size has-small-font-size has-text-align-center quote-btn button add_to_cart_button product_type_' . esc_attr($product->get_type()) . '" style="background-color:' . esc_attr($quote_btn_color) . ';color:' . esc_attr($quote_text_color) . ';">' . esc_attr($add_quote_text) . '</a>';
				if ( 'underneath' == $quote_button_position ) {
					$quote_button_html .= '</div>';
				}

				
				return $html . $quote_button_html;
			} elseif (quote_check_required_addons($product->get_id()) ) {
				// WooCommerce Product Add-ons compatibility
				$quote_button = false;
				return $html;
			}
		}

		return $html;
	}

	public function wc_quote_shop_page_counter() {
		
		$display_quote_counter = isset($this->quote_settings['general']['display_quote_counter']) ? $this->quote_settings['general']['display_quote_counter'] : '';        
		
		$key = 'counter_shop';

		if ( 'woocommerce_after_add_to_cart_form' == current_action() ) {
			$key = 'counter_single_product';
		}

		$counter_shop =  isset($this->quote_settings['general'][$key]) ? $this->quote_settings['general'][$key] : '0';    
		$quote_counter_text_color = isset($this->quote_settings['customization']['quote_counter_text_color']) ? $this->quote_settings['customization']['quote_counter_text_color'] : '';

		if ('1' == $display_quote_counter && '1' == $counter_shop && is_user_logged_in() ) :

			$wc_quote_counter_text = isset($this->quote_settings['customization']['quote_counter_text']) ? $this->quote_settings['customization']['quote_counter_text'] : 'Quote Counter';
			if ( empty( $wc_quote_counter_text ) ) {
				$wc_quote_counter_text = esc_html__('Quote Counter', 'woocommerce-wholesale-pricing');
			}

			$post_id = get_the_ID();
			$wc_quote_counter = get_post_meta($post_id, 'quote_counter', true);

			if (! empty($wc_quote_counter) &&  0 != $wc_quote_counter  ) :
				?>
			<p class="wc_quote_counter" style="color: <?php echo esc_attr($quote_counter_text_color); ?>;"> <?php echo esc_attr($wc_quote_counter_text) . ' : ' . esc_attr($wc_quote_counter); ?></p>
				<?php	
			endif;           
		endif;
	}
}
