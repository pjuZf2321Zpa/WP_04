<?php
/**
 * Company users AJAX endpoints (My Account portal).
 *
 * @package WooCommerceWholesalePricing
 */

namespace WooCommerceWholesalePricing\App\Modules\CompanyCredits;

/**
 * List, add, and remove company users from the frontend Users tab.
 */
class UsersAjax {

	/**
	 * UsersAjax constructor.
	 */
	public function __construct() {
		add_action( 'wp_ajax_ccp_get_company_users', array( $this, 'get_company_users' ) );
		add_action( 'wp_ajax_ccp_get_add_user_form', array( $this, 'get_add_user_form' ) );
		add_action( 'wp_ajax_ccp_add_company_user', array( $this, 'add_company_user' ) );
		add_action( 'wp_ajax_ccp_update_company_user', array( $this, 'update_company_user' ) );
		add_action( 'wp_ajax_ccp_remove_company_member', array( $this, 'remove_company_member' ) );
	}

	/**
	 * Current user's company management context.
	 *
	 * @return array{company_id:int,role:string,user_id:int}|null
	 */
	protected function get_manage_context() {
		if ( ! is_user_logged_in() ) {
			return null;
		}

		if ( 'yes' !== ccp_get_option_yes_default( 'ccp_manage_users' ) ) {
			return null;
		}

		$user_id    = get_current_user_id();
		$company_id = absint( get_user_meta( $user_id, 'ccp_company_id', true ) );
		$role       = (string) get_user_meta( $user_id, 'ccp_company_role', true );

		if ( empty( $company_id ) ) {
			return null;
		}

		if ( ! in_array( $role, array( 'ccp_owner', 'ccp_manager' ), true ) ) {
			return null;
		}

		return array(
			'company_id' => $company_id,
			'role'       => $role,
			'user_id'    => $user_id,
		);
	}

	/**
	 * Human-readable company role label.
	 *
	 * @param string $role Role slug.
	 * @return string
	 */
	protected function format_company_role_label( $role ) {
		$labels = array(
			'ccp_owner'   => __( 'Owner', 'woocommerce-wholesale-pricing' ),
			'ccp_manager' => __( 'Manager', 'woocommerce-wholesale-pricing' ),
			'ccp_member'  => __( 'Member', 'woocommerce-wholesale-pricing' ),
		);

		return isset( $labels[ $role ] ) ? $labels[ $role ] : $role;
	}

	/**
	 * DataTables payload for company users.
	 *
	 * @return void
	 */
	public function get_company_users() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		$ctx = $this->get_manage_context();
		if ( ! $ctx ) {
			wp_send_json( array( 'data' => array() ) );
		}

		$users = get_users(
			array(
				'meta_key'   => 'ccp_company_id',
				'meta_value' => $ctx['company_id'],
			)
		);

		$rows = array();
		foreach ( (array) $users as $user ) {
			if ( ! $user instanceof \WP_User ) {
				continue;
			}

			$company_role = (string) get_user_meta( $user->ID, 'ccp_company_role', true );
			$can_remove   = ( 'ccp_member' === $company_role && (int) $user->ID !== (int) $ctx['user_id'] );

			$rows[] = array(
				'user_id'      => (int) $user->ID,
				'display_name' => $user->display_name,
				'user_email'   => $user->user_email,
				'user_role'    => $this->format_company_role_label( $company_role ),
				'can_edit'     => true,
				'can_remove'   => $can_remove,
			);
		}

		wp_send_json( array( 'data' => $rows ) );
	}

	/**
	 * Render add/edit-user form markup for the modal.
	 *
	 * @return void
	 */
	public function get_add_user_form() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		$ctx = $this->get_manage_context();
		if ( ! $ctx ) {
			wp_die( esc_html__( 'You are not allowed to manage company users.', 'woocommerce-wholesale-pricing' ) );
		}

		$edit_user = null;
		$post      = function_exists( 'ccp_post_data' ) ? ccp_post_data() : array();
		$user_id   = isset( $post['user_id'] ) ? absint( $post['user_id'] ) : 0;

		if ( $user_id ) {
			$target_company_id = absint( get_user_meta( $user_id, 'ccp_company_id', true ) );
			if ( $target_company_id !== $ctx['company_id'] ) {
				wp_die( esc_html__( 'User does not belong to your company.', 'woocommerce-wholesale-pricing' ) );
			}

			$edit_user = get_userdata( $user_id );
			if ( ! $edit_user instanceof \WP_User ) {
				wp_die( esc_html__( 'Invalid user.', 'woocommerce-wholesale-pricing' ) );
			}
		}

		wwp_view(
			'frontend.company-credits.my-account.add-user-form',
			array(
				'edit_user' => $edit_user,
			),
			true
		);
		wp_die();
	}

	/**
	 * Create a WordPress user and assign as company member.
	 *
	 * @return void
	 */
	public function add_company_user() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		$ctx = $this->get_manage_context();
		if ( ! $ctx ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to manage company users.', 'woocommerce-wholesale-pricing' ) ),
				403
			);
		}

		$post       = function_exists( 'ccp_post_data' ) ? ccp_post_data() : array();
		$first_name = isset( $post['account_first_name'] ) ? sanitize_text_field( $post['account_first_name'] ) : '';
		$last_name  = isset( $post['account_last_name'] ) ? sanitize_text_field( $post['account_last_name'] ) : '';
		$user_login = isset( $post['account_user_login'] ) ? sanitize_user( $post['account_user_login'], true ) : '';
		$user_email = isset( $post['account_email'] ) ? sanitize_email( $post['account_email'] ) : '';

		if ( '' === $first_name ) {
			wp_send_json_error( array( 'message' => __( 'First name is required.', 'woocommerce-wholesale-pricing' ) ) );
		}
		if ( '' === $last_name ) {
			wp_send_json_error( array( 'message' => __( 'Last name is required.', 'woocommerce-wholesale-pricing' ) ) );
		}
		if ( '' === $user_login ) {
			wp_send_json_error( array( 'message' => __( 'Username is required.', 'woocommerce-wholesale-pricing' ) ) );
		}
		if ( '' === $user_email || ! is_email( $user_email ) ) {
			wp_send_json_error( array( 'message' => __( 'A valid email address is required.', 'woocommerce-wholesale-pricing' ) ) );
		}
		if ( username_exists( $user_login ) ) {
			wp_send_json_error( array( 'message' => __( 'This username is already taken.', 'woocommerce-wholesale-pricing' ) ) );
		}
		if ( email_exists( $user_email ) ) {
			wp_send_json_error( array( 'message' => __( 'This email address is already registered.', 'woocommerce-wholesale-pricing' ) ) );
		}

		$display_name = trim( $first_name . ' ' . $last_name );
		$userdata     = array(
			'first_name'   => $first_name,
			'last_name'    => $last_name,
			'user_login'   => $user_login,
			'user_email'   => $user_email,
			'display_name' => $display_name,
			'user_pass'    => wp_generate_password( 20, true, true ),
			'role'         => 'customer',
		);

		/**
		 * Filter the create new user data.
		 *
		 * @since 3.4.0
		 *
		 * @param array $userdata The user data.
		 */
		$userdata = apply_filters( 'ccp_create_new_user_data', $userdata );
		$user_id  = wp_insert_user( $userdata );

		if ( is_wp_error( $user_id ) ) {
			wp_send_json_error( array( 'message' => $user_id->get_error_message() ) );
		}

		ccp_sync_user_company_assignment( $user_id, $ctx['company_id'], 'ccp_member' );

		if ( function_exists( 'ccp_get_effective_user_credit_limit' ) && function_exists( 'ccp_set_user_wallet_balance' ) ) {
			$limit = (float) ccp_get_effective_user_credit_limit( $ctx['company_id'], $user_id );
			ccp_set_user_wallet_balance( $ctx['company_id'], $user_id, $limit );
		}

		/**
		 * Action to create a new user update.
		 *
		 * @since 3.4.0
		 *
		 * @param int $user_id The user ID.
		 */
		do_action( 'ccp_create_new_user_update', $user_id );

		wp_send_json_success(
			array(
				'message' => __( 'User added successfully.', 'woocommerce-wholesale-pricing' ),
			)
		);
	}

	/**
	 * Update a company user's first and last name.
	 *
	 * @return void
	 */
	public function update_company_user() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		$ctx = $this->get_manage_context();
		if ( ! $ctx ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to manage company users.', 'woocommerce-wholesale-pricing' ) ),
				403
			);
		}

		$post           = function_exists( 'ccp_post_data' ) ? ccp_post_data() : array();
		$target_user_id = isset( $post['user_id'] ) ? absint( $post['user_id'] ) : 0;
		$first_name     = isset( $post['account_first_name'] ) ? sanitize_text_field( $post['account_first_name'] ) : '';
		$last_name      = isset( $post['account_last_name'] ) ? sanitize_text_field( $post['account_last_name'] ) : '';

		if ( empty( $target_user_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid user.', 'woocommerce-wholesale-pricing' ) ) );
		}

		$target_company_id = absint( get_user_meta( $target_user_id, 'ccp_company_id', true ) );
		if ( $target_company_id !== $ctx['company_id'] ) {
			wp_send_json_error( array( 'message' => __( 'User does not belong to your company.', 'woocommerce-wholesale-pricing' ) ) );
		}

		if ( '' === $first_name ) {
			wp_send_json_error( array( 'message' => __( 'First name is required.', 'woocommerce-wholesale-pricing' ) ) );
		}
		if ( '' === $last_name ) {
			wp_send_json_error( array( 'message' => __( 'Last name is required.', 'woocommerce-wholesale-pricing' ) ) );
		}

		$display_name = trim( $first_name . ' ' . $last_name );
		$result       = wp_update_user(
			array(
				'ID'           => $target_user_id,
				'first_name'   => $first_name,
				'last_name'    => $last_name,
				'display_name' => $display_name,
			)
		);

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		/**
		 * Action to update a company user.
		 *
		 * @since 3.4.0
		 *
		 * @param int $target_user_id The user ID.
		 * @param array $ctx The context array.
		 */
		do_action( 'ccp_update_company_user', $target_user_id, $ctx );

		wp_send_json_success(
			array(
				'message' => __( 'User updated successfully.', 'woocommerce-wholesale-pricing' ),
			)
		);
	}

	/**
	 * Remove a member from the company (does not delete the WP user).
	 *
	 * @return void
	 */
	public function remove_company_member() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		$ctx = $this->get_manage_context();
		if ( ! $ctx ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to manage company users.', 'woocommerce-wholesale-pricing' ) ),
				403
			);
		}

		$post           = function_exists( 'ccp_post_data' ) ? ccp_post_data() : array();
		$target_user_id = isset( $post['user_id'] ) ? absint( $post['user_id'] ) : 0;

		if ( empty( $target_user_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid user.', 'woocommerce-wholesale-pricing' ) ) );
		}

		if ( (int) $target_user_id === (int) $ctx['user_id'] ) {
			wp_send_json_error( array( 'message' => __( 'You cannot remove yourself.', 'woocommerce-wholesale-pricing' ) ) );
		}

		$target_company_id = absint( get_user_meta( $target_user_id, 'ccp_company_id', true ) );
		if ( $target_company_id !== $ctx['company_id'] ) {
			wp_send_json_error( array( 'message' => __( 'User does not belong to your company.', 'woocommerce-wholesale-pricing' ) ) );
		}

		$target_role = (string) get_user_meta( $target_user_id, 'ccp_company_role', true );
		if ( 'ccp_member' !== $target_role ) {
			wp_send_json_error( array( 'message' => __( 'Only members can be removed from the company.', 'woocommerce-wholesale-pricing' ) ) );
		}

		ccp_remove_user_from_company_lists( $target_user_id, $ctx['company_id'] );
		ccp_clear_user_company_assignment( $target_user_id );

		wp_send_json_success(
			array(
				'message' => __( 'Member removed from the company.', 'woocommerce-wholesale-pricing' ),
			)
		);
	}
}
