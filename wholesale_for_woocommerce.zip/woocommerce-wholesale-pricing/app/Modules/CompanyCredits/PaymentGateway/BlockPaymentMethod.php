<?php
/**
 * Block checkout registration for Company Credit Payment.
 *
 * @package WooCommerceWholesalePricing\App\Modules\CompanyCredits\PaymentGateway
 */

namespace WooCommerceWholesalePricing\App\Modules\CompanyCredits\PaymentGateway;

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

/**
 * Registers company_credit_payment with WooCommerce Blocks.
 *
 * @extends AbstractPaymentMethodType
 */
class BlockPaymentMethod extends AbstractPaymentMethodType {

	/**
	 * Payment method name/id.
	 *
	 * @var string
	 */
	protected $name = 'company_credit_payment';

	/**
	 * Gateway settings.
	 *
	 * @var array
	 */
	protected $settings = array();

	/**
	 * Initialize settings from the classic gateway.
	 *
	 * @return void
	 */
	public function initialize() {
		$payment_gateways = WC()->payment_gateways()->payment_gateways();
		$title            = '';
		$description      = '';

		if ( isset( $payment_gateways[ $this->name ] ) ) {
			$title       = isset( $payment_gateways[ $this->name ]->settings['title'] ) ? $payment_gateways[ $this->name ]->settings['title'] : '';
			$description = isset( $payment_gateways[ $this->name ]->settings['description'] ) ? $payment_gateways[ $this->name ]->settings['description'] : '';
		}

		$this->settings = get_option(
			'woocommerce_' . $this->name . '_settings',
			array(
				'title'       => $title,
				'description' => $description,
			)
		);
	}

	/**
	 * Whether the payment method is available.
	 *
	 * @return bool
	 */
	public function is_active() {
		$payment_gateways = WC()->payment_gateways()->payment_gateways();

		if ( ! isset( $payment_gateways[ $this->name ] ) ) {
			return false;
		}

		return $payment_gateways[ $this->name ]->is_available();
	}

	/**
	 * Register and return frontend script handles.
	 *
	 * @return string[]
	 */
	public function get_payment_method_script_handles() {
		$asset_path   = WWP_PLUGIN_PATH . 'build/company-credits/payment-gateway/index.asset.php';
		$version      = WWP_VERSION;
		$dependencies = array();

		if ( file_exists( $asset_path ) ) {
			$asset        = include $asset_path;
			$version      = is_array( $asset ) && isset( $asset['version'] ) ? $asset['version'] : $version;
			$dependencies = is_array( $asset ) && isset( $asset['dependencies'] ) ? $asset['dependencies'] : $dependencies;
		}

		wp_register_style(
			'wwp-ccp-checkout',
			WWP_PLUGIN_URL . 'public/css/company-credits/checkout.css',
			array(),
			WWP_VERSION
		);
		wp_enqueue_style( 'wwp-ccp-checkout' );

		wp_register_script(
			'wwp-ccp-company-credit-payment',
			WWP_PLUGIN_URL . 'build/company-credits/payment-gateway/index.js',
			$dependencies,
			$version,
			true
		);

		return array( 'wwp-ccp-company-credit-payment' );
	}

	/**
	 * Data passed to the payment method frontend script.
	 *
	 * @return array
	 */
	public function get_payment_method_data() {
		$available_credit = 0.0;
		$user_id          = get_current_user_id();
		$company_id       = absint( get_user_meta( $user_id, 'ccp_company_id', true ) );

		if ( ! empty( $company_id ) && $user_id && function_exists( 'ccp_get_user_wallet_balance' ) ) {
			$available_credit = (float) ccp_get_user_wallet_balance( $company_id, $user_id );
		}

		return array(
			'title'                   => isset( $this->settings['title'] ) ? $this->settings['title'] : '',
			'description'             => isset( $this->settings['description'] ) ? $this->settings['description'] : '',
			'availableCredit'         => $available_credit,
			'currencySymbol'          => html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401 ),
			'currencyCode'            => get_woocommerce_currency(),
			'decimals'                => wc_get_price_decimals(),
			'decimalSeparator'        => wc_get_price_decimal_separator(),
			'thousandSeparator'       => wc_get_price_thousand_separator(),
			'priceFormat'             => get_woocommerce_price_format(),
			'labelAvailable'          => __( 'Available Credit Balance:', 'woocommerce-wholesale-pricing' ),
			'labelOrderTotal'         => __( 'Order Total:', 'woocommerce-wholesale-pricing' ),
			'labelRemaining'          => __( 'Remaining Balance:', 'woocommerce-wholesale-pricing' ),
		);
	}
}
