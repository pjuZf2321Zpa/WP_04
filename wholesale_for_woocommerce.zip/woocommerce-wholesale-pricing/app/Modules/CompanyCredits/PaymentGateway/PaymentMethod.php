<?php
/**
 * Company Credit Payment gateway.
 *
 * @package WooCommerceWholesalePricing\App\Modules\CompanyCredits\PaymentGateway
 */

namespace WooCommerceWholesalePricing\App\Modules\CompanyCredits\PaymentGateway;

/**
 * WooCommerce payment gateway for company credit checkout.
 *
 * @extends \WC_Payment_Gateway
 */
class PaymentMethod extends \WC_Payment_Gateway {

	/**
	 * Instructions shown on thank-you page and emails.
	 *
	 * @var string
	 */
	public $instructions;

	/**
	 * Whether the thank-you credit summary was already rendered.
	 *
	 * @var bool
	 */
	protected $thankyou_summary_rendered = false;

	/**
	 * Constructor for the gateway.
	 *
	 * @param string $gateway_name Gateway display name.
	 */
	public function __construct( $gateway_name ) {
		$this->id           = strtolower( str_replace( ' ', '_', $gateway_name ) );
		
		/**
		 * Filter the company credits payment gateway icon.
		 *
		 * @since 3.4.0
		 *
		 * @param string $icon The icon.
		 */
		$this->icon         = apply_filters( 'ccp_payment_gateway_icon', '' );
		$this->has_fields   = true;
		$this->method_title = $gateway_name;

		$this->init_form_fields();
		$this->init_settings();

		$this->title        = $this->get_option( 'title' );
		$this->description  = $this->get_option( 'description' );
		$this->instructions = $this->get_option( 'instructions', $this->description );

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );
		add_action( 'woocommerce_order_details_before_order_table', array( $this, 'maybe_render_thankyou_summary_before_details' ), 5 );
		add_action( 'woocommerce_email_before_order_table', array( $this, 'email_instructions' ), 10, 3 );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'validate' ), 10, 2 );
		add_action( 'woocommerce_checkout_process', array( $this, 'validate_checkout_process' ) );
		add_action( 'woocommerce_store_api_checkout_update_order_from_request', array( $this, 'validate_store_api_checkout' ), 10, 2 );
	}

	/**
	 * Get current user's wallet balance for their company.
	 *
	 * @return array{company_id:int,user_id:int,wallet:float}
	 */
	protected function get_checkout_wallet_context() {
		$user_id    = get_current_user_id();
		$company_id = absint( get_user_meta( $user_id, 'ccp_company_id', true ) );
		$wallet     = 0.0;

		if ( $company_id && $user_id && function_exists( 'ccp_get_user_wallet_balance' ) ) {
			$wallet = (float) ccp_get_user_wallet_balance( $company_id, $user_id );
		}

		return array(
			'company_id' => $company_id,
			'user_id'    => $user_id,
			'wallet'     => $wallet,
		);
	}

	/**
	 * Extract payment method from classic or Store API checkout requests.
	 *
	 * @param mixed $request Request or posted checkout data.
	 * @return string
	 */
	protected function get_request_payment_method( $request ) {
		if ( ! is_object( $request ) && ! is_array( $request ) ) {
			return '';
		}

		if ( is_array( $request ) && ! empty( $request['payment_method'] ) ) {
			return (string) $request['payment_method'];
		}

		if ( is_object( $request ) && method_exists( $request, 'get_param' ) ) {
			$method = $request->get_param( 'payment_method' );
			if ( ! empty( $method ) ) {
				return (string) $method;
			}
		}

		if ( is_object( $request ) && method_exists( $request, 'get_json_params' ) ) {
			$params = $request->get_json_params();
			if ( ! empty( $params['payment_method'] ) ) {
				return (string) $params['payment_method'];
			}
		}

		return '';
	}

	/**
	 * Run shared company credit checkout validations.
	 *
	 * @param float            $total Order/cart total.
	 * @param \WC_Order|null   $order Optional order for line-item validation.
	 * @return string|null Error message or null when valid.
	 */
	protected function run_checkout_validations( $total, $order = null ) {
		$ctx = $this->get_checkout_wallet_context();

		if ( empty( $ctx['company_id'] ) ) {
			/**
			 * Filter the company credits message failed.
			 *
			 * @since 3.4.0
			 *
			 * @param string $message The message.
			 * @param array $ctx The context array.
			 */
			return apply_filters(
				'ccp_company_credits_message_failed',
				__( 'You Can not use this payment gateway', 'woocommerce-wholesale-pricing' )
			);
		}

		if ( function_exists( 'ccp_validate_cart_for_company_credit' ) ) {
			$restriction = ccp_validate_cart_for_company_credit( $ctx['company_id'], null, $order );
			if ( is_wp_error( $restriction ) ) {
				return $restriction->get_error_message();
			}
		}

		if ( $ctx['wallet'] <= 0 || $ctx['wallet'] < $total ) {
			
			/**
			 * Filter the company credits message funds.
			 *
			 * @since 3.4.0
			 *
			 * @param string $message The message.
			 * @param array $ctx The context array.
			 * @param float $total The total.
			 */
			return apply_filters(
				'ccp_company_credits_message_funds',
				__( 'Insufficient Funds', 'woocommerce-wholesale-pricing' ),
				$ctx,
				$total
			);
		}

		return null;
	}

	/**
	 * Validate block checkout before order is created.
	 *
	 * @param \WC_Order        $order   Order object.
	 * @param \WP_REST_Request $request Request object.
	 * @return void
	 */
	public function validate_store_api_checkout( $order, $request ) {
		if ( 'company_credit_payment' !== $this->get_request_payment_method( $request ) ) {
			return;
		}

		$total = $order instanceof \WC_Order
			? (float) $order->get_total()
			: ( WC()->cart ? (float) WC()->cart->get_total( 'edit' ) : 0 );
		$message = $this->run_checkout_validations( $total, $order instanceof \WC_Order ? $order : null );

		if ( null === $message ) {
			return;
		}

		if ( class_exists( '\Automattic\WooCommerce\StoreApi\Exceptions\RouteException' ) ) {
			throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException(
				'woocommerce_rest_checkout_invalid_company_credit',
				esc_html( $message ),
				400
			);
		}

		wc_add_notice( $message, 'error' );
	}

	/**
	 * Whether this gateway is visible for the current company user.
	 *
	 * Product/category restrictions are validated on checkout, not here.
	 *
	 * @return bool
	 */
	public function is_available() {
		if ( ! parent::is_available() ) {
			return false;
		}

		$ctx = $this->get_checkout_wallet_context();
		if ( empty( $ctx['company_id'] ) || empty( $ctx['user_id'] ) ) {
			return false;
		}

		$role = get_user_meta( $ctx['user_id'], 'ccp_company_role', true );

		return in_array( $role, array( 'ccp_owner', 'ccp_manager', 'ccp_member' ), true );
	}

	/**
	 * Validate classic checkout submission.
	 *
	 * @param array     $payment_method Posted payment data.
	 * @param \WP_Error $errors Validation errors.
	 * @return void
	 */
	public function validate( $payment_method, $errors ) {
		
		/**
		 * Action to validate company credit payment checkout.
		 *
		 * @since 3.4.0
		 *
		 * @param array $payment_method Posted payment data.
		 * @param \WP_Error $errors Validation errors.
		 */
		do_action( 'company_credit_payment_checkout_validation', $payment_method, $errors );

		if ( 'company_credit_payment' !== $this->get_request_payment_method( $payment_method ) ) {
			return;
		}

		$total   = WC()->cart ? (float) WC()->cart->get_total( 'edit' ) : 0;
		$message = $this->run_checkout_validations( $total );

		if ( null !== $message ) {
			$errors->add( 'validation', $message );
		}
	}

	/**
	 * Validate classic checkout before order creation.
	 *
	 * @return void
	 */
	public function validate_checkout_process() {
		if ( ! isset( $_POST['payment_method'] ) || 'company_credit_payment' !== wc_clean( wp_unslash( $_POST['payment_method'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return;
		}

		$total   = WC()->cart ? (float) WC()->cart->get_total( 'edit' ) : 0;
		$message = $this->run_checkout_validations( $total );

		if ( null !== $message ) {
			wc_add_notice( $message, 'error' );
		}
	}

	/**
	 * Initialize gateway settings fields.
	 *
	 * @return void
	 */
	public function init_form_fields() {
		
		/**
		 * Filter the payment form fields.
		 *
		 * @since 3.4.0
		 *
		 * @param array $form_fields The payment form fields.
		 */
		$this->form_fields = apply_filters(
			'ccp_payment_form_fields',
			array(
				'enabled'     => array(
					'title'   => __( 'Enable/Disable', 'woocommerce-wholesale-pricing' ),
					'type'    => 'checkbox',
					'label'   => 'Enable ' . $this->method_title,
					'default' => 'yes',
				),
				'title'       => array(
					'title'       => __( 'Title', 'woocommerce-wholesale-pricing' ),
					'type'        => 'text',
					'description' => __( 'This controls the title for the payment method the customer sees during checkout.', 'woocommerce-wholesale-pricing' ),
					'default'     => $this->method_title,
					'desc_tip'    => true,
				),
				'description' => array(
					'title'       => __( 'Description', 'woocommerce-wholesale-pricing' ),
					'type'        => 'textarea',
					'description' => __( 'Payment method description that the customer will see on your checkout.', 'woocommerce-wholesale-pricing' ),
					'default'     => null,
					'desc_tip'    => true,
				),
			)
		);
	}

	/**
	 * Output credit payment summary (and optional instructions) on the thank-you page.
	 *
	 * Hooked after the order overview and before order details.
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public function thankyou_page( $order_id = 0 ) {
		$order = wc_get_order( $order_id );
		if ( $order instanceof \WC_Order && 'company_credit_payment' === $order->get_payment_method() ) {
			$this->render_thankyou_credit_summary( $order );
		}

		if ( $this->instructions ) {
			echo wp_kses_post( wpautop( wptexturize( $this->instructions ) ) );
		}
	}

	/**
	 * Fallback for block order-confirmation templates that skip gateway thankyou hooks.
	 *
	 * @param \WC_Order $order Order object.
	 * @return void
	 */
	public function maybe_render_thankyou_summary_before_details( $order ) {
		if ( $this->thankyou_summary_rendered ) {
			return;
		}

		if ( ! function_exists( 'is_order_received_page' ) || ! is_order_received_page() ) {
			return;
		}

		if ( ! $order instanceof \WC_Order || $this->id !== $order->get_payment_method() ) {
			return;
		}

		$this->render_thankyou_credit_summary( $order );
	}

	/**
	 * Render the Figma credit payment summary card.
	 *
	 * @param \WC_Order $order Order object.
	 * @return void
	 */
	protected function render_thankyou_credit_summary( $order ) {
		if ( $this->thankyou_summary_rendered ) {
			return;
		}
		$this->thankyou_summary_rendered = true;
		$credits_used = (float) $order->get_meta( '_ccp_credits_used' );
		if ( $credits_used <= 0 ) {
			$held = (float) $order->get_meta( '_ccp_wallet_held' );
			$credits_used = $held > 0 ? $held : (float) $order->get_total();
		}

		$previous_balance = $order->get_meta( '_ccp_previous_wallet_balance' );
		$available_balance = $order->get_meta( '_ccp_available_wallet_balance' );

		if ( '' === $previous_balance || '' === $available_balance ) {
			$company_id = absint( $order->get_meta( '_ccp_company_id' ) );
			$buyer_id   = absint( $order->get_meta( '_ccp_buyer_user_id' ) );
			if ( empty( $buyer_id ) ) {
				$buyer_id = absint( $order->get_user_id() );
			}

			$current = ( $company_id && $buyer_id && function_exists( 'ccp_get_user_wallet_balance' ) )
				? (float) ccp_get_user_wallet_balance( $company_id, $buyer_id )
				: 0.0;

			if ( '' === $available_balance ) {
				$available_balance = $current;
			}
			if ( '' === $previous_balance ) {
				$previous_balance = $current + $credits_used;
			}
		}

		wwp_view(
			'frontend.company-credits.thankyou-credit-summary',
			array(
				'credits_used'         => (float) $credits_used,
				'previous_balance'     => (float) $previous_balance,
				'available_balance'    => (float) $available_balance,
				'is_pending_approval'  => $order->has_status( 'pending-approval' ),
			),
			true
		);
	}

	/**
	 * Add instructions to customer emails.
	 *
	 * @param \WC_Order $order Order object.
	 * @param bool      $sent_to_admin Whether email is sent to admin.
	 * @param bool      $plain_text Plain text email.
	 * @return void
	 */
	public function email_instructions( $order, $sent_to_admin, $plain_text = false ) {
		unset( $plain_text );

		$payment_method = is_callable( array( $order, 'get_payment_method' ) ) ? $order->get_payment_method() : $order->payment_method;

		if ( $this->instructions && ! $sent_to_admin && $this->id === $payment_method && $order->has_status( 'on-hold' ) ) {
			echo wp_kses_post( wpautop( wptexturize( $this->instructions ) ) ) . PHP_EOL;
		}
	}

	/**
	 * Process payment against the buyer's user wallet.
	 *
	 * @param int $order_id Order ID.
	 * @return array
	 */
	public function process_payment( $order_id ) {
		$order          = wc_get_order( $order_id );
		$payment_method = $order->get_payment_method();
		$ctx            = $this->get_checkout_wallet_context();
		$total          = (float) $order->get_total();

		if ( empty( $ctx['company_id'] ) || 'company_credit_payment' !== $payment_method ) {
			$order->update_status( 'cancelled', $this->method_title );
			$order->save();
			return array(
				'result'   => 'failure',
				'messages' => 'Company Id Missing',
			);
		}

		if ( function_exists( 'ccp_validate_cart_for_company_credit' ) ) {
			$restriction = ccp_validate_cart_for_company_credit( $ctx['company_id'], null, $order );
			if ( is_wp_error( $restriction ) ) {
				$order->update_status( 'cancelled', $restriction->get_error_message() );
				$order->save();
				wc_add_notice( $restriction->get_error_message(), 'error' );
				return array(
					'result'   => 'failure',
					'messages' => $restriction->get_error_message(),
				);
			}
		}

		if ( $ctx['wallet'] <= 0 || $ctx['wallet'] < $total ) {
			$order->update_status( 'cancelled', __( 'Insufficient wallet credits.', 'woocommerce-wholesale-pricing' ) );
			$order->save();
			wc_add_notice( __( 'Insufficient Funds', 'woocommerce-wholesale-pricing' ), 'error' );
			return array(
				'result'   => 'failure',
				'messages' => __( 'Insufficient Funds', 'woocommerce-wholesale-pricing' ),
			);
		}

		$previous_balance = (float) $ctx['wallet'];
		$new_balance      = ccp_decrease_user_wallet_balance( $ctx['company_id'], $ctx['user_id'], $total );
		if ( false === $new_balance ) {
			$order->update_status( 'cancelled', __( 'Insufficient wallet credits.', 'woocommerce-wholesale-pricing' ) );
			$order->save();
			wc_add_notice( __( 'Insufficient Funds', 'woocommerce-wholesale-pricing' ), 'error' );
			return array(
				'result'   => 'failure',
				'messages' => __( 'Insufficient Funds', 'woocommerce-wholesale-pricing' ),
			);
		}

		// Debit company pool and keep an order-linked log for wallet consumption reporting.
		ccp_add_company_credit(
			array(
				'company_id'   => $ctx['company_id'],
				'order_id'     => $order_id,
				'amount'       => -1 * $total,
				'event'        => __( 'Company Credit Consumed', 'woocommerce-wholesale-pricing' ),
				'user_id'      => $ctx['user_id'],
				'affects_pool' => true,
			)
		);

		$requires_approval = ccp_company_requires_order_approval( $ctx['company_id'] );

		$order->update_meta_data( '_ccp_company_id', $ctx['company_id'] );
		$order->update_meta_data( '_ccp_buyer_user_id', $ctx['user_id'] );
		$order->update_meta_data( '_ccp_wallet_held', $total );
		$order->update_meta_data( '_ccp_credits_used', $total );
		$order->update_meta_data( '_ccp_previous_wallet_balance', $previous_balance );
		$order->update_meta_data( '_ccp_available_wallet_balance', (float) $new_balance );
		$order->update_meta_data( '_ccp_requires_approval', $requires_approval ? 'yes' : 'no' );
		// Keep legacy meta key for company order queries.
		$order->update_meta_data( 'company_id', $ctx['company_id'] );

		if ( $requires_approval ) {
			$order->update_status(
				'pending-approval',
				__( 'Company credit order awaiting owner/manager approval. Wallet credits held.', 'woocommerce-wholesale-pricing' )
			);
		} else {
			$order->update_status( 'processing', $this->method_title );
			wc_reduce_stock_levels( $order_id );
			$order->update_meta_data( '_ccp_wallet_held', 0 );
		}

		WC()->cart->empty_cart();
		$order->save();

		return array(
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order ),
		);
	}

	/**
	 * Output gateway description and wallet summary on classic checkout.
	 *
	 * @return void
	 */
	public function payment_fields() {
		$description = $this->get_description();
		if ( $description ) {
			echo wp_kses_post( wpautop( wptexturize( $description ) ) );
		}

		$ctx = $this->get_checkout_wallet_context();
		if ( empty( $ctx['company_id'] ) ) {
			return;
		}

		$available   = $ctx['wallet'];
		$order_total = ( WC()->cart ) ? (float) WC()->cart->get_total( 'edit' ) : 0;
		$remaining   = $available - $order_total;
		?>
		<div class="wwp-ccp-payment-summary">
			<div class="wwp-ccp-payment-summary__rows">
				<div class="wwp-ccp-payment-summary__row">
					<span class="wwp-ccp-payment-summary__label"><?php esc_html_e( 'Available Credit Balance:', 'woocommerce-wholesale-pricing' ); ?></span>
					<span class="wwp-ccp-payment-summary__value wwp-ccp-payment-summary__value--available"><?php echo wp_kses_post( wc_price( $available ) ); ?></span>
				</div>
				<div class="wwp-ccp-payment-summary__row">
					<span class="wwp-ccp-payment-summary__label"><?php esc_html_e( 'Order Total:', 'woocommerce-wholesale-pricing' ); ?></span>
					<span class="wwp-ccp-payment-summary__value"><?php echo wp_kses_post( wc_price( $order_total ) ); ?></span>
				</div>
				<div class="wwp-ccp-payment-summary__row wwp-ccp-payment-summary__row--remaining">
					<span class="wwp-ccp-payment-summary__label"><?php esc_html_e( 'Remaining Balance:', 'woocommerce-wholesale-pricing' ); ?></span>
					<span class="wwp-ccp-payment-summary__value wwp-ccp-payment-summary__value--remaining"><?php echo wp_kses_post( wc_price( $remaining ) ); ?></span>
				</div>
			</div>
		</div>
		<?php
	}
}
