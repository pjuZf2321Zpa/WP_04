<?php
/**
 * Credit request AJAX endpoints.
 *
 * @package WooCommerceWholesalePricing
 */

namespace WooCommerceWholesalePricing\App\Modules\CompanyCredits;

/**
 * Submit / approve / decline dual-queue company credit requests.
 */
class CreditRequestsAjax {

	/**
	 * CreditRequestsAjax constructor.
	 */
	public function __construct() {
		add_action( 'wp_ajax_ccp_submit_credit_request', array( $this, 'submit_request' ) );
		add_action( 'wp_ajax_ccp_approve_credit_request', array( $this, 'approve_request' ) );
		add_action( 'wp_ajax_ccp_decline_credit_request', array( $this, 'decline_request' ) );
	}

	/**
	 * Submit a credit request from My Account.
	 *
	 * @return void
	 */
	public function submit_request() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		if ( ! is_user_logged_in() || ! authentication_role( 'credit' ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'You are not allowed to request credit.', 'woocommerce-wholesale-pricing' ),
				),
				403
			);
		}

		$user_id    = get_current_user_id();
		$company_id = absint( get_user_meta( $user_id, 'ccp_company_id', true ) );
		$role       = get_user_meta( $user_id, 'ccp_company_role', true );
		$amount     = isset( $_POST['amount'] ) ? (float) wc_clean( wp_unslash( $_POST['amount'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$reason     = isset( $_POST['reason'] ) ? sanitize_textarea_field( wp_unslash( $_POST['reason'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		$company_slug = function_exists( 'wwp_env' ) ? wwp_env()->get( 'company_credits_slug' ) : 'ccp_company';
		if ( empty( $company_id ) || get_post_type( $company_id ) !== $company_slug ) {
			wp_send_json_error(
				array(
					'message' => __( 'You are not associated with any company.', 'woocommerce-wholesale-pricing' ),
				),
				400
			);
		}

		if ( $amount <= 0 ) {
			wp_send_json_error(
				array(
					'message' => __( 'Please enter a valid credit amount.', 'woocommerce-wholesale-pricing' ),
				),
				400
			);
		}

		if ( '' === trim( $reason ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Please provide a reason for your request.', 'woocommerce-wholesale-pricing' ),
				),
				400
			);
		}

		// Owners request from website admin; managers/members request from company owner.
		$request_to = ( 'ccp_owner' === $role ) ? 'admin' : 'owner';
		if ( ! in_array( $role, array( 'ccp_owner', 'ccp_manager', 'ccp_member' ), true ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Invalid company role.', 'woocommerce-wholesale-pricing' ),
				),
				400
			);
		}

		$user = wp_get_current_user();
		$row  = array(
			'user_id'         => $user_id,
			'name'            => $user->display_name,
			'email'           => $user->user_email,
			'current_limit'   => ccp_get_user_wallet_balance( $company_id, $user_id ),
			'requested_limit' => $amount,
			'reason'          => $reason,
			'status'          => 'pending',
			'request_to'      => $request_to,
			'requested_on'    => gmdate( 'Y-m-d H:i:s' ),
			'reviewed_by'     => null,
			'reviewed_on'     => null,
		);

		$requests   = ccp_get_credit_requests( $company_id );
		$requests[] = $row;
		ccp_save_credit_requests( $company_id, $requests );

		$message = ( 'admin' === $request_to )
			? __( 'Credit request submitted to the store admin.', 'woocommerce-wholesale-pricing' )
			: __( 'Credit request submitted to the company owner.', 'woocommerce-wholesale-pricing' );

		wp_send_json_success(
			array(
				'message' => $message,
			)
		);
	}

	/**
	 * Approve a pending credit request.
	 *
	 * @return void
	 */
	public function approve_request() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		$company_id = isset( $_POST['company_id'] ) ? absint( $_POST['company_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$index      = isset( $_POST['index'] ) ? absint( $_POST['index'] ) : -1; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		$requests = ccp_get_credit_requests( $company_id );
		if ( ! isset( $requests[ $index ] ) || ! is_array( $requests[ $index ] ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Credit request not found.', 'woocommerce-wholesale-pricing' ),
				),
				404
			);
		}

		$request    = $requests[ $index ];
		$request_to = isset( $request['request_to'] ) && 'admin' === $request['request_to'] ? 'admin' : 'owner';

		if ( ! ccp_user_can_review_credit_requests( $company_id, $request_to ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'You are not allowed to review credit requests.', 'woocommerce-wholesale-pricing' ),
				),
				403
			);
		}

		$status = isset( $request['status'] ) ? $request['status'] : '';
		if ( 'pending' !== $status ) {
			wp_send_json_error(
				array(
					'message' => __( 'Only pending requests can be approved.', 'woocommerce-wholesale-pricing' ),
				),
				400
			);
		}

		$amount = isset( $request['requested_limit'] ) ? (float) $request['requested_limit'] : 0;
		if ( $amount <= 0 ) {
			wp_send_json_error(
				array(
					'message' => __( 'Invalid requested amount.', 'woocommerce-wholesale-pricing' ),
				),
				400
			);
		}

		if ( 'admin' === $request_to ) {
			$result = ccp_add_company_credit(
				array(
					'company_id' => $company_id,
					'order_id'   => '',
					'amount'     => $amount,
					'event'      => __( 'Credit Request Approved', 'woocommerce-wholesale-pricing' ),
				)
			);

			if ( true !== $result ) {
				wp_send_json_error(
					array(
						'message' => is_string( $result ) ? $result : __( 'Failed to add credit.', 'woocommerce-wholesale-pricing' ),
					),
					500
				);
			}
		} else {
			$pool      = ccp_company_credits( $company_id );
			$remaining = isset( $pool['remaining'] ) ? (float) $pool['remaining'] : 0;

			if ( $remaining < $amount ) {
				wp_send_json_error(
					array(
						'message' => sprintf(
							/* translators: %s: available company credit */
							__( 'Insufficient company credits to approve this request. Available: %s', 'woocommerce-wholesale-pricing' ),
							wc_format_decimal( $remaining, 2 )
						),
					),
					400
				);
			}

			$target_user_id = isset( $request['user_id'] ) ? absint( $request['user_id'] ) : 0;
			if ( empty( $target_user_id ) ) {
				wp_send_json_error(
					array(
						'message' => __( 'Invalid requester.', 'woocommerce-wholesale-pricing' ),
					),
					400
				);
			}

			// Raise both spendable wallet and configured credit limit.
			$previous_limit  = (float) ccp_get_effective_user_credit_limit( $company_id, $target_user_id );
			$previous_wallet = (float) ccp_get_user_wallet_balance( $company_id, $target_user_id );

			ccp_increase_user_credit_limit( $company_id, $target_user_id, $amount );
			ccp_increase_user_wallet_balance( $company_id, $target_user_id, $amount );

			$result = ccp_add_company_credit(
				array(
					'company_id' => $company_id,
					'order_id'   => '',
					'amount'     => -1 * $amount,
					'event'      => __( 'Credit Allocated to User', 'woocommerce-wholesale-pricing' ),
					'user_id'    => $target_user_id,
				)
			);

			if ( true !== $result ) {
				// Roll back wallet + limit if company log failed.
				ccp_set_user_wallet_balance( $company_id, $target_user_id, $previous_wallet );
				$user_limits = get_post_meta( $company_id, 'ccp_user_credit_limits', true );
				if ( ! is_array( $user_limits ) ) {
					$user_limits = array();
				}
				$user_limits[ $target_user_id ] = wc_format_decimal( $previous_limit, 2 );
				update_post_meta( $company_id, 'ccp_user_credit_limits', $user_limits );

				wp_send_json_error(
					array(
						'message' => is_string( $result ) ? $result : __( 'Failed to allocate credit.', 'woocommerce-wholesale-pricing' ),
					),
					500
				);
			}
		}

		$requests[ $index ]['status']      = 'approved';
		$requests[ $index ]['reviewed_by'] = get_current_user_id();
		$requests[ $index ]['reviewed_on'] = gmdate( 'Y-m-d H:i:s' );
		ccp_save_credit_requests( $company_id, $requests );

		wp_send_json_success(
			array(
				'message' => __( 'Credit request approved.', 'woocommerce-wholesale-pricing' ),
				'status'  => 'approved',
				'index'   => $index,
			)
		);
	}

	/**
	 * Decline a pending credit request.
	 *
	 * @return void
	 */
	public function decline_request() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		$company_id = isset( $_POST['company_id'] ) ? absint( $_POST['company_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$index      = isset( $_POST['index'] ) ? absint( $_POST['index'] ) : -1; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		$requests = ccp_get_credit_requests( $company_id );
		if ( ! isset( $requests[ $index ] ) || ! is_array( $requests[ $index ] ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Credit request not found.', 'woocommerce-wholesale-pricing' ),
				),
				404
			);
		}

		$request    = $requests[ $index ];
		$request_to = isset( $request['request_to'] ) && 'admin' === $request['request_to'] ? 'admin' : 'owner';

		if ( ! ccp_user_can_review_credit_requests( $company_id, $request_to ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'You are not allowed to review credit requests.', 'woocommerce-wholesale-pricing' ),
				),
				403
			);
		}

		$status = isset( $request['status'] ) ? $request['status'] : '';
		if ( 'pending' !== $status ) {
			wp_send_json_error(
				array(
					'message' => __( 'Only pending requests can be declined.', 'woocommerce-wholesale-pricing' ),
				),
				400
			);
		}

		$requests[ $index ]['status']      = 'declined';
		$requests[ $index ]['reviewed_by'] = get_current_user_id();
		$requests[ $index ]['reviewed_on'] = gmdate( 'Y-m-d H:i:s' );
		ccp_save_credit_requests( $company_id, $requests );

		wp_send_json_success(
			array(
				'message' => __( 'Credit request declined.', 'woocommerce-wholesale-pricing' ),
				'status'  => 'declined',
				'index'   => $index,
			)
		);
	}
}
