<?php
/**
 * Custom WooCommerce order status: Pending Approval.
 *
 * @package WooCommerceWholesalePricing
 */

namespace WooCommerceWholesalePricing\App\Modules\CompanyCredits;

/**
 * Registers wc-pending-approval for company credit order approval flow.
 *
 * Note: full status key must stay within 20 characters (post_status column limit),
 * so the slug is "pending-approval" (19 chars with the wc- prefix).
 */
class OrderStatus {

	/**
	 * Status slug without wc- prefix.
	 *
	 * @var string
	 */
	const STATUS = 'pending-approval';

	/**
	 * OrderStatus constructor.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'register_post_status' ), 20 );
		add_filter( 'wc_order_statuses', array( $this, 'add_to_order_statuses' ) );
		add_filter( 'woocommerce_register_shop_order_post_statuses', array( $this, 'register_shop_order_status' ) );
	}

	/**
	 * Register the custom post status.
	 *
	 * @return void
	 */
	public function register_post_status() {
		register_post_status(
			'wc-' . self::STATUS,
			array(
				'label'                     => _x( 'Pending Approval', 'Order status', 'woocommerce-wholesale-pricing' ),
				'public'                    => true,
				'exclude_from_search'       => false,
				'show_in_admin_all_list'    => true,
				'show_in_admin_status_list' => true,
				/* translators: %s: number of orders */
				'label_count'               => _n_noop(
					'Pending Approval <span class="count">(%s)</span>',
					'Pending Approval <span class="count">(%s)</span>',
					'woocommerce-wholesale-pricing'
				),
			)
		);
	}

	/**
	 * Add status to WooCommerce order statuses list.
	 *
	 * @param array $statuses Existing statuses.
	 * @return array
	 */
	public function add_to_order_statuses( $statuses ) {
		$new = array();
		foreach ( $statuses as $key => $label ) {
			$new[ $key ] = $label;
			if ( 'wc-processing' === $key ) {
				$new[ 'wc-' . self::STATUS ] = _x( 'Pending Approval', 'Order status', 'woocommerce-wholesale-pricing' );
			}
		}

		if ( ! isset( $new[ 'wc-' . self::STATUS ] ) ) {
			$new[ 'wc-' . self::STATUS ] = _x( 'Pending Approval', 'Order status', 'woocommerce-wholesale-pricing' );
		}

		return $new;
	}

	/**
	 * Register status args for HPOS / shop order post type.
	 *
	 * @param array $statuses Statuses.
	 * @return array
	 */
	public function register_shop_order_status( $statuses ) {
		$statuses[ 'wc-' . self::STATUS ] = array(
			'label'                     => _x( 'Pending Approval', 'Order status', 'woocommerce-wholesale-pricing' ),
			'public'                    => true,
			'exclude_from_search'       => false,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			/* translators: %s: number of orders */
			'label_count'               => _n_noop(
				'Pending Approval <span class="count">(%s)</span>',
				'Pending Approval <span class="count">(%s)</span>',
				'woocommerce-wholesale-pricing'
			),
		);

		return $statuses;
	}
}
