<?php

namespace WooCommerceWholesalePricing\App\Modules\SalesAgent;

use WooCommerceWholesalePricing\App\Models\SalesAgent\AgentCommission;
use WooCommerceWholesalePricing\App\Models\SalesAgent\Commission;
use WooCommerceWholesalePricing\App\Strategies\Init;

class Request extends Init {

	public function __construct() {
		parent::__construct();
	}

	public function register() {
		$this->commission_list_export_actions();
		$this->commission_delete_actions();
	}

	public function commission_list_export_actions() {

		if ( isset( $_REQUEST['export_commissions'], $_REQUEST['export_commissions_nonce'] ) && 'Export' == sanitize_text_field( $_REQUEST['export_commissions'] ) && wp_verify_nonce( sanitize_text_field( $_REQUEST['export_commissions_nonce'] ), '_export_commissions_nonce' ) ) {
			global $wpdb;
			// temp folder of export
			$tmp_folder = get_temp_dir();

			// whre  condition
			$where = filter_where_condtion();
			// check if in commission end point
			$actual_link = ( isset( $_SERVER['HTTPS'] ) && isset( $_SERVER['HTTP_HOST'] ) && isset( $_SERVER['REQUEST_URI'] ) && 'on' === sanitize_text_field( $_SERVER['HTTPS'] ) ? 'https' : 'http' ) . '://' . sanitize_text_field( $_SERVER['HTTP_HOST'] ) . sanitize_text_field( $_SERVER['REQUEST_URI'] );

			if ( strpos( $actual_link, wc_get_endpoint_url( 'commissions' ) ) !== false ) {

				// get currnt agent id
				$agent_id       = Actions::is_agent();
				$where          = filter_where_condtion( $agent_id );
			}
			// connect to database
			$commission_db      = new AgentCommission();
			$select_commissions = $commission_db->get_commissions_by_agent_id( $where, false, false, false, 'agent' );

			// check export customer filter
			if ( isset( $_REQUEST['user-filter'] ) && ! empty( $_REQUEST['user-filter'] ) ) {
				$customer_id        = sanitize_text_field( $_REQUEST['user-filter'] );
				$select_commissions = $commission_db->get_commissions_by_agent_id( $where, false, false, $customer_id );
			}
			// colums of export
			$commission_columns = array(
				array(
					__( 'Agent Name', 'woocommerce-wholesale-pricing' ),
					__( 'Customer Name', 'woocommerce-wholesale-pricing' ),
					__( 'Order No#', 'woocommerce-wholesale-pricing' ),
					__( 'Date', 'woocommerce-wholesale-pricing' ),
					__( 'Commission', 'woocommerce-wholesale-pricing' ),
					__( 'Status', 'woocommerce-wholesale-pricing' ),
				),
			);
			// data export
			if ( $select_commissions ) {
				foreach ( $select_commissions as $commission ) {

					$order    = wc_get_order( $commission->order_id );
					$fullname = '-';
					if ( $order ) {
						$user_id = $order->get_customer_id();
						if ( $user_id ) {
							$customer = new \WC_Customer( $user_id );
							$fullname = trim( $customer->get_first_name() . ' ' . $customer->get_last_name() );
						} else {
							$fullname = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
						}
						if ( '' === $fullname ) {
							$fullname = 'Guest';
						}
					}

					$commission_columns[] = array(
						get_the_title( $commission->agent_id ),
						$fullname,
						$commission->order_id,
						$commission->create_date,
						$commission->commission_value,
						$commission->commission_status,
					);
				}
			}
			// export commissions
			$file_name = 'Commission.csv';
			header( 'content-Type: text/plain; charset=utf-8' );
			header( 'content-Disposition: attachment; filename="' . $file_name . '"' );
			header( 'Pragma: no-cache' );
			$_temp = fopen( $file_name, 'w' );
			// make it to make file translations to any languae
			fputs( $_temp, $bom = ( chr( 0xEF ) . chr( 0xBB ) . chr( 0xBF ) ) );

			foreach ( $commission_columns as $i => $row ) {
				fputcsv( $_temp, array_values( $row ), ',', '"', false );
			}
			readfile( $file_name );
			unlink( $file_name );
			exit;
		}
	}

	public function commission_delete_actions() {
		if ( isset( $_REQUEST['delete_commission'] ) && ! empty( $_REQUEST['delete_commission'] ) ) {
			check_admin_referer( 'delete_commission_nonce' );


			$delete_comiision_id = sanitize_text_field( $_REQUEST['delete_commission'] );
			// delete commission
			$commission_db = new AgentCommission();
			$commission_db->delete_commission( $delete_comiision_id );

			// after delete commission delete data on order
			$order_id = isset( $_REQUEST['delete_order'] ) ? sanitize_text_field( $_REQUEST['delete_order'] ) : '';
			$order    = $order_id ? wc_get_order( $order_id ) : false;
			if ( $order ) {
				$order->delete_meta_data( 'sales_agent' );
				$order->delete_meta_data( 'sales_agent_commision' );
				$order->save();
			}

			// prepare url for redirect
			$actual_link = ( isset( $_SERVER['HTTPS'] ) && isset( $_SERVER['HTTP_HOST'] ) && isset( $_SERVER['REQUEST_URI'] ) && 'on' === sanitize_text_field( $_SERVER['HTTPS'] ) ? 'https' : 'http' ) . '://' . sanitize_text_field( $_SERVER['HTTP_HOST'] ) . sanitize_text_field( $_SERVER['REQUEST_URI'] );
			$actual_link = str_replace( '&delete_commission=' . $delete_comiision_id, '', $actual_link );
			$actual_link = str_replace( '?delete_commission=' . $delete_comiision_id, '', $actual_link );
			$actual_link = str_replace( '&delete_order=' . $order_id, '', $actual_link );

			// check no data rediecr to perious page
			if ( isset( $_REQUEST['paged'] ) && $_REQUEST['paged'] > 1 ) {
				$current_page       = sanitize_text_field( $_REQUEST['paged'] );
				$commission_in_page = count( $this->query( 1, $current_page ) );
				if ( 1 == $commission_in_page ) {

					$page        = $current_page - 1;
					$actual_link = str_replace( '&paged=' . $current_page, '&paged=' . $page, $actual_link );
				}
			}
			// in case commission end point
			if ( strpos( $actual_link, wc_get_endpoint_url( 'commissions' ) ) !== false ) {
				$actual_link = get_permalink( get_option( 'woocommerce_myaccount_page_id' ) ) . wc_get_endpoint_url( 'commissions' );
			}
			wp_safe_redirect( $actual_link );
			exit;
		}
	}

	public function query( $per_page, $currentPage ) {

		$offset = ( $currentPage - 1 ) * $per_page;
		$where  = filter_where_condtion();
		$commission_db = new AgentCommission();

		if ( isset( $_REQUEST['customer_id'] ) && isset( $_REQUEST['date_from'] ) && isset( $_REQUEST['date_to'] ) ) {
			$order = $this->order_condition_sortable();
			$rows  = $commission_db->query_commission_by_sort_sales_agent( $where, false, $offset, $per_page, $order, sanitize_text_field( $_REQUEST['customer_id'] ) );
		}

		// query and sort data
		if ( isset( $_REQUEST['orderby'] ) && 'sales_agent' == $_REQUEST['orderby'] ) {
			$sort_type = isset( $_REQUEST['order'] ) ? strtoupper( sanitize_text_field( $_REQUEST['order'] ) ) : '';
			$rows      = $commission_db->query_commission_by_sort_sales_agent( $where, $sort_type, $offset, $per_page, false );
		} elseif ( isset( $_REQUEST['customer_id'] ) && empty( $_REQUEST['date_from'] ) && empty( $_REQUEST['date_to'] ) ) {
			$sort_type = isset( $_REQUEST['order'] ) ? strtoupper( sanitize_text_field( $_REQUEST['order'] ) ) : '';
			$rows      = $commission_db->query_commission_by_sort_sales_agent( $where, $sort_type, $offset, $per_page, false );
		} elseif ( isset( $_REQUEST['customer_id'] ) && isset( $_REQUEST['date_from'] ) && isset( $_REQUEST['date_to'] ) ) {
			$sort_type = isset( $_REQUEST['order'] ) ? strtoupper( sanitize_text_field( $_REQUEST['order'] ) ) : '';
			$rows      = $commission_db->query_commission_by_sort_sales_agent( $where, $sort_type, $offset, $per_page, false );
		} else {
			$order = $this->order_condition_sortable();
			if ( isset( $_REQUEST['agent_id'] ) ) {
				$rows = $commission_db->query_commission_by_sort_sales_agent( $where, false, $offset, $per_page, $order, sanitize_text_field( $_REQUEST['agent_id'] ) );
			}
		}

		/**
		* Filter.
		*
		* @since 1.0.4
		*/
		return apply_filters( 'after_get_commissions_list_data', $rows );
	}

	public function order_condition_sortable() {
		$sort = ' ORDER BY id DESC';
		if ( isset( $_REQUEST['order'] ) && ! empty( $_REQUEST['order'] ) ) {
			$sort_type = isset( $_REQUEST['order'] ) ? strtoupper( sanitize_text_field( $_REQUEST['order'] ) ) : '';
		}
		if ( isset( $_REQUEST['orderby'] ) && ! empty( $_REQUEST['order'] ) ) {

			switch ( $_REQUEST['orderby'] ) {
				case 'order_no':
					$sort = 'order_id';
					break;

				case 'oder_date':
					$sort = 'create_date';
					break;

				case 'status':
					$sort = 'commission_status';
					break;

				case 'commission':
					$sort = 'commission_value';
					break;
			}

			$sort = " ORDER BY $sort $sort_type";
		}
		return $sort;
	}
}
