<?php
namespace WooCommerceWholesalePricing\App\Modules\SalesAgent\Emails;

if ( ! class_exists( 'WC_Email' ) ) {
	require_once WC_ABSPATH . 'includes/emails/class-wc-email.php';
}

class AssigningAgent extends \WC_Email {

	public function __construct() {

		$this->id             = 'safw_assign_agent';
		$this->title          = __( 'SAFW Assigning Sales Agent', 'woocommerce-wholesale-pricing' );
		$this->description    = __( 'SAFW Assigning Sales Agent emails are sent to Sales Agent when user will assign to Sales Agent.', 'woocommerce-wholesale-pricing' );
		$this->template_base  = WWP_PLUGIN_PATH . 'resources/views/admin/sales-agent/';
		$this->template_html  = 'emails/safw-assign-agent-temp.php';
		$this->template_plain = 'emails/plain/safw-assign-agent-plain-temp.php';
		$this->customer_email = true;
		$this->placeholders   = array(
			'{user_name}'  => '',
			'{agent_name}' => '',
		);

		parent::__construct();

		add_action( 'safw_email_assign_agent', array( $this, 'trigger' ), 10, 2 );
	}

	public function trigger( $user_id, $agent_id ) {

		$this->setup_locale();

		if ( ! isset( $agent_id ) || empty( $agent_id ) ) {
			return;
		}

		$user_data     = new \WP_User( $user_id );
		$category_id   = get_post_meta( $agent_id, 'commission_category', true );
		$terms         = get_term( $category_id, 'commission_cat' );
		$agent_user_id = get_post_meta( $agent_id, 'assign_user', true );
		$agent_data    = new \WP_User( $agent_user_id );

		if ( ! $agent_data->exists() ) {
			return;
		}

		$this->recipient = $agent_data->user_email;

		$this->placeholders['{user_name}']           = $agent_data->display_name;
		$this->placeholders['{agent_name}']          = get_the_title( $agent_id );
		$this->placeholders['{commission_category}'] = ( ! is_wp_error( $terms ) && ! empty( $terms ) ) ? $terms->name : '';

		if ( $this->is_enabled() && $this->get_recipient() ) {
			$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
		}

		$this->restore_locale();
	}

	public function get_content_html() {
		$args = array(
			'email_heading'       => $this->get_heading(),
			'additional_content'  => $this->get_additional_content(),
			'email'               => $this,
			'site_title'          => $this->placeholders['{site_title}'],
			'site_address'        => $this->placeholders['{site_address}'],
			'site_url'            => $this->placeholders['{site_url}'],
			'user_name'           => $this->placeholders['{user_name}'],
			'agent_name'          => $this->placeholders['{agent_name}'],
			'commission_category' => $this->placeholders['{commission_category}'],
		);

		extract( $args );

		ob_start();
		include WWP_PLUGIN_PATH . 'resources/views/admin/sales-agent/' . $this->template_html;
		return ob_get_clean();
	}

	public function get_content_plain() {
		$args = array(
			'email_heading'       => $this->get_heading(),
			'additional_content'  => $this->get_additional_content(),
			'email'               => $this,
			'site_title'          => $this->placeholders['{site_title}'],
			'site_address'        => $this->placeholders['{site_address}'],
			'site_url'            => $this->placeholders['{site_url}'],
			'user_name'           => $this->placeholders['{user_name}'],
			'agent_name'          => $this->placeholders['{agent_name}'],
			'commission_category' => $this->placeholders['{commission_category}'],
		);

		extract( $args );

		ob_start();
		include WWP_PLUGIN_PATH . 'resources/views/admin/sales-agent/' . $this->template_plain;
		return ob_get_clean();
	}

	public function get_default_subject() {
		return __( '[{site_title}]: Assigned User as a Sales Agent', 'woocommerce-wholesale-pricing' );
	}

	public function get_default_heading() {
		return __( 'Assigned User as a Sales Agent', 'woocommerce-wholesale-pricing' );
	}
}
