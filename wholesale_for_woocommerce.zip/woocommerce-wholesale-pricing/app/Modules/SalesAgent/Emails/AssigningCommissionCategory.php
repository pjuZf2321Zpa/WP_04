<?php

namespace WooCommerceWholesalePricing\App\Modules\SalesAgent\Emails;

class AssigningCommissionCategory extends \WC_Email {

	public function __construct() {

		$this->id             = 'safw_assign_comm_cat';
		$this->title          = __( 'SAFW Assigning Commission Category', 'woocommerce-wholesale-pricing' );
		$this->description    = __( 'SAFW Assigning Commission Category emails are sent to Sales Agent when a any commission category will assign to the Sales Agent.', 'woocommerce-wholesale-pricing' );
		$this->template_base  = WWP_PLUGIN_PATH . 'resources/views/admin/sales-agent/';
		$this->template_html  = 'emails/safw-assign-comm-cat-temp.php';
		$this->template_plain = 'emails/plain/safw-assign-comm-cat-plain-temp.php';
		$this->customer_email = true;
		$this->placeholders   = array(
			'{agent_name}'          => '',
			'{commission_category}' => '',
			'{commission_value}'    => '',
		);

		parent::__construct();

		add_action( 'safw_email_assign_comm_cat_notification', array( $this, 'trigger' ), 10, 2 );
	}

	public function trigger( $agent_id, $commission_category_id ) {

		$this->setup_locale();

		$terms = get_term( $commission_category_id, 'commission_cat' );

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return;
		}

		$commission_category = get_option( 'taxonomy_term_' . $terms->term_id );

		$agent_user_id = get_post_meta( $agent_id, 'assign_user', true );
		$user_data     = get_userdata( $agent_user_id );

		if ( ! $user_data ) {
			return;
		}

		$this->recipient = $user_data->user_email;

		$this->placeholders['{agent_name}']          = get_the_title( $agent_id );
		$this->placeholders['{commission_category}'] = $terms->name;
		$this->placeholders['{commission_value}']    = ( isset( $commission_category['commission_value'] ) ? $commission_category['commission_value'] : '' ) . ' ' . ( isset( $commission_category['commission_type'] ) ? ucfirst( $commission_category['commission_type'] ) : '' );

		if ( $this->is_enabled() && $this->get_recipient() ) {
			$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
		}

		$this->restore_locale();
	}

	public function get_content_html() {
		$args = array(
			'email_heading'       => $this->get_heading(),
			'additional_content'  => $this->get_additional_content(),
			'email'               => $this,
			'site_title'          => $this->placeholders['{site_title}'],
			'site_address'        => $this->placeholders['{site_address}'],
			'site_url'            => $this->placeholders['{site_url}'],
			'agent_name'          => $this->placeholders['{agent_name}'],
			'commission_category' => $this->placeholders['{commission_category}'],
			'commission_value'    => $this->placeholders['{commission_value}'],
		);

		extract( $args );

		ob_start();
		include WWP_PLUGIN_PATH . 'resources/views/admin/sales-agent/' . $this->template_html;
		return ob_get_clean();
	}

	public function get_content_plain() {
		$args = array(
			'email_heading'       => $this->get_heading(),
			'additional_content'  => $this->get_additional_content(),
			'email'               => $this,
			'site_title'          => $this->placeholders['{site_title}'],
			'site_address'        => $this->placeholders['{site_address}'],
			'site_url'            => $this->placeholders['{site_url}'],
			'agent_name'          => $this->placeholders['{agent_name}'],
			'commission_category' => $this->placeholders['{commission_category}'],
			'commission_value'    => $this->placeholders['{commission_value}'],
		);

		extract( $args );

		ob_start();
		include WWP_PLUGIN_PATH . 'resources/views/admin/sales-agent/' . $this->template_plain;
		return ob_get_clean();
	}

	public function get_default_subject() {
		return __( '[{site_title}]: Assign Commission Category to Sales Agent.', 'woocommerce-wholesale-pricing' );
	}

	public function get_default_heading() {
		return __( 'Assigned Commission Category to Sales Agent', 'woocommerce-wholesale-pricing' );
	}
}
