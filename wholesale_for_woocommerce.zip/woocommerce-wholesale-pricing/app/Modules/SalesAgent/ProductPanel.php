<?php

namespace WooCommerceWholesalePricing\App\Modules\SalesAgent;

class ProductPanel {

	public function __construct() {
		add_action( 'woocommerce_product_data_panels', array( $this, 'add_commission_opt_in_each_pord' ) );

		add_action( 'woocommerce_admin_process_product_object', array( $this, 'set_commission_props_in_prod_obj' ), 99, 1 );

		add_filter( 'woocommerce_product_data_tabs', array( $this, 'render_product_commission_tab' ) );

		add_filter( 'manage_edit-product_columns', array( $this, 'safw_commission_coloum' ), 10, 1 );

		add_action( 'manage_product_posts_custom_column', array( $this, 'safw_commission_column_data' ), 10, 2 );

		// Variations Support
		add_action( 'woocommerce_variation_options_pricing', array( $this, 'add_variation_commission_fields' ), 10, 3 );
		add_action( 'woocommerce_save_product_variation', array( $this, 'save_variation_commission_fields' ), 10, 2 );

		add_action('admin_footer', array( $this, 'add_admin_footer_script' ) );
	}

	public function add_commission_opt_in_each_pord() {

		global $product_object;
		$data = get_post_meta( $product_object->get_id(), 'individual_prod_data', true );

		?>
		<div id="prod_commission_data" class="panel woocommerce_options_panel safw_prod_commission_wrapper">
			<?php

			woocommerce_wp_checkbox(
				array(
					'id'          => 'per_prod_commission',
					'value'       => isset( $data['per_prod_commission'] ) ? $data['per_prod_commission'] : 'no',
					'label'       => __( 'Add Commission Amount', 'woocommerce-wholesale-pricing' ),
					'description' => __( 'Check this to calculate commission per product value.', 'woocommerce-wholesale-pricing' ),
				)
			);

			woocommerce_wp_select(
				array(
					'id'       => 'commission_type',
					'value'    => isset( $data['commission_type'] ) ? $data['commission_type'] : 'percentage',
					'label'    => __( 'Commission Type', 'woocommerce-wholesale-pricing' ),
					'options'  => array(
						'percentage' => __( 'Percentage', 'woocommerce-wholesale-pricing' ),
						'fixed'      => __( 'Fixed', 'woocommerce-wholesale-pricing' ),
					),
					'desc_tip' => 'true',
				)
			);

			woocommerce_wp_text_input(
				array(
					'id'        => 'commission_value',
					'value'     => isset( $data['commission_value'] ) ? $data['commission_value'] : '',
					'label'     => __( 'Commission Value', 'woocommerce-wholesale-pricing' ) . ' (' . get_woocommerce_currency_symbol() . ')',
					'data_type' => 'price',
				)
			);

			woocommerce_wp_hidden_input(
				array(
					'id'    => 'ind_prod_nonce',
					'value' => wp_create_nonce( __FILE__ ),
				)
			);
			?>
		</div>
		<?php
	}

	public function set_commission_props_in_prod_obj( $product ) {

		if ( ! isset( $_POST['ind_prod_nonce'] ) || ( isset( $_POST['ind_prod_nonce'] ) && ! wp_verify_nonce( sanitize_text_field( $_POST['ind_prod_nonce'] ), __FILE__ ) ) ) {
			exit( 'Not Authorized' );
		}

		$prod_id = $product->get_id();

		$per_prod_data = array(
			'per_prod_commission' => isset( $_POST['per_prod_commission'] ) ? sanitize_text_field( $_POST['per_prod_commission'] ) : 'no',
			'commission_type'     => isset( $_POST['commission_type'] ) ? sanitize_text_field( $_POST['commission_type'] ) : 'percentage',
			'commission_value'    => isset( $_POST['commission_value'] ) ? sanitize_text_field( $_POST['commission_value'] ) : '',
		);

		if ( isset( $per_prod_data['per_prod_commission'] ) && 'no' === $per_prod_data['per_prod_commission'] ) {
			unset( $per_prod_data['commission_type'] );
			unset( $per_prod_data['commission_value'] );
		}

		update_post_meta( $prod_id, 'individual_prod_data', $per_prod_data );
	}

	public function render_product_commission_tab( $tab ) {

		$tab['commission_tab'] = array(
			'label'    => __( 'Sales Agent Commission', 'woocommerce-wholesale-pricing' ),
			'target'   => 'prod_commission_data',
			'class'    => array(),
			'priority' => 1000,
		);

		return $tab;
	}

	public function safw_commission_coloum( $columns ) {

		$new_columns = array();
		$flag        = true;

		foreach ( $columns as $key => $value ) {

			if ( $flag && 'featured' === $key ) {
				$flag                      = false;
				$new_columns['commission'] = __( 'Commission', 'woocommerce-wholesale-pricing' );
			}

			$new_columns[ $key ] = $value;
		}

			return $new_columns;
	}

	public function safw_commission_column_data( $column, $post_id ) {
		$ind_prod_commission = get_post_meta( $post_id, 'individual_prod_data', true );
		if ( 'commission' === $column ) {
			if ( $ind_prod_commission && 'yes' === $ind_prod_commission['per_prod_commission'] && '' != $ind_prod_commission['commission_value'] ) {
				if ( $ind_prod_commission['commission_type'] && 'percentage' === $ind_prod_commission['commission_type'] ) {
					/* translators: $s: CommissionValue */
					echo wp_kses_post( sprintf( 'Percentage -  %s%%', $ind_prod_commission['commission_value'] ), 'woocommerce-wholesale-pricing' );
				} else {
					/* translators: $s: CommissionValue */
					echo wp_kses_post( sprintf( 'Fixed -  %s', wc_price( $ind_prod_commission['commission_value'] ) ), 'woocommerce-wholesale-pricing' );
				}
			} else {
				echo '–';
			}
		}
	}

	public function add_variation_commission_fields( $loop, $variation_data, $variation ) {
		$data = get_post_meta( $variation->ID, 'individual_prod_data', true );
		?>
		<div class="variation_commission_fields">
			<?php
				woocommerce_wp_checkbox(
					array(
						'id'            => "per_prod_commission_{$variation->ID}",
						'name'          => "per_prod_commission[{$variation->ID}]",
						'value'         => isset( $data['per_prod_commission'] ) ? $data['per_prod_commission'] : 'no',
						'label'         => __( 'Add Commission', 'woocommerce-wholesale-pricing' ),
						'wrapper_class' => 'tips',
						'style' => 'margin-right: 5px !important;',
					)
				);

				woocommerce_wp_select(
					array(
						'id'      => "commission_type_{$variation->ID}",
						'name'    => "commission_type[{$variation->ID}]",
						'value'   => isset( $data['commission_type'] ) ? $data['commission_type'] : 'percentage',
						'label'   => __( 'Commission Type', 'woocommerce-wholesale-pricing' ),
						'options' => array(
							'percentage' => __( 'Percentage', 'woocommerce-wholesale-pricing' ),
							'fixed'      => __( 'Fixed', 'woocommerce-wholesale-pricing' ),
						),
						'style' => 'width: 100%;max-width: 100%;',
					)
				);

				woocommerce_wp_text_input(
					array(
						'id'        => "commission_value_{$variation->ID}",
						'name'      => "commission_value[{$variation->ID}]",
						'value'     => isset( $data['commission_value'] ) ? $data['commission_value'] : '',
						'label'     => __( 'Commission Amount', 'woocommerce-wholesale-pricing' ) . ' (' . get_woocommerce_currency_symbol() . ')',
						'data_type' => 'price',
						'style' => 'width: 100%;max-width: 100%;',
					)
				);

				woocommerce_wp_hidden_input(
					array(
						'id'    => 'ind_prod_nonce',
						'value' => wp_create_nonce( __FILE__ ),
					)
				);
			?>
		</div>
		<?php
	}

	public function save_variation_commission_fields( $variation_id, $i ) {
		if ( ! isset( $_POST['ind_prod_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ind_prod_nonce'] ) ), __FILE__ ) ) {
			return;
		}
		$per_prod_commission = isset( $_POST['per_prod_commission'][ $variation_id ] ) ? 'yes' : 'no';
		$commission_type     = isset( $_POST['commission_type'][ $variation_id ] ) ? sanitize_text_field( wp_unslash( $_POST['commission_type'][ $variation_id ] ) ) : 'percentage';
		$commission_value    = isset( $_POST['commission_value'][ $variation_id ] ) ? sanitize_text_field( wp_unslash( $_POST['commission_value'][ $variation_id ] ) ) : '';

		$per_prod_data = array(
			'per_prod_commission' => $per_prod_commission,
			'commission_type'     => $commission_type,
			'commission_value'    => $commission_value,
		);

		if ( 'no' === $per_prod_commission ) {
			unset( $per_prod_data['commission_type'] );
			unset( $per_prod_data['commission_value'] );
		}

		update_post_meta( $variation_id, 'individual_prod_data', $per_prod_data );
	}

	public function add_admin_footer_script() {
		global $current_screen;

		if ('product' !== $current_screen->post_type) {
			return;
		}

		?>
		<script>
			jQuery(document).ready(function() {
				var CommissionTypeDiv = jQuery('.commission_type_field');
				var CommissionValueDiv = jQuery('.commission_value_field');
				
				jQuery('#per_prod_commission').on('change', function(e) {

					if ( jQuery(this).is(':checked') ) {
						CommissionTypeDiv.show(500);
						CommissionValueDiv.show(500);
					} else {
						CommissionTypeDiv.hide(500);
						CommissionValueDiv.hide(500);
					}
				});
				jQuery('#per_prod_commission').trigger('change');
			});
		</script>
		<?php
	}
}