<?php

namespace WooCommerceWholesalePricing\App\Modules\SalesAgent;

use WooCommerceWholesalePricing\App\Strategies\Init;

class Registration extends Init {

	public function __construct() {
		add_shortcode( 'sales_agent_registeration_form', array( $this, 'wc_agent_registeration_form' ) );

		add_filter('post_row_actions', array( $this, 'add_post_row_actions' ), 10, 2);
		add_action('add_meta_boxes', array( $this, 'add_meta_boxes' ));

		add_action( 'before_delete_post', array( $this, 'delete_registration_request' ) );

		parent::__construct();

		// Register after standalone woocommerce-wholesale-pricing (init@10) so is_registered can skip duplicates.
		remove_action( 'init', array( $this, 'register' ), 5 );
		add_action( 'init', array( $this, 'register' ), 20 );
	}

	public function register() {
		if ( ! is_sales_agent_enabled() ) {
			return;
		}

		// Register the block script

		$deps_path = WWP_PLUGIN_PATH . 'build/sales-agent/registration-block/index.asset.php';
		$deps = file_exists( $deps_path ) ? require $deps_path : array();

		wp_register_script( 'woocommerce-wholesale-pricing-Resgistration-Block', WWP_PLUGIN_URL . 'build/sales-agent/registration-block/index.js', $deps['dependencies'], $deps['version'] );

		if ( ! \WP_Block_Type_Registry::get_instance()->is_registered( 'salesagent/salesagent-registration' ) ) {
			register_block_type( 'salesagent/salesagent-registration', array(
				'editor_script'   => 'woocommerce-wholesale-pricing-Resgistration-Block',
				'render_callback' => array( $this, 'render_registration_block' ),
				'attributes'      => array(
					'imageUrl'  => array(
						'type'    => 'string',
						'default' => '',
					),
					'altText'   => array(
						'type'    => 'string',
						'default' => 'Default Image',
					),
					'caption'   => array(
						'type'    => 'string',
						'default' => '',
					),
					'alignment' => array(
						'type'    => 'string',
						'default' => 'center',
					),
					'size'      => array(
						'type'    => 'string',
						'default' => 'medium',
					),
				),
			) );
		}
	}

	/**
	 * Block render callback — outputs registration form via shortcode.
	 *
	 * @param array $attributes Block attributes.
	 * @return string
	 */
	public function render_registration_block( $attributes ) {
		return do_shortcode( '[sales_agent_registeration_form]' );
	}

	public function wc_agent_registeration_form( $attributes ) {
		/**
		 * Filter.
		 *
		 * @since 1.4
		 */
		$messages = apply_filters(
			'sc_agent_register_notices',
			array(
				'first_name' => __( 'First Name is required.', 'woocommerce-wholesale-pricing' ),
				'last_name'  => __( 'Last Name is required.', 'woocommerce-wholesale-pricing' ),
				'email'      => __( 'Email is required.', 'woocommerce-wholesale-pricing' ),
				'password'   => __( 'Password is required.', 'woocommerce-wholesale-pricing' ),
				'category'   => __( 'Category is required.', 'woocommerce-wholesale-pricing' ),
				'success'    => __( 'You are registered successfully.', 'woocommerce-wholesale-pricing' ),
			)
		);

		ob_start();

		if ( isset( $_POST['sales_agent_nonce'] ) && wp_verify_nonce( sanitize_text_field( $_POST['sales_agent_nonce'] ), 'sales_agent_nonce' ) ) {

			if ( isset( $_POST['data'] ) ) {
				$firstname = ! empty( $_POST['data']['first_name'] ) ? sanitize_text_field( $_POST['data']['first_name'] ) : '';
				if ( empty( $firstname ) ) {
					echo "<div class='woocommerce-error'>" . esc_html( $messages['first_name'] ) . '</div>';
				}

				$lastname = ! empty( $_POST['data']['last_name'] ) ? sanitize_text_field( $_POST['data']['last_name'] ) : '';
				if ( empty( $lastname ) ) {
					echo "<div class='woocommerce-error'>" . esc_html( $messages['last_name'] ) . '</div>';
				}

				$email = ! empty( $_POST['data']['email'] ) ? sanitize_email( $_POST['data']['email'] ) : '';
				if ( empty( $email ) ) {
					echo "<div class='woocommerce-error'>" . esc_html( $messages['email'] ) . '</div>';
				}

				$password = ! empty( $_POST['data']['pass'] ) ? sanitize_text_field( $_POST['data']['pass'] ) : '';
				if ( empty( $password ) ) {
					echo "<div class='woocommerce-error'>" . esc_html( $messages['password'] ) . '</div>';
				}

				$agent_categories = get_terms(
					array(
						'taxonomy'   => 'commission_cat',
						'hide_empty' => false,
					)
				);

				$valid_categories = wp_list_pluck( $agent_categories, 'term_id' );

				$commission_cat = ! empty( $_POST['data']['cat'] ) ? sanitize_text_field( $_POST['data']['cat'] ) : '';
				if ( ! in_array( $commission_cat, $valid_categories ) ) {
					echo "<div class='woocommerce-error'>" . esc_html( $messages['category'] ) . '</div>';
				}

				if ( $firstname && $lastname && $email && $password && $commission_cat && in_array( $commission_cat, $valid_categories ) ) {

					$user_id = wp_insert_user(
						array(
							'user_login'   => $email,
							'user_pass'    => $password,
							'user_email'   => $email,
							'first_name'   => $firstname,
							'last_name'    => $lastname,
							'display_name' => $firstname,
						)
					);

					if ( is_wp_error( $user_id ) ) {
						echo "<div class='woocommerce-error'>" . esc_html( $user_id->get_error_message() ) . '</div>';
					} else {
						$post_id = wp_insert_post(
							array(
								'post_title'  => sprintf('%s %s - %s', $firstname, $lastname, $email),
								'post_type'   => 'agent_approval',
								'post_status' => 'publish',
							)
						);

						if ( $post_id ) {
							$sanitized_data = map_deep( $_POST['data'], 'sanitize_text_field' );
							update_post_meta( $post_id, 'wc_agent_register_extra_fields', $sanitized_data );

							foreach ( $sanitized_data as $key => $val ) {
								update_post_meta( $post_id, 'wc_sales_agent_' . $key, $val );
							}

							update_post_meta( $post_id, 'wc_sales_agent_user_id', $user_id );
							echo "<div class='woocommerce-message'>" . esc_html( $messages['success'] ) . '</div>';
						}
					}
				}
			}
		}
		/**
		 *  Action
		 *
		 *  @since 1.4
		 */
		do_action( 'wc_user_registration_before_form' );

		$form = str_replace( '"false"', 'false', get_option( 'sales_agent_form_builder_data' ) );

		$agent_categories = get_terms(
			array(
				'taxonomy'   => 'commission_cat',
				'hide_empty' => false,
			)
		);

		$form = get_form_result_with_catagory( json_decode( $form ), $agent_categories );

		if ( empty( $form ) ) {
			$form = mendatory_fields();
		}
		if ( $form ) {
			?>
			<div class="woocommerce">
				<div class="woocommerce-notices-wrapper"></div>
				<form method="post" class="user-request-role-form woocommerce-form woocommerce-form-register">
					<div class="woocommerce-wholesale-pricing-registration-fields" id="registration-form-fields"></div>
					<p class="woocommerce-form-row" data-id="registration-form-fields" style="display:none;">
						<input type="hidden" name="sales_agent_nonce"
							value="<?php echo esc_attr( wp_create_nonce( 'sales_agent_nonce' ) ); ?>">
						<input type="hidden" name="register" value="<?php esc_attr_e( 'Register', 'woocommerce-wholesale-pricing' ); ?>">
						<button type="submit" class="woocommerce-Button woocommerce-button button woocommerce-form-register__submit"
							name="register"
							value="<?php esc_attr_e( 'Register', 'woocommerce-wholesale-pricing' ); ?>"><?php esc_html_e( 'Register', 'woocommerce-wholesale-pricing' ); ?></button>
					</p>
					<?php
					/**
					 *  Action
					 *
					 *  @since 1.4
					 */
					do_action( 'wc_agent_registration_after_form' );
					?>
				</form>
			</div>
			<?php
		}

		return ob_get_clean();
	}

	public function add_post_row_actions( $actions, $post ) {
		if ( 'agent_approval' === $post->post_type ) {
		   unset($actions['inline hide-if-no-js']);
		}
		return $actions;
	}

	public function add_meta_boxes() {
		add_meta_box(
			'agent_approval_meta_box',
			__( 'Fields', 'woocommerce-wholesale-pricing' ),
			array( $this, 'agent_approval_meta_box' ),
			'agent_approval',
			'normal',
			'high'
		);
	}

	public function agent_approval_meta_box( $post ) {
		wwp_view('admin.sales-agent.requests.meta-box.fields', compact('post'));
	}

	public function delete_registration_request( $post_id ) {
		if ( 'agent_approval' !== get_post_type( $post_id ) ) {
			return;
		}

		$agent_email = get_post_meta( $post_id, 'wc_sales_agent_email', true );

		// Get the user by email
		$user = get_user_by( 'email', $agent_email );
		if ( $user ) {
			$user_id = $user->ID;

			wp_delete_user( $user_id ); // nosemgrep: audit.php.wp.security.user-deletion
		}
	}
}