<?php

namespace WooCommerceWholesalePricing\App\Modules\ProductTable\Traits;

trait ResponsiveOptions {
	
	public static function get_responsive_options( $args ) {

		$responsive            = get_post_meta($args['id'], 'display_responsive', true);
		$data_attr             = '';
		$options               = array();
		$hidden_col_mobile     = array();
		$hidden_col_mobile_ids = '';
		$hidden_col_tablet     = array();
		$hidden_col_tablet_ids = '';
		$hidden_col_ids        = '';
		$hidden_col            = '';
		if ($responsive ) {
			// Instantiate the class
	
			if ('priority_opt' === $responsive ) {
				$hidden_col = get_post_meta($args['id'], 'columns_show', true);
				if (is_array($hidden_col) ) {
					$hidden_col_ids          = prepare_columns_ids($hidden_col);
					$hidden_col_ids_imploded = implode(',', $hidden_col_ids);
	
					$data_attr = 'data-hidden-col-ids="' . esc_attr( $hidden_col_ids_imploded ) . '"';
				}
			} elseif ('column_breakpts' === $responsive ) {
				$data_attr         = 'data-column_breakpts="yes"';
				$hidden_col_mobile = get_post_meta($args['id'], 'columns_mobile_show', true);
				if (is_array($hidden_col_mobile) ) {
					$hidden_col_mobile_ids          = prepare_columns_ids($hidden_col_mobile);
					$hidden_col_mobile_ids_imploded = implode(',', $hidden_col_mobile_ids);
					$data_attr                     .= ' data-hidden-col-mob-ids="' . esc_attr( $hidden_col_mobile_ids_imploded ) . '"';
				}
	
				$hidden_col_tablet = get_post_meta($args['id'], 'columns_tablet_show', true);
				if (is_array($hidden_col_tablet) ) {
					$hidden_col_tablet_ids          = prepare_columns_ids($hidden_col_tablet);
					$hidden_col_tablet_ids_imploded = implode(',', $hidden_col_tablet_ids);
	
					$data_attr .= ' data-hidden-col-tab-ids="' . esc_attr( $hidden_col_tablet_ids_imploded ) . '"';
				}
			} elseif ('fully_resp' === $responsive ) {
				$data_attr = 'data-responsive=' . esc_attr($responsive);
			}
		}
		$options = array(
		'data_attr'             => $data_attr,
		'hidden_col_mobile'     => $hidden_col_mobile,
		'hidden_col_mobile_ids' => $hidden_col_mobile_ids,
		'hidden_col_tablet'     => $hidden_col_tablet,
		'hidden_col_tablet_ids' => $hidden_col_tablet_ids,
		'hidden_col'            => $hidden_col,
		'hidden_col_ids'        => $hidden_col_ids,
		);
		return $options;
	}
}
