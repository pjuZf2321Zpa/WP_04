<?php

namespace WooCommerceWholesalePricing\App\Modules\ProductTable\Traits;

trait SelectedCart {

	use Fields;

	/**
	 * Get product table selected product to cart position.
	 *
	 * @param  int $product_table_id product table id.
	 * @return string $selected_cart_position
	 */
	public static function product_table_add_selected_cart( $product_table_id ) {
		$selected_cart_position = '';
		// get product table fields.
		$product_table_fields = self::get_product_table_fields($product_table_id);
		if ($product_table_fields ) {
			foreach ( $product_table_fields as $product_table_field ) {
				if ('cart_button' === $product_table_field['woo_ids'] && 'add_button' !== $product_table_field['woo_add_types'] && 'add_quick_view_button' !== $product_table_field['woo_add_types']  ) {
					$selected_cart_position = $product_table_field['woo_add_selected_cart'];
				}

			}
		}
		/**
		 * Filter wcpt selected cart position
		 * 
		 * @since 1.1.5
		**/
		return apply_filters('wcpt_selected_cart_position', $selected_cart_position, $product_table_fields, $product_table_id);
	}
}
