<?php

namespace WooCommerceWholesalePricing\App\Modules\ProductTable\Traits;

trait Fields {
	public static function get_product_table_fields( $product_table_id ) {
		$product_table_fields = array();
		if ($product_table_id ) {
			// get product table fields.
			$product_table_fields = get_post_meta($product_table_id, 'product_table_fields', true);
		}
		/**
		 * Filter product table fields
		 * 
		 * @since 1.1.5
		**/
		$product_table_fields = apply_filters('wcpt_product_table_fields', $product_table_fields, $product_table_id);
		return $product_table_fields;
	}
}
