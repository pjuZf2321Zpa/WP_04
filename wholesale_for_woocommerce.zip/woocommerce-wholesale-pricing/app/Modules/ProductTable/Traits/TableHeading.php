<?php

namespace WooCommerceWholesalePricing\App\Modules\ProductTable\Traits;

trait TableHeading {

	use Fields;

	/**
	 * Get woocommerce product table headings.
	 *
	 * @param  int $product_table_id table id.
	 * @return array $product_table_headings
	 */
	public static function products_table_heading( $product_table_id ) {
		// Check if display table heading or not.
		$product_table_headings = array();
		// get product table fields.
		$product_table_fields = self::get_product_table_fields($product_table_id);
		if ($product_table_fields ) {
			foreach ( $product_table_fields as $product_table_field ) {
				$product_table_headings[] = array(
					'label' => $product_table_field['woo_label'],
					'type'  => $product_table_field['woo_ids'],
					'width' => $product_table_field['woo_width'],
				);
			}
		}
		/**
		 * Filter product table headings
		 * 
		 * @since 1.1.5
		**/
		return apply_filters('wcpt_product_table_headings', $product_table_headings, $product_table_fields, $product_table_id);
	}
}
