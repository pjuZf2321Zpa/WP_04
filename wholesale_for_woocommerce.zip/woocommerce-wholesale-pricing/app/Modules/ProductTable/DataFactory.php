<?php
namespace WooCommerceWholesalePricing\App\Modules\ProductTable;

class DataFactory {
	/**
	 * The full list of table args.
	 *
	 * @var Args
	 */
	private $args;
	private $available_variations;

	/**
	 * The main class constructor
	 *
	 * @param array $args The array with all configuration options.
	 */
	public function __construct( $args ) {
		$this->args = $args;
	}

	/**
	 * Retrieve the default quantity for each product
	 *
	 * @param  WC_Product $product The product
	 * @return int The default quantity
	 */
	public function get_default_quantity( $product ) {
		$default_quantity = 0;
		return $default_quantity;
	}

	/**
	 * Generate the HTML markup of an image
	 *
	 * @param  string $variation_attribute The attribute to retrieve an image for
	 * @return string The HTML markup of the retrieved image or empty string
	 */
	public function get_attribute_image_html( $variation_attribute, $aria_label ) {
		if ('off' === $this->args->variation_images ) {
			return false;
		}

		$use_lightbox = $this->args->use_lightbox;
		$image_id     = $this->get_variation_image_id($variation_attribute);

		return $this->get_image_html($image_id, $aria_label, $use_lightbox);
	}

	public function get_attribute_term_image( $term_slug, $dimension = 'rows' ) {
		$dimension_attributes = $this->get_dimension_attributes();

		if (! $dimension_attributes || ! isset($dimension_attributes[ $dimension ]) ) {
			return false;
		}

		$dimension_attribute = 'pa_' . str_replace(array( 'attribute_pa_', 'pa_' ), '', wc_sanitize_taxonomy_name($dimension_attributes[ $dimension ]));

		if (isset($this->args->term_thumbnails[ $dimension_attribute ]) 
			&& isset($this->args->term_thumbnails[ $dimension_attribute ][ $term_slug ]) 
		) {

			$image_id = $this->args->term_thumbnails[ $dimension_attribute ][ $term_slug ];

			if (wp_attachment_is_image($image_id) ) {
				return $image_id;
			}
		}

		return false;
	}

	public function get_variation_image_id( $attribute ) {
		$variation_id = 0;
		$image_id     = 0;

		$ids = $this->args->get_attribute_variation_ids($attribute);

		foreach ( $ids as $variation_id ) {
			$variation = wc_get_product($variation_id);

			if ($variation ) {
				// use an empty context so that the parent image is not returned
				$image_id = $variation->get_image_id('');
			}

			if ($image_id && wp_attachment_is_image($image_id) ) {
				return $image_id;
			}
		}

		// no variation image was found
		// use the first variation to get the parent image
		$variation_id = reset($ids);
		$variation    = wc_get_product($variation_id);

		if ($variation ) {
			// the parent image is automatically returned when context is `view`
			$image_id = $variation->get_image_id('view');

			if ($image_id && wp_attachment_is_image($image_id) ) {
				return $image_id;
			}
		}

		return false;
	}

	public function get_image_html( $image_id, $aria_label = '', $use_lightbox = true ) {
		$attachment_image_src = wp_get_attachment_image_src($image_id, 'full');
		$attachment_thumb_src = wp_get_attachment_image_src($image_id, 'thumbnail');

		if (isset($attachment_image_src[0]) ) {

			$image_atts = array(
			'title'                   => $aria_label,
			'alt'                     => $aria_label,
			'data-caption'            => get_post_field('post_excerpt', $image_id),
			'data-src'                => $attachment_image_src[0],
			'data-large_image'        => $attachment_image_src[0],
			'data-large_image_width'  => $attachment_image_src[1],
			'data-large_image_height' => $attachment_image_src[2],
			'class'                   => 'product-thumbnail product-table-image',
			'style'                   => 'max-width:64px; max-height: 64px;',
			'aria-label'              => $aria_label,
			);

			// Alt fallbacks
			$image_atts['alt'] = empty($image_atts['alt']) ? $image_atts['data-caption'] : $image_atts['alt'];
			$image_atts['alt'] = empty($image_atts['alt']) ? $image_atts['title'] : $image_atts['alt'];

			$data = '';

			if ($use_lightbox ) {
				$data .= sprintf(
					'<div data-thumb="%1$s" class="product-thumbnail-wrapper woocommerce-product-gallery__image"><a href="%2$s">',
					esc_url($attachment_thumb_src[0]),
					esc_url($attachment_image_src[0])
				);
			} else {
				$data .= '<div>';
			}

			$data .= wp_get_attachment_image($image_id, array( 64, 64, true ), false, $image_atts);

			if ($use_lightbox ) {
				$data .= '</a></div>';
			} else {
				$data .= '</div>';
			}

			return $data;
		}

		return false;
	}

	public function get_cell_content( $column, $row ) {
		$variation_ids = $this->args->get_cell_variation_ids($column, $row);
		$variation_id  = reset($variation_ids);
		$variation     = wc_get_product($variation_id);
		$product_id    = $variation->get_parent_id();
		$product       = wc_get_product($product_id);

		// This should never happen
		if (! $product ) {
			return;
		}

		$content = $this->get_cell_html($column, $row);

		/**
		* Hook: wcpt_table_cell_output.
		*
		* Filters output of each individual cell in the WCPT table.
		*
		* @deprecated 2.0.0
		*/
		$content = apply_filters_deprecated('wcpt_table_cell_output', array( $content, $product ), '2.0.0', 'wcpt_table_cell_content');

		/**
		* Hook: wcpt_table_cell_content.
		*
		* Filters the content of a single cell in the WCPT grid.
		* 
		* @since 1.1.5
		*/
		return apply_filters('wcpt_table_cell_content', $content, $column, $row, $product);
	}

	public function get_single_variation_input_attrs( $variation_ids, $is_single_variation ) {
		$classes = array( 'wcpt-quantity' );
		$attrs   = array(
		'type'  => 'number',
		'name'  => 'input_quantity',
		'value' => 0,
		'title' => _x('Qty', 'Product quantity input tooltip', 'woocommerce-wholesale-pricing'),
		);

		if (count($this->args->attributes) > 2 ) {
			$attrs['disabled'] = '';
		}

		$variation = wc_get_product(reset($variation_ids));

		if ($is_single_variation && $variation ) {
			$variation_id = $variation->get_id();
			$stock        = $variation->get_stock_quantity();
			$max          = $stock ? $stock : '';
			$max          = $variation->is_sold_individually() ? 1 : $max;
			$individual   = $variation->is_sold_individually() ? 1 : 0;
			$price        = wc_get_price_to_display($variation);
			$manage_stock = $variation->get_manage_stock();
			$backorders   = $variation->get_backorders();

			$min = 0;
			$step = 1;
			if (class_exists('WC_Min_Max_Quantities')) {
				$parent_id         = $variation->is_type( 'variation' ) ? $variation->get_parent_id() : $variation->get_id();
				$allow_combination = 'yes' === get_post_meta( $parent_id, 'allow_combination', true );
				if ( '1' == $allow_combination ) {
					$max   = absint( get_post_meta($parent_id, 'maximum_allowed_quantity', true) );
					$min   = absint( get_post_meta($parent_id, 'minimum_allowed_quantity', true) );
					$step  = absint( get_post_meta($parent_id, 'group_of_quantity', true) );
				} else {
					$max   = absint( get_post_meta($variation->get_id(), 'variation_maximum_allowed_quantity', true) );
					$min   = absint( get_post_meta($variation->get_id(), 'variation_minimum_allowed_quantity', true) );
					$step  = absint( get_post_meta($variation->get_id(), 'variation_group_of_quantity', true) );
				}
				
			}
				
			if (is_numeric($price) && $variation->is_in_stock() ) {

				$default = $this->get_default_quantity($variation);

				if ($default > $stock && $manage_stock && 'no' === $backorders ) {
					$default = $stock;
				}

				if ('no' !== $backorders ) {
					$max = 9999;
				}

				$default = ( $default <= $max || ! $max ) ? $default : $max;
				$default = max(0, $default);

				if (! $max ) {
					$max = 9999;
				}

				$attrs = array_merge(
					$attrs,
					array(
					'type'            => 'number',
					'step'            => $step,
					'value'           => $default,
					'title'           => _x('Qty', 'Product quantity input tooltip', 'woocommerce-wholesale-pricing'),
					'size'            => 4,
					'inputmode'       => 'numeric',
					'data-price'      => $price,
					'data-product_id' => $variation_id,
					'min'             => $min,
					)
				);

				if ('no' === $backorders || $individual ) {
						  $attrs['max'] = $max;
				}
				
				if ($this->args->disable_purchasing || ! $variation->is_purchasable() ) {
					$attrs['disabled'] = '';
				}
				/**
				 * Filters the content of a single cell in the WCPT grid.
				 * 
				 * @since 1.1.5
				**/
				$attrs = apply_filters('woocommerce_quantity_input_args', $attrs, $variation);

				if ( class_exists('WC_Min_Max_Quantities') ) { 
					if ( $attrs['max'] > $variation->get_stock_quantity() ) {
						$attrs['max_value'] = $variation->get_stock_quantity();
					}
				}
				if (isset($attrs['classes']) ) {
					unset($attrs['classes']);
				}
			}
		}

		if ($variation && ! $variation->is_in_stock() && 'no' === $variation->get_backorders() ) {
			$attrs['max']      = 0;
			$attrs['disabled'] = '';
		}

		$attrs['class'] = implode(' ', $classes);
		$attrs          = $this->convert_wc_input_attrs($attrs);

		/**
		* Hook: wcpt_qty_input_args.
		*
		* Filters all of the input arguments before they are converted to attribute pairs. If you need
		* to add a class to the input, this is where you'd do it.
		* 
		* @since 1.1.5
		*/
		$attrs = apply_filters('wcpt_qty_input_args', $attrs, $variation);

		return $attrs;
	}

	public function get_available_variations() {
		if (empty($this->available_variations) ) {
			$product = wc_get_product($this->args->include);

			$this->available_variations = array_filter(
				array_map(
					function ( $variation_id ) use ( $product ) {
							$variation = wc_get_product($variation_id);

						if ($variation ) {
							return array(
							'attributes'            => $variation->get_variation_attributes(),
							'availability_html'     => wc_get_stock_html($variation),
							'display_price'         => wc_get_price_to_display($variation),
							'display_regular_price' => wc_get_price_to_display($variation, array( 'price' => $variation->get_regular_price() )),
							'is_downloadable'       => $variation->is_downloadable(),
							'is_in_stock'           => $variation->is_in_stock(),
							'is_purchasable'        => $variation->is_purchasable(),
							'max_qty'               => 0 < $variation->get_max_purchase_quantity() ? $variation->get_max_purchase_quantity() : '',
							'min_qty'               => $variation->get_min_purchase_quantity(),
							'variation_id'          => $variation->get_id(),
							);
						}

							return false;
					},
					$product->get_children()
				)
			);
		}

		return $this->available_variations;
	}

	public function get_filtered_available_variations( $variation_ids ) {
		$available_variations = $this->get_available_variations();

		// Filter only the variations relevant to the current $column and $row.
		return array_values(
			array_filter(
				$available_variations,
				function ( $av ) use ( $variation_ids ) {
					return in_array($av['variation_id'], $variation_ids, true);
				}
			)
		);
	}

	public function get_extra_attribute_dropdown_html() {
		$product = wc_get_product($this->args->include);

		if (! $product ) {
			return false;
		}

		ob_start();

		foreach ( $this->args->extra_attributes as $attribute ) {
			wc_dropdown_variation_attribute_options(
				array(
				'product'          => $product,
				'attribute'        => $attribute['name'],
				'class'            => 'wcpt-additional-attribute',
				'show_option_none' => wc_attribute_label($attribute['name']),
				)
			);
		}

		return ob_get_clean();
	}

	public function get_cell_html( $column, $row ) {
		$variation_ids       = $this->args->get_cell_variation_ids($column, $row);
		$is_single_variation = 1 === count($variation_ids);
		$variation           = null;
		$variation = wc_get_product(reset($variation_ids));
		if ($is_single_variation ) {
			if ($variation && ! $this->args->is_variation_visible($variation) ) {
				return '';
			}
		}
		ob_start();

		if (! $this->args->disable_purchasing || count($this->args->attributes) > 2 ) {

			?>

			<div class="wcpt-form-variation">
			<?php

			if (count($this->args->attributes) > 2 && ( ! $this->args->has_fast_pool || 'expanded' === $this->args->grid_mode ) ) {
				echo wp_kses($this->get_extra_attribute_dropdown_html(), wwp_wc_allowed_html()); //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}

			if (! $this->args->disable_purchasing ) {
				?>

					<div class="wcpt-quantity-field">
				<?php echo wp_kses($this->get_quantity_input_html($variation_ids, $is_single_variation), wwp_wc_allowed_html()); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</div>

				<?php
			}
			?>
			</div>

			<?php

		}

		$variations_price_range = array_reduce(
			$this->get_available_variations(),
			function ( $r, $v ) {
				$r['min'] = min($r['min'], $v['display_price']);
				$r['max'] = max($r['max'], $v['display_price']);
				return $r;
			},
			array(
				'min' => INF,
				'max' => 0,
			)
		);

		$is_product_same_price = $variations_price_range['min'] === $variations_price_range['max'];
		/**
		 * Filter product table get cell price range html
		 * 
		 * @since 1.1.5
		**/
		$price_range_html      = apply_filters('wcpt_get_cell_price_range_html', $this->get_price_range_html($variation_ids), $variations_price_range, $variation_ids);
		$default_price = sprintf(
			'<div class="price" data-default="%2$s">%1$s</div>',
			$price_range_html,
			htmlentities($price_range_html, ENT_QUOTES)
		);

		if (! $this->args->hide_same_price || ! $is_product_same_price || $this->args->disable_purchasing ) {
			if ($variation ) {
				printf(
					'<div class="price">%s</div>',
					wp_kses($variation->get_price_html(), wwp_wc_allowed_html()) //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				);
			} else {
				echo wp_kses($default_price, wwp_wc_allowed_html()); //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}

		$stock = '';
		
		$parent_product = wc_get_product($variation->get_parent_id());
		$show_stock_variation = get_post_meta($parent_product->get_id(), '_show_stock_variation', true);
		if ($variation && count($this->args->attributes) < 3 && ( $this->args->show_stock || ! $variation->is_in_stock() || 'discontinued' === $variation->get_stock_status() ) ) {
			$stock = $this->get_stock_html($variation); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} elseif ('yes' == $show_stock_variation   ) {
			$min = 0 ;
			if ( class_exists('WC_Min_Max_Quantities') ) {
				$parent_id         = $variation->is_type( 'variation' ) ? $variation->get_parent_id() : $variation->get_id();
				$allow_combination = 'yes' === get_post_meta( $parent_id, 'allow_combination', true );
				if ( '1' == $allow_combination ) {
					$min   = absint( get_post_meta($parent_id, 'minimum_allowed_quantity', true) );
				} else {
					$min   = absint( get_post_meta($variation->get_id(), 'variation_minimum_allowed_quantity', true) );
				}
			}
			
			if ( $variation->get_stock_quantity() < $min ) {
				$stock = __( 'Out of stock', 'woocommerce-wholesale-pricing' );
			} else {
				$stock = $variation->get_stock_quantity() . __( ' in stock', 'woocommerce-wholesale-pricing' );
			}
			
		}

		printf(
			'<div class="stock">%s</div>',
			wp_kses_post($stock) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		);

		return ob_get_clean();
	}

	public function get_quantity_input_html( $variation_ids, $is_single_variation = false ) {
		$attrs = $this->get_single_variation_input_attrs($variation_ids, $is_single_variation);
	
		$input = sprintf('<input %s />', wc_implode_html_attributes($attrs));
		$variation = false;
		if ($is_single_variation ) {
			$variation = wc_get_product(reset($variation_ids));
			/**
			* Hook: wcpt_qty_input_html.
			*
			* Filters output of each individual the quantity <input> in the WCPT table.
			* 
			* @since 1.1.5
			*/
			return apply_filters('wcpt_qty_input_html', $input, $attrs, $variation);
		}
		return $input;
	}

	public function get_stock_html( $product ) {

		$availability = $product->get_availability();

		$stock_message = apply_filters_deprecated(
			'wcpt_stock_message',
			array(
			$availability['availability'],
			$product,
			),
			'1.2',
			'woocommerce_get_availability_text'
		);

		$stock_html = wc_get_stock_html($product);
		return apply_filters_deprecated(
			'wcpt_stock_message_html',
			array(
			$stock_html,
			$stock_message,
			$product,
			),
			'1.2',
			'woocommerce_get_stock_html'
		);
	}

	public function get_price_range_html( $variation_ids ) {
		$variations = $this->get_filtered_available_variations($variation_ids);

		$product_price_range = array_reduce(
			$variations,
			function ( $r, $v ) {
				$r['min'] = min($r['min'], $v['display_price']);
				$r['max'] = max($r['max'], $v['display_price']);
				return $r;
			},
			array(
				'min' => INF,
				'max' => 0,
			)
		);

		$price_range_html = wc_price($product_price_range['min']);
		$first_id         = reset($variation_ids);
		$first_variation  = wc_get_product($first_id);

		if ($first_variation ) {
			$price_range_html = $first_variation->get_price_html();
		}

		if ($product_price_range['min'] !== $product_price_range['max'] ) {
			$price_range_html = sprintf(
				'%1$s &ndash; %2$s',
				wc_price($product_price_range['min']),
				wc_price($product_price_range['max'])
			);
		}

		return $price_range_html;
	}

	//phpcs:ignore Squiz.Commenting.FunctionComment.MissingParamTag
	/**
	 * The woocommerce_quantity_input_args filter has all sorts of custom names for attributes that
	 * get hardcoded into the template, this function massages those array keypairs into their
	 * final form.
	 */
	private function convert_wc_input_attrs( $attrs ) {

		foreach ( $attrs as $key => $value ) {
			$newkey = null;
			if (is_string($key) && !empty($key)) {
				// Check if the key starts with 'input_' and remove the 'input_' prefix
				if ( 0 === strpos($key, 'input_') ) {
					$newkey = substr($key, 6);
				} elseif (strrpos($key, '_value') === strlen($key) - 6) {
					$newkey = substr($key, 0, -6);
				}
			}
		
			// If we have a new key, modify the array
			if ( null !== $newkey ) {
				// Add the new key with the original value and unset the old key
				$attrs[$newkey] = $value;
				unset($attrs[$key]);
			}
		}
		

		return $attrs;
	}
}
