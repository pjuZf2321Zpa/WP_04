<?php
/**
 * Trait RejectionEmail
 *
 * Handles sending notification emails to users when their wholesale request is rejected.
 * Uses the EmailHelper trait for email preparation and sending.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Emails\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Emails\Traits;

trait RejectionEmail {

	use EmailHelper;

	/**
	 * Sends a notification email to a user upon rejection of their wholesale request.
	 *
	 * Checks if rejection notifications are enabled, prepares subject and body with user data,
	 * applies filters for customization, and sends the email.
	 *
	 * @param int $user_id The ID of the user whose request was rejected.
	 *
	 * @return void
	 */
	public function user_rejection_notification( $user_id ) {
		if ('yes' !== get_option('wwp_wholesale_user_rejection_notification') ) {
			return;
		}

		$user = get_user_by('ID', $user_id);
		if (is_wp_error($user) ) {
return;
		}

		$subject = get_option('wwp_wholesale_rejection_notification_subject');
		$subject = ! empty($subject) ? $subject : esc_html__('Request Rejected', 'woocommerce-wholesale-pricing');

		$subject = $this->prepare_subject(
			$subject,
			$user,
			'wwp_wholesale_user_rejection_notification_subject'
		);

		$body = $this->prepare_body(
			get_option('wwp_wholesale_rejection_notification_body'),
			$user,
			'wwp_wholesale_user_rejection_notification_tag',
			$this->get_wholesale_placeholders($user_id)
		);

		$headers = $this->get_headers( 
			/**
			 * Filter 
			 * 
			 * @var string email
			 * 
			 * @since 1.8.0
			 */
			apply_filters('wwp_custom_sender_email', get_option('admin_email')),
			'wwp_wholesale_rejected_request_header_user'
		);
		/**
		 * Filter 
		 * 
		 * @var string email
		 * 
		 * @since 1.8.0
		 */
		$to      = apply_filters('wwp_wholesale_user_rejection_notification_reciver_email', $user->user_email);

		$this->send_mail($to, $subject, $body, $headers);
	}
}
