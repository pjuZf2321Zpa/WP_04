<?php

namespace WooCommerceWholesalePricing\App\Modules\Emails\Traits\Quote;

trait Admin {

	/**
	 * Send email to admins.
	 *
	 * @param int $quote_id The quote ID.
	 * @return void
	 */
	public function send_email_to_admins( $quote_id ) {

		// Email to administrators, shop managers.
		$user_name     = get_the_author_meta('display_name', get_post($quote_id)->post_author);
		$user_email    = get_the_author_meta('user_email', get_post($quote_id)->post_author);
		$admin_email = isset($this->quote_settings['email']['admin_email']) && ! empty($this->quote_settings['email']['admin_email']) ? $this->quote_settings['email']['admin_email'] : get_bloginfo('admin_email');
		$quote_status  = get_post($quote_id)->post_status;
		$quote_status  = str_replace('quote_', '', $quote_status);

		$quote_heading = isset( get_post_status_object(get_post_status($quote_id))->label ) ? get_post_status_object(get_post_status($quote_id))->label : 'Quote Request';

		$email_enable  = isset($this->quote_settings['email'][$quote_status . '_admin_email_enable']) ? $this->quote_settings['email'][$quote_status . '_admin_email_enable'] : '0';
		$email_subject = isset($this->quote_settings['email'][$quote_status . '_admin_email_subject']) ? $this->quote_settings['email'][$quote_status . '_admin_email_subject'] : '';
		$filter_hook = 'wc_quote_admin_' . strtolower($quote_heading) . '_email_heading';
		$quote_heading = $quote_heading . ' Quote Request';
		/**
		 * Filter Quote Request
		 * 
		 * @since 1.0
		**/
		$filtered_heading = apply_filters($filter_hook, '');
		$email_heading = !empty($filtered_heading) 
			? $filtered_heading 
			: esc_html__($quote_heading, 'woocommerce-wholesale-pricing');

		/**
		 * Filter wc_quote_$quote_status_admin_email_heading
		 * 
		 * @since 1.0
		**/
		$email_heading = apply_filters('wc_quote_' . $quote_status . '_admin_email_heading', $email_heading);
		$email_message = isset($this->quote_settings['email'][$quote_status . '_admin_email_msg']) ? $this->quote_settings['email'][$quote_status . '_admin_email_msg'] : '';

		$email_subject = str_replace('{quote_id}', $quote_id, $email_subject);
		$email_heading = str_replace('{quote_id}', $quote_id, $email_heading);

		$email_subject = str_replace('{user_name}', $user_name, $email_subject);
		$email_heading = str_replace('{user_name}', $user_name, $email_heading);
		/**
		 * Filter wc_quote_admin_email
		 * 
		 * @since 1.0
		**/
		$email = apply_filters('wc_quote_admin_email', $admin_email, $quote_id);
		/**
		 * Filter wc_quote_admin_email
		 * 
		 * @since 1.0
		**/
		$admin_email = apply_filters('wc_quote_admin_email', $admin_email, $quote_id);
		  
		$email_valid_msg = isset($this->quote_settings['notifications']['email_valid_msg']) ? $this->quote_settings['notifications']['email_valid_msg'] : 'Please enter a valid email'; 

		if ('1' !== $email_enable ) {
			return;
		}
		  
		if (!is_email($admin_email) && !is_admin() ) { 
			wc_add_notice(esc_html__($email_valid_msg, 'woocommerce-wholesale-pricing'), 'error');
			return;
		} elseif (!is_email($admin_email) ) {
			/* translators: %s: Customer email address. */
			printf('<div class="notice notice-error"><p>%s is not a valid email address please insert a valid email in quote settings</p></div>', esc_attr($admin_email));
			return;
		}

		ob_start();

		wwp_view( 'quote.emails.email-to-admin', compact( 'email_heading', 'email', 'email_message', 'quote_id', 'user_name' ) );
		
		$template = ob_get_clean();

		$admin_email_html = $this->style_inline($template);

		$headers   = self::$email_headers;
		$headers[] = 'Reply-to: ' . $user_name . ' <' . $user_email . '>';

		$send_email_admin = wp_mail($admin_email, $email_subject, $admin_email_html, $headers);
	}
}
