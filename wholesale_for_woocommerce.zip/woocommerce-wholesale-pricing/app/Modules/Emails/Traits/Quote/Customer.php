<?php

namespace WooCommerceWholesalePricing\App\Modules\Emails\Traits\Quote;

use WooCommerceWholesalePricing\App\Services\Quote\PDFService;

trait Customer {

	/**
	 * Apply inline styles to dynamic content.
	 *
	 * We only inline CSS for html emails, and to do so we use Emogrifier library (if supported).
	 *
	 * @param  string|null $content Content that will receive inline styles.
	 * @return string
	 */
	public function send_email_to_customer( $quote_id ) {
		  
		// Email to customer.
		$user_name     = get_the_author_meta('display_name', get_post($quote_id)->post_author);
		$user_email = get_the_author_meta('user_email', get_post($quote_id)->post_author);
		  
		if (!empty($this->quote_fields) && is_array($this->quote_fields) ) :
			foreach ( $this->quote_fields['components'] as $key => $field ) {
				if ('email' === $field['type'] ) {
					$field_data = get_post_meta($quote_id, 'quote_fields', true);
					$field_key  = $field['key'];
					$user_email = !empty($field_data[$field_key]) ? $field_data[$field_key] : '' ;
					break;
				}
			}
		endif;
		$quote_status  = get_post($quote_id)->post_status;
		$quote_status  = str_replace('quote_', '', $quote_status);

		$quote_heading = isset( get_post_status_object(get_post_status($quote_id))->label ) ? get_post_status_object(get_post_status($quote_id))->label : 'Quote Request';

		$email_enable  = isset($this->quote_settings['email'][$quote_status . '_user_email_enable']) ? $this->quote_settings['email'][$quote_status . '_user_email_enable'] : '0';
		$enable_pdf  = isset($this->quote_settings['pdf']['enable_pdf']) ? $this->quote_settings['pdf']['enable_pdf'] : '0';
		$enable_pdf_attach  = isset($this->quote_settings['pdf']['enable_pdf_attach']) ? $this->quote_settings['pdf']['enable_pdf_attach'] : '0';
		
		$attachments = array();
		$filter_hook = 'wc_quote_' . strtolower($quote_heading) . '_email_heading';

		$quote_heading = $quote_heading . ' Quote Request';
		/**
		 * Filter Quote Request
		 * 
		 * @since 1.0
		**/
		$filtered_heading = apply_filters($filter_hook, '');
		$email_heading = !empty($filtered_heading) 
			? $filtered_heading 
			: esc_html__($quote_heading, 'woocommerce-wholesale-pricing');

		/**
		 * Filter wc_quote_$quote_status_user_email_heading
		 * 
		 * @since 1.0
		**/
		$email_heading = apply_filters('wc_quote_' . $quote_status . '_user_email_heading', $email_heading);
		$email_subject = isset($this->quote_settings['email'][$quote_status . '_user_email_subject']) ? $this->quote_settings['email'][$quote_status . '_user_email_subject'] : $email_heading;
		$email_message = isset($this->quote_settings['email'][$quote_status . '_user_email_msg']) ? $this->quote_settings['email'][$quote_status . '_user_email_msg'] : '';

		$email_valid_msg = isset($this->quote_settings['notifications']['email_valid_msg']) ? $this->quote_settings['notifications']['email_valid_msg'] : 'Please enter a valid email'; 

		if ('1' !== $email_enable ) {
			return;
		}
		  
		if (!is_email($user_email) && !is_admin() ) { 
			wc_add_notice(esc_html__($email_valid_msg, 'woocommerce-wholesale-pricing'), 'error');
			return;
		} elseif (!is_email($user_email) ) {
			/* translators: %s: Customer email address. */
			printf('<div class="notice notice-error"><p>%s is not a valid email address</p></div>', esc_attr($user_email));
			return;
		}

		$email = $user_email;

		$email_subject = str_replace('{quote_id}', $quote_id, $email_subject);
		$email_heading = str_replace('{quote_id}', $quote_id, $email_heading);

		$email_subject = str_replace('{user_name}', $user_name, $email_subject);
		$email_heading = str_replace('{user_name}', $user_name, $email_heading);

		ob_start();

		wwp_view( 'quote.emails.email-to-customer', compact( 'email_heading', 'email', 'email_message', 'quote_id', 'user_name', 'quote_status' ) );

		$template = ob_get_clean();

		$customer_email_html = $this->style_inline($template);
		 
		// =============== custom pdf sprint 2.7 ============
		// for custom pdf 
		 
		$wc_quote_pdf_value = get_option('wc_quote_pdf');

		// ============ custom pdf sprint 2.7 end ============

		 
		if ('1' === $enable_pdf && '1' === $enable_pdf_attach ) {
			$pdf_controller = new PDFService();
			/**
			 * Filter pdf_attachment_in_email
			 * 
			 * @since 1.0
			**/
			$pdf_attachment_in_email = apply_filters('pdf_attachment_in_email', '');
	
			if ( !( in_array($quote_status, array( 'new', 'accepted' )) && $pdf_attachment_in_email ) ) {
				$attachments = array( $pdf_controller->process_pdf_attachment(intval($quote_id)) );
				
			}

			$send_user_email = wp_mail($user_email, $email_subject, $customer_email_html, self::$email_headers, $attachments);
		} else {
		 
			// =============== custom pdf sprint 2.7 ============
		 
			$send_user_email = wp_mail($user_email, $email_subject, $customer_email_html, self::$email_headers);
		 
			// =============== custom pdf sprint 2.7 end ============
		}
	}
}
