<?php
/**
 * Trait ApprovalEmail
 *
 * Handles sending notification emails to users when their wholesale request is approved.
 * Utilizes the EmailHelper trait for preparing and sending emails.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Emails\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Emails\Traits;

trait ApprovalEmail {

	use EmailHelper;

	/**
	 * Sends a notification email to a user upon approval of their wholesale request.
	 *
	 * Checks plugin settings to determine if approval notifications are enabled,
	 * prepares the email subject and body with user data,
	 * applies filters for customization, and sends the email.
	 *
	 * @param int $user_id The ID of the user whose request was approved.
	 *
	 * @return void
	 */
	public function user_request_approved_notification( $user_id ) {
		if ('yes' !== get_option('wwp_wholesale_request_approve_notification') ) {
			return;
		}

		$user = get_user_by('ID', $user_id);
		if (is_wp_error($user) ) {
return;
		}

		$subject = get_option('wwp_wholesale_email_request_subject');
		$subject = ! empty($subject) ? $subject : esc_html__('Your Requested Approved', 'woocommerce-wholesale-pricing');

		$subject = $this->prepare_subject(
			$subject,
			$user,
			'wwp_wholesale_user_request_approved_notification_subject'
		);

		$body = $this->prepare_body(
			get_option('wwp_wholesale_email_request_body'),
			$user,
			'wwp_wholesale_user_request_approved_notification_tag',
			$this->get_wholesale_placeholders($user_id)
		);

		$headers = $this->get_headers( 
			/**
			* Filter 
			* 
			* @var string Email
			* 
			* @since 1.8.0
			*/
			apply_filters('wwp_custom_sender_email', get_option('admin_email')),
			'wwp_wholesale_approval_email_header_user'
		);
		/**
		 * Filter 
		 * 
		 * @var string Email
		 * 
		 * @since 1.8.0
		 */
		$to      = apply_filters('wwp_wholesale_user_request_approved_notification_reciver_email', $user->user_email);

		$this->send_mail($to, $subject, $body, $headers);
	}
}
