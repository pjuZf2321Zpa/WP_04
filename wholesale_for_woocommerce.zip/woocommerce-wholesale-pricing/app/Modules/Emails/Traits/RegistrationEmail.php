<?php
/**
 * Trait RegistrationEmail
 *
 * Handles sending notification emails when a new wholesale user registration request is submitted.
 * Utilizes the EmailHelper trait for email preparation and sending.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Emails\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Emails\Traits;

trait RegistrationEmail {


	use EmailHelper;

	/**
	 * Sends a notification email for a new wholesale registration request.
	 *
	 * Checks if notifications are enabled, prepares subject and body using user data,
	 * applies filters for customization, and sends the email.
	 *
	 * @param int $user_id The ID of the newly registered user.
	 *
	 * @return void
	 */
	public function new_registration_request( $user_id ) {
		if ('yes' !== get_option('wwp_wholesale_user_registration_notification') ) {
			return;
		}

		$user = get_user_by('ID', $user_id);
		if (is_wp_error($user) ) {
return;
		}

		$subject = get_option('wwp_wholesale_registration_notification_subject');
		$subject = ! empty($subject) ? $subject : esc_html__('New Request Received', 'woocommerce-wholesale-pricing');

		$subject = $this->prepare_subject(
			$subject,
			$user,
			'wwp_wholesale_new_registered_request_subject'
		);

		$body = $this->prepare_body(
			get_option('wwp_wholesale_registration_notification_body'),
			$user,
			'wwp_wholesale_new_registered_request_tag',
			$this->get_wholesale_placeholders($user_id)
		);

		$headers = $this->get_headers( 
			/**
			 * Filter 
			 * 
			 * @var string email
			 * 
			 * @since 1.8.0
			 */
			apply_filters('wwp_custom_sender_email', get_option('admin_email')),
			'wwp_wholesale_new_request_header_user'
		);
		/**
		 * Filter 
		 * 
		 * @var string $email
		 * 
		 * @since 1.8.0
		 */
		$to      = apply_filters('wwp_wholesale_new_registered_request_reciver_email', $user->user_email);

		$this->send_mail($to, $subject, $body, $headers);
	}
}
