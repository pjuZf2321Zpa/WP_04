<?php
/**
 * Multiple File Uploads for WooCommerce Wholesale Pricing
 * 
 * This class handles the functionality for multiple file uploads in the WooCommerce Wholesale Pricing plugin.
 * It provides methods for uploading files, handling uploaded files, and displaying them on the user edit page.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Registration
 */
namespace WooCommerceWholesalePricing\App\Modules\Registration;

/**
 * Class MultipleUploads
 * 
 * This class provides functionality to handle multiple file uploads for wholesalers. It listens for actions
 * related to file uploads, processes them, and stores the uploaded files as WordPress media attachments.
 */
class MultipleUploads {

	/**
	 * Constructor Method
	 * 
	 * Sets up action hooks for handling file uploads and displaying files on the user edit page.
	 *
	 * @return void
	 */
	public function __construct() {
		add_action('wwp_wholesaler_file_upload_multiple_handle', array( $this, 'wwp_wholesaler_file_upload_multiple_handle_callback' ), 10, 2);
		add_action('wwp_wholesaler_file_upload_user_edit_page', array( $this, 'wwp_wholesaler_file_upload_user_edit_page' ));
	}

	/**
	 * Placeholder for handling multiple file uploads.
	 * 
	 * This method serves as a callback for handling multiple file uploads. It currently just returns `true`.
	 * This can be extended later to handle file validation, processing, etc.
	 *
	 * @param  array $multiple Array of multiple files to be handled.
	 * @return bool Always returns true.
	 */
	public function wwp_wholesaler_file_upload_multiple_callback( $multiple ) {
		return true;
	}

	/**
	 * Handle the multiple file uploads for wholesalers.
	 * 
	 * This method processes the uploaded files from the wholesaler registration form. It handles file
	 * validation and uploads, saves them as WordPress attachments, and stores the attachment IDs in the user's
	 * meta data for later retrieval.
	 *
	 * @param  array $files   The uploaded files data.
	 * @param  int   $user_id The user ID of the wholesaler uploading the files.
	 * @return void
	 */
	public function wwp_wholesaler_file_upload_multiple_handle_callback( $files, $user_id ) {
		include_once ABSPATH . 'wp-admin/includes/image.php';
		include_once ABSPATH . 'wp-admin/includes/file.php';
		include_once ABSPATH . 'wp-admin/includes/media.php';
		
		$post_ids = array();

		$file_data = $files;
		if (isset($file_data['wwp_wholesaler_file_upload'])) {
			$customer = new \WC_Customer($user_id);
			$files = $file_data['wwp_wholesaler_file_upload'];
			foreach ($files['name'] as $key => $value) {
				if ($files['name'][$key]) {
					$file          = array(
						'name' => $files['name'][$key],
						'type' => $files['type'][$key],
						'tmp_name' => $files['tmp_name'][$key],
						'error' => $files['error'][$key],
						'size' => $files['size'][$key],
					);
					if (UPLOAD_ERR_OK === $file['error'] ) {
						$attachment_id = media_handle_sideload($file, 0); 
						if (!is_wp_error($attachment_id)) { 
							$post_ids[] = $attachment_id;
						} else {
							$error = $attachment_id->get_error_message();
						}
					}
				}
			}
			$customer->update_meta_data('wwp_wholesaler_file_upload', $post_ids);
			$customer->save();
		}
	}

	/**
	 * Display the uploaded files on the user edit page.
	 * 
	 * This method displays the uploaded files in the user edit page in a grid. Each file is displayed
	 * as an image with a link to the media library.
	 *
	 * @param  array $file An array of file attachment IDs to display.
	 * @return string Rendered HTML output.
	 */
	public function wwp_wholesaler_file_upload_user_edit_page( $file ) {
		?>
			<p>
				<?php foreach ($file as $j) : ?>
					<a href="<?php echo esc_url(admin_url('upload.php?item=' . $j)); ?>">
						<img src="<?php echo esc_url(wp_get_attachment_url($j)); ?>" width="100" height="100" class="wwp_wholesaler_file_upload">
					</a>
				<?php endforeach; ?>
			</p> 
		<?php
	}
}
