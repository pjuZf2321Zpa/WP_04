<?php

namespace WooCommerceWholesalePricing\App\Models\SalesAgent;

use WooCommerceWholesalePricing\App\Models\SalesAgent\AgentCommission;
use WooCommerceWholesalePricing\App\Modules\SalesAgent\Actions;

class Agent {

	public function query( $per_page, $currentPage, $front_end = false, $agent = false ) {
		$users       = array();
		$total_items = 0;
		$num_pages   = 0;

		if ( $front_end ) {
			$agent_id = $agent;
		} elseif ( isset( $_GET['agent_id'] ) && sanitize_text_field( wp_unslash( $_GET['agent_id'] ) ) ) {
			$agent_id = sanitize_text_field( wp_unslash( $_GET['agent_id'] ) );
		} else {
			$agent_id = 0;
		}

		if ( $agent_id ) {
			$offset = ( $currentPage - 1 ) * $per_page;
			$args   = array(
				'number'     => $per_page,
				'offset'     => $offset,
				'meta_query' => array(
					'relation' => 'OR',
					array(
						'key'     => 'sales_agent',
						'value'   => $agent_id,
						'compare' => '=',
					),
					array(
						'key'     => 'sales_agent',
						'value'   => $agent_id . ',%',
						'compare' => 'LIKE',
					),
					array(
						'key'     => 'sales_agent',
						'value'   => '%,' . $agent_id,
						'compare' => 'LIKE',
					),
					array(
						'key'     => 'sales_agent',
						'value'   => '%,' . $agent_id . ',%',
						'compare' => 'LIKE',
					),
				),
			);

			if ( isset( $_GET['user-filter'] ) && sanitize_text_field( wp_unslash( $_GET['user-filter'] ) ) ) {
				$args['include'] = sanitize_text_field( wp_unslash( $_GET['user-filter'] ) );
			}

			if ( ! $front_end ) {
				$args_sortable = Actions::prepare_query_sortable();
				if ( is_array( $args_sortable ) ) {
					$args = array_merge( $args, $args_sortable );
				}
			}

			/**
			 * Filter the customer list arguments.
			 *
			 * @since 1.0.4
			 * @param array $args The query arguments.
			 */
			$args = apply_filters( 'list_customers_agent_args', $args );

			if ( ! empty( $args['search'] ) ) {
				$allowed_search_columns = array( 'ID', 'user_login', 'user_nicename', 'display_name' );

				if ( ! empty( $args['search_columns'] ) && is_array( $args['search_columns'] ) ) {
					$args['search_columns'] = array_values( array_intersect( $args['search_columns'], $allowed_search_columns ) );
				}

				if ( empty( $args['search_columns'] ) ) {
					$args['search_columns'] = array( 'user_login', 'user_nicename', 'display_name' );
				}
			} else {
				$args['search']         = '';
				$args['search_columns'] = array( 'user_login', 'user_nicename', 'display_name' );
			}

			// Final User Query using get_users for better compliance
			$users = get_users( $args );

			// Calculate total items correctly
			$count_args           = $args;
			$count_args['number'] = -1;
			$count_args['offset'] = 0;
			$count_args['fields'] = 'ID';
			$total_items          = count( get_users( $count_args ) );

			$num_pages = ceil( $total_items / $per_page );
		}

		$data = array(
			'users'       => $users,
			'total_items' => $total_items,
			'num_pages'   => $num_pages,
		);

		/**
		 * Filter the final customer data.
		 *
		 * @since 1.0.4
		 * @param array $data The customer data and totals.
		 */
		return apply_filters( 'after_get_customers_agent', $data );
	}

	public function get_customer_total_order( $customer_id, $agent_id ) {
		$statuses = array_keys( wc_get_order_statuses() );
		$orders   = wc_get_orders(
			array(
				'customer' => $customer_id,
				'status'   => $statuses,
				'limit'    => -1,
			)
		);

		$count = 0;
		$total = 0;
		foreach ( $orders as $order ) {
			$agent_meta = $order->get_meta( 'sales_agent', true );
			$agents     = is_array( $agent_meta ) ? $agent_meta : explode( ',', str_replace( ' ', '', (string) $agent_meta ) );
			if ( in_array( (string) $agent_id, $agents, true ) ) {
				$count++;
				$total += (float) $order->get_total();
			}
		}

		$data = array(
			'count' => $count,
			'total' => $total,
		);

		/**
		 * Filter the customer order stats.
		 *
		 * @since 1.0.4
		 * @param array $data The order stats data.
		 */
		return apply_filters( 'after_customer_orders_amount', $data );
	}

	public function get_orders( $parameters, $per_page, $current_page ) {
		$args = array(
			'limit'    => $per_page,
			'paged'    => $current_page,
			'paginate' => true,
		);

		if ( ! empty( $parameters['agent_id'] ) ) {
			$agent_id             = intval( $parameters['agent_id'] );
			$args['meta_key']     = 'sales_agent';
			$args['meta_value']   = $agent_id;
			$args['meta_compare'] = 'LIKE';
		}

		if ( ! empty( $parameters['customer_id'] ) ) {
			$args['customer'] = intval( $parameters['customer_id'] );
		}

		if ( ! empty( $parameters['date_from'] ) && ! empty( $parameters['date_to'] ) ) {
			$args['date_created'] = $parameters['date_from'] . '...' . $parameters['date_to'];
		}

		return wc_get_orders( $args );
	}

	public static function query_by_agent( $per_page, $current_page, $agent_id ) {

		$offset = ( $current_page - 1 ) * $per_page;
		$where  = filter_where_condtion( $agent_id );

		$commission_db = new AgentCommission();

		// get commissions
		$commissions = $commission_db->get_commissions_by_agent_id( $where, $offset, $per_page );
		if ( isset( $_REQUEST['user-filter'] ) && ! empty( $_REQUEST['user-filter'] ) ) {
			$customer_id = isset( $_REQUEST['user-filter'] ) ? sanitize_text_field( $_REQUEST['user-filter'] ) : '';
			$commissions = $commission_db->get_commissions_by_agent_id( $where, $offset, $per_page, $customer_id );
			$total_items = $commission_db->get_total_commissions_by_agent_id( $where, $customer_id );
		} elseif ( isset( $_REQUEST['user-filter'] ) && empty( $_REQUEST['user-filter'] ) ) {

			$customer_id = isset( $_REQUEST['user-filter'] ) ? sanitize_text_field( $_REQUEST['user-filter'] ) : '';
			$commissions = $commission_db->get_commissions_by_agent_id( $where, $offset, $per_page, $customer_id );
			$total_items = $commission_db->get_total_commissions_by_agent_id( $where, $customer_id );
		}

		$data = array(
			'data' => $commissions,
		);

		return $data;
	}

	public static function get_agent_customers( $agent_id ) {
		$direct_users = get_users(
			array(
				'fields'     => 'ID',
				'meta_query' => array(
					'relation' => 'OR',
					array(
						'key'     => 'sales_agent',
						'compare' => '=',
						'value'   => $agent_id,
					),
					array(
						'key'     => 'sales_agent',
						'compare' => 'LIKE',
						'value'   => 'i:' . $agent_id . ';',
					),
					array(
						'key'     => 'sales_agent',
						'compare' => 'LIKE',
						'value'   => ':"' . $agent_id . '";',
					),
				),
			)
		);
		
		return $direct_users ? $direct_users : array();
	}
}
