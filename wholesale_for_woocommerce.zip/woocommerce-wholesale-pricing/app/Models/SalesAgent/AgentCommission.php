<?php

namespace WooCommerceWholesalePricing\App\Models\SalesAgent;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


use WooCommerceWholesalePricing\App\Modules\SalesAgent\Actions;

class AgentCommission {

	private $table_name          = 'wc_agents_commissions';
	private $columns_placeholder = array(
		'agent_id'              => '%d',
		'order_id'              => '%d',
		'commission_type'       => '%s',
		'commission_percentage' => '%s',
		'commission_value'      => '%s',
		'create_date'           => '%s',
	);

	/**
	 * Whether HPOS is the authoritative order datastore.
	 *
	 * @return bool
	 */
	private function is_hpos_enabled() {
		return Actions::is_hpos_enabled();
	}

	/**
	 * Add wc agent commission
	 *
	 * @global type $wpdb
	 * @param  type $args
	 */
	public function add_commission( $args ) {
		global $wpdb;

		$wc_agents_commissions = $wpdb->prefix . $this->table_name;

		/**
		* Filter.
		*
		* @since 1.0.4
		*/
		$args = apply_filters( 'before_add_commission_row', $args );
		$agent_id = isset( $args['agent_id'] ) ? absint( $args['agent_id'] ) : 0;
		$order_id = isset( $args['order_id'] ) ? absint( $args['order_id'] ) : 0;
		if ( $agent_id <= 0 || $order_id <= 0 ) {
			return;
		}

		$args_placeholder = array();

		foreach ( $args as $key => $value ) {
			if ( isset( $this->columns_placeholder[ $key ] ) ) {
				$args_placeholder[] = $this->columns_placeholder[ $key ];
			}
		}
		$args_placeholder[] = $this->columns_placeholder['create_date'];

		$wpdb->insert(
			$wc_agents_commissions,
			array(
				'agent_id'              => $agent_id,
				'order_id'              => $order_id,
				'commission_type'       => $args['commission_type'],
				'commission_percentage' => $args['commission_percentage'],
				'commission_value'      => $args['commission_value'],
				'create_date'           => current_time( 'Y-m-d H:i:s' ),
			),
			$args_placeholder
		);

		$commission_id = $wpdb->insert_id;

		/**
		* Filter.
		*
		* @since 1.0.4
		*/
		do_action( 'after_add_commission_row', $commission_id, $args );
	}

	/**
	 * Update Commission
	 *
	 * @global type $wpdb
	 * @param  type $update_args
	 * @param  type $where
	 */
	public function update_commission( $update_args, $where ) {
		global $wpdb;

		$wc_agents_commissions = $wpdb->prefix . $this->table_name;
		/**
		* Filter.
		*
		* @since 1.0.4
		*/
		$update_args = apply_filters( 'before_update_commission_row', $update_args, $where );

		$where_placeholder       = array();
		$update_args_placeholder = array();

		foreach ( $update_args as $key => $value ) {
			if ( isset( $this->columns_placeholder[ $key ] ) ) {
				$where_placeholder[] = $this->columns_placeholder[ $key ];
			}
		}

		foreach ( $update_args as $key => $value ) {
			if ( isset( $this->columns_placeholder[ $key ] ) ) {
				$update_args_placeholder[] = $this->columns_placeholder[ $key ];
			}
		}

		$wpdb->update(
			$wc_agents_commissions,
			$update_args,
			$where,
			$update_args_placeholder,
			$where_placeholder
		);

		/**
		* Filter.
		*
		* @since 1.0.4
		*/
		do_action( 'after_update_commission_row', $update_args, $where );
	}

	/**
	 * Get total comission by specific agent id
	 *
	 * @global type $wpdb
	 * @param  type $where
	 * @param  type $customer_id
	 * @return type
	 */
	public function get_total_commissions_by_agent_id( $where, $customer_id = false ) {
		global $wpdb;
		$total_items = '';

		if ( 'WHERE 1' == $where && empty( $customer_id ) ) {
			$total_items = $wpdb->get_var(
				$wpdb->prepare(
					"
                SELECT count(agent_id) FROM {$wpdb->prefix}wc_agents_commissions Where %d
                ",
					1
				)
			);

			return $total_items;

		} elseif ( 'WHERE 1' != $where && empty( $customer_id ) && isset( $_REQUEST['date_from'] ) && ! empty( $_REQUEST['date_from'] ) && isset( $_REQUEST['date_to'] ) && ! empty( $_REQUEST['date_to'] ) ) {
			$from        = gmdate( 'Y-m-d 00:00:01', strtotime( sanitize_text_field( $_REQUEST['date_from'] ) ) );
			$to          = gmdate( 'Y-m-d 23:59:59', strtotime( sanitize_text_field( $_REQUEST['date_to'] ) ) );
			$total_items = $wpdb->get_var(
				$wpdb->prepare(
					"
                SELECT count(agent_id) FROM {$wpdb->prefix}wc_agents_commissions Where agent_id=%d AND (create_date >= %s AND create_date <= %s)
                ",
					$where,
					$from,
					$to
				)
			);

			return $total_items;
		}

		if ( isset( $_REQUEST['date_from'] ) && ! empty( $_REQUEST['date_from'] ) && isset( $_REQUEST['date_to'] ) && ! empty( $_REQUEST['date_to'] ) ) {
			$from        = gmdate( 'Y-m-d 00:00:01', strtotime( sanitize_text_field( $_REQUEST['date_from'] ) ) );
			$to          = gmdate( 'Y-m-d 23:59:59', strtotime( sanitize_text_field( $_REQUEST['date_to'] ) ) );
			$total_items = $wpdb->get_var(
				$wpdb->prepare(
					"
                SELECT * FROM {$wpdb->prefix}wc_agents_commissions 
                WHERE agent_id = %d AND (create_date >= %s AND create_date <= %s)",
					$customer_id,
					$from,
					$to
				)
			);

			return $total_items;
		}

		if ( 'WHERE 1' === $where && ! empty( $customer_id ) ) {
			$total_items = $wpdb->get_var(
				$wpdb->prepare(
					"
                SELECT count(agent_id) FROM {$wpdb->prefix}wc_agents_commissions WHERE agent_id = %d
                ",
					$customer_id
				)
			);

			return $total_items;
		}

		// in case filter by customer id
		if ( $customer_id ) {

			if ( $this->is_hpos_enabled() ) {
				$total_items = $wpdb->get_var(
					$wpdb->prepare(
						"
                    SELECT count(com.agent_id) FROM {$wpdb->prefix}wc_agents_commissions com
                    INNER JOIN {$wpdb->prefix}wc_orders o ON com.order_id = o.id
                    WHERE com.agent_id = %d
                    AND o.customer_id = %d
                    ",
						$where,
						$customer_id
					)
				);
			} else {
				$total_items = $wpdb->get_var(
					$wpdb->prepare(
						"
                    SELECT count(agent_id) FROM {$wpdb->prefix}wc_agents_commissions 
                    JOIN {$wpdb->prefix}postmeta ON {$wpdb->prefix}postmeta.post_id = {$wpdb->prefix}wc_agents_commissions.order_id 
                    WHERE 1 
                    AND agent_id = %d 
                    AND {$wpdb->prefix}postmeta.meta_key = '_customer_user' 
                    AND {$wpdb->prefix}postmeta.meta_value = %d
                    ",
						$where,
						$customer_id
					)
				);
			}
		}

		return $total_items;
	}

	/**
	 * Get  commissions by specific agent id
	 *
	 * @global type $wpdb
	 * @param  type $where
	 * @param  type $customer_id
	 * @return type
	 */
	public function get_commissions_by_agent_id( $where, $offset = false, $per_page = false, $customer_id = false, $export_type = false ) {
		global $wpdb;

		if ( is_admin() ) {
			// ADMIN COMMISSION FILTER WORK
			if ( isset( $_REQUEST['customer_id'] ) && isset( $_REQUEST['agent_id'] ) && empty( $_REQUEST['date_from'] ) && empty( $_REQUEST['date_to'] ) ) {
				// print_r("CASE 1");
				$customer_id = sanitize_text_field( $_REQUEST['customer_id'] );
				$agent_id    = sanitize_text_field( $_REQUEST['agent_id'] );
				// Show Commission List with Customer ID
				if ( $this->is_hpos_enabled() ) {
					$commissions = $wpdb->get_results(
						$wpdb->prepare(
							"
                        SELECT com.* FROM {$wpdb->prefix}wc_agents_commissions com
                        INNER JOIN {$wpdb->prefix}wc_orders o ON com.order_id = o.id
                        WHERE com.agent_id = %d
                        AND o.customer_id = %d
                        ",
							$agent_id,
							$customer_id
						)
					);
				} else {
					$commissions = $wpdb->get_results(
						$wpdb->prepare(
							"
                        SELECT * FROM {$wpdb->prefix}wc_agents_commissions
                        LEFT JOIN {$wpdb->prefix}postmeta 
                        ON {$wpdb->prefix}wc_agents_commissions.order_id = {$wpdb->prefix}postmeta.post_id
                        WHERE agent_id = %d 
                        AND meta_key = '_customer_user' 
                        AND meta_value = %d
                        ",
							$agent_id,
							$customer_id
						)
					);
				}

				return $commissions;
			} elseif ( isset( $_REQUEST['customer_id'] ) && isset( $_REQUEST['date_from'] ) && isset( $_REQUEST['date_to'] ) ) {

				$from        = gmdate( 'Y-m-d 00:00:01', strtotime( sanitize_text_field( $_REQUEST['date_from'] ) ) );
				$to          = gmdate( 'Y-m-d 23:59:59', strtotime( sanitize_text_field( $_REQUEST['date_to'] ) ) );
				$customer_id = sanitize_text_field( $_REQUEST['customer_id'] );
				$agent_id    = sanitize_text_field( $_REQUEST['agent_id'] );

				if ( empty( $customer_id ) && isset( $from ) && isset( $to ) && isset( $agent_id ) ) {
					// Show Commission List with Date Filter and Agent ID
					$commissions = $wpdb->get_results(
						$wpdb->prepare(
							"
                            SELECT DISTINCT agent_id, order_id, create_date,  commission_type, commission_percentage, commission_value, commission_status, id FROM {$wpdb->prefix}wc_agents_commissions
                            LEFT JOIN {$wpdb->prefix}postmeta ON {$wpdb->prefix}wc_agents_commissions.order_id = {$wpdb->prefix}postmeta.post_id
                            WHERE agent_id = %d AND ( create_date >= %s AND create_date <= %s)
                            ",
							$agent_id,
							$from,
							$to
						)
					);

					// wp_die('raza');
					return $commissions;
				} else {
					// Show Commission List with Date Filter & Agent ID & Customer ID
					if ( $this->is_hpos_enabled() ) {
						$commissions = $wpdb->get_results(
							$wpdb->prepare(
								"
                            SELECT com.* FROM {$wpdb->prefix}wc_agents_commissions com
                            INNER JOIN {$wpdb->prefix}wc_orders o ON com.order_id = o.id
                            WHERE com.agent_id = %d
                            AND o.customer_id = %d
                            AND ( com.create_date >= %s AND com.create_date <= %s)
                            ",
								$agent_id,
								$customer_id,
								$from,
								$to
							)
						);
					} else {
						$commissions = $wpdb->get_results(
							$wpdb->prepare(
								"
                            SELECT * FROM {$wpdb->prefix}wc_agents_commissions
                            LEFT JOIN {$wpdb->prefix}postmeta 
                            ON {$wpdb->prefix}wc_agents_commissions.order_id = {$wpdb->prefix}postmeta.post_id
                            WHERE agent_id = %d 
                            AND meta_key = '_customer_user' 
                            AND meta_value = %d 
                            AND ( create_date >= %s AND create_date <= %s)
                            ",
								$agent_id,
								$customer_id,
								$from,
								$to
							)
						);
					}

					return $commissions;
				}
			} elseif ( isset( $_REQUEST['agent_id'] ) && empty( $_REQUEST['customer_id'] ) && empty( $_REQUEST['date_from'] ) && empty( $_REQUEST['date_to'] ) ) {

				$agent_id    = sanitize_text_field( $_REQUEST['agent_id'] );
				$commissions = $wpdb->get_results(
					$wpdb->prepare(
						"
                    SELECT * FROM {$wpdb->prefix}wc_agents_commissions
                    WHERE agent_id = %d
                    ",
						$agent_id
					)
				);

				return $commissions;
			}
		}

		if ( isset( $_REQUEST['agent_id'] ) &&
			(
				(
					isset( $_REQUEST['date_from'] ) && isset( $_REQUEST['date_to'] ) && isset( $_REQUEST['user-filter'] )
					&& ! empty( sanitize_text_field( $_REQUEST['user-filter'] ) )
				)
				||
				(
					isset( $_REQUEST['date_from'] ) && ! empty( sanitize_text_field( $_REQUEST['date_from'] ) )
				)
				||
				(
					isset( $_REQUEST['date_to'] ) && ! empty( sanitize_text_field( $_REQUEST['date_to'] ) )
				)
			)
		) {

			$user_id = get_current_user_id();

			$agent_post = get_posts(
				array(
					'post_type'        => 'agent',
					'numberposts'      => 1,
					'meta_key'         => 'assign_user',
					'meta_value'       => $user_id,
					'suppress_filters' => true,
				)
			);

			$agent_id = $agent_post[0]->ID;

			if ( ! isset( $_REQUEST['user-filter'] ) ) {
				$_REQUEST['user-filter'] = '';
			}

			if ( ! empty( sanitize_text_field( $_REQUEST['user-filter'] ) )
			&& ! empty( sanitize_text_field( $_REQUEST['date_from'] ) )
			&& ! empty( sanitize_text_field( $_REQUEST['date_to'] ) ) ) {
				$from        = gmdate( 'Y-m-d 00:00:01', strtotime( sanitize_text_field( $_REQUEST['date_from'] ) ) );
				$to          = gmdate( 'Y-m-d 23:59:59', strtotime( sanitize_text_field( $_REQUEST['date_to'] ) ) );
				$user_filter = sanitize_text_field( $_REQUEST['user-filter'] );
				$agent_id    = ! empty( $_REQUEST['agent_id'] ) ? sanitize_text_field( $_REQUEST['agent_id'] ) : $agent_id;

				// Fetch commissions where agent_id matches and the related order's customer_id matches user_filter
				$commissions = $wpdb->get_results(
					$wpdb->prepare(
						"
                        SELECT DISTINCT com.agent_id, com.order_id, com.create_date, 
                                        com.commission_type, com.commission_percentage, 
                                        com.commission_value, com.commission_status, com.id
                        FROM {$wpdb->prefix}wc_agents_commissions com
                        LEFT JOIN {$wpdb->prefix}wc_orders o ON com.order_id = o.id
                        WHERE com.agent_id = %d 
                        AND o.customer_id = %d 
                        AND (com.create_date >= %s AND com.create_date <= %s)
                        ",
						$agent_id,
						$user_filter,
						$from,
						$to
					)
				);

				return $commissions;
			}

			if ( ! empty( sanitize_text_field( $_REQUEST['user-filter'] ) )
				&& empty( sanitize_text_field( $_REQUEST['date_from'] ) )
				&& empty( sanitize_text_field( $_REQUEST['date_to'] ) ) ) {

				$user_filter = sanitize_text_field( $_REQUEST['user-filter'] );
				$agent_id    = ! empty( $_REQUEST['agent_id'] ) ? sanitize_text_field( $_REQUEST['agent_id'] ) : $agent_id;

				$commissions = $wpdb->get_results(
					$wpdb->prepare(
						"
                        SELECT DISTINCT com.agent_id, com.order_id, com.create_date, 
                                        com.commission_type, com.commission_percentage, 
                                        com.commission_value, com.commission_status, com.id
                        FROM {$wpdb->prefix}wc_agents_commissions com
                        LEFT JOIN {$wpdb->prefix}wc_orders o ON com.order_id = o.id
                        WHERE com.agent_id = %d 
                        AND o.customer_id = %d 
                        ",
						$agent_id,
						$user_filter
					)
				);

				return $commissions;
			}

			if ( empty( sanitize_text_field( $_REQUEST['user-filter'] ) )
				&& ! empty( sanitize_text_field( $_REQUEST['date_from'] ) )
				&& ! empty( sanitize_text_field( $_REQUEST['date_to'] ) ) ) {

					$from     = gmdate( 'Y-m-d 00:00:01', strtotime( sanitize_text_field( $_REQUEST['date_from'] ) ) );
					$to       = gmdate( 'Y-m-d 23:59:59', strtotime( sanitize_text_field( $_REQUEST['date_to'] ) ) );
					$agent_id = ! empty( $_REQUEST['agent_id'] ) ? sanitize_text_field( $_REQUEST['agent_id'] ) : $agent_id;

					// Show Commission List on Agent commission with Date Filter
					$commissions = $wpdb->get_results(
						$wpdb->prepare(
							"
                        SELECT DISTINCT agent_id, order_id, create_date,  commission_type, commission_percentage, commission_value, commission_status, id  FROM {$wpdb->prefix}wc_agents_commissions
                        LEFT JOIN {$wpdb->prefix}postmeta ON {$wpdb->prefix}wc_agents_commissions.order_id = {$wpdb->prefix}postmeta.post_id
                        WHERE agent_id = %d AND ( create_date >= %s AND create_date <= %s )
                        ",
							$agent_id,
							$from,
							$to
						)
					);

					return $commissions;
			}
		} else {
			$user_id = get_current_user_id();

			$agent_post = get_posts(
				array(
					'post_type'        => 'agent',
					'numberposts'      => 1,
					'meta_key'         => 'assign_user',
					'meta_value'       => $user_id,
					'suppress_filters' => true,
				)
			);

			$agent_id = $agent_post[0]->ID;

			$commissions = $wpdb->get_results(
				$wpdb->prepare(
					"
                    SELECT * FROM {$wpdb->prefix}wc_agents_commissions ac
                    LEFT JOIN {$wpdb->prefix}posts p ON p.ID = ac.agent_id 
                    WHERE agent_id = %d
                    ",
					$agent_id
				)
			);

			return $commissions;
		}
	}

	/**
	 * Delete commissioon
	 *
	 * @global type $wpdb
	 * @param  type $delete_comiision_id
	 */
	public function delete_commission( $delete_commission_id ) {
		global $wpdb;

		$result = $wpdb->delete( $wpdb->prefix . 'wc_agents_commissions', array( 'id' => $delete_commission_id ), array( '%d' ) );

		if ( false != $result ) {
			/**
			 * Action.
			 *
			 * @since 1.0.4
			 */
			do_action( 'wc_agentafter_delete_commission_row', $delete_commission_id );

			return true;
		} else {
			return false;
		}
	}

	/**
	 * Query commission by sort sales agent
	 *
	 * @global type $wpdb
	 * @param  type $where
	 * @param  type $sort_type
	 * @param  type $offset
	 * @param  type $per_page
	 * @param  type $order
	 * @return type
	 */
	public function query_commission_by_sort_sales_agent( $where, $sort_type = false, $offset = false, $per_page = false, $order = false, $agent_filter = 0 ) {
		global $wpdb;

		if ( isset( $_REQUEST['agent_id'] ) && ! empty( sanitize_text_field( $_REQUEST['agent_id'] ) ) ) {
			$customer_date_flag = false;
			$only_date_flag     = false;
			$agent_id           = sanitize_text_field( $_REQUEST['agent_id'] );

			if ( isset( $_REQUEST['customer_id'] ) && ! empty( sanitize_text_field( $_REQUEST['customer_id'] ) ) && isset( $_REQUEST['date_from'] ) && ! empty( sanitize_text_field( $_REQUEST['date_from'] ) ) && isset( $_REQUEST['date_to'] ) && ! empty( sanitize_text_field( $_REQUEST['date_to'] ) ) ) {
				$customer_date_flag = true;
				$customer_id        = sanitize_text_field( $_REQUEST['customer_id'] );
				$from               = gmdate( 'Y-m-d 00:00:01', strtotime( sanitize_text_field( $_REQUEST['date_from'] ) ) );
				$to                 = gmdate( 'Y-m-d 23:59:59', strtotime( sanitize_text_field( $_REQUEST['date_to'] ) ) );
				// Show Commission List with Date Filter & Agent ID & Customer ID
				if ( $this->is_hpos_enabled() ) {
					$rows = $wpdb->get_results(
						$wpdb->prepare(
							"
                        SELECT com.* FROM {$wpdb->prefix}wc_agents_commissions com
                        INNER JOIN {$wpdb->prefix}wc_orders o ON com.order_id = o.id
                        WHERE com.agent_id = %d
                        AND o.customer_id = %d
                        AND ( com.create_date >= %s and com.create_date <= %s)
                        ORDER BY com.id DESC
                        LIMIT %d, %d
                        ",
							$agent_id,
							$customer_id,
							$from,
							$to,
							$offset,
							$per_page
						)
					);
				} else {
					$rows = $wpdb->get_results(
						$wpdb->prepare(
							"
                        SELECT * FROM {$wpdb->prefix}wc_agents_commissions
                        LEFT JOIN {$wpdb->prefix}postmeta 
                        ON {$wpdb->prefix}wc_agents_commissions.order_id = {$wpdb->prefix}postmeta.post_id
                        WHERE agent_id = %d 
                        AND meta_key = '_customer_user' 
                        AND meta_value = %d 
                        AND ( create_date >= %s and create_date <= %s) 
                        ORDER BY 'id' DESC 
                        LIMIT %d, %d
                        ",
							$agent_id,
							$customer_id,
							$from,
							$to,
							$offset,
							$per_page
						)
					);
				}

			} elseif ( isset( $_REQUEST['date_from'] ) && ! empty( sanitize_text_field( $_REQUEST['date_from'] ) ) && isset( $_REQUEST['date_to'] ) && ! empty( sanitize_text_field( $_REQUEST['date_to'] ) ) ) {
				$only_date_flag = true;
				$from           = gmdate( 'Y-m-d 00:00:01', strtotime( sanitize_text_field( $_REQUEST['date_from'] ) ) );
				$to             = gmdate( 'Y-m-d 23:59:59', strtotime( sanitize_text_field( $_REQUEST['date_to'] ) ) );
				// Show Commission List with Date Filter and Agent ID
				$rows = $wpdb->get_results(
					$wpdb->prepare(
						"
                        SELECT DISTINCT agent_id, order_id, create_date,  commission_type, commission_percentage, commission_value, commission_status, id FROM {$wpdb->prefix}wc_agents_commissions
                        LEFT JOIN {$wpdb->prefix}postmeta ON {$wpdb->prefix}wc_agents_commissions.order_id = {$wpdb->prefix}postmeta.post_id
                        WHERE 1 AND agent_id = %d AND ( create_date >= %s AND create_date <= %s) ORDER BY 'id' DESC LIMIT %d, %d
                        ",
						$agent_id,
						$from,
						$to,
						$offset,
						$per_page
					)
				);

			} elseif ( isset( $_REQUEST['customer_id'] ) && ! empty( sanitize_text_field( $_REQUEST['customer_id'] ) ) ) {

				$customer_id = sanitize_text_field( $_REQUEST['customer_id'] );
				// Show Commission List with Customer ID
				if ( $this->is_hpos_enabled() ) {
					$rows = $wpdb->get_results(
						$wpdb->prepare(
							"
                        SELECT com.* FROM {$wpdb->prefix}wc_agents_commissions com
                        INNER JOIN {$wpdb->prefix}wc_orders o ON com.order_id = o.id
                        WHERE com.agent_id = %d
                        AND o.customer_id = %d
                        ORDER BY com.id DESC
                        LIMIT %d, %d
                        ",
							$agent_id,
							$customer_id,
							$offset,
							$per_page
						)
					);
				} else {
					$rows = $wpdb->get_results(
						$wpdb->prepare(
							"
                        SELECT * FROM {$wpdb->prefix}wc_agents_commissions
                        LEFT JOIN {$wpdb->prefix}postmeta 
                        ON {$wpdb->prefix}wc_agents_commissions.order_id = {$wpdb->prefix}postmeta.post_id
                        WHERE agent_id = %d 
                        AND meta_key = '_customer_user' 
                        AND meta_value = %d 
                        ORDER BY 'id' DESC 
                        LIMIT %d, %d
                        ",
							$agent_id,
							$customer_id,
							$offset,
							$per_page
						)
					);
				}

			} else {
				$rows = $wpdb->get_results(
					$wpdb->prepare(
						"
                    SELECT * FROM {$wpdb->prefix}wc_agents_commissions 
                    LEFT JOIN {$wpdb->prefix}posts ON {$wpdb->prefix}posts.ID = {$wpdb->prefix}wc_agents_commissions.agent_id 
                    WHERE 1 AND agent_id = %d ORDER BY 'id' DESC LIMIT %d, %d
                    ",
						$agent_id,
						$offset,
						$per_page
					)
				);
			}

			/**
			 * Filter.
			 *
			 * @since 1.2
			 *
			 * Custom Task - CT-220
			 */
			return apply_filters( 'safw_admin_query_commission_list', $rows, $customer_date_flag, $only_date_flag, $offset, $per_page );
		}
	}


	/**
	 * Query commission by id
	 *
	 * @global type $wpdb
	 * @param  type $commission_id
	 * @return type
	 */
	public function query_get_commission_by_id( $commission_id ) {
		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"
            SELECT * FROM {$wpdb->prefix}wc_agents_commissions WHERE id = %d
            ",
				$commission_id
			)
		);
		return $rows;
	}

	public function get_commission_by_order_id( $order_id ) {
		global $wpdb;

		$wc_agents_commissions = $wpdb->prefix . $this->table_name;
		$rows                  = $wpdb->get_row(
			$wpdb->prepare(
				"
            SELECT * FROM {$wpdb->prefix}wc_agents_commissions WHERE order_id = %d
            ",
				$order_id
			)
		);
		return $rows;
	}

	/**
	 * Get all commission rows for an order (multi-agent split commissions).
	 *
	 * @param int $order_id Order ID.
	 * @return array
	 */
	public function get_commissions_by_order_id( $order_id ) {
		global $wpdb;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"
            SELECT * FROM {$wpdb->prefix}wc_agents_commissions WHERE order_id = %d ORDER BY id ASC
            ",
				$order_id
			)
		);

		return is_array( $rows ) ? $rows : array();
	}

	public function get_commission_by_order_agent( $order_id, $agent_id ) {
		global $wpdb;

		$rows = $wpdb->get_row(
			$wpdb->prepare(
				"
            SELECT * FROM {$wpdb->prefix}wc_agents_commissions WHERE order_id = %d AND agent_id = %d
            ",
				$order_id,
				$agent_id
			)
		);
		return $rows;
	}

	public function get_pending_commission_by_agent_id( $agent_id = '', $status = '' ) {
		global $wpdb;
		$wc_agents_commissions = $wpdb->prefix . $this->table_name;
		$result                = $wpdb->get_results(
			$wpdb->prepare(
				"
            SELECT * FROM {$wpdb->prefix}wc_agents_commissions WHERE agent_id = %d AND commission_status = %s
            ",
				$agent_id,
				$status
			)
		);

		return $result;
	}

	public function get_commission_by_agent_id( $agent_id = '', $id = '' ) {
		global $wpdb;
		$results = $wpdb->get_results(
			$wpdb->prepare(
				"
            SELECT * FROM {$wpdb->prefix}wc_agents_commissions WHERE agent_id = %d
            ",
				$agent_id
			)
		);

		return $results;
	}
}

return new AgentCommission();
