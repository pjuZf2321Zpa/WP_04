<?php
/**
 * UserService
 *
 * This service manages wholesale-specific user interfaces and metadata within the
 * WordPress administration area. It handles the display and saving of custom fields
 * like Tax ID, uploaded documents, and wholesale group assignment on user profiles,
 * and extends the users list table with relevant information.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * UserService
 *
 * Implements administrative functions for viewing and editing wholesale user data.
 *
 * @implements ServiceInterface
 */
class UserService implements ServiceInterface {


   
	/**
	 * Trait that provides static access to wholesale pricing settings.
	 */
	use WholesaleSettings;

	/**
	 * UserService constructor.
	 *
	 * Hooks into WordPress actions and filters for managing user columns and profile fields.
	 */
	public function __construct() {
		// Manage user list table columns.
		add_filter('manage_users_columns', array( $this, 'columns' ));
		add_filter('manage_users_custom_column', array( $this, 'column_values' ), 10, 3);

		// Display custom fields on user profile edit screens.
		add_action('show_user_profile', array( $this, 'fields' ));
		add_action('edit_user_profile', array( $this, 'fields' ));

		// Save custom fields when user profile is updated.
		add_action('personal_options_update', array( $this, 'update_fields' ));
		add_action('edit_user_profile_update', array( $this, 'update_fields' ));
	}    

	/**
	 * Adds a 'Group' column to the user list table.
	 *
	 * @param  array $column Existing columns in the user table.
	 * @return array Modified array of columns.
	 */
	public function columns( $column ) {
		if (isset($column['posts']) ) {
			unset($column['posts']);
		}
		$column['wwp_group'] = 'Group';
		if (! isset($column['post']) ) {
			$column['posts'] = 'Posts';
		}
		return $column;
	}

	/**
	 * Populates the custom column values for the user list table.
	 *
	 * Specifically handles the 'wwp_group' column to display the user's assigned wholesale group.
	 *
	 * @param  string $val         The column value (unused for custom column).
	 * @param  string $column_name The name of the custom column.
	 * @param  int    $user_id     The ID of the user being processed.
	 * @return string The value to display in the column.
	 */
	public function column_values( $val, $column_name, $user_id ) {
		switch ( $column_name ) {
			case 'wwp_group':
				$group_name = '-';
				if (! empty(get_user_meta($user_id, 'add_in_wwp_group', true)) && 'true' == get_user_meta($user_id, 'add_in_wwp_group', true) ) {
					$group_id = get_user_meta($user_id, 'user_wwp_groupname', true);
					$group_name = get_the_title($group_id);
				}
				return $group_name;
			default:
		}
		return $val;
	}

	/**
	 * Renders custom fields on the user profile edit screen in the WordPress admin.
	 *
	 * Includes fields for Wholesaler Tax ID, File Uploads, Custom Registration Fields,
	 * and Form Builder data.
	 *
	 * @param  \WP_User $user The user object whose profile is being displayed.
	 * @return void
	 */
	public function fields( $user ) {
		$woo_tax_id    = get_the_author_meta('wwp_wholesaler_tax_id', $user->ID);
		$file_id       = get_the_author_meta('wwp_wholesaler_file_upload', $user->ID);
		$registrations = self::get_registration_settings();
		if (is_array($file_id) ) {
			$file = array();

			if (isset($registrations['multiple_file_upload']) && 'yes' == $registrations['multiple_file_upload']) {
				foreach ($file_id as $i) {
					$file[] = $i; 
				}
			}
		} else {
			$file = ! is_wp_error($file_id) ? wp_get_attachment_url($file_id) : '';
		}
		wp_nonce_field('wwp_wholesaler_nonce', 'wwp_wholesaler_nonce'); ?>
		<h3><?php esc_html_e('Others Fields', 'woocommerce-wholesale-pricing'); ?></h3>
		<table class="form-table">
			<tr>
				<th>
					<label for="birth-date-day"><?php esc_html_e('Wholesaler Tax ID', 'woocommerce-wholesale-pricing'); ?></label>
				</th>
				<td>
					<input type="text" name="wwp_wholesaler_tax_id" id="wwp_wholesaler_tax_id" value="<?php esc_attr_e($woo_tax_id); ?>">
				</td>
			</tr>
			<?php 
			
			if (! empty($file) ) { 
				?>
			<tr>
				<th>
					<label for="wwp_wholesaler_file_upload"><?php esc_html_e('Wholesaler File Upload', 'woocommerce-wholesale-pricing'); ?></label>
				</th>
				<td>
				<?php if (isset($registrations['multiple_file_upload']) && 'yes' == $registrations['multiple_file_upload'] && is_array($file) ) : ?>
					<?php 
					/**
					 * Hooks
					 *
					 * @since 3.0
					 */
					do_action('wwp_wholesaler_file_upload_user_edit_page', $file); 
					?>
				<?php else : ?>
					<p><a href="<?php echo esc_url(admin_url('upload.php?item=' . $file_id)); ?>"><img src="<?php echo esc_url($file); ?>" width="100" height="100" class="wwp_wholesaler_file_upload"></a></p>
				<?php endif; ?>
				</td>
			</tr>
				<?php
			}
			for ( $i = 1; $i < 6; $i++ ) {
				if (isset($registrations[ 'custom_field_' . $i ]) && ! empty(get_the_author_meta('wwp_custom_field_' . $i, $user->ID)) ) {
					$value = get_the_author_meta('wwp_custom_field_' . $i, $user->ID);
					?>
					<tr>
						<th>
							<label for="wwp_custom_field_<?php esc_attr_e($i); ?>"><?php echo ! empty($registrations[ 'woo_custom_field_' . $i ]) ? esc_html($registrations[ 'woo_custom_field_' . $i ]) : esc_html__('Custom Field', 'woocommerce-wholesale-pricing'); ?></label>
						</th>
						<td>
						<?php if ('5' == $i ) { ?>
							<textarea rows="4" cols="120" name="wwp_custom_field_<?php esc_attr_e($i); ?>" id="wwp_custom_field_<?php esc_attr_e($i); ?>" ><?php esc_attr_e($value); ?></textarea>
						<?php } else { ?>
							<input type="text" name="wwp_custom_field_<?php esc_attr_e($i); ?>" id="wwp_custom_field_<?php esc_attr_e($i); ?>" value="<?php esc_attr_e($value); ?>">
						<?php } ?>
						</td>
					</tr>
					<?php
				}
			}
			?>
			<?php if (( isset($registrations['display_fields_registration']) && 'yes' == $registrations['display_fields_registration'] ) || ( isset($registrations['display_fields_myaccount']) && 'yes' == $registrations['display_fields_myaccount'] ) ) { ?>
			<tr>
				<th>
					<label for="render_form_builder"><?php esc_html_e('Wholesaler Extra Fields Data', 'woocommerce-wholesale-pricing'); ?></label>
				</th>
				<td>
				<?php render_form_builder( 'get_user_meta', $user->ID ); ?>
				</td>
			</tr>
			<?php } ?>
		</table>
		<?php
	}

	/**
	 * Saves custom fields and handles cleanup when a user profile is updated.
	 *
	 * It performs nonce and capability checks, saves Tax ID and custom fields,
	 * and deletes pending wholesale registration requests if the user's role is changed.
	 *
	 * @param  int $user_id The ID of the user being updated.
	 * @return bool|void False if user cannot edit the profile, otherwise void.
	 */
	public function update_fields( $user_id ) {
		if (! current_user_can('edit_user', $user_id) ) {
			return false;
		}
		
		if (! isset($_POST['wwp_wholesaler_nonce']) || ( isset($_POST['wwp_wholesaler_nonce']) && ! wp_verify_nonce(wc_clean($_POST['wwp_wholesaler_nonce']), 'wwp_wholesaler_nonce') ) ) {
			wp_die(esc_html__('security check', 'wholesale-for-woocommerce'));
		}
		
		$post = $_POST;

		{
		
		if (isset($_POST['wwp_wholesaler_tax_id']) ) {
				
			update_user_meta($user_id, 'wwp_wholesaler_tax_id', wc_clean($_POST['wwp_wholesaler_tax_id']));
				
		}

		$form_data = wwp_get_form_builder_posted_data( $post );
		if ( ! empty( $form_data ) ) {
			update_user_meta( $user_id, 'wwp_form_data_json', $form_data );
		}

		for ( $i = 1; $i < 6; $i++ ) {
			if (isset($_POST[ 'wwp_custom_field_' . $i ]) ) {
				update_user_meta($user_id, 'wwp_custom_field_' . $i, wc_clean($_POST[ 'wwp_custom_field_' . $i ]));
			}
		}
		}

		{
			$user = get_userdata($user_id);
			
		if (! $user ) {
			return;
		}
			$old_roles = $user->roles;
			
		if (isset($post['role']) ) {
			$new_role = sanitize_text_field($post['role']);
				
			if (! in_array($new_role, $old_roles) ) {
				$args = array(
					'post_type'   => 'wwp_requests', 
					'meta_query'  => array( 
						array( 
							'key' => '_user_id',
							'value' => $user_id, 
						), 
					), 
				);
				$post = get_posts($args);
				if (is_array($post) ) {
					foreach ( $post as $key => $value ) {
						wp_delete_post($value->ID);
					}
				}
				delete_user_meta($user_id, '_user_status');
			}
		}
		}
	}

	/**
	 * Determines whether this service should be initialized based on the environment.
	 *
	 * This service is only relevant in the WordPress administration area.
	 *
	 * @return bool True if the current request is in the admin area, false otherwise.
	 */
	public static function resolveDependency() {
		return is_admin();
	}
}
