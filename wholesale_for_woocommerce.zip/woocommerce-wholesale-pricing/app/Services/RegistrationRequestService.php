<?php
/**
 * RegistrationRequestService
 *
 * Handles the comprehensive management of wholesale registration requests,
 * including Custom Post Type (CPT) administration, status synchronization
 * with user roles, and handling of post lifecycle events (save, trash, delete).
 *
 * @package    WooCommerceWholesalePricing\Services
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Strategies\Init;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Service class for managing the lifecycle of a wholesale registration request.
 *
 * This class coordinates administrative tasks related to the 'wwp_requests'
 * CPT. It defines custom list table columns, handles quick actions for
 * approving/rejecting users, and ensures the user's role and metadata are
 * updated when a request is modified. It implements ServiceInterface for
 * integration with the plugin's service architecture.
 *
 * @implements ServiceInterface
 * @extends    Init
 */
class RegistrationRequestService extends Init implements ServiceInterface {

	/**
	 * Includes methods for retrieving general wholesale settings.
	 */
	use WholesaleSettings;

	
	/**
	 * Constructor: Hooks up all the necessary WordPress actions and filters.
	 */
	public function __construct() {
		parent::__construct();
		// Custom column management for the wwp_requests CPT list table
		add_filter('manage_wwp_requests_posts_columns', array( $this, 'columns' ));
		add_action('manage_wwp_requests_posts_custom_column', array( $this, 'column_values' ), 15, 2);

		// Admin Edit Screen Meta Box
		add_action('add_meta_boxes', array( $this, 'meta_box' ));

		// Handle status updates from the CPT edit screen save action
		add_action('save_post_wwp_requests', array( $this, 'update_request' ));

		// Cleanup request CPT when a linked user is deleted
		add_action('deleted_user', array( $this, 'delete_request' ));

		// Handle CPT status changes (like restoring from trash)
		add_action('transition_post_status', array( $this, 'wwp_handle_post_restore' ), 10, 3);
		add_action('wp_trash_post', array( $this, 'wwp_handle_post_trashed' ), 10, 1);
		add_action('before_delete_post', array( $this, 'wwp_user_status_on_post_delete' ));
	}

	/**
	 * Processes and finalizes wholesale user registration requests based on user action.
	 *
	 * This function serves as the callback for handling quick actions (like 'Approve' or 'Reject')
	 * taken by an administrator on a wholesale request. It relies on status and ID parameters
	 * passed via the global `$_GET` superglobal.
	 *
	 * It enforces several security and process flow checks:
	 * 1. Guards against execution during `AUTOSAVE` or `AJAX` processes.
	 * 2. Validates user intent via a strict nonce check (`request_user_role_nonce`).
	 *
	 * If validation passes, it proceeds to:
	 * - Update the request CPT post meta and WooCommerce user status.
	 * - If **'active'**: strips all roles, adds the configured wholesale role, and triggers the
	 * `wwp_wholesale_user_request_approved` action.
	 * - If **'rejected'**: strips any wholesale roles, reverts the user to the site's default
	 * role, and triggers the `wwp_wholesale_user_rejection_notification` action.
	 *
	 * @return void
	 */
	public function register() {
		// Autosave
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) {
			return;
		}
		// AJAX
		if (defined('DOING_AJAX') && DOING_AJAX ) {
			return;
		}
		if (! isset($_GET['_wpnonce']) || ! wp_verify_nonce(wc_clean($_GET['_wpnonce']), 'request_user_role_nonce') ) {
			return;
		}
		$settings = self::get_pricing_settings();
		$post_id = null;
		if (isset($_GET['post_id']) ) {
			$post_id = wc_clean($_GET['post_id']);

		}
		if (isset($_GET['user_status']) && ( ( isset($_GET['post_type']) && 'wwp_requests' == $_GET['post_type'] )  || ( isset($_GET['page']) && 'wwp_wholesale' == $_GET['page'] ) ) ) {
			$status = wc_clean($_GET['user_status']);

			$user_role_set = 'default_wholesaler';

			if (isset($settings['default_multipe_wholesale_roles']) && '' != $settings['default_multipe_wholesale_roles'] && 'multiple' == $settings['wholesale_role'] ) {
				$user_role_set = $settings['default_multipe_wholesale_roles'];
				if (! empty(get_post_meta($post_id, 'user_role_set', true)) ) {
					$user_role_set = get_post_meta($post_id, 'user_role_set', true);
				}
			}
			
			$term_list = wp_get_post_terms($post_id, 'wholesale_user_roles', array( 'fields' => 'all' ));

			$allterms = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));

			$user_id = get_post_meta($post_id, '_user_id', true);
			$user = get_user($user_id);

			if (! $user ) {
				return;
			}

			$customer = new \WC_Customer($user_id);
			//update_user_meta( $user_id, '_user_status', $status );
			update_post_meta($post_id, '_user_status', $status);
			$customer->update_meta_data('_user_status', $status);
			
			$u = new \WP_User($user_id);

			if ('active' == $status ) {
			
				$wp_roles = new \WP_Roles();
				$names    = $wp_roles->get_names();

				foreach ( $names as $key => $value ) {
					$u->remove_role($key);
				}
				$u->add_role($user_role_set);

				foreach ( $term_list as $term_remove ) {
					wp_remove_object_terms($post_id, $term_remove->slug, 'wholesale_user_roles', true);
				}

				wp_set_object_terms($post_id, $user_role_set, 'wholesale_user_roles', true);

				if ('sent' != get_post_meta($post_id, '_approval_notification', true) ) {
				
					/**
					* Hooks
					*
					* @since 3.0
					*/
					do_action('wwp_wholesale_user_request_approved', $user_id);
					update_post_meta($post_id, '_approval_notification', 'sent');
				}
			} elseif ('rejected' == $status ) { 
					
				foreach ( $allterms as $key => $value ) {
					$u->remove_role($value->slug);
				}
					
					$u->add_role(get_option('default_role'));
					
					/**
					* Hooks
					*
					* @since 3.0
					*/
					do_action('wwp_wholesale_user_rejection_notification', $user_id);
			}
			$customer->save();
		}
	}

	/**
	 * Customizes the columns shown in the 'wwp_requests' CPT list table.
	 *
	 * @param  array $columns Existing columns.
	 * @return array Modified columns.
	 */
	public function columns( $columns ) {
		unset($columns['author']);
		unset($columns['date']);
		$columns['user_email']  = esc_html__('User Email', 'woocommerce-wholesale-pricing');
		$columns['user_status'] = esc_html__('User Status', 'woocommerce-wholesale-pricing');
		$columns['date']        = esc_html__('Date', 'woocommerce-wholesale-pricing');
		$columns['action']      = esc_html__('Action', 'woocommerce-wholesale-pricing');
		return $columns;
	}

	/**
	 * Renders the values for custom columns in the 'wwp_requests' list table.
	 *
	 * @param  string $column  The name of the column to display.
	 * @param  int    $post_id The current post ID.
	 * @return void
	 */
	public function column_values( $column, $post_id ) {
		switch ( $column ) {
			case 'user_status':
				$status = get_post_meta($post_id, '_user_status', true);
				if ('active' == $status ) {
					echo '<p class="approved">' . esc_html__('Approved', 'woocommerce-wholesale-pricing') . '</p>';
				} elseif ('waiting' == $status ) {
					echo '<p class="waiting">' . esc_html__('Waiting', 'woocommerce-wholesale-pricing') . '</p>';
				} elseif ('rejected' == $status ) {
					echo '<p class="rejected">' . esc_html__('Rejected', 'woocommerce-wholesale-pricing') . '</p>';
				}
				break;

			case 'user_email':
				$user_id = get_post_meta($post_id, '_user_id', true);
				if (! empty($user_id) ) {
					$user_info = get_userdata($user_id);
					if ($user_info ) {
						echo esc_html($user_info->user_email);
					}
				}
				break;

			case 'action':
				$user_id = get_post_meta($post_id, '_user_id', true);
				if (! empty($user_id) ) {
					$status = get_post_meta($post_id, '_user_status', true);
					$nonce  = wp_create_nonce('request_user_role_nonce');
					?>
					<form action="">
						<a href="edit.php?post_type=wwp_requests&post_id=<?php echo esc_attr($post_id); ?>&user_status=active&_wpnonce=<?php echo esc_attr($nonce); ?>">Approve</a> | 
						<a href="edit.php?post_type=wwp_requests&post_id=<?php echo esc_attr($post_id); ?>&user_status=rejected&_wpnonce=<?php echo esc_attr($nonce); ?>">Reject</a>
					</form> 
					<?php
				}
				break;
		}
	}

	/**
	 * Registers the meta box for user request confirmation on the CPT edit screen.
	 *
	 * @return void
	 */
	public function meta_box() {
		add_meta_box(
			'wholesale-pricing-pro-user-status',
			esc_html__('Wholesale User Request Confirmation', 'woocommerce-wholesale-pricing'),
			function () {
				return wwp_view('admin.requests.meta-box'); 
			},
			'wwp_requests',
			'normal',
			'high'
		);
	}

	/**
	 * Handles updating user status and role upon saving the wwp_requests CPT.
	 * This handles updates from the single Edit Request page.
	 *
	 * @param  int $post_id The post ID.
	 * @return void
	 */
	public function update_request( $post_id ) {
		// Autosave
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) {
			return;
		}
		// AJAX
		if (defined('DOING_AJAX') && DOING_AJAX ) {
			return;
		}
		if (! isset($_POST['request_user_role_nonce']) || ! wp_verify_nonce(wc_clean($_POST['request_user_role_nonce']), 'request_user_role_nonce') ) {
			return;
		}
		if (isset($_POST['user_status']) ) {
			$status = wc_clean($_POST['user_status']);
			if (isset($_POST['user_role_set']) ) {
				$user_role_set = wc_clean($_POST['user_role_set']);
			} else {
				$user_role_set = 'default_wholesaler';
			}

			$user_id = get_post_meta($post_id, '_user_id', true);
			if (user_can($user_id, 'edit_others_posts') ) {
				wp_die('Administrator or editor role can not be changed.');
			}

			$rejected_note = isset($_POST['rejected_note']) ? wc_clean($_POST['rejected_note']) : '';

			update_post_meta($post_id, '_user_status', $status);
			update_post_meta($post_id, 'user_role_set', $user_role_set);
			update_user_meta($user_id, '_user_status', $status);
			if ( '' !== $rejected_note || 'rejected' === $status ) {
				update_user_meta($user_id, 'rejected_note', $rejected_note);
			}

			$term_list = wp_get_post_terms($post_id, 'wholesale_user_roles', array( 'fields' => 'all' ));

			$allterms = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));

			$user_id = get_post_meta($post_id, '_user_id', true);
			$user = get_user($user_id);

			if (! $user ) {
				return;
			}
			if (user_can($user_id, 'edit_others_posts') ) {
				wp_die('Administrator or editor role can not be changed.');
			}
			
			$customer = new \WC_Customer($user_id);
			
			$customer->update_meta_data('_user_status', $status);
			$customer->update_meta_data('rejected_note', $rejected_note);

			$u = new \WP_User($user_id);
			if ('active' == $status ) {
				$wp_roles = new \WP_Roles();
				$names    = $wp_roles->get_names();

				foreach ( $names as $key => $value ) {
					$u->remove_role($key);
				}
				$u->add_role($user_role_set);

				foreach ( $term_list as $term_remove ) {

					wp_remove_object_terms($post_id, $term_remove->slug, 'wholesale_user_roles', true);
				}

				wp_set_object_terms($post_id, $user_role_set, 'wholesale_user_roles', true);

				if ('sent' != get_post_meta($post_id, '_approval_notification', true) ) {
				
					/**
					* Hooks
					*
					* @since 3.0
					*/
					do_action('wwp_wholesale_user_request_approved', $user_id);
					update_post_meta($post_id, '_approval_notification', 'sent');
				}
			} elseif ('rejected' == $status ) {
				foreach ( $allterms as $key => $value ) {
					$u->remove_role($value->slug);
				}
					$u->add_role(get_option('default_role'));
					
					/**
					* Hooks
					*
					* @since 3.0
					*/
					do_action('wwp_wholesale_user_rejection_notification', $user_id);
			}
			$customer->save();
		}
	}

	/**
	 * Deletes the wwp_requests CPT when the associated user is deleted.
	 *
	 * @param  int $user_id The ID of the deleted user.
	 * @return void
	 */
	public function delete_request( $user_id ) {
		$request = get_posts(
			array(
				'post_type'     => 'wwp_requests',
				'fields'        => 'ids',
				'meta_key'      => '_user_id',
				'meta_value'    => $user_id,
			)
		);

		if (! empty($request) && count($request) > 0 ) {
			wp_delete_post(reset($request), true);
		}
	}

	/**
	 * Handles restoring a request CPT from the trash.
	 *
	 * @param  string   $new_status The new post status.
	 * @param  string   $old_status The old post status.
	 * @param  \WP_Post $post       The post object.
	 * @return void
	 */
	public function wwp_handle_post_restore( $new_status, $old_status, $post ) {

		if ($post && 'trash' === $old_status && 'wwp_requests' === $post->post_type ) {
			
			if ('draft' == $new_status  ) {
				wp_update_post(
					array(
					'ID' => $post->ID,
					'post_status' => 'publish',
					) 
				);
			}

			$user_id = get_post_meta($post->ID, '_user_id', true);

			if ($user_id ) {
				update_post_meta($post->ID, '_user_status', 'waiting');
				update_user_meta($user_id, '_user_status', 'waiting');
			}

			$default_role = get_option('default_role');
			$user = get_user_by('ID', $user_id);

			if ($user && ! in_array($default_role, $user->roles) ) {
				$user->set_role($default_role);
			}
		}
	}

	/**
	 * Handles moving a request CPT to the trash.
	 *
	 * @param  int $post_id The ID of the post being trashed.
	 * @return void
	 */
	public function wwp_handle_post_trashed( $post_id ) {
		$post = get_post($post_id);

		if ($post &&'wwp_requests' === $post->post_type  ) {

			$user_id = get_post_meta($post_id, '_user_id', true);

			if ($user_id ) {
				$user = get_user_by('ID', $user_id);
				update_post_meta($post_id, '_user_status', 'waiting');
				update_user_meta($user_id, '_user_status', 'waiting');
				if ($user ) {
					$user_roles = $user->roles;
					$allterms = get_terms(
						array(
						'taxonomy'   => 'wholesale_user_roles',
						'hide_empty' => false,
						) 
					);

					$default_role = get_option('default_role');
					foreach ( $allterms as $term ) {
						if (in_array($term->slug, $user_roles) ) {
							$user->set_role($default_role);
						}
					}
				}
			}
		}
	}

	/**
	 * Clears user status meta when the request CPT is permanently deleted.
	 *
	 * @param  int $post_id The ID of the post being deleted.
	 * @return void
	 */
	public function wwp_user_status_on_post_delete( $post_id ) {
		$post = get_post($post_id);

		if ($post && 'wwp_requests' === $post->post_type ) {
			$user_id = get_post_meta($post_id, '_user_id', true);

			if ($user_id ) {
				delete_post_meta($post_id, '_user_status');

				delete_user_meta($user_id, '_user_status');
			}
		}
	}

	/**
	 * Determines if this service should be active (dependency resolution).
	 * This service runs if 'advance_registration_form' is set to 'no'.
	 *
	 * @return bool True if this service should be registered.
	 */
	public static function resolveDependency() {
		$status     = filter_input(INPUT_GET, 'user_status', FILTER_SANITIZE_SPECIAL_CHARS);
		$post_id    = filter_input(INPUT_GET, 'post_id', FILTER_SANITIZE_SPECIAL_CHARS);

		$request_check = ( is_admin() && $status && $post_id );

		$settings                   = self::get_pricing_settings();
		$advance_registration_form  = isset($settings['advance_registration_form']) ? sanitize_text_field($settings['advance_registration_form']) : 'no';
		
		return ( 'no' == $advance_registration_form ) || ( $request_check );
	}
}
