<?php
/**
 * Read and update wholesale registration form settings.
 *
 * @package WooCommerceWholesalePricing\App\Services
 */

namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\RegistrationFieldCatalog;
use WooCommerceWholesalePricing\App\Providers\WholesaleOption;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

/**
 * Manages wwp_wholesale_registration_options for the default registration form UI.
 */
class WholesaleRegistrationSettingsService {

	/**
	 * Keys managed by this service (registration.php fields only).
	 *
	 * @var list<string>
	 */
	const ALLOWED_KEYS = array(
		'billing_first_name', 'enable_billing_first_name', 'required_billing_first_name',
		'billing_last_name', 'enable_billing_last_name', 'required_billing_last_name',
		'billing_company', 'enable_billing_company', 'required_billing_company',
		'billing_address_1', 'enable_billing_address_1', 'required_billing_address_1',
		'billing_address_2', 'enable_billing_address_2', 'required_billing_address_2',
		'billing_city', 'enable_billing_city', 'required_billing_city',
		'billing_post_code', 'enable_billing_post_code', 'required_billing_post_code', 'billing_validate_uk_postcode',
		'billing_countries', 'enable_billing_country', 'required_billing_country',
		'billing_state', 'enable_billing_state', 'required_billing_state',
		'billing_phone', 'enable_billing_phone', 'required_billing_phone',
		'shipping_first_name', 'enable_shipping_first_name', 'required_shipping_first_name',
		'shipping_last_name', 'enable_shipping_last_name', 'required_shipping_last_name',
		'shipping_company', 'enable_shipping_company', 'required_shipping_company',
		'shipping_address_1', 'enable_shipping_address_1', 'required_shipping_address_1',
		'shipping_address_2', 'enable_shipping_address_2', 'required_shipping_address_2',
		'shipping_city', 'enable_shipping_city', 'required_shipping_city',
		'shipping_post_code', 'enable_shipping_post_code', 'required_shipping_post_code', 'shipping_validate_uk_postcode',
		'shipping_countries', 'enable_shipping_country', 'required_shipping_country',
		'shipping_state', 'enable_shipping_state', 'required_shipping_state',
		'woo_tax_id', 'enable_tex_id', 'required_tex_id',
		'woo_file_upload', 'enable_file_upload', 'required_file_upload', 'multiple_file_upload',
		'tax_id_display', 'extra_pass_field', 'extra_role_fields', 'show_role_on_reg_page',
		'vat_validation', 'show_tax_on_checkout', 'vat_countries',
		'enable_recaptcha', 'enable_recaptcha_quote', 'recaptcha_version',
		'recaptcha_v2_site_key', 'recaptcha_v2_secret_key', 'recaptcha_v2_theme',
		'recaptcha_v3_site_key', 'recaptcha_v3_secret_key', 'recaptcha_v3_score', 'recaptcha_v3_badge_position',
		'custommer_billing_address', 'custommer_shipping_address',
		'display_fields_registration', 'display_fields_myaccount', 'display_fields_checkout',
	);

	/**
	 * Get formatted registration settings exposed to the ability API.
	 *
	 * @return array<string, mixed>
	 */
	public function get_settings() {
		$stored = $this->get_raw_settings();

		return array(
			'option_key' => WholesaleOption::REGISTRATION_OPTION,
			'settings'   => $this->format_settings( $stored ),
		);
	}

	/**
	 * Update allowed registration settings (partial merge).
	 *
	 * @param array<string, mixed> $settings Settings patch.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function update_settings( $settings ) {
		if ( empty( $settings ) ) {
			return new \WP_Error(
				'wwp_registration_missing_settings',
				__( 'Registration settings are required for update.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$settings = RegistrationFieldCatalog::normalize_settings_keys( $settings );

		$unknown = array_diff( array_keys( $settings ), self::ALLOWED_KEYS );
		if ( ! empty( $unknown ) ) {
			return new \WP_Error(
				'wwp_registration_invalid_field',
				sprintf(
					/* translators: %s: comma-separated field names */
					__( 'Unknown registration setting(s): %s', 'woocommerce-wholesale-pricing' ),
					implode( ', ', $unknown )
				),
				array( 'status' => 400 )
			);
		}

		$stored  = $this->get_raw_settings();
		$updated = $stored;

		foreach ( $settings as $key => $value ) {
			$sanitized = $this->sanitize_value( $key, $value );
			if ( is_wp_error( $sanitized ) ) {
				return $sanitized;
			}

			$updated[ $key ] = $sanitized;
		}

		WholesaleSettingsHelper::update_registration_settings( $updated );

		return $this->get_settings();
	}

	/**
	 * Snapshot raw stored values for undo.
	 *
	 * @return array<string, mixed>
	 */
	public function snapshot_settings() {
		return array(
			'option_key' => WholesaleOption::REGISTRATION_OPTION,
			'value'      => $this->get_raw_settings(),
		);
	}

	/**
	 * Restore a full registration settings snapshot.
	 *
	 * @param array<string, mixed> $snapshot Snapshot data.
	 * @return true|\WP_Error
	 */
	public function restore_settings( $snapshot ) {
		if ( empty( $snapshot['option_key'] ) || WholesaleOption::REGISTRATION_OPTION !== $snapshot['option_key'] ) {
			return new \WP_Error(
				'wwp_registration_restore_invalid_snapshot',
				__( 'Cannot restore registration settings: invalid snapshot.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$value = is_array( isset( $snapshot['value'] ) ? $snapshot['value'] : null ) ? $snapshot['value'] : array();
		WholesaleSettingsHelper::update_registration_settings( $value );

		return true;
	}

	/**
	 * Get raw stored registration settings without formatting, for internal use only (e.g. snapshot/restore).
	 * 
	 * @return array<string, mixed>
	 */
	private function get_raw_settings() {
		$stored = WholesaleSettingsHelper::get_registration_settings();

		return is_array( $stored ) ? $stored : array();
	}

	/**
	 * Format stored settings for API exposure, ensuring all allowed keys are present and properly typed.
	 * 
	 * @param array<string, mixed> $stored Stored settings.
	 * @return array<string, mixed>
	 */
	private function format_settings( $stored ) {
		$formatted = array();

		foreach ( self::ALLOWED_KEYS as $key ) {
			$formatted[ $key ] = $this->format_value( $key, isset( $stored[ $key ] ) ? $stored[ $key ] : null );
		}

		return $formatted;
	}

	/**
	 * Format a stored value for a given setting key.
	 *
	 * @param string $key   Setting key.
	 * @param mixed  $value Stored value.
	 * @return mixed
	 */
	private function format_value( $key, $value ) {
		if ( 'show_role_on_reg_page' === $key || 'vat_countries' === $key ) {
			if ( ! is_array( $value ) ) {
				return array();
			}

			return array_values( array_map( 'strval', $value ) );
		}

		if ( $this->is_yes_no_key( $key ) ) {
			return 'yes' === $value;
		}

		return is_string( $value ) ? $value : ( is_scalar( $value ) ? (string) $value : '' );
	}

	/**
	 * Sanitize an incoming value for a given setting key, validating as needed.
	 * 
	 * @param string $key   Setting key.
	 * @param mixed  $value Incoming value.
	 * @return mixed|\WP_Error
	 */
	private function sanitize_value( $key, $value ) {
		if ( 'show_role_on_reg_page' === $key || 'vat_countries' === $key ) {
			if ( ! is_array( $value ) ) {
				return array();
			}

			return array_values(
				array_filter(
					array_map(
						static function ( $slug ) {
							return sanitize_key( (string) $slug );
						},
						$value
					)
				)
			);
		}

		if ( $this->is_yes_no_key( $key ) ) {
			if ( is_bool( $value ) ) {
				return $value ? 'yes' : '';
			}

			if ( in_array( $value, array( 'yes', 'no', '1', '0', 1, 0 ), true ) ) {
				return in_array( $value, array( 'yes', '1', 1 ), true ) ? 'yes' : '';
			}

			return new \WP_Error(
				'wwp_registration_invalid_boolean',
				__( 'Boolean registration fields must be true or false.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( 'recaptcha_version' === $key && ! in_array( (string) $value, array( 'v2', 'v3' ), true ) ) {
			return new \WP_Error(
				'wwp_registration_invalid_recaptcha_version',
				__( 'recaptcha_version must be v2 or v3.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( 'recaptcha_v2_theme' === $key && ! in_array( (string) $value, array( 'light', 'dark' ), true ) ) {
			return new \WP_Error(
				'wwp_registration_invalid_recaptcha_theme',
				__( 'recaptcha_v2_theme must be light or dark.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( 'recaptcha_v3_score' === $key ) {
			$allowed = array( '0.1', '0.2', '0.3', '0.4', '0.5' );
			$score   = (string) $value;
			if ( ! in_array( $score, $allowed, true ) ) {
				return new \WP_Error(
					'wwp_registration_invalid_recaptcha_score',
					__( 'recaptcha_v3_score must be one of 0.1, 0.2, 0.3, 0.4, 0.5.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			return $score;
		}

		if ( 'recaptcha_v3_badge_position' === $key ) {
			$allowed = array( 'inline', 'bottomleft', 'bottomright' );
			$badge   = (string) $value;
			if ( ! in_array( $badge, $allowed, true ) ) {
				return new \WP_Error(
					'wwp_registration_invalid_recaptcha_badge',
					__( 'recaptcha_v3_badge_position must be inline, bottomleft, or bottomright.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			return $badge;
		}

		return is_string( $value ) ? sanitize_text_field( $value ) : sanitize_text_field( (string) $value );
	}

	/**
	 * Is the given key a boolean yes/no field?
	 * 
	 * @param string $key Setting key.
	 * @return bool
	 */
	private function is_yes_no_key( $key ) {
		if ( in_array(
			$key,
			array(
				'tax_id_display',
				'extra_pass_field',
				'extra_role_fields',
				'multiple_file_upload',
				'enable_recaptcha',
				'enable_recaptcha_quote',
				'vat_validation',
				'show_tax_on_checkout',
				'billing_validate_uk_postcode',
				'shipping_validate_uk_postcode',
				'custommer_billing_address',
				'custommer_shipping_address',
				'display_fields_registration',
				'display_fields_myaccount',
				'display_fields_checkout',
			),
			true
		) ) {
			return true;
		}

		return 0 === strpos( $key, 'enable_' ) || 0 === strpos( $key, 'required_' );
	}
}
