<?php
/**
 * Registers the Purchase Order payment gateway and shared helpers.
 *
 * @package WooCommerceWholesalePricing\App\Services
 */

namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Modules\Wholesale\PaymentGateway\BlockPurchaseOrderPaymentMethod;
use WooCommerceWholesalePricing\App\Modules\Wholesale\PaymentGateway\PurchaseOrderPaymentMethod;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Purchase Order gateway service.
 */
class PurchaseOrderGatewayService implements ServiceInterface {

	const GATEWAY_ID = 'wwp_purchase_order';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_filter( 'woocommerce_payment_gateways', array( $this, 'register_gateway' ) );
		add_action( 'woocommerce_blocks_loaded', array( $this, 'register_block_payment_method' ) );
		add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
		add_action( 'woocommerce_admin_order_data_after_billing_address', array( $this, 'render_admin_order_details' ), 20, 1 );
		add_action( 'add_meta_boxes', array( $this, 'register_admin_order_metabox' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_checkout_assets' ) );
	}

	/**
	 * Whether this service should load.
	 *
	 * @return bool
	 */
	public static function resolveDependency() {
		return true;
	}

	/**
	 * Register the classic payment gateway.
	 *
	 * @param array $gateways Registered gateways.
	 * @return array
	 */
	public function register_gateway( $gateways ) {
		if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
			return $gateways;
		}

		$gateways[] = PurchaseOrderPaymentMethod::class;

		return $gateways;
	}

	/**
	 * Register the gateway with WooCommerce Blocks checkout.
	 *
	 * @return void
	 */
	public function register_block_payment_method() {
		if ( ! class_exists( '\Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
			return;
		}

		add_action(
			'woocommerce_blocks_payment_method_type_registration',
			function ( $payment_method_registry ) {
				$payment_method_registry->register( new BlockPurchaseOrderPaymentMethod() );
			}
		);
	}

	/**
	 * REST routes for block checkout document upload.
	 *
	 * @return void
	 */
	public function register_rest_routes() {
		register_rest_route(
			'wwp/v1',
			'/po-document',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_rest_upload' ),
				'permission_callback' => array( $this, 'rest_upload_permissions' ),
			)
		);
	}

	/**
	 * Logged-in shopper with PO enabled may upload.
	 *
	 * @return bool
	 */
	public function rest_upload_permissions() {
		return is_user_logged_in() && self::is_po_enabled_for_user();
	}

	/**
	 * Handle REST document upload.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function handle_rest_upload( $request ) {
		unset( $request );

		$settings = self::get_po_settings_for_user();
		if ( empty( $settings['enabled'] ) || empty( $settings['allow_upload'] ) ) {
			return new \WP_Error( 'wwp_po_upload_disabled', __( 'Document upload is not enabled for your wholesale role.', 'woocommerce-wholesale-pricing' ), array( 'status' => 403 ) );
		}

		$file = self::get_uploaded_file_from_request( 'file' );
		if ( empty( $file['name'] ) ) {
			return new \WP_Error( 'wwp_po_missing_file', __( 'Please attach a purchase order document.', 'woocommerce-wholesale-pricing' ), array( 'status' => 400 ) );
		}

		$result = self::create_attachment_from_file( $file, $settings );
		if ( is_wp_error( $result ) ) {
			$result->add_data( array( 'status' => 400 ) );
			return $result;
		}

		return rest_ensure_response(
			array(
				'attachment_id' => (int) $result,
			)
		);
	}

	/**
	 * Checkout stylesheet.
	 *
	 * @return void
	 */
	public function enqueue_checkout_assets() {
		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
			return;
		}

		wp_enqueue_style(
			'wwp-po-checkout',
			WWP_PLUGIN_URL . 'public/css/purchase-order-checkout.css',
			array(),
			WWP_VERSION
		);

		wp_enqueue_script(
			'wwp-po-checkout',
			WWP_PLUGIN_URL . 'public/js/purchase-order-checkout.js',
			array( 'jquery' ),
			WWP_VERSION,
			true
		);

		$settings = self::get_po_settings_for_user();
		wp_localize_script(
			'wwp-po-checkout',
			'wwpPoCheckout',
			array(
				'gatewayId'    => self::GATEWAY_ID,
				'uploadUrl'     => esc_url_raw( rest_url( 'wwp/v1/po-document' ) ),
				'uploadNonce'   => wp_create_nonce( 'wp_rest' ),
				'fileTypes'     => isset( $settings['file_types'] ) ? $settings['file_types'] : array(),
				'maxFileSize'   => isset( $settings['max_file_size'] ) ? absint( $settings['max_file_size'] ) : 5,
				'errorFileType' => __( 'This file type is not allowed.', 'woocommerce-wholesale-pricing' ),
				'errorFileSize' => __( 'The document is too large.', 'woocommerce-wholesale-pricing' ),
				'errorUpload'   => __( 'The document could not be uploaded. Please try again.', 'woocommerce-wholesale-pricing' ),
			)
		);
	}

	/**
	 * Register a side metabox on the order edit screen.
	 *
	 * @return void
	 */
	public function register_admin_order_metabox() {
		$screens = array( 'shop_order', 'woocommerce_page_wc-orders' );
		foreach ( $screens as $screen ) {
			add_meta_box(
				'wwp-po-order-document',
				__( 'Purchase Order', 'woocommerce-wholesale-pricing' ),
				array( $this, 'render_admin_order_metabox' ),
				$screen,
				'side',
				'high'
			);
		}
	}

	/**
	 * Metabox callback.
	 *
	 * @param mixed $post_or_order Post or order object.
	 * @return void
	 */
	public function render_admin_order_metabox( $post_or_order ) {
		$order = $post_or_order instanceof \WC_Order
			? $post_or_order
			: wc_get_order( isset( $post_or_order->ID ) ? $post_or_order->ID : 0 );

		$this->render_admin_order_details( $order );
	}

	/**
	 * Render PO details on the admin order screen.
	 *
	 * @param \WC_Order $order Order.
	 * @return void
	 */
	public function render_admin_order_details( $order ) {
		if ( ! $order instanceof \WC_Order ) {
			return;
		}

		static $rendered = array();
		$order_id        = $order->get_id();
		if ( isset( $rendered[ $order_id ] ) ) {
			return;
		}
		$rendered[ $order_id ] = true;

		$is_po           = self::GATEWAY_ID === $order->get_payment_method();
		$po_number       = (string) $order->get_meta( '_wwp_po_number' );
		$attachment_id  = absint( $order->get_meta( '_wwp_po_attachment_id' ) );
		$require_number = 'yes' === (string) $order->get_meta( '_wwp_po_require_number' );
		$allow_upload    = 'yes' === (string) $order->get_meta( '_wwp_po_allow_upload' );

		$filename = (string) $order->get_meta( '_wwp_po_attachment_filename' );

		if ( ! $is_po && '' === $po_number && ! $attachment_id ) {
			return;
		}

		$attachment_url  = $attachment_id ? wp_get_attachment_url( $attachment_id ) : '';
		$attachment_name = $filename;
		if ( $attachment_id && '' === $attachment_name ) {
			$attachment_name = get_the_title( $attachment_id );
		}
		if ( $attachment_id && '' === $attachment_name ) {
			$attachment_name = basename( (string) get_attached_file( $attachment_id ) );
		}
		if ( $attachment_id && ! $attachment_url ) {
			$attachment_url = admin_url( 'upload.php?item=' . $attachment_id );
		}

		wwp_view(
			'admin.order.purchase-order-details',
			array(
				'po_number'       => $po_number,
				'require_number'  => $is_po || $require_number || '' !== $po_number,
				'allow_upload'    => $is_po || $allow_upload || $attachment_id > 0,
				'attachment_url'  => $attachment_url,
				'attachment_name' => $attachment_name,
			),
			true
		);
	}

	/**
	 * Allowed PO upload extensions (no leading dot).
	 *
	 * @return list<string>
	 */
	public static function get_allowed_po_file_types() {
		return array( 'pdf', 'jpg', 'jpeg', 'png', 'csv', 'doc', 'docx', 'xls', 'xlsx', 'txt', 'rtf', 'zip' );
	}

	/**
	 * Resolve wholesale role term ID for a user.
	 *
	 * @param int $user_id User ID, 0 = current user.
	 * @return int
	 */
	public static function get_role_term_id( $user_id = 0 ) {
		$user_id = absint( $user_id );

		if ( $user_id && get_current_user_id() !== $user_id ) {
			return self::get_role_term_id_from_user( $user_id );
		}

		if ( function_exists( 'get_current_user_role_id' ) ) {
			$term_id = absint( get_current_user_role_id() );
			if ( $term_id ) {
				return $term_id;
			}
		}

		return self::get_role_term_id_from_user( $user_id ? $user_id : get_current_user_id() );
	}

	/**
	 * Role term from a user's WP roles.
	 *
	 * @param int $user_id User ID.
	 * @return int
	 */
	private static function get_role_term_id_from_user( $user_id ) {
		$user_id = absint( $user_id );
		if ( ! $user_id ) {
			return 0;
		}

		$user = get_userdata( $user_id );
		if ( ! $user || empty( $user->roles ) ) {
			return 0;
		}

		$taxonomy = 'wholesale_user_roles';
		if ( function_exists( 'wwp_env' ) ) {
			$slug = (string) wwp_env()->get( 'role_taxonomy' );
			if ( '' !== $slug ) {
				$taxonomy = $slug;
			}
		}

		foreach ( (array) $user->roles as $role ) {
			$term = get_term_by( 'slug', $role, $taxonomy );
			if ( $term && ! is_wp_error( $term ) ) {
				return (int) $term->term_id;
			}
		}

		return 0;
	}

	/**
	 * PO settings for a role term.
	 *
	 * @param int $term_id Term ID.
	 * @return array<string, mixed>
	 */
	public static function get_po_settings_for_term( $term_id ) {
		$term_id = absint( $term_id );
		if ( ! $term_id ) {
			return self::empty_po_settings();
		}

		$file_types = get_term_meta( $term_id, 'wwp_po_file_types', true );
		$file_types = self::sanitize_po_file_types( $file_types );
		if ( empty( $file_types ) ) {
			$file_types = array( 'pdf', 'jpg', 'png' );
		}

		$allow_upload   = 'yes' === (string) get_term_meta( $term_id, 'wwp_po_allow_upload', true );
		$require_upload = $allow_upload && 'yes' === (string) get_term_meta( $term_id, 'wwp_po_require_upload', true );

		return array(
			'enabled'        => 'yes' === (string) get_term_meta( $term_id, 'wwp_po_enabled', true ),
			'require_number' => 'yes' === (string) get_term_meta( $term_id, 'wwp_po_require_number', true ),
			'allow_upload'   => $allow_upload,
			'require_upload' => $require_upload,
			'file_types'     => $file_types,
			'max_file_size'  => absint( get_term_meta( $term_id, 'wwp_po_max_file_size', true ) ) ?: 5,
		);
	}

	/**
	 * PO settings for a user.
	 *
	 * @param int $user_id User ID, 0 = current.
	 * @return array<string, mixed>
	 */
	public static function get_po_settings_for_user( $user_id = 0 ) {
		return self::get_po_settings_for_term( self::get_role_term_id( $user_id ) );
	}

	/**
	 * Whether PO is enabled for the current (or given) user.
	 *
	 * @param int $user_id User ID.
	 * @return bool
	 */
	public static function is_po_enabled_for_user( $user_id = 0 ) {
		$settings = self::get_po_settings_for_user( $user_id );
		return ! empty( $settings['enabled'] );
	}

	/**
	 * Validate PO number / attachment against role settings.
	 *
	 * @param array  $settings      Role PO settings.
	 * @param string $po_number    Submitted number.
	 * @param int    $attachment_id Attachment ID.
	 * @return string[] Error messages.
	 */
	public static function validate_po_submission( $settings, $po_number, $attachment_id ) {
		$errors         = array();
		$po_number      = is_string( $po_number ) ? trim( $po_number ) : '';
		$attachment_id = absint( $attachment_id );

		if ( ! empty( $settings['require_number'] ) && '' === $po_number ) {
			$errors[] = __( 'Please enter a purchase order number.', 'woocommerce-wholesale-pricing' );
		}

		if ( ! empty( $settings['require_upload'] ) && $attachment_id < 1 ) {
			$errors[] = __( 'Please attach a purchase order document.', 'woocommerce-wholesale-pricing' );
		}

		if ( $attachment_id > 0 && empty( $settings['allow_upload'] ) ) {
			$errors[] = __( 'Document upload is not enabled for this payment method.', 'woocommerce-wholesale-pricing' );
		}

		if ( $attachment_id > 0 ) {
			$owner_error = self::verify_attachment_owner( $attachment_id );
			if ( $owner_error ) {
				$errors[] = $owner_error;
			}
		}

		return $errors;
	}

	/**
	 * Validate an uploaded file against type and size rules.
	 *
	 * @param array $file     PHP $_FILES element.
	 * @param array $settings Role PO settings.
	 * @return \WP_Error|true
	 */
	public static function validate_uploaded_file( $file, $settings ) {
		if ( ! is_array( $file ) || empty( $file['name'] ) ) {
			return new \WP_Error( 'wwp_po_missing_file', __( 'Please attach a purchase order document.', 'woocommerce-wholesale-pricing' ) );
		}

		if ( ! empty( $file['error'] ) && UPLOAD_ERR_OK !== (int) $file['error'] ) {
			return new \WP_Error( 'wwp_po_upload_error', __( 'The document could not be uploaded. Please try again.', 'woocommerce-wholesale-pricing' ) );
		}

		$ext = strtolower( pathinfo( (string) $file['name'], PATHINFO_EXTENSION ) );
		$ext = ltrim( $ext, '.' );
		$allowed = isset( $settings['file_types'] ) && is_array( $settings['file_types'] ) ? $settings['file_types'] : array();

		if ( empty( $allowed ) || ! in_array( $ext, $allowed, true ) ) {
			return new \WP_Error(
				'wwp_po_invalid_type',
				sprintf(
					/* translators: %s: comma-separated extensions */
					__( 'This file type is not allowed. Allowed types: %s.', 'woocommerce-wholesale-pricing' ),
					'.' . implode( ', .', $allowed )
				)
			);
		}

		$max_mb    = isset( $settings['max_file_size'] ) ? absint( $settings['max_file_size'] ) : 5;
		$max_bytes = ( $max_mb > 0 ? $max_mb : 5 ) * 1024 * 1024;
		$size      = isset( $file['size'] ) ? absint( $file['size'] ) : 0;

		if ( $size > $max_bytes ) {
			return new \WP_Error(
				'wwp_po_file_too_large',
				sprintf(
					/* translators: %d: maximum size in MB */
					__( 'The document is too large. Maximum size is %d MB per file.', 'woocommerce-wholesale-pricing' ),
					$max_mb > 0 ? $max_mb : 5
				)
			);
		}

		return true;
	}

	/**
	 * Create a private attachment from an uploaded file.
	 *
	 * @param array $file     PHP file array.
	 * @param array $settings  Role PO settings.
	 * @return int|\WP_Error Attachment ID or error.
	 */
	public static function create_attachment_from_file( $file, $settings ) {
		$valid = self::validate_uploaded_file( $file, $settings );
		if ( is_wp_error( $valid ) ) {
			return $valid;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$mimes     = self::mimes_for_extensions( isset( $settings['file_types'] ) ? $settings['file_types'] : array() );
		$overrides = array(
			'test_form' => false,
			'mimes'     => $mimes,
		);

		$uploaded = wp_handle_upload( $file, $overrides );
		if ( isset( $uploaded['error'] ) ) {
			return new \WP_Error( 'wwp_po_upload_error', (string) $uploaded['error'] );
		}

		$attachment = array(
			'post_mime_type' => $uploaded['type'],
			'post_title'     => sanitize_file_name( wp_basename( $uploaded['file'] ) ),
			'post_content'   => '',
			'post_status'    => 'private',
			'post_author'    => get_current_user_id(),
		);

		$attachment_id = wp_insert_attachment( $attachment, $uploaded['file'] );
		if ( is_wp_error( $attachment_id ) || ! $attachment_id ) {
			return new \WP_Error( 'wwp_po_upload_error', __( 'The document could not be saved.', 'woocommerce-wholesale-pricing' ) );
		}

		$metadata = wp_generate_attachment_metadata( $attachment_id, $uploaded['file'] );
		if ( ! empty( $metadata ) ) {
			wp_update_attachment_metadata( $attachment_id, $metadata );
		}

		update_post_meta( $attachment_id, '_wwp_po_user_id', get_current_user_id() );
		update_post_meta( $attachment_id, '_wwp_po_pending', 'yes' );

		return (int) $attachment_id;
	}

	/**
	 * Persist PO data on an order.
	 *
	 * @param \WC_Order $order         Order.
	 * @param string    $po_number    PO number.
	 * @param int       $attachment_id Attachment ID.
	 * @param array     $settings      Role PO settings.
	 * @return void
	 */
	public static function save_po_to_order( $order, $po_number, $attachment_id, $settings ) {
		if ( ! $order instanceof \WC_Order ) {
			return;
		}

		$po_number      = sanitize_text_field( (string) $po_number );
		$attachment_id = absint( $attachment_id );

		$order->update_meta_data( '_wwp_po_number', $po_number );
		$order->update_meta_data( '_wwp_po_attachment_id', $attachment_id );
		$order->update_meta_data( '_wwp_po_require_number', ! empty( $settings['require_number'] ) ? 'yes' : 'no' );
		$order->update_meta_data( '_wwp_po_allow_upload', ! empty( $settings['allow_upload'] ) ? 'yes' : 'no' );

		if ( $attachment_id ) {
			$file     = get_attached_file( $attachment_id );
			$filename = $file ? wp_basename( $file ) : get_the_title( $attachment_id );
			$order->update_meta_data( '_wwp_po_attachment_filename', $filename );
			update_post_meta( $attachment_id, '_wwp_po_order_id', $order->get_id() );
			delete_post_meta( $attachment_id, '_wwp_po_pending' );
		}

		$order->save();
	}

	/**
	 * Sanitized upload array from $_FILES.
	 *
	 * @param string $field File field name.
	 * @return array{name:string,type:string,tmp_name:string,error:int,size:int}
	 */
	public static function get_uploaded_file_from_request( $field = 'wwp_po_document' ) {
		$field = sanitize_key( $field );
		if ( '' === $field || empty( $_FILES[ $field ]['name'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return array();
		}

		return array(
			'name'     => sanitize_file_name( wp_unslash( $_FILES[ $field ]['name'] ) ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
			'type'     => isset( $_FILES[ $field ]['type'] ) ? sanitize_mime_type( wp_unslash( $_FILES[ $field ]['type'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification.Missing
			'tmp_name' => isset( $_FILES[ $field ]['tmp_name'] ) ? $_FILES[ $field ]['tmp_name'] : '', // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
			'error'    => isset( $_FILES[ $field ]['error'] ) ? absint( $_FILES[ $field ]['error'] ) : UPLOAD_ERR_NO_FILE, // phpcs:ignore WordPress.Security.NonceVerification.Missing
			'size'     => isset( $_FILES[ $field ]['size'] ) ? absint( $_FILES[ $field ]['size'] ) : 0, // phpcs:ignore WordPress.Security.NonceVerification.Missing
		);
	}

	/**
	 * Collect PO number and attachment from classic POST / Store API payment data.
	 *
	 * @param mixed $request Optional Store API request.
	 * @return array{po_number:string,attachment_id:int}
	 */
	public static function get_submission_from_request( $request = null ) {
		$po_number      = '';
		$attachment_id = 0;

		if ( isset( $_POST['wwp_po_number'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$po_number = sanitize_text_field( wp_unslash( $_POST['wwp_po_number'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}

		if ( isset( $_POST['wwp_po_attachment_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$attachment_id = absint( wp_unslash( $_POST['wwp_po_attachment_id'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}

		$payment_data = self::extract_payment_data( $request );
		if ( isset( $payment_data['wwp_po_number'] ) && '' === $po_number ) {
			$po_number = sanitize_text_field( (string) $payment_data['wwp_po_number'] );
		}
		if ( ! $attachment_id ) {
			foreach ( array( 'wwp_po_attachment_id', 'po_attachment_id', 'attachment_id' ) as $key ) {
				if ( ! empty( $payment_data[ $key ] ) ) {
					$attachment_id = absint( $payment_data[ $key ] );
					break;
				}
			}
		}

		return array(
			'po_number'      => $po_number,
			'attachment_id' => $attachment_id,
		);
	}

	/**
	 * Normalize Store API payment_data into a key/value map.
	 *
	 * @param mixed $request Request object or null.
	 * @return array<string, string>
	 */
	public static function extract_payment_data( $request ) {
		$raw = array();

		if ( is_object( $request ) && method_exists( $request, 'get_param' ) ) {
			$param = $request->get_param( 'payment_data' );
			if ( is_array( $param ) ) {
				$raw = $param;
			}
		}

		if ( empty( $raw ) && is_object( $request ) && method_exists( $request, 'get_json_params' ) ) {
			$json = $request->get_json_params();
			if ( is_array( $json ) && isset( $json['payment_data'] ) && is_array( $json['payment_data'] ) ) {
				$raw = $json['payment_data'];
			}
		}

		if ( empty( $raw ) && isset( $_POST['payment_data'] ) && is_array( $_POST['payment_data'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$raw = wc_clean( wp_unslash( $_POST['payment_data'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}

		$map = array();
		foreach ( $raw as $key => $item ) {
			if ( is_array( $item ) && isset( $item['key'] ) ) {
				$map[ (string) $item['key'] ] = isset( $item['value'] ) ? (string) $item['value'] : '';
			} elseif ( is_string( $key ) && ! is_array( $item ) ) {
				$map[ (string) $key ] = (string) $item;
			}
		}

		return $map;
	}

	/**
	 * Throw a Store API route exception.
	 *
	 * @param string $message Error message.
	 * @return void
	 * @throws \Automattic\WooCommerce\StoreApi\Exceptions\RouteException|\WC_REST_Exception When Store API is available.
	 */
	public static function throw_store_api_error( $message ) {
		if ( class_exists( '\Automattic\WooCommerce\StoreApi\Exceptions\RouteException' ) ) {
			throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException(
				'woocommerce_rest_purchase_order_invalid',
				esc_html( $message ),
				400
			);
		}

		throw new \WC_REST_Exception( 'woocommerce_rest_purchase_order_invalid', esc_html( $message ), 400 );
	}

	/**
	 * Empty settings payload.
	 *
	 * @return array<string, mixed>
	 */
	private static function empty_po_settings() {
		return array(
			'enabled'        => false,
			'require_number' => false,
			'allow_upload'   => false,
			'require_upload' => false,
			'file_types'     => array( 'pdf', 'jpg', 'png' ),
			'max_file_size'  => 5,
		);
	}

	/**
	 * Sanitize file type list.
	 *
	 * @param mixed $value Raw value.
	 * @return list<string>
	 */
	private static function sanitize_po_file_types( $value ) {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$clean   = array();
		$allowed = self::get_allowed_po_file_types();
		foreach ( $value as $ext ) {
			$ext = ltrim( strtolower( (string) $ext ), '.' );
			if ( in_array( $ext, $allowed, true ) ) {
				$clean[] = $ext;
			}
		}

		return array_values( array_unique( $clean ) );
	}

	/**
	 * MIME map for allowed extensions.
	 *
	 * @param list<string> $extensions Extensions.
	 * @return array<string, string>
	 */
	private static function mimes_for_extensions( $extensions ) {
		$map = array(
			'pdf'  => 'application/pdf',
			'jpg'  => 'image/jpeg',
			'jpeg' => 'image/jpeg',
			'png'  => 'image/png',
			'csv'  => 'text/csv',
			'doc'  => 'application/msword',
			'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
			'xls'  => 'application/vnd.ms-excel',
			'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
			'txt'  => 'text/plain',
			'rtf'  => 'application/rtf',
			'zip'  => 'application/zip',
		);

		$mimes = array();
		foreach ( (array) $extensions as $ext ) {
			if ( isset( $map[ $ext ] ) ) {
				$mimes[ $ext ] = $map[ $ext ];
			}
		}

		return $mimes;
	}

	/**
	 * Confirm the attachment belongs to the current user.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return string|null Error message or null.
	 */
	private static function verify_attachment_owner( $attachment_id ) {
		$post = get_post( $attachment_id );
		if ( ! $post || 'attachment' !== $post->post_type ) {
			return __( 'The attached purchase order document is invalid.', 'woocommerce-wholesale-pricing' );
		}

		$current = get_current_user_id();
		$meta    = absint( get_post_meta( $attachment_id, '_wwp_po_user_id', true ) );
		$author  = absint( $post->post_author );

		if ( $current && ( $author === $current || $meta === $current ) ) {
			return null;
		}

		if ( current_user_can( 'manage_woocommerce' ) ) {
			return null;
		}

		return __( 'The attached purchase order document is invalid.', 'woocommerce-wholesale-pricing' );
	}
}
