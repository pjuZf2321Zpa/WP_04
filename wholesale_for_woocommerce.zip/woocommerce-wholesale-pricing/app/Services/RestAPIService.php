<?php
/**
 * RestAPIService
 *
 * This service is responsible for initializing and managing all custom REST API controllers
 * for the wholesale pricing functionality. It ensures that custom endpoints are registered
 * with WordPress and includes logic for authenticating API requests.
 *
 * @package    WooCommerceWholesalePricing\Services
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Modules\RestAPIs\Wholesale_Category_V1_Controller;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Wholesale_Products_V1_Controller;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Wholesale_Product_Variations_V1_Controller;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Wholesale_Roles_V1_Controller;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Wholesale_Settings_V1_Controller;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Dashboard_V1_Controller;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Apis\AI_Assistant_V1_Controller;
/**
 * Service class for registering and managing all custom Wholesale REST API controllers.
 *
 * This class implements the Singleton pattern to ensure a single point of control
 * for initializing the custom API endpoints under the 'wholesale/v1' namespace.
 * It also hooks into the WooCommerce REST authentication to secure these custom routes.
 *
 * @since 1.12.0
 */
class RestAPIService {

	/**
	 * Property that holds the single main instance of WWP_REST_API.
	 *
	 * @since 1.12.0
	 *
	 * @var WWP_REST_API
	 */
	private static $_instance;

	/**
	 * Property that holds WWP API Products Controllers.
	 *
	 * @since 1.12.0
	 * 
	 * @var WWP_REST_API_Wholesale_Products_Controller
	 */
	public $wwp_rest_api_wholesale_products_controller;

	/**
	 * Property that holds WWP API Variations Controllers.
	 *
	 * @since 1.12.0
	 * 
	 * @var WWP_REST_API_Wholesale_Variations_Controller
	 */
	public $wwp_rest_api_wholesale_variations_controller;

	/**
	 * Property that holds WWP API Wholesale Roles Controllers.
	 *
	 * @since 1.12.0
	 * 
	 * @var WWP_REST_API_Wholesale_Roles_Controller
	 */
	public $wwp_rest_api_wholesale_roles_controller;

	/**
	 * Property that holds WWP API Wholesale Category Controllers.
	 *
	 * @since 1.12.0
	 * 
	 * @var WWP_REST_Wholesale_Category_V1_Controller
	 */
	public $WWP_REST_Wholesale_Category_V1_Controller;

	/**
	 * Property that holds WWP API Settings Controllers.
	 *
	 * @since 1.12.0
	 * 
	 * @var WWP_REST_Wholesale_Settings_V1_Controller
	 */
	public $WWP_REST_Wholesale_Settings_V1_Controller;
	
	/**
	 * RestAPIService constructor.
	 *
	 * Hooks into WordPress to load controllers and enable API key authentication.
	 *
	 * @since 1.12.0
	 *
	 * @param array $dependencies Array of instance objects of all dependencies (unused in this implementation).
	 */
	public function __construct( $dependencies = array() ) {
		add_action('rest_api_init', array( $this, 'load_api_wwp_controllers' ), 5);
		add_action('woocommerce_rest_is_request_to_rest_api', array( $this, 'authenticate_user' ));
	}

	/**
	 * Load WWP API.
	 *
	 * This method explicitly registers the hooks required for API functionality.
	 * It is functionally identical to the constructor's actions but can be called externally.
	 *
	 * @return void
	 */
	public function load_wwp_api() {
		// API controllers using wholesale/v1 namespace.
		add_action('rest_api_init', array( $this, 'load_api_wwp_controllers' ), 5);

		// Authenticate users if api keys are provided.
		add_action('woocommerce_rest_is_request_to_rest_api', array( $this, 'authenticate_user' ));
	}

	/**
	 * Ensures that only one instance of RestAPIService is loaded (Singleton Pattern).
	 *
	 * @since 1.12.0
	 *
	 * @param  array $dependencies Array of instance objects of all dependencies (unused in this implementation).
	 * @return self The single instance of RestAPIService.
	 */
	public static function instance( $dependencies = array() ) {
		if (! self::$_instance instanceof self ) {
			self::$_instance = new self($dependencies);
		}

		return self::$_instance;
	}

	/**
	 * Instantiates and registers all custom Wholesale REST API controllers.
	 *
	 * This method is hooked into the `rest_api_init` action.
	 *
	 * @since 1.12
	 *
	 * @return void
	 */
	public function load_api_wwp_controllers() {
		$this->wwp_rest_api_wholesale_products_controller   = new Wholesale_Products_V1_Controller();
		$this->wwp_rest_api_wholesale_variations_controller = new Wholesale_Product_Variations_V1_Controller();
		$this->wwp_rest_api_wholesale_roles_controller      = new Wholesale_Roles_V1_Controller();
		$this->WWP_REST_Wholesale_Category_V1_Controller    = new Wholesale_Category_V1_Controller();
		$this->WWP_REST_Wholesale_Settings_V1_Controller    = new Wholesale_Settings_V1_Controller();

		new Dashboard_V1_Controller();
		new AI_Assistant_V1_Controller();
	}

	/**
	 * Authenticates the user for custom 'wholesale/' REST API requests.
	 *
	 * This checks if the request URI contains the 'wholesale/' endpoint prefix
	 * and returns true to signal that the standard WooCommerce API authentication
	 * (via consumer keys/secrets) should proceed.
	 *
	 * @param  bool $rest_request Whether the request is already recognized as a REST API request.
	 * @return bool True if the request is targeting a custom wholesale endpoint, or the original value.
	 */
	public function authenticate_user( $rest_request ) {
		$rest_prefix = trailingslashit(rest_get_url_prefix());
		$request_uri = isset($_SERVER['REQUEST_URI']) ? esc_url_raw(wp_unslash($_SERVER['REQUEST_URI'])) : '';

		// Authenticate if the request is using the wholesale/v1 endpoint.
		if (false !== strpos($request_uri, $rest_prefix . 'wholesale/') ) {
			return true;
		}

		return $rest_request;
	}
}
