<?php
/**
 * GroupService class.
 *
 * Manages the administrative interface, custom list table columns,
 * row actions, meta boxes, and post metadata saving for the 'wwp_groups'
 * custom post type in the WordPress admin.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Service class for managing the Wholesale Group custom post type administration.
 * 
 * @implements ServiceInterface
 */
class GroupService implements ServiceInterface {


	/**
	 * The slug of the wholesale group custom post type, retrieved from the environment.
	 *
	 * @var string
	 */
	private $slug;

	/**
	 * Constructor.
	 *
	 * Sets up the necessary filters and actions for the wholesale group CPT administration.
	 *
	 * @return void
	 */
	public function __construct() {
		// Retrieve the group slug from the environment configuration.
		$this->slug = wwp_env()->get('group_slug');

		// Manage custom list table columns.
		add_filter('manage_' . $this->slug . '_posts_columns', array( $this, 'columns' ));
		add_action('manage_' . $this->slug . '_posts_custom_column', array( $this, 'column_values' ), 15, 2);
		
		// Remove default row actions like 'Quick Edit' and 'View'.
		add_filter('post_row_actions', array( $this, 'row_actions' ), 10, 2);

		// Register custom meta boxes for group configuration.
		add_action('add_meta_boxes', array( $this, 'meta_box' ));

		// Save post metadata when a group is updated.
		add_action('save_post_' . $this->slug, array( $this, 'update' ), 10, 2);
	}

	/**
	 * Defines the custom columns displayed in the wholesale groups list table.
	 *
	 * Adds 'Members', 'Status', and 'Action' columns before the 'Date' column.
	 *
	 * @filter manage_{$this->slug}_posts_columns
	 * @param  array $columns The existing array of columns.
	 * @return array The modified array of columns.
	 */
	public function columns( $columns ) {
		$temp = $columns['date'];
		unset($columns['date']);
		$columns['wwp_group_members']   = esc_html__('Members', 'woocommerce-wholesale-pricing');
		$columns['wwp_group_status']    = esc_html__('Status', 'woocommerce-wholesale-pricing');
		$columns['wwp_group_action']    = esc_html__('Action', 'woocommerce-wholesale-pricing');
		$columns['date']                = $temp;
		return $columns;
	}

	/**
	 * Populates the content for the custom columns in the wholesale groups list table.
	 *
	 * Handles the display of members count, current status, and activation/deactivation links.
	 *
	 * @action manage_{$this->slug}_posts_custom_column
	 * @param  string $column  The name of the custom column.
	 * @param  int    $post_id The ID of the post (wholesale group).
	 * @return void
	 */
	public function column_values( $column, $post_id ) {
		switch ( $column ) {
			case 'title':
				$post_title = get_the_title($post_id);
				echo '<a href="' . esc_url(get_edit_post_link($post_id)) . '">' . esc_html($post_title) . '</a>';
				break;

			case 'date':
				$post_date = get_the_date('Y/m/d \a\t g:i a', $post_id);
				$post_status = get_post_status($post_id);
				echo '<span>' . esc_html(ucfirst($post_status)) . '</span><br>';
				echo '<span>' . esc_html($post_date) . '</span>';
				break;

			case 'wwp_group_members':
				// Assuming the number of members is stored in post meta with the key '_group_members_count'
				$members_count = get_post_meta($post_id, '_group_members_count', true);
				if (empty($members_count) ) {
					$members_count = 0;
				}
				echo esc_html($members_count);
				break;

			case 'wwp_group_status':
				// Assuming the status is stored in post meta with the key '_group_status'
				$status = get_post_meta($post_id, '_wholesale_group_status', true);
				if ('active' == $status ) {
					echo '<span class="active">' . esc_html__('Active', 'woocommerce-wholesale-pricing') . '</span>';
				} else {
					echo '<span class="inactive">' . esc_html__('Inactive', 'woocommerce-wholesale-pricing') . '</span>';
				}
				break;

			case 'wwp_group_action':
				// Actions: Deactivate | Edit | Delete
				$status = get_post_meta($post_id, '_wholesale_group_status', true);
				$status = get_post_status($post_id);
				$edit_link = get_edit_post_link($post_id);
				$delete_link = get_delete_post_link($post_id);
				$nonce = wp_create_nonce('wwp_group_nonce');

				$activate_url = add_query_arg(
				array(
				'action'   => 'activate_group',
				'post' => 'wwp_groups',
				'post_id'  => $post_id,
				'_wpnonce' => $nonce,
				), admin_url('edit.php') 
				);

				$deactivate_url = add_query_arg(
					array(
					'action'   => 'deactivate_group',
					'post' => 'wwp_groups',
					'post_id'  => $post_id,
					'_wpnonce' => $nonce,
				), admin_url('edit.php') 
				);

				if ('publish' == $status ) {
					echo '<a href="' . esc_url($deactivate_url) . '">' . esc_html__('Deactivate', 'woocommerce-wholesale-pricing') . '</a>';
				} else {
					echo '<a href="' . esc_url($activate_url) . '">' . esc_html__('Activate', 'woocommerce-wholesale-pricing') . '</a>';
				}
				echo ' | <a href="' . esc_url($edit_link) . '">' . esc_html__('Edit', 'woocommerce-wholesale-pricing') . '</a>';
				echo ' | <a href="' . esc_url($delete_link) . '">' . esc_html__('Delete', 'woocommerce-wholesale-pricing') . '</a>';
				break;
		}
	}

	/**
	 * Removes unnecessary row actions (Edit, Trash, View, Quick Edit) from the group list table.
	 *
	 * @filter post_row_actions
	 * @param  array   $actions The array of row actions.
	 * @param  WP_Post $post    The post object for the current row.
	 * @return array The filtered array of row actions.
	 */
	public function row_actions( $actions, $post ) {

		if (isset($post->post_type) && 'wwp_groups' === $post->post_type ) {
			unset($actions['edit']);
			unset($actions['trash']);
			unset($actions['view']);
			unset($actions['inline hide-if-no-js']);
		}
		return $actions;
	}

	/**
	 * Registers all custom meta boxes for the wholesale group edit screen.
	 *
	 * Enqueues necessary scripts/styles (`wc-enhanced-select` for improved dropdowns).
	 *
	 * @action add_meta_boxes
	 * @return void
	 */
	public function meta_box() {
		wp_enqueue_script('wc-enhanced-select');
		wp_enqueue_style('wwp-select2');

		add_meta_box(
			'wwp-group-description',
			esc_html__('Group description', 'woocommerce-wholesale-pricing'),
			array( $this, 'wholesale_group_description' ),
			'wwp_groups',
			'advanced',
			'high'
		);

		add_meta_box(
			'wwp-group-configuration',
			esc_html__('Group Configuration', 'woocommerce-wholesale-pricing'),
			array( $this, 'wholesale_group_configuration' ),
			'wwp_groups',
			'advanced',
			'high'
		);

		add_meta_box(
			'wwp-group-action',
			esc_html__('Actions', 'woocommerce-wholesale-pricing'),
			array( $this, 'wholesale_group_action' ),
			'wwp_groups',
			'side',
			'core'
		);

		add_meta_box(
			'wwp-group-announcement',
			esc_html__('Announcement', 'woocommerce-wholesale-pricing'),
			array( $this, 'wholesale_group_announcement' ),
			'wwp_groups',
			'side',
			'core'
		);
	}

	/**
	 * Handles saving all custom post metadata for the wholesale group post type.
	 *
	 * Includes nonce verification, autosave check, permission check, and detailed
	 * logic for updating post meta and associated user meta (when members are added/removed).
	 *
	 * @action save_post_{$this->slug}
	 * @param  int     $post_id The ID of the post being saved.
	 * @param  WP_Post $post    The post object.
	 * @return void
	 */
	public function update( $post_id, $post ) {

		// Verify nonce
		if (! isset($_POST['wwp_group_nonce']) || ! wp_verify_nonce(sanitize_text_field($_POST['wwp_group_nonce']), 'wwp_save_group') ) {
			return;
		}

		// Check if the user has permission to save
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) {
			return;
		}

		// Save metadata
		if (! empty($_POST['wwp_group_description']) ) {
			update_post_meta($post_id, '_wwp_group_description', wp_kses_post($_POST['wwp_group_description']));
		} else {
			update_post_meta($post_id, '_wwp_group_description', '');

		}

		if (!empty($_POST['include_products']) ) {
			update_post_meta($post_id, '_include_products', sanitize_text_field($_POST['include_products']));
		}

		if (! empty($_POST['include_specific_products']) ) {
			update_post_meta($post_id, '_include_specific_products', array_map('sanitize_text_field', $_POST['include_specific_products']));
		} else {
			update_post_meta($post_id, '_include_specific_products', array());
		}

		if (! empty($_POST['exclude_products']) ) {
			update_post_meta($post_id, '_exclude_products', array_map('sanitize_text_field', $_POST['exclude_products']));
		} else {
			update_post_meta($post_id, '_exclude_products', array());
		}
		
		if (! empty($_POST['add_users_in_group']) ) {
			$users = array_map('sanitize_text_field', $_POST['add_users_in_group']);
			$old_users = get_post_meta($post_id, '_add_users', true);
			if (! empty($old_users) ) {
				foreach ( $old_users as $user_id ) { 
					if (! in_array($user_id, $users) ) {
						update_user_meta($user_id, 'add_in_wwp_group', 'false');
						update_user_meta($user_id, 'user_wwp_groupname', '');
					}
				}
			}
			update_post_meta($post_id, '_group_members_count', intval(count($_POST['add_users_in_group'])));
			foreach ( $users as $user_id ) {
				update_user_meta($user_id, 'add_in_wwp_group', 'true');
				update_user_meta($user_id, 'user_wwp_groupname', $post_id);

			}
			update_post_meta($post_id, '_add_users', $users);

		} else {
			$old_users = get_post_meta($post_id, '_add_users', true);
			if (! empty($old_users) ) {
				foreach ( $old_users as $user_id ) { 
					update_user_meta($user_id, 'add_in_wwp_group', 'false');
					update_user_meta($user_id, 'user_wwp_groupname', '');
				}
			}
			update_post_meta($post_id, '_add_users', array());

		}
		
		if (! empty($_POST['discount_type']) ) {
			update_post_meta($post_id, '_discount_type', sanitize_text_field($_POST['discount_type']));
		}
		
		if (! empty($_POST['min_quantity']) ) {
			update_post_meta($post_id, '_min_quantity', absint($_POST['min_quantity']));
		} else {
			update_post_meta($post_id, '_min_quantity', '1');
		}

		if (! empty($_POST['wwp_group_price']) ) {
			update_post_meta($post_id, '_wwp_group_price', absint($_POST['wwp_group_price']));
		} else {
			update_post_meta($post_id, '_wwp_group_price', '');
		}

		if (! empty($_POST['max_quantity']) ) {
			update_post_meta($post_id, '_max_quantity', absint($_POST['max_quantity']));
		} else {
			update_post_meta($post_id, '_max_quantity', '');
		}

		if (! empty($_POST['disable_payment_methods']) ) {
			update_post_meta($post_id, '_disable_payment_methods', array_map('sanitize_text_field', $_POST['disable_payment_methods']));
		} else {
			update_post_meta($post_id, '_disable_payment_methods', array());
		}

		if (! empty($_POST['disable_shipping_methods']) ) {
			update_post_meta($post_id, '_disable_shipping_methods', array_map('sanitize_text_field', $_POST['disable_shipping_methods']));
		} else {
			update_post_meta($post_id, '_disable_shipping_methods', array());
		}

		if (! empty($_POST['wholesale_group_status']) ) {
			update_post_meta($post_id, '_wholesale_group_status', sanitize_text_field($_POST['wholesale_group_status']));
		}

		if ('inactive' == $_POST['wholesale_group_status'] ) {
			if ('publish' == $post->post_status ) {
				wp_update_post(array( 'ID' => $post_id, 'post_status' => 'draft' ));
			}
		}
	}

	/**
	 * Renders the template for the 'Group description' meta box.
	 *
	 * @param  WP_Post $post The post object.
	 * @return string Rendered HTML output.
	 */
	public function wholesale_group_description( $post ) {
		return wwp_view('admin.groups.meta-boxes.description', compact('post'));
	}

	/**
	 * Renders the template for the 'Group Configuration' meta box.
	 *
	 * @param  WP_Post $post The post object.
	 * @return string Rendered HTML output.
	 */
	public function wholesale_group_configuration( $post ) {
		return wwp_view('admin.groups.meta-boxes.configuration', compact('post'));
	}

	/**
	 * Renders the template for the 'Actions' meta box.
	 *
	 * @param  WP_Post $post The post object.
	 * @return string Rendered HTML output.
	 */
	public function wholesale_group_action( $post ) {
		return wwp_view('admin.groups.meta-boxes.actions', compact('post'));
	}

	/**
	 * Renders the template for the 'Announcement' meta box.
	 *
	 * @param  WP_Post $post The post object.
	 * @return string Rendered HTML output.
	 */
	public function wholesale_group_announcement( $post ) {
		return wwp_view('admin.groups.meta-boxes.announcement', compact('post'));
	}

	/**
	 * Determines the dependency resolution for this service.
	 *
	 * This service handles admin-side functionality, so it should only run in the admin area.
	 *
	 * @return string Rendered HTML output.
	 */
	public static function resolveDependency() {
		return is_admin();
	}
}
