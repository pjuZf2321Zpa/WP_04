<?php
/**
 * Read and update wholesale pricing / general plugin settings.
 *
 * @package WooCommerceWholesalePricing\App\Services
 */

namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleOption;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

/**
 * Manages wwp_wholesale_pricing_options (settings page tabs except global/cart discounts).
 */
class WholesalePricingSettingsService {

	/**
	 * Keys blocked from this ability (handled elsewhere).
	 *
	 * @var list<string>
	 */
	const BLOCKED_KEYS = array(
		'tier_pricing',
		'enable_quote',
	);

	/**
	 * Keys exposed to the ability API.
	 *
	 * @var list<string>
	 */
	const ALLOWED_KEYS = array(
		'wholesale_role',
		'default_multipe_wholesale_roles',
		'wholesale_price_application',
		'disable_auto_role',
		'wwp_attachment_location',
		'emailuserrole',
		'email_user_role_value',
		'order_custom_email_value',
		'enable_admin_new_order_item',
		'wwp_hide_add_to_cart',
		'wwp_hide_add_to_cart_on',
		'wwp_specific_product',
		'wwp_specific_cat',
		'wwp_specific_user_role',
		'custom_message_for_cart',
		'wwp_hide_price',
		'wwp_hide_price_on',
		'wwp_specific_product_price',
		'wwp_specific_cat_price',
		'wwp_specific_user_role_price',
		'custom_message_for_price',
		'enable_coupon',
		'requisition_list',
		'requisition_list_cart_page',
		'variation_table_enable',
		'request_for_sample_enable',
		'request_for_sample_label',
		'enable_groups',
		'enable_wholesale_price',
		'wwp_select_wholesale_role_for_non_logged_in',
		'enable_non_logged_shop_page_wholesale_price',
		'enable_non_logged_product_page_wholesale_price',
		'wwp_custom_message_non_logged_in',
		'enable_subscription',
		'wholesale_subscription',
		'enable_registration_page',
		'advance_registration_form',
		'registration_page',
		'register_redirect',
		'over_right_wholesale_form',
		'retailer_label',
		'retailer_disabled',
		'retailer_price_disabled',
		'wholesaler_label',
		'wholesaler_disabled',
		'wholesaler_price_disabled',
		'save_label',
		'save_price_label_disabled',
		'save_price_disabled',
		'enable_strike_through_price',
		'price_hide',
		'price_hide_role',
		'display_link_text',
		'wholesaler_login_restriction',
		'login_message_waiting_user',
		'login_message_rejected_user',
		'restrict_store_access',
		'enable_store_access_cookie',
		'wwp_cookie_interval',
		'restrict_store_access_message',
		'wholesaler_prodcut_only',
		'non_wholesale_product_hide',
		'wholesaler_allow_minimum_qty',
		'enable_upgrade',
		'request_again_submit',
		'upgrade_tab_text',
		'enable_custom_payment_method',
		'payment_method_name',
		'wholesale_css',
	);

	/**
	 * Checkbox fields stored as yes/no in the database.
	 *
	 * @var list<string>
	 */
	const YES_NO_BOOLEAN_KEYS = array(
		'disable_auto_role',
		'enable_admin_new_order_item',
		'wwp_hide_add_to_cart',
		'advance_registration_form',
		'wwp_hide_price',
		'enable_strike_through_price',
		'enable_groups',
		'enable_registration_page',
		'over_right_wholesale_form',
		'wholesaler_prodcut_only',
		'enable_upgrade',
		'retailer_disabled',
		'save_price_disabled',
		'restrict_store_access',
		'wholesaler_allow_minimum_qty',
	);

	/**
	 * Checkbox fields stored as yes when enabled, empty when disabled.
	 *
	 * @var list<string>
	 */
	const YES_EMPTY_BOOLEAN_KEYS = array(
		'enable_coupon',
		'requisition_list',
		'requisition_list_cart_page',
		'variation_table_enable',
		'request_for_sample_enable',
		'enable_wholesale_price',
		'enable_non_logged_shop_page_wholesale_price',
		'enable_non_logged_product_page_wholesale_price',
		'enable_subscription',
		'retailer_price_disabled',
		'wholesaler_disabled',
		'wholesaler_price_disabled',
		'save_price_label_disabled',
		'price_hide',
		'wholesaler_login_restriction',
		'enable_store_access_cookie',
		'non_wholesale_product_hide',
		'request_again_submit',
		'enable_custom_payment_method',
	);

	/**
	 * Scope values for hide price / hide cart settings.
	 *
	 * @var list<string>
	 */
	const SCOPE_VALUES = array(
		'specific_product',
		'specific_product_cat',
		'specific_user_roles',
	);

	/**
	 * Get formatted pricing settings exposed to the ability API.
	 *
	 * @return array<string, mixed>
	 */
	public function get_settings() {
		$stored = $this->get_raw_settings();

		return array(
			'option_key' => WholesaleOption::PRICING_OPTION,
			'settings'   => $this->format_settings( $stored ),
		);
	}

	/**
	 * Update allowed pricing settings (partial merge).
	 *
	 * @param array<string, mixed> $settings Settings patch.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function update_settings( array $settings ) {
		if ( empty( $settings ) ) {
			return new \WP_Error(
				'wwp_pricing_settings_missing',
				__( 'Settings are required for update.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$blocked = array_intersect( array_keys( $settings ), self::BLOCKED_KEYS );
		if ( ! empty( $blocked ) ) {
			return new \WP_Error(
				'wwp_pricing_settings_blocked_key',
				sprintf(
					/* translators: %s: comma-separated field names */
					__( 'Setting(s) not managed by wholesale settings: %s. Use global_discounts for tier_pricing and quote_settings for quote options.', 'woocommerce-wholesale-pricing' ),
					implode( ', ', $blocked )
				),
				array( 'status' => 400 )
			);
		}

		$unknown = array_diff( array_keys( $settings ), self::ALLOWED_KEYS );
		if ( ! empty( $unknown ) ) {
			return new \WP_Error(
				'wwp_pricing_settings_invalid_field',
				sprintf(
					/* translators: %s: comma-separated field names */
					__( 'Unknown wholesale setting(s): %s', 'woocommerce-wholesale-pricing' ),
					implode( ', ', $unknown )
				),
				array( 'status' => 400 )
			);
		}

		$stored  = $this->get_raw_settings();
		$updated = $stored;

		foreach ( $settings as $key => $value ) {
			$sanitized = $this->sanitize_value( $key, $value );
			if ( is_wp_error( $sanitized ) ) {
				return $sanitized;
			}

			$updated[ $key ] = $sanitized;
		}

		$this->apply_scope_rules( $updated );

		// Preserve tier_pricing untouched when other keys are updated.
		if ( isset( $stored['tier_pricing'] ) ) {
			$updated['tier_pricing'] = $stored['tier_pricing'];
		}

		WholesaleSettingsHelper::update_pricing_settings( $updated );

		return $this->get_settings();
	}

	/**
	 * Snapshot raw stored values for undo.
	 *
	 * @return array<string, mixed>
	 */
	public function snapshot_settings() {
		return array(
			'option_key' => WholesaleOption::PRICING_OPTION,
			'value'      => $this->get_raw_settings(),
		);
	}

	/**
	 * Restore a full pricing settings snapshot.
	 *
	 * @param array<string, mixed> $snapshot Snapshot data.
	 * @return true|\WP_Error
	 */
	public function restore_settings( array $snapshot ) {
		if ( empty( $snapshot['option_key'] ) || WholesaleOption::PRICING_OPTION !== $snapshot['option_key'] ) {
			return new \WP_Error(
				'wwp_pricing_settings_restore_invalid_snapshot',
				__( 'Cannot restore wholesale settings: invalid snapshot.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$value = is_array( isset( $snapshot['value'] ) ? $snapshot['value'] : null ) ? $snapshot['value'] : array();
		WholesaleSettingsHelper::update_pricing_settings( $value );

		return true;
	}

	/**
	 * Get raw stored settings without formatting, used for snapshotting and internal processing.
	 * 
	 * @return array<string, mixed>
	 */
	private function get_raw_settings() {
		$stored = WholesaleSettingsHelper::get_pricing_settings();

		return is_array( $stored ) ? $stored : array();
	}

	/**
	 * Format stored settings for API output based on allowed keys and their expected types/formats.
	 * 
	 * @param array<string, mixed> $stored Stored settings.
	 * @return array<string, mixed>
	 */
	private function format_settings( array $stored ) {
		$formatted = array();

		foreach ( self::ALLOWED_KEYS as $key ) {
			$formatted[ $key ] = $this->format_value( $key, isset( $stored[ $key ] ) ? $stored[ $key ] : null );
		}

		return $formatted;
	}

	/**
	 * Format stored values for API output based on their expected types and formats, with special handling for certain keys.
	 * 
	 * @param string $key   Setting key.
	 * @param mixed  $value Stored value.
	 * @return mixed
	 */
	private function format_value( $key, $value ) {
		if ( $this->is_boolean_key( $key ) ) {
			return 'yes' === $value;
		}

		if ( in_array( $key, array( 'wwp_specific_cat', 'wwp_specific_cat_price' ), true ) ) {
			return $this->format_category_refs( $value );
		}

		if ( in_array( $key, array( 'wwp_specific_product', 'wwp_specific_product_price' ), true ) ) {
			return $this->format_product_refs( $value );
		}

		if ( in_array( $key, array( 'wwp_specific_user_role', 'wwp_specific_user_role_price', 'price_hide_role' ), true ) ) {
			if ( ! is_array( $value ) ) {
				return array();
			}

			return array_values( array_map( 'strval', $value ) );
		}

		if ( 'payment_method_name' === $key ) {
			if ( ! is_array( $value ) ) {
				return array();
			}

			return array_values(
				array_filter(
					array_map(
						static function ( $name ) {
							return is_string( $name ) ? $name : (string) $name;
						},
						array_keys( $value )
					)
				)
			);
		}

		if ( in_array( $key, array( 'custom_message_for_cart', 'custom_message_for_price', 'restrict_store_access_message', 'wholesale_css', 'wwp_custom_message_non_logged_in' ), true ) ) {
			return is_string( $value ) ? $value : '';
		}

		if ( in_array( $key, array( 'registration_page', 'register_redirect', 'wwp_cookie_interval' ), true ) ) {
			return is_scalar( $value ) ? (string) $value : '';
		}

		return is_string( $value ) ? $value : ( is_scalar( $value ) ? (string) $value : '' );
	}

	/**
	 * Sanitize and validate incoming setting values based on their expected types and formats, with special handling for certain keys.
	 * 
	 * @param string $key   Setting key.
	 * @param mixed  $value Incoming value.
	 * @return mixed|\WP_Error
	 */
	private function sanitize_value( $key, $value ) {
		if ( $this->is_boolean_key( $key ) ) {
			return $this->sanitize_boolean( $key, $value );
		}

		if ( in_array( $key, array( 'wwp_hide_add_to_cart_on', 'wwp_hide_price_on' ), true ) ) {
			$scope = sanitize_key( (string) $value );
			if ( '' !== $scope && ! in_array( $scope, self::SCOPE_VALUES, true ) ) {
				return new \WP_Error(
					'wwp_pricing_settings_invalid_scope',
					__( 'Scope must be specific_product, specific_product_cat, or specific_user_roles.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			return $scope;
		}

		if ( in_array( $key, array( 'wwp_specific_cat', 'wwp_specific_cat_price' ), true ) ) {
			return $this->resolve_category_ids( $value );
		}

		if ( in_array( $key, array( 'wwp_specific_product', 'wwp_specific_product_price' ), true ) ) {
			return $this->resolve_product_ids( $value );
		}

		if ( in_array( $key, array( 'wwp_specific_user_role', 'wwp_specific_user_role_price', 'price_hide_role' ), true ) ) {
			if ( ! is_array( $value ) ) {
				return array();
			}

			return array_values(
				array_filter(
					array_map(
						static function ( $role ) {
							return sanitize_key( (string) $role );
						},
						$value
					)
				)
			);
		}

		if ( 'payment_method_name' === $key ) {
			if ( ! is_array( $value ) ) {
				return array();
			}

			$methods = array();
			foreach ( $value as $method ) {
				$name = sanitize_text_field( (string) $method );
				if ( '' !== $name ) {
					$methods[ $name ] = 'no';
				}
			}

			return $methods;
		}

		if ( 'wholesale_role' === $key && ! in_array( (string) $value, array( 'single', 'multiple' ), true ) ) {
			return new \WP_Error(
				'wwp_pricing_settings_invalid_wholesale_role',
				__( 'wholesale_role must be single or multiple.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( 'wholesale_price_application' === $key && ! in_array( (string) $value, array( '_regular_price', '_price' ), true ) ) {
			return new \WP_Error(
				'wwp_pricing_settings_invalid_price_application',
				__( 'wholesale_price_application must be _regular_price or _price.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( 'emailuserrole' === $key && ! in_array( (string) $value, array( 'order_email_user_role', 'order_email_custom' ), true ) ) {
			return new \WP_Error(
				'wwp_pricing_settings_invalid_emailuserrole',
				__( 'emailuserrole must be order_email_user_role or order_email_custom.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( in_array( $key, array( 'custom_message_for_cart', 'custom_message_for_price', 'restrict_store_access_message', 'wholesale_css' ), true ) ) {
			return is_string( $value ) ? wp_kses_post( $value ) : '';
		}

		if ( 'wwp_custom_message_non_logged_in' === $key ) {
			return is_string( $value ) ? esc_html( $value ) : esc_html( (string) $value );
		}

		if ( in_array( $key, array( 'registration_page', 'register_redirect' ), true ) ) {
			$page_id = absint( $value );
			if ( $page_id > 0 && ! get_post( $page_id ) ) {
				return new \WP_Error(
					'wwp_pricing_settings_invalid_page',
					__( 'The selected page does not exist.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			return $page_id > 0 ? (string) $page_id : '';
		}

		if ( 'wwp_cookie_interval' === $key ) {
			$interval = absint( $value );

			return $interval > 0 ? (string) $interval : '1';
		}

		return is_string( $value ) ? sanitize_text_field( $value ) : sanitize_text_field( (string) $value );
	}

	/**
	 * Mirror admin save validation for hide cart / hide price scopes.
	 *
	 * @param array<string, mixed> $settings Settings being saved.
	 * @return void
	 */
	private function apply_scope_rules( array &$settings ) {
		$this->apply_hide_scope_rules(
			$settings,
			'wwp_hide_add_to_cart',
			'wwp_hide_add_to_cart_on',
			'wwp_specific_product',
			'wwp_specific_cat',
			'wwp_specific_user_role'
		);

		$this->apply_hide_scope_rules(
			$settings,
			'wwp_hide_price',
			'wwp_hide_price_on',
			'wwp_specific_product_price',
			'wwp_specific_cat_price',
			'wwp_specific_user_role_price'
		);
	}

	/**
	 * Apply validation and cleanup rules for hide cart / hide price settings based on their scope and references.
	 * 
	 * @param array<string, mixed> $settings Settings being saved.
	 * @param string               $enabled_key Enabled flag key.
	 * @param string               $scope_key Scope key.
	 * @param string               $product_key Product IDs key.
	 * @param string               $category_key Category IDs key.
	 * @param string               $role_key Role slugs key.
	 * @return void
	 */
	private function apply_hide_scope_rules(
		array &$settings,
		$enabled_key,
		$scope_key,
		$product_key,
		$category_key,
		$role_key
	) {
		$scope     = isset( $settings[ $scope_key ] ) ? (string) $settings[ $scope_key ] : '';
		$products  = isset( $settings[ $product_key ] ) && is_array( $settings[ $product_key ] ) ? $settings[ $product_key ] : array();
		$categories = isset( $settings[ $category_key ] ) && is_array( $settings[ $category_key ] ) ? $settings[ $category_key ] : array();
		$roles     = isset( $settings[ $role_key ] ) && is_array( $settings[ $role_key ] ) ? $settings[ $role_key ] : array();

		if (
			( 'specific_product' === $scope && empty( $products ) )
			|| ( 'specific_product_cat' === $scope && empty( $categories ) )
			|| ( 'specific_user_roles' === $scope && empty( $roles ) )
		) {
			$settings[ $scope_key ]     = '';
			$settings[ $enabled_key ]   = 'no';
			$settings[ $product_key ]   = array();
			$settings[ $category_key ]  = array();
			$settings[ $role_key ]      = array();

			return;
		}

		if ( 'specific_product' === $scope && ! empty( $products ) ) {
			$settings[ $category_key ] = array();
			$settings[ $role_key ]     = array();
		} elseif ( 'specific_product_cat' === $scope && ! empty( $categories ) ) {
			$settings[ $product_key ] = array();
			$settings[ $role_key ]    = array();
		} elseif ( 'specific_user_roles' === $scope && ! empty( $roles ) ) {
			$settings[ $product_key ]  = array();
			$settings[ $category_key ] = array();
		}
	}

	/**
	 * Resolve category references (IDs or slugs) into category IDs, validating existence.
	 * 
	 * @param mixed $categories Category slugs or IDs.
	 * @return list<int>|\WP_Error
	 */
	private function resolve_category_ids( $categories ) {
		if ( ! is_array( $categories ) ) {
			return array();
		}

		$ids = array();

		foreach ( $categories as $category ) {
			if ( is_numeric( $category ) ) {
				$term = get_term( (int) $category, 'product_cat' );
			} else {
				$term = get_term_by( 'slug', sanitize_title( (string) $category ), 'product_cat' );
				if ( ! $term ) {
					$term = get_term_by( 'name', (string) $category, 'product_cat' );
				}
			}

			if ( ! $term || is_wp_error( $term ) ) {
				return new \WP_Error(
					'wwp_pricing_settings_invalid_category',
					sprintf(
						/* translators: %s: category identifier */
						__( 'Unknown product category: %s', 'woocommerce-wholesale-pricing' ),
						(string) $category
					),
					array( 'status' => 400 )
				);
			}

			$ids[] = (int) $term->term_id;
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Resolve product references (IDs, slugs, or SKUs) into product IDs, validating existence.
	 * 
	 * @param mixed $products Product IDs, slugs, or SKUs.
	 * @return list<int>|\WP_Error
	 */
	private function resolve_product_ids( $products ) {
		if ( ! is_array( $products ) ) {
			return array();
		}

		$ids = array();

		foreach ( $products as $product_ref ) {
			$product_id = 0;

			if ( is_numeric( $product_ref ) ) {
				$product_id = (int) $product_ref;
			} else {
				$ref = (string) $product_ref;
				if ( function_exists( 'wc_get_product_id_by_sku' ) ) {
					$product_id = (int) wc_get_product_id_by_sku( $ref );
				}

				if ( $product_id <= 0 ) {
					$posts = get_posts(
						array(
							'name'           => sanitize_title( $ref ),
							'post_type'      => 'product',
							'post_status'    => 'any',
							'posts_per_page' => 1,
							'fields'         => 'ids',
						)
					);
					$product_id = ! empty( $posts ) ? (int) $posts[0] : 0;
				}
			}

			if ( $product_id <= 0 || ! wc_get_product( $product_id ) ) {
				return new \WP_Error(
					'wwp_pricing_settings_invalid_product',
					sprintf(
						/* translators: %s: product identifier */
						__( 'Unknown product: %s', 'woocommerce-wholesale-pricing' ),
						(string) $product_ref
					),
					array( 'status' => 400 )
				);
			}

			$ids[] = $product_id;
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Fornat stored category IDs into detailed references with ID, slug, and name for API output.
	 * 
	 * @param mixed $ids Stored category IDs.
	 * @return list<array{id:int,slug:string,name:string}>
	 */
	private function format_category_refs( $ids ) {
		if ( ! is_array( $ids ) ) {
			return array();
		}

		$refs = array();

		foreach ( $ids as $id ) {
			$term = get_term( (int) $id, 'product_cat' );
			if ( ! $term || is_wp_error( $term ) ) {
				continue;
			}

			$refs[] = array(
				'id'   => (int) $term->term_id,
				'slug' => (string) $term->slug,
				'name' => (string) $term->name,
			);
		}

		return $refs;
	}

	/**
	 * Format stored product IDs into detailed references with ID, slug, and name for API output.
	 * 
	 * @param mixed $ids Stored product IDs.
	 * @return list<array{id:int,slug:string,name:string}>
	 */
	private function format_product_refs( $ids ) {
		if ( ! is_array( $ids ) ) {
			return array();
		}

		$refs = array();

		foreach ( $ids as $id ) {
			$product = wc_get_product( (int) $id );
			if ( ! $product ) {
				continue;
			}

			$refs[] = array(
				'id'   => (int) $product->get_id(),
				'slug' => (string) $product->get_slug(),
				'name' => (string) $product->get_name(),
			);
		}

		return $refs;
	}

	/**
	 * Sanitize boolean-like values for checkbox settings, with support for both yes/no and yes/empty formats.
	 * 
	 * @param string $key Setting key.
	 * @param mixed  $value Incoming value.
	 * @return string|\WP_Error
	 */
	private function sanitize_boolean( $key, $value ) {
		$enabled = null;

		if ( is_bool( $value ) ) {
			$enabled = $value;
		} elseif ( in_array( $value, array( 'yes', 'no', '1', '0', 1, 0 ), true ) ) {
			$enabled = in_array( $value, array( 'yes', '1', 1 ), true );
		} else {
			return new \WP_Error(
				'wwp_pricing_settings_invalid_boolean',
				__( 'Boolean settings must be true or false.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( in_array( $key, self::YES_NO_BOOLEAN_KEYS, true ) ) {
			return $enabled ? 'yes' : 'no';
		}

		return $enabled ? 'yes' : '';
	}

	/**
	 * Is the given key a boolean setting key?
	 * 
	 * @param string $key Setting key.
	 * @return bool
	 */
	private function is_boolean_key( $key ) {
		return in_array( $key, self::YES_NO_BOOLEAN_KEYS, true )
			|| in_array( $key, self::YES_EMPTY_BOOLEAN_KEYS, true );
	}
}
