<?php
/**
 * GutenbergBlockService class.
 *
 * Manages the registration of custom Gutenberg blocks for the wholesale plugin,
 * specifically the registration form block. It also handles compatibility
 * loading for the modern WooCommerce block environment.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @extends    Init
 */
namespace WooCommerceWholesalePricing\App\Services;

use Automattic\WooCommerce\Blocks\Package;
use WooCommerceWholesalePricing\App\Strategies\Init;

/**
 * Service class for registering and managing custom Gutenberg blocks.
 * 
 * @extends Init
 */
class GutenbergBlockService extends Init {


   
	/**
	 * Constructor.
	 *
	 * Initializes the service by calling the parent constructor.
	 *
	 * @return void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Registers the custom 'wholesale/wholesale-registration' Gutenberg block.
	 *
	 * The block is implemented as a wrapper around the existing registration shortcode,
	 * allowing users to insert the form via the block editor.
	 *
	 * @action init
	 * @return void
	 */
	public function register() {
		wp_register_script(
			'wwp_register_block', 
			WWP_PLUGIN_URL . 'build/registration-form-block/index.js', 
			array( 'wp-blocks', 'wp-element' ) 
		);

		register_block_type(
			'wholesale/wholesale-registration', 
			array(
			'editor_script' => 'wwp_register_block', 
				'render_callback' => function () {
					return sprintf('[%s]', wwp_env()->get('registration_shortcode'));
				},
			)
		);
	}

	/**
	 * Handles conditional loading of WooCommerce Blocks compatibility modules.
	 *
	 * Checks for the existence and minimum required version of the
	 * WooCommerce Blocks Package to load specific integration files.
	 *
	 * @return void
	 */
	public function loaded() {
		$module_paths = array();

		if (class_exists('Automattic\WooCommerce\Blocks\Package') && version_compare(Package::get_version(), '7.2.0') >= 0 ) {
			$module_paths[ 'blocks' ] = WWP_PLUGIN_PATH . 'app/Modules/GutenbergBlock/Integration.php';
			$module_paths[ 'wc-quote-blocks' ] = WWP_PLUGIN_PATH . 'app/Modules/GutenbergBlock/Quote/Integration.php';
			$module_paths[ 'checkout-tax-id' ] = WWP_PLUGIN_PATH . 'app/Modules/GutenbergBlock/CheckoutTaxId/Integration.php';
		}

		/**
		 * 'woocommerce_bundles_compatibility_modules' filter.
		 *
		 * Use this to filter the required compatibility modules.
		 *
		 * @since 3.0.0
		 * @param array $module_paths
		 */ 
		$module_paths = apply_filters('woocommerce_wholeasle_pricing_compatibility_modules', $module_paths);

		foreach ( $module_paths as $name => $path ) {
			include_once $path;
		}
	}
}
