<?php
/**
 * ScriptService
 *
 * Handles the enqueuing and localization of all JavaScript and CSS assets for the
 * WooCommerce Wholesale Pricing plugin on both the frontend and the WordPress admin area.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @uses       WooCommerceWholesalePricing\App\Providers\WholesaleSettings
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

/**
 * Service class for managing all plugin scripts and styles.
 *
 * This class hooks into WordPress and WooCommerce actions to load necessary
 * assets (scripts and styles) and to pass dynamic data to JavaScript using
 * wp_localize_script.
 */
class ScriptService {

	/**
	 * Trait that provides static access to wholesale pricing settings.
	 */
	use WholesaleSettings;

	/**
	 * ScriptService constructor.
	 *
	 * Registers the necessary hooks for loading admin and blog scripts.
	 */
	public function __construct() {
		add_action('admin_enqueue_scripts', array( $this, 'adminScripts' ), 10);
		add_action('wp_enqueue_scripts', array( $this, 'blogScripts' ), 10);

		add_action('wp_head', array( $this, 'hook_javascript' ));
	}
	
	/**
	 * Registers admin asset handles once, then enqueue conditionally where needed.
	 *
	 * @return void
	 */
	private function register_admin_assets() {
		wp_register_script('wwp-script', WWP_PLUGIN_URL . 'public/js/admin-script.js', array( 'jquery' ), WWP_VERSION);
		wp_register_style('wwp-style', WWP_PLUGIN_URL . 'public/css/admin-style.css', array(), WWP_VERSION);
		wp_register_style('wwp_fontawesome', WWP_PLUGIN_URL . 'public/css/font-awesome.min.css', array(), WWP_VERSION);
		wp_register_script('wwp-popper-min-js', WWP_PLUGIN_URL . 'public/js/popper.min.js', array( 'jquery' ), WWP_VERSION);
		wp_register_script('wwp-bootstrap-js', WWP_PLUGIN_URL . 'public/js/bootstrap.min.js', array( 'jquery' ), WWP_VERSION);
		wp_register_script('wwp-bootstrap-select-js', WWP_PLUGIN_URL . 'public/js/bootstrap-select.min.js', array( 'wwp-bootstrap-js' ), WWP_VERSION);
		wp_register_style('wwp-data-tip', WWP_PLUGIN_URL . 'public/css/data-tip.min.css', array(), WWP_VERSION);
		wp_register_style('wwp-bootstrap', WWP_PLUGIN_URL . 'public/css/bootstrap.min.css', array(), WWP_VERSION, 'all');
		wp_register_style('wwp-bootstrap-select', WWP_PLUGIN_URL . 'public/css/bootstrap-select.min.css', array(), WWP_VERSION, 'all');
		wp_register_style('wwp-admin-new', WWP_PLUGIN_URL . 'public/css/admin-style-new.css', array(), WWP_VERSION, 'all');
		wp_register_style('wwp-product-admin', WWP_PLUGIN_URL . 'public/css/product-admin.css', array(), WWP_VERSION, 'all');
		wp_register_style('wwp-select2', WWP_PLUGIN_URL . 'public/css/wc-enhanced-select.css', false, WWP_VERSION);
		wp_register_style('wc-quote-builder-admin-styles', WWP_PLUGIN_URL . 'public/css/admin-wc-quote.css', array(), WWP_VERSION);
		wp_register_style('wc-quote-admin-styles', WWP_PLUGIN_URL . 'public/css/wc-quote-admin.css', array(), WWP_VERSION);
		wp_register_script('wc-quote-admin', WWP_PLUGIN_URL . 'public/js/wc-quote-admin.js', array( 'jquery' ), WWP_VERSION, true);
		wp_register_script('wwp-moment', WWP_PLUGIN_URL . 'public/js/deps/moment.min.js', array(), WWP_VERSION, array( 'in_footer' => true ));
		wp_register_script('wwp-daterangepicker', WWP_PLUGIN_URL . 'public/js/deps/daterangepicker.min.js', array( 'wwp-moment' ), WWP_VERSION, array( 'in_footer' => true ));
		wp_register_style('wwp-daterangepicker', WWP_PLUGIN_URL . 'public/css/deps/daterangepicker.css', array(), WWP_VERSION);
		wp_register_style('dashboard-style', WWP_PLUGIN_URL . 'public/css/dashboard.css', array(), WWP_VERSION);

		/** Product table styles and scripts */
		wp_register_style('wcpt-style', WWP_PLUGIN_URL . 'public/css/product-table/style.css', array(), WWP_VERSION, 'all');
		wp_register_style('wcpt-jquery-ui-style', WWP_PLUGIN_URL . 'public/css/deps/jqueryui/jquery-ui.min.css', array(), WWP_VERSION);
		// wp_register_style('wwp-select2
		wp_register_style('woocommerce_admin_styles', WC()->plugin_url() . '/assets/css/admin.css', array(), WWP_VERSION);
		wp_register_script('wcpt-scripts', WWP_PLUGIN_URL . 'public/js/product-table/script.js', array( 'jquery', 'jquery-ui-droppable', 'jquery-ui-sortable', 'jquery-ui-draggable', 'jquery-ui-dialog' ), WWP_VERSION, true);
		wp_register_script('wcpt-select2', WWP_PLUGIN_URL . 'public/js/deps/select2/select2.min.js', array( 'jquery' ), WWP_VERSION, true);
		wp_register_script('wcpt-custom-sel', WWP_PLUGIN_URL . 'public/js/product-table/settings-script.js', array( 'jquery', 'wcpt-select2', 'jquery-ui-datepicker' ), WWP_VERSION, true);
		wp_register_script('wcpt-list-table', WWP_PLUGIN_URL . 'public/js/product-table/list-table.js', array( 'jquery' ), WWP_VERSION, true);
		wp_register_script('wcpt-quick-order-admin', WWP_PLUGIN_URL . 'public/js/product-table/quick-order-admin.js', array( 'jquery' ), WWP_VERSION, true);

		wp_register_style('wwp-ccp-admin', WWP_PLUGIN_URL . 'public/css/company-credits/admin.css', array(), WWP_VERSION);
		wp_register_script('wwp-ccp-admin', WWP_PLUGIN_URL . 'public/js/company-credits/admin.js', array( 'jquery', 'wc-enhanced-select' ), WWP_VERSION, true);

		wp_register_script(
			'wwp-dynamic-rules-admin',
			WWP_PLUGIN_URL . 'public/js/dynamic-rules/admin.js',
			array( 'jquery', 'wc-enhanced-select' ),
			WWP_VERSION,
			true
		);
	}

	/**
	 * Registers frontend asset handles once, then enqueue where needed.
	 *
	 * @return void
	 */
	private function register_frontend_assets() {
		wp_register_script('wwp-script', WWP_PLUGIN_URL . 'public/js/script.js', array( 'jquery' ), WWP_VERSION, true);
		wp_register_style('wwp-wholesale', WWP_PLUGIN_URL . 'public/css/wwp-css-script.css', array(), '1.1.0', false);
		wp_register_style('wwp_dataTables', WWP_PLUGIN_URL . 'public/css/jquery.dataTables.min.css', array(), WWP_VERSION, false);
		wp_register_script('wwp_dataTables', WWP_PLUGIN_URL . 'public/js/jquery.dataTables.min.js', array( 'jquery' ), '1.1.0', false);
		wp_register_style('wwp-bootstrap', WWP_PLUGIN_URL . 'public/css/bootstrap.min.css', array(), WWP_VERSION, 'all');
		wp_register_style('wwp-ccp-checkout', WWP_PLUGIN_URL . 'public/css/company-credits/checkout.css', array(), WWP_VERSION);
		wp_register_style('wwp-ccp-frontend', WWP_PLUGIN_URL . 'public/css/company-credits/frontend.css', array(), WWP_VERSION);
		wp_register_script('wwp-ccp-frontend', WWP_PLUGIN_URL . 'public/js/company-credits/frontend.js', array( 'jquery' ), WWP_VERSION, true);

		wp_register_script('wc-quote-front', WWP_PLUGIN_URL . 'public/js/quote/wc-quote-front.js', array( 'jquery' ), WWP_VERSION);
		wp_register_script('wc-quote-front-fields', WWP_PLUGIN_URL . 'public/js/quote/wc-quote-front-fields.js', array( 'jquery' ), WWP_VERSION, true);

		wp_register_style('wc-quote-front', WWP_PLUGIN_URL . 'public/css/quote/wc-quote-front.css', array(), WWP_VERSION, false);

		wp_register_script('wwp_sales_agent_form', WWP_PLUGIN_URL . 'public/js/sales-agent/registration-form.js', array( 'jquery' ), WWP_VERSION, true);
	}

	/**
	 * Registers shared Form.io assets used in admin/frontend contexts.
	 *
	 * @return void
	 */
	private function register_formbuilder_assets() {
		wp_register_style('wwp_formbuilder', 'https://cdn.form.io/formiojs/formio.full.min.css', array(), WWP_VERSION);
		wp_register_script('wwp_formbuilder', 'https://cdn.form.io/formiojs/formio.full.js', array( 'jquery' ), WWP_VERSION);
		wp_register_script('wwp_formbuilder_init', WWP_PLUGIN_URL . 'public/formio/init-builder.js', array( 'jquery', 'wwp_formbuilder' ), WWP_VERSION, array( 'in_footer' => true ));
	}

	private function register_product_table_scripts() {
		$suffix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';

		if ( $this->is_product_table_request() && ! defined('WOOCOMMERCE_CHECKOUT') ) {
			define('WOOCOMMERCE_CHECKOUT', true);
		}

		wp_register_style('datatables_style', WWP_PLUGIN_URL . 'public/css/product-table/jquery.dataTables' . $suffix . '.css', array(), true);
		wp_register_style('wcpt_single_product', WWP_PLUGIN_URL . 'public/css/product-table/wcpt-product.css', array(), true);
		wp_register_script('wcpt_calculate', WWP_PLUGIN_URL . 'public/js/product-table/wcpt-calculate' . $suffix . '.js', array( 'jquery' ), true, true);
		/**
		 * Filter bulk variation script params
		 * 
		 * @since 1.1.6
		**/
		$params = apply_filters(
			'wc_bulk_variations_script_params',
			array(
				'debug'                   => defined('SCRIPT_DEBUG') && SCRIPT_DEBUG,
				'currency_options'        => array(
					'decimals'        => wc_get_price_decimals(),
					'd_separator'     => wc_get_price_decimal_separator(),
					't_separator'     => wc_get_price_thousand_separator(),
					'currency_symbol' => get_woocommerce_currency_symbol(),
					'price_format'    => get_woocommerce_price_format(),
					'price_markup'    => '<span class="woocommerce-Price-amount amount"><bdi>%s</bdi></span>',
				),
				'hide_out_of_stock_items' => filter_var(get_option('woocommerce_hide_out_of_stock_items'), FILTER_VALIDATE_BOOLEAN),
				'show_stock'              => false,
				'disable_purchasing'      => false,
				'i18n_item_singular'      => __('Item', 'woocommerce-wholesale-pricing'),
				'i18n_item_plural'        => __('Items', 'woocommerce-wholesale-pricing'),
			// translators: the total amount (currency)
				'i18n_your_total'         => __('Your total is %s', 'woocommerce-wholesale-pricing'),
			)
		);

		$script = sprintf('const wcpt_params = %s;', wp_json_encode($params));

		wp_add_inline_script('wcpt_calculate', $script, 'before');
		wp_register_script('datatables_script', WWP_PLUGIN_URL . 'public/js/product-table/jquery.dataTables' . $suffix . '.js', array( 'jquery' ), true, true);
		wp_register_script('product_table_script', WWP_PLUGIN_URL . 'public/js/product-table/wc-product-datatable-scripts.js', array( 'jquery' ), time(), true);
		wp_register_style('product_table_style', WWP_PLUGIN_URL . 'public/css/product-table/wcpt-style.css', array(), true);

		// localize product table script.s
		$product_table_params = array(
			'ajax_url'      => admin_url('admin-ajax.php'),
			'error_message' => __('No product added to cart', 'woocommerce-wholesale-pricing'),
			'nonce'         => wp_create_nonce('ajax-nonce'),
		);
		wp_register_style('responsive_datatables_style', WWP_PLUGIN_URL . 'public/css/product-table/responsive.dataTables.css', array(), true);
		wp_register_script('responsive_datatables_script', WWP_PLUGIN_URL . 'public/js/product-table/responsive.dataTables.js', array( 'jquery' ), true, true);
		wp_register_script('colvis_button_datatables_script', WWP_PLUGIN_URL . 'public/js/product-table/colvis.button.dataTables.js', array( 'jquery' ), true, true);
		wp_localize_script('product_table_script', 'product_table_params', $product_table_params); 
	}

	/**
	 * Enqueues scripts and styles for the WordPress admin area.
	 *
	 * This method is hooked to `admin_enqueue_scripts`. It conditionally loads
	 * assets based on the current screen, post type, and page query arguments.
	 *
	 * @global string $post_type The current post type being edited.
	 * @global \WP_Screen $current_screen The current screen object.
	 * @return void
	 */
	public function adminScripts() {

		global $post_type, $current_screen;
		$this->register_admin_assets();
		$this->register_formbuilder_assets();
		/**
		* Hooks
		*
		* @since 3.0
		*/
		wp_enqueue_style('jquery-ui-styles');
		wp_enqueue_script('jquery-ui-core');
		wp_enqueue_script('jquery-ui-autocomplete');
		wp_enqueue_script('jquery-ui-sortable');
		wp_enqueue_script('wwp-script');
		$settings = self::get_pricing_settings();
		if (isset($settings['wholesale_css']) ) {
			unset($settings['wholesale_css']);
		}

		wp_localize_script(
			'wwp-script',
			'wwpscript',
			array(
				'ajaxurl'                => admin_url('admin-ajax.php'),
				'admin_url'              => admin_url(),
				'ajax_nonce'             => wp_create_nonce('wwp_wholesale_pricing'),
				'wwp_wholesale_settings' => $settings,
				/**
				 * Filter 
				 * 
				 * @var bool value
				 * 
				 * @since 2.5.0
				 */
				'quantity_flag_cart_total_discount' => apply_filters('wwp_enable_quantity_flag_cart_total_discount', false),
				'wc_get_cart_url' => wc_get_cart_url(),
			)
		);

		add_thickbox();

		wp_enqueue_style('wwp-style');
		$screen        = get_current_screen();
		$screen_id    = $screen ? $screen->id : '';
		$role_taxonomy = function_exists( 'wwp_env' ) ? wwp_env()->get( 'role_taxonomy' ) : 'wholesale_user_roles';
		$role_screens  = array( 'edit-' . $role_taxonomy, $role_taxonomy );

		if ( in_array( $screen_id, $role_screens, true ) ) {
			$states    = function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_states() : array();
			$countries = function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_countries() : array();

			wp_enqueue_style( 'select2' );
			wp_enqueue_style( 'woocommerce_admin_styles' );
			wp_enqueue_script( 'select2' );
			wp_enqueue_script( 'wc-enhanced-select' );
			wp_enqueue_script(
				'wwp-user-role-conditions',
				WWP_PLUGIN_URL . 'public/js/user-role-conditions.js',
				array( 'jquery', 'wc-enhanced-select' ),
				WWP_VERSION,
				true
			);
			wp_localize_script(
				'wwp-user-role-conditions',
				'wwpRoleConditions',
				array(
					'states'    => is_array( $states ) ? $states : array(),
					'countries' => is_array( $countries ) ? $countries : array(),
					'i18n'      => array(
						'noStates'    => __( 'No states/regions for the selected country.', 'woocommerce-wholesale-pricing' ),
						'leaveEmpty'  => __( 'Leave empty to apply to the whole country.', 'woocommerce-wholesale-pricing' ),
						'billing'     => __( 'billing address', 'woocommerce-wholesale-pricing' ),
						'shipping'    => __( 'shipping address', 'woocommerce-wholesale-pricing' ),
						'anyLocation' => __( 'any location', 'woocommerce-wholesale-pricing' ),
						'anyTotal'    => __( 'any order total', 'woocommerce-wholesale-pricing' ),
						'betweenTotals' => __( 'orders from %1$s to %2$s', 'woocommerce-wholesale-pricing' ),
						'minTotal'    => __( 'orders of at least %s', 'woocommerce-wholesale-pricing' ),
						'maxTotal'    => __( 'orders up to %s', 'woocommerce-wholesale-pricing' ),
						'summary'     => __( 'Restricted when the %1$s is in %2$s, for %3$s.', 'woocommerce-wholesale-pricing' ),
					),
				)
			);
		}     
		/**
		*  Filter 
		*                            
		*  @since 2.3.0 
		*/
		if (! in_array($screen_id, apply_filters('wwp_disable_scripts', array())) ) {
			wp_enqueue_style('wwp_fontawesome');
		}
		
		wp_enqueue_script('wwp-popper-min-js');
		wp_enqueue_script('wwp-bootstrap-js');
		wp_enqueue_script('wwp-bootstrap-select-js');

		$wholesale_screens = array( 'wwp_wholesale', 'wwp_wholesale_settings', 'wwp-registration-setting', 'wwp_wholesale_notifcations', 'wwp-bulk-wholesale-pricing' );

		if (( isset($_GET['page']) && in_array(sanitize_text_field($_GET['page']), $wholesale_screens) ) || ( in_array($screen_id, array( 'wwp_requests' )) ) ) {
			wp_enqueue_style('wwp-data-tip');
			wp_enqueue_style('wwp-bootstrap');
			wp_enqueue_style('wwp-bootstrap-select');
			wp_enqueue_style('wwp-admin-new');

			wp_enqueue_media();
		}

		if (( 'product' === $post_type ) 
			|| ( isset($_GET['post_type']) && isset($_GET['taxonomy']) 
			&& 'product' === wc_clean($_GET['post_type']) && 'product_cat' === wc_clean($_GET['taxonomy']) ) 
		) {
			wp_enqueue_style('wwp-product-admin');
			wp_enqueue_script('wwp-bootstrap-js');
			wp_enqueue_style('wwp-data-tip');
		}

		if ( 'woocommerce_page_wc-orders' == $current_screen->id && is_quote_enabled() ) {
			wp_enqueue_script('wwp_formbuilder');
			wp_enqueue_style('wwp_formbuilder');
			// wp_enqueue_style('wc-quote-admin-styles');
		}

		if (in_array($current_screen->id, array( 'wholesale_page_wwp-registration-setting' )) ) {
			$current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : '';
			wp_enqueue_script('wwp_formbuilder');
			wp_enqueue_style('wwp_formbuilder');

			// Quote and wholesale builders share one initializer with tab-specific config.
			if ('quote-form-builder' === $current_tab ) {
				wp_enqueue_style('wc-quote-builder-admin-styles');
				wp_enqueue_script('wwp_formbuilder_init');
				$quote_builder_config = str_replace('"false"', 'false', wp_unslash(get_option('wc_quote_form_builder')));
				$wwp_formbuilder_config = array(
					'ajax_url' => admin_url('admin-ajax.php'),
					'nonce' => wp_create_nonce('wc-quote-ajax-nonce'),
					'builder_config' => json_decode($quote_builder_config),
					'builder_element_id' => 'wc-quote-formbuilder',
					'save_button_selector' => '#wc-quote-save-formbuilder',
					'success_message_selector' => '.registration-form-message',
					'save_action' => 'wc_quote_form_builder_save',
					'payload_key' => 'builder_schema',
				);
				wp_localize_script('wwp_formbuilder_init', 'wwp_formbuilder_config', $wwp_formbuilder_config);
			} elseif ('extra-fields' === $current_tab ) {
				// Wholesale registration form builder keeps using its own option key.
				wp_enqueue_script('wwp_formbuilder_init');
				$builder_config = str_replace('"false"', 'false', wp_unslash(get_option('wwp_save_form')));
				$wwp_formbuilder_config = array(
					'ajax_url' => admin_url('admin-ajax.php'),
					'nonce' => wp_create_nonce('wc-wholesale-ajax-nonce'),
					'builder_config' => json_decode($builder_config),
					'builder_element_id' => 'build-wrap',
					'save_button_selector' => '#wc-wholesale-save-formbuilder',
					'success_message_selector' => '.registration-form-message',
					'save_action' => 'wwp_save_form',
					'payload_key' => 'formData',
				);
				wp_localize_script('wwp_formbuilder_init', 'wwp_formbuilder_config', $wwp_formbuilder_config);
			}
		}

		if ( in_array($current_screen->id, array( 'toplevel_page_wwp_wholesale' )) ) {
			$dashboard_asset_path = WWP_PLUGIN_PATH . 'build/dashboard/index.asset.php';
			$dashboard_dependencies = array();
			if ( file_exists( $dashboard_asset_path ) ) {
				$dashboard_asset = include_once $dashboard_asset_path;
				if ( isset( $dashboard_asset['dependencies'] ) && is_array( $dashboard_asset['dependencies'] ) ) {
					$dashboard_dependencies = $dashboard_asset['dependencies'];
				}
			}

			$dashboard_asset_version = WWP_VERSION;
			if ( isset( $dashboard_asset['version'] ) ) {
				$dashboard_asset_version = $dashboard_asset['version'];
			}
			// Dequeued default bootstrap
			wp_dequeue_style('wwp-bootstrap');

			wp_enqueue_script('wwp-moment');
			wp_enqueue_script('wwp-daterangepicker');

			wp_enqueue_style('wwp-daterangepicker');

			// Enqueue compiled Tailwind/Flowbite CSS for dashboard
			wp_enqueue_style('wwp-dashboard', WWP_PLUGIN_URL . 'build/dashboard/index.css', array(), $dashboard_asset_version, 'all');
			wp_enqueue_style('dashboard-style');
			// Enqueue dashboard JS bundle
			wp_enqueue_script('wwp-dashboard', WWP_PLUGIN_URL . 'build/dashboard/index.js', $dashboard_dependencies, $dashboard_asset_version, array( 'in_footer' => true ));
		}
		
		if ( in_array( $current_screen->id, array( 'edit-wc-quote-rules', 'wc-quote-rules', 'wc-quote', 'edit-wc-quote' ) ) ) { 
			wp_enqueue_style('wc-quote-admin-styles');
			wp_enqueue_script('wc-quote-admin');
			$wc_quote_vars = array(
				'ajax_url' => admin_url('admin-ajax.php'),
				'nonce'    => wp_create_nonce('wc-quote-ajax-nonce'),
				);
				wp_localize_script('wc-quote-admin', 'wc_quote_vars', $wc_quote_vars);
		}

		if ( 'wc-quote-rules' == $screen->id ) {
			wp_enqueue_style('wwp-admin-new');

			wp_enqueue_script('wc-quote-admin');

			wp_enqueue_script('selectWoo');
			$extra_script = 'jQuery("input#wc_quote_enable_pdf_attach").is(":checked")||jQuery("tr.wc_quote_hide_product_list").hide(),jQuery("input#wc_quote_enable_pdf_attach").change(function(){jQuery(this).is(":checked")?jQuery("tr.wc_quote_hide_product_list").show():jQuery("tr.wc_quote_hide_product_list").hide()}),jQuery("input#wc_quote_expire").is(":checked")||jQuery("tr.wc_quote_expiration_days").hide(),jQuery("input#wc_quote_expire").change(function(){jQuery(this).is(":checked")?jQuery("tr.wc_quote_expiration_days").show():jQuery("tr.wc_quote_expiration_days").hide()}),jQuery("input#wc_quote_enable_offered").is(":checked")||jQuery("tr.wc_quote_increase_offered_price").hide(),jQuery("input#wc_quote_enable_offered").change(function(){jQuery(this).is(":checked")?jQuery("tr.wc_quote_increase_offered_price").show():jQuery("tr.wc_quote_increase_offered_price").hide()}),jQuery("input#wc_quote_mini_cart").is(":checked")||(jQuery("tr.wc_quote_basket_menu").hide(),jQuery("tr.wc_quote_disable_basket_roles").hide()),jQuery("input#wc_quote_mini_cart").change(function(){jQuery(this).is(":checked")?(jQuery("tr.wc_quote_basket_menu").show(),jQuery("tr.wc_quote_disable_basket_roles").show()):(jQuery("tr.wc_quote_basket_menu").hide(),jQuery("tr.wc_quote_disable_basket_roles").hide())});';
			wp_add_inline_script('iris', $extra_script);
			$wc_quote_vars = array(
			'ajax_url' => admin_url('admin-ajax.php'),
			'nonce'    => wp_create_nonce('wc-quote-ajax-nonce'),
			);
			wp_localize_script('wc-quote-admin', 'wc_quote_vars', $wc_quote_vars);
		}

		if ( 'custom_pdf' == $screen->id ) {
			wp_deregister_script('wwp-script');
		}

		if ( 'user-edit' == $screen->id ) {
			wp_enqueue_script('wwp_formbuilder');
			wp_enqueue_style('wwp_formbuilder');
			$builder_config = str_replace('"false"', 'false', wp_unslash(get_option('wwp_save_form')));
			$extra_script = 'var components = ' . $builder_config . ';';
			wp_add_inline_script('wwp_formbuilder', $extra_script);

		}

		if ( 'wc-quote' == $screen->id ) {
			wp_enqueue_script('wwp_formbuilder');
			wp_enqueue_style('wwp_formbuilder');
			$builder_config = str_replace('"false"', 'false', wp_unslash(get_option('wc_quote_form_builder')));
			$extra_script = 'var components = ' . $builder_config . ';';
			wp_add_inline_script('wwp_formbuilder', $extra_script);

			wp_dequeue_style('wwp-style');
		}

		if ( 'wholesale_page_wwp-aiassistant' == $screen->id ) {
			$ai_assistant_asset_path = WWP_PLUGIN_PATH . 'build/pages/ai-assistant.asset.php';
			$ai_assistant_dependencies = array();
			if ( file_exists( $ai_assistant_asset_path ) ) {
				$ai_assistant_asset = include_once $ai_assistant_asset_path;
				if ( isset( $ai_assistant_asset['dependencies'] ) && is_array( $ai_assistant_asset['dependencies'] ) ) {
					$ai_assistant_dependencies = $ai_assistant_asset['dependencies'];
				}
			}

			$ai_assistant_asset_version = WWP_VERSION;
			if ( isset( $ai_assistant_asset['version'] ) ) {
				$ai_assistant_asset_version = $ai_assistant_asset['version'];
			}

			wp_enqueue_style('wwp-ai-assistant', WWP_PLUGIN_URL . 'build/pages/ai-assistant.css', array(), $ai_assistant_asset_version, 'all');
			wp_enqueue_script('wwp-ai-assistant', WWP_PLUGIN_URL . 'build/pages/ai-assistant.js', $ai_assistant_dependencies, $ai_assistant_asset_version, array( 'in_footer' => true ));
		}

		if ( 'edit-wcpt' === $screen_id ) {
			wp_enqueue_style('wcpt-style');
			wp_enqueue_script('wcpt-list-table');
			wp_localize_script(
				'wcpt-list-table',
				'wcpt_list_table_params',
				array(
					'ajax_url'            => admin_url('admin-ajax.php'),
					'nonce'               => wp_create_nonce('wcpt_list_table'),
					'error_message'       => __('Something went wrong. Please try again.', 'woocommerce-wholesale-pricing'),
					'copy_hint'           => __('Click to copy', 'woocommerce-wholesale-pricing'),
					'copied_message'      => __('Copied!', 'woocommerce-wholesale-pricing'),
					'copy_error_message'  => __('Could not copy shortcode. Please copy it manually.', 'woocommerce-wholesale-pricing'),
				)
			);

			if ( is_quick_order_form_enabled() ) {
				wp_enqueue_script('wcpt-quick-order-admin');
				wp_localize_script(
					'wcpt-quick-order-admin',
					'wcpt_quick_order_admin_params',
					array(
						'quick_order_enabled' => true,
						'is_quick_order_form' => false,
					)
				);
			}
		}

		if ( wwp_env()->get('product_table_slug') == $post_type && 'edit-wcpt' !== $screen_id ) {
			wp_enqueue_style('wcpt-style');
			wp_enqueue_style('wcpt-jquery-ui-style');
			wp_enqueue_style('wwp-select2');
			wp_enqueue_style('woocommerce_admin_styles');
			wp_enqueue_script('wcpt-scripts');
			wp_enqueue_script('wcpt-select2');
			wp_enqueue_script('jquery-tiptip');
			wp_enqueue_script('wcpt-custom-sel');

			if ( is_quick_order_form_enabled() ) {
				wp_enqueue_script('wcpt-quick-order-admin');
				wp_localize_script(
					'wcpt-quick-order-admin',
					'wcpt_quick_order_admin_params',
					array(
						'quick_order_enabled' => true,
						'is_quick_order_form' => \WooCommerceWholesalePricing\App\Services\ProductTable\TableTypeHelper::is_quick_order_form(),
					)
				);
			}
		}

		if ( in_array( $screen->id, array( 'agent', 'commission_cat', 'edit-commission_cat', 'edit-agent_approval' ) ) ) {
			wp_enqueue_script('wc-enhanced-select');
			wp_enqueue_style('wwp-select2');
			wp_enqueue_style( 'sa-admin', WWP_PLUGIN_URL . 'public/css/sales-agent/admin.css', false, '1.0' );
			wp_enqueue_style( 'select2css', WC()->plugin_url() . '/assets/css/select2.css', false, '1.0' );
			wp_enqueue_script( 'select2js', WC()->plugin_url() . '/assets/js/select2/select2.full.min.js', array( 'jquery' ), '1.0', true );
			wp_enqueue_script( 'custom-admin-setting', WWP_PLUGIN_URL . 'public/js/sales-agent/script.js', array( 'jquery' ), 1.0, true );
			wp_localize_script( 'custom-admin-setting', 'ajax', array( 'ajax_url' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce('wc_sales_agent_nonce') ) );
		}

		if ( 'wholesale_page_wwp-registration-setting' === $screen->id && 'sales-agent' == filter_input(INPUT_GET, 'tab', FILTER_SANITIZE_SPECIAL_CHARS) ) {
			wp_enqueue_script('wwp_formbuilder');
			wp_enqueue_script(
				'sales-agent-init-builder',
				WWP_PLUGIN_URL . 'public/js/sales-agent/formbuilder.js',
				array( 'jquery', 'wwp_formbuilder' ),
				'1.3',
				true
			);
		}

		if ('wholesale_page_agent-payout-view' == $current_screen->id) {
			wp_enqueue_style( 'commission-datepakercss', WWP_PLUGIN_URL . '/public/css/sales-agent/jquery-ui.css', false, WWP_VERSION );
			wp_enqueue_script( 'commission-datepakerjs', WWP_PLUGIN_URL . '/public/js/sales-agent/jquery-ui.min.js', array( 'jquery' ), WWP_VERSION, true );

			wp_enqueue_script( 'agent-payout-list-js', WWP_PLUGIN_URL . 'public/js/sales-agent/my-account.js', array( 'jquery', 'commission-datepakerjs' ), WWP_VERSION, true );
			wp_localize_script(
				'agent-payout-list-js',
				'ajax',
				array(
					'ajax_url'                 => admin_url( 'admin-ajax.php' ),
					'nonce'                    => wp_create_nonce( 'wc_sales_agent_nonce' ),
					'delete_commission_nonce'  => wp_create_nonce( 'delete_commission_nonce' ),
					'export_commissions_nonce' => wp_create_nonce( 'export_commissions_nonce' ),
					'delete_commission'        => __(
						'Do you want to delete this commission',
						'woocommerce-wholesale-pricing'
					),
				)
			);
		}

		if ( function_exists( 'is_company_credits_enabled' ) && is_company_credits_enabled() ) {
			$company_slug = wwp_env()->get( 'company_credits_slug' );
			$logs_slug    = wwp_env()->get( 'company_credit_logs_slug' );
			$ccp_screens  = array(
				$company_slug,
				'edit-' . $company_slug,
				$logs_slug,
				'edit-' . $logs_slug,
			);

			if ( in_array( $screen->id, $ccp_screens, true ) || $company_slug === $post_type || $logs_slug === $post_type ) {
				wp_enqueue_style( 'wwp-ccp-admin' );
				wp_enqueue_script( 'wc-enhanced-select' );
				wp_enqueue_script( 'wwp-ccp-admin' );
				wp_localize_script(
					'wwp-ccp-admin',
					'wwp_ccp_admin',
					array(
						'ajax_url'  => admin_url( 'admin-ajax.php' ),
						'nonce'     => wp_create_nonce( 'ccp_user_security' ),
						'post_type' => $company_slug,
						'i18n'      => array(
							'requestFailed'         => __( 'Request failed.', 'woocommerce-wholesale-pricing' ),
							'confirmDeclineRequest' => __( 'Decline this credit request?', 'woocommerce-wholesale-pricing' ),
							'titleRequired'         => __( 'Company name is required.', 'woocommerce-wholesale-pricing' ),
							'userAlreadySelected'   => __( 'This user is already assigned to a company role.', 'woocommerce-wholesale-pricing' ),
							'editCreditLimit'       => __( 'Edit credit limit', 'woocommerce-wholesale-pricing' ),
						),
					)
				);
			}
		}

		$dynamic_rules_slug = wwp_env()->get( 'dynamic_rules_slug' );
		if (
			$dynamic_rules_slug
			&& (
				$dynamic_rules_slug === $post_type
				|| 'edit-' . $dynamic_rules_slug === $screen_id
			)
		) {
			wp_enqueue_style( 'woocommerce_admin_styles' );
			wp_enqueue_script( 'wc-enhanced-select' );
			wp_enqueue_script( 'wwp-dynamic-rules-admin' );

			$groups_enabled = false;
			$pricing        = self::get_pricing_settings();
			if ( isset( $pricing['enable_groups'] ) && 'yes' === $pricing['enable_groups'] ) {
				$groups_enabled = true;
			}

			wp_localize_script(
				'wwp-dynamic-rules-admin',
				'wwp_dynamic_rules_params',
				array(
					'groupsEnabled'    => $groups_enabled,
					'currencySymbol'   => function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : '',
					'ajaxUrl'          => admin_url( 'admin-ajax.php' ),
					'applicableProducts' => array(
						'action' => 'wwp_dynamic_rule_applicable_products',
						'nonce'  => wp_create_nonce( 'wwp_dynamic_rule_applicable_products' ),
					),
					'ruleTypeLabels'   => \WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMetaHelper::get_rule_type_options( true ),
					'conditionLabels'  => \WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMetaHelper::get_condition_options(),
					'appliesToLabels'  => \WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMetaHelper::get_applies_to_options(),
					'i18n'             => array(
						'allWholesaleRoles' => __( 'All wholesale roles', 'woocommerce-wholesale-pricing' ),
						'allGroups'         => __( 'All groups', 'woocommerce-wholesale-pricing' ),
						'b2c'               => __( 'B2C (retail)', 'woocommerce-wholesale-pricing' ),
						'guests'            => __( 'Guest users', 'woocommerce-wholesale-pricing' ),
						'all'               => __( 'All', 'woocommerce-wholesale-pricing' ),
						'titleRequired'     => __( 'Rule title is required.', 'woocommerce-wholesale-pricing' ),
						'days'              => __( 'days', 'woocommerce-wholesale-pricing' ),
						'loadingProducts'   => __( 'Updating…', 'woocommerce-wholesale-pricing' ),
						'noProducts'        => __( 'No products match the current rule, group, and role settings.', 'woocommerce-wholesale-pricing' ),
						'previewFailed'     => __( 'Could not refresh applicable products.', 'woocommerce-wholesale-pricing' ),
						'applicableProducts'=> __( 'applicable products', 'woocommerce-wholesale-pricing' ),
						'allProducts'       => __( 'All products', 'woocommerce-wholesale-pricing' ),
						'unsupportedRule'   => __( 'Product applicability does not apply to Change Group rules.', 'woocommerce-wholesale-pricing' ),
					),
				)
			);
		}
	}

	/**
	 * Enqueues scripts and styles for the frontend (store/shop).
	 *
	 * This method is hooked to `wp_enqueue_scripts`. It registers and enqueues
	 * general frontend assets and DataTables for displaying wholesale pricing tables.
	 *
	 * @return void
	 */
	public function blogScripts() {
		$this->register_frontend_assets();
		$this->register_formbuilder_assets();
		$this->register_product_table_scripts();
		wp_enqueue_script('wwp-script');
		wp_enqueue_style('wwp-wholesale');

		if (
			function_exists( 'is_company_credits_enabled' )
			&& is_company_credits_enabled()
			&& function_exists( 'is_checkout' )
			&& (
				is_checkout()
				|| ( function_exists( 'is_order_received_page' ) && is_order_received_page() )
			)
		) {
			wp_enqueue_style( 'wwp-ccp-checkout' );
		}

		$settings           = self::get_pricing_settings();
		$global_settings    = self::get_multiuser_pricing_settings();
		$role               = get_current_user_role_id();

		unset($settings['wholesale_css']);

		if (is_object(wc_get_product(get_the_id())) ) {
			$product = wc_get_product(get_the_id());
			$type    = $product->get_type();
		}
		
		if (empty($type)) {
			$type ='';
		}

		$wwp_wholesale_pricing = array(
			'ajaxurl'                => admin_url('admin-ajax.php'),
			'ajax_nonce'             => wp_create_nonce('wwp_wholesale_pricing'),
			'product_type'           => $type,
			'product_id'             => get_the_id(),
			'plugin_url'             => WWP_PLUGIN_URL,
			'currency_symbol'        => get_woocommerce_currency_symbol(),
			'wwp_wholesale_settings' => $settings,
			'wc_get_cart_url'        => wc_get_cart_url(),
			'payment_methods'        => wwp_get_active_payment_methods(),
			'min_subtotal_enabled'   => ( bool ) ( isset($global_settings[$role]) && isset($global_settings[$role]['min_subtotal']) && ! empty($global_settings[$role]['min_subtotal']) && 0 < $global_settings[$role]['min_subtotal'] ),
			/**
			* Hooks
			*
			* @since 3.0
			*/
			'check_subtotal'   => apply_filters('wwp_check_subtotal', false),
		);
		wp_localize_script('wwp-script', 'wwpscript', $wwp_wholesale_pricing);

		if ( is_quote_enabled() && wwp_should_enqueue_quote_assets() ) {
			$quote_settings = self::get_quote_notifications_settings();

			$add_quote_redirect = isset($quote_settings['add_quote_redirect']) ? $quote_settings['add_quote_redirect'] : '0';
			$add_quote_redirect_url = isset($quote_settings['add_quote_redirect_url']) ? $quote_settings['add_quote_redirect_url'] : '';

			$wc_quote_vars = array(
			'ajax_url' => admin_url('admin-ajax.php'),
			'nonce'     => wp_create_nonce('wc-quote-ajax-nonce'),
			'redirect'  => $add_quote_redirect,
			'redirect_url'   => $add_quote_redirect_url,
			'post_id' => get_the_ID(),
			);

			wp_localize_script('wc-quote-front', 'wc_quote_vars', $wc_quote_vars);
			wp_enqueue_script('wc-quote-front');
			wp_enqueue_style('wc-quote-front');

			if ( function_exists( 'is_quote' ) && is_quote() ) {
				$email_valid_msg = isset($quote_settings['email_valid_msg']) && !empty($quote_settings['email_valid_msg']) ? $quote_settings['email_valid_msg'] : '{{field}} must be a valid email.';
				$current_user = wp_get_current_user();
				$builder_config = str_replace('"false"', 'false', wp_unslash(get_option('wc_quote_form_builder')));
				$wc_quote_fields_vars = array(
				'form_fields' => json_decode($builder_config),
				'user_email' => $current_user->user_email,
				'invalid_email_msg' => $email_valid_msg,
				);
				wp_localize_script('wc-quote-front-fields', 'wc_quote_fields_vars', $wc_quote_fields_vars);
				wp_enqueue_script('wc-quote-front-fields');
				wp_enqueue_script('wwp_formbuilder');
			}

			if ( is_account_page() || get_query_var('download_pdf') ) {
				wp_enqueue_script('wcquote-jspdf-min', WWP_PLUGIN_URL . 'public/js/deps/jspdf.min.js', array(), WWP_VERSION, false);
				wp_enqueue_script('wcquote-jhtml2canvas', WWP_PLUGIN_URL . 'public/js/deps/html2canvas.min.js', array(), WWP_VERSION, false);
				wp_enqueue_script('wcquote_html2pdf', WWP_PLUGIN_URL . 'public/js/deps/html2pdf.min.js', array(), WWP_VERSION, false);
				wp_enqueue_script('wcquote_html2pdfs', 'https://cdn.jsdelivr.net/npm/pdf-lib/dist/pdf-lib.min.js', array(), WWP_VERSION, false);
			}
		}

		if ( is_product_table_enabled() && $this->is_product_table_request() ) {
			if (wc_post_content_has_shortcode('wc_products_table') ) {
				wp_enqueue_style('wc-bundle-css');
			}

			wp_enqueue_style('datatables_style');
			wp_enqueue_style('wcpt_single_product');
			wp_enqueue_script('wcpt_calculate');
		
			wp_enqueue_script('datatables_script');
			wp_enqueue_script('product_table_script');
			wp_enqueue_style('product_table_style');

			wp_enqueue_style('responsive_datatables_style');
			wp_enqueue_script('responsive_datatables_script');
			wp_enqueue_script('colvis_button_datatables_script');
		}
		
		if ( is_sales_agent_registration_form() ) {

			$form = str_replace( '"false"', 'false', get_option( 'sales_agent_form_builder_data' ) );

			$args = array(
				'taxonomy'   => 'commission_cat',
				'hide_empty' => false,
			);

			$agent_categories = get_terms( $args );

			$form = get_form_result_with_catagory( json_decode( $form ), $agent_categories );

			if ( empty( $form ) ) {
				$form = (object) array(
					'components' => mendatory_fields(),
				);
			}

			wp_localize_script(
				'wwp_sales_agent_form',
				'USER_REGISTER_FORM',
				array(
					'ajax_url'    => admin_url( 'admin-ajax.php' ),
					'nonce'       => wp_create_nonce( 'sales-agent-register-nonce' ),
					'form_fields' => $form,
				)
			);
			wp_enqueue_style( 'wwp-bootstrap' );
			wp_enqueue_style( 'wwp_formbuilder' );

			wp_enqueue_script( 'wwp_formbuilder' );
			wp_enqueue_script( 'wwp_sales_agent_form' );
		}

		if ( is_account_page() ) {
			wp_enqueue_style( 'commission-datepakercss', WWP_PLUGIN_URL . '/public/css/sales-agent/jquery-ui.css', false, WWP_VERSION );
			wp_enqueue_script( 'commission-datepakerjs', WWP_PLUGIN_URL . '/public/js/sales-agent/jquery-ui.min.js', array( 'jquery' ), WWP_VERSION, true );
			wp_enqueue_script( 'selectWoo' );
			wp_enqueue_style( 'select2' );
			wp_enqueue_script( 'customer-details-list-js', WWP_PLUGIN_URL . 'public/js/sales-agent/my-account.js', array( 'jquery', 'selectWoo', 'commission-datepakerjs' ), WWP_VERSION, true );
			wp_localize_script(
				'customer-details-list-js',
				'ajax',
				array(
					'ajax_url' => admin_url( 'admin-ajax.php' ),
					'nonce'    => wp_create_nonce( 'wc_sales_agent_nonce' ),
					'delete_commission_nonce' => wp_create_nonce( 'delete_commission_nonce' ),
					'delete_commission'       => __(
						'Do you want to delete this commission',
						'woocommerce-wholesale-pricing'
					),
				)
			);

			wp_enqueue_style( 'wc_list_customers_my_account', WWP_PLUGIN_URL . 'public/css/sales-agent/my-account.css', array(), WWP_VERSION );
		}

		$this->enqueue_registration_form_assets();
	}

	/**
	 * Determine whether current frontend request renders the product table.
	 *
	 * @return bool
	 */
	private function is_product_table_request() {
		if ( function_exists( 'wc_post_content_has_shortcode' ) && wc_post_content_has_shortcode( 'wc_products_table' ) ) {
			return true;
		}

		if ( function_exists( 'is_singular' ) && is_singular() && function_exists( 'has_block' ) ) {
			$post = get_post( get_queried_object_id() );

			if ( $post instanceof \WP_Post && has_block( 'product-table/wcpt-product-table', $post ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Enqueues additional scripts that need to be loaded in the `<head>` or early.
	 *
	 * This method is hooked to `wp_head`. These scripts are often required for
	 * early rendering or core functionality like country/address selection.
	 *
	 * @return void
	 */
	public function hook_javascript() {
		$this->enqueue_registration_form_assets();
	}

	/**
	 * Enqueue Form.io and country-select assets for wholesale extra fields.
	 *
	 * Must run during `wp_enqueue_scripts` so inline schema is printed with Form.io.
	 * Attaching it from `wp_head` (priority 10) is too late once quotes already
	 * printed the Form.io handle in the head.
	 *
	 * @return void
	 */
	private function enqueue_registration_form_assets() {
		$this->register_formbuilder_assets();
		$settings = self::get_registration_settings();

		$should_enqueue = (
			(
				is_wholesale_registration_page()
				&& isset( $settings['display_fields_registration'] )
				&& 'yes' === $settings['display_fields_registration']
			)
			|| (
				function_exists( 'is_account_page' )
				&& is_account_page()
				&& isset( $settings['display_fields_myaccount'] )
				&& 'yes' === $settings['display_fields_myaccount']
			)
			|| (
				function_exists( 'is_checkout' )
				&& is_checkout()
				&& isset( $settings['display_fields_checkout'] )
				&& 'yes' === $settings['display_fields_checkout']
			)
		);

		if ( ! $should_enqueue ) {
			return;
		}

		wp_enqueue_script( 'address-i18n' );
		wp_enqueue_script( 'wc-country-select' );
		wp_enqueue_style( 'wwp_formbuilder' );
		wp_enqueue_script( 'wwp_formbuilder' );

		static $inline_added = false;
		if ( ! $inline_added && ! wp_script_is( 'wwp_formbuilder', 'done' ) ) {
			$inline_added = true;
			$builder_config = wp_json_encode( wwp_get_wholesale_form_builder_config(), JSON_HEX_TAG | JSON_UNESCAPED_SLASHES );
			wp_add_inline_script( 'wwp_formbuilder', 'var components = ' . $builder_config . ';' );
		}
	}
}
