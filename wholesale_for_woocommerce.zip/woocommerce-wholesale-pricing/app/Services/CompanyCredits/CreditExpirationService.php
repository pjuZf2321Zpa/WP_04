<?php
/**
 * Company credit expiration scheduler and reset routine.
 *
 * @package WooCommerceWholesalePricing\App\Services\CompanyCredits
 */

namespace WooCommerceWholesalePricing\App\Services\CompanyCredits;

use DateTime;
use DateTimeZone;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Schedules and executes recurring company credit expiration resets.
 */
class CreditExpirationService implements ServiceInterface {

	/**
	 * Cron hook name.
	 *
	 * @var string
	 */
	const CRON_HOOK = 'ccp_credit_expiration_daily_event';

	/**
	 * Company post type.
	 *
	 * @var string
	 */
	protected $company_slug;

	/**
	 * CreditExpirationService constructor.
	 */
	public function __construct() {
		$this->company_slug = wwp_env()->get( 'company_credits_slug' );

		add_action( 'init', array( $this, 'register_cron' ) );
		add_action( self::CRON_HOOK, array( $this, 'run_due_expirations' ) );
	}

	/**
	 * Only run when the module is enabled.
	 *
	 * @return bool
	 */
	public static function resolveDependency() {
		return is_company_credits_enabled();
	}

	/**
	 * Register daily cron event.
	 *
	 * @return void
	 */
	public function register_cron() {
		if ( ! function_exists( 'wp_next_scheduled' ) ) {
			return;
		}

		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time(), 'daily', self::CRON_HOOK );
		}
	}

	/**
	 * Daily cron handler: finds due companies and performs reset.
	 *
	 * @return void
	 */
	public function run_due_expirations() {
		if ( empty( $this->company_slug ) ) {
			return;
		}

		$companies = get_posts(
			array(
				'post_type'      => $this->company_slug,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'meta_query'     => array(
					array(
						'key'   => 'ccp_credit_expiration_enabled',
						'value' => 'yes',
					),
				),
				'fields'         => 'ids',
			)
		);

		if ( empty( $companies ) || ! is_array( $companies ) ) {
			return;
		}

		foreach ( $companies as $company_id ) {
			$company_id = absint( $company_id );
			if ( empty( $company_id ) ) {
				continue;
			}

			if ( $this->is_company_due_today( $company_id ) ) {
				$this->reset_company_credits( $company_id );
			}
		}
	}

	/**
	 * Determine whether a company is due to expire today.
	 *
	 * @param int $company_id Company post ID.
	 * @return bool
	 */
	protected function is_company_due_today( $company_id ) {
		$today = $this->get_today_ymd_in_wp_timezone();
		$last_run = get_post_meta( $company_id, 'ccp_credit_expiration_last_run', true );
		if ( ! empty( $last_run ) && (string) $last_run === (string) $today ) {
			return false;
		}

		$mode = get_post_meta( $company_id, 'ccp_credit_expiration_mode', true );
		$mode = in_array( $mode, array( 'monthly', 'yearly' ), true ) ? $mode : 'monthly';

		$day = absint( get_post_meta( $company_id, 'ccp_credit_expiration_day', true ) );
		$day = $day >= 1 && $day <= 31 ? $day : 1;

		$month = absint( get_post_meta( $company_id, 'ccp_credit_expiration_month', true ) );
		$month = $month >= 1 && $month <= 12 ? $month : 1;

		$now = $this->get_now_in_wp_timezone();
		$year = (int) $now->format( 'Y' );

		if ( 'monthly' === $mode ) {
			$targetMonth = (int) $now->format( 'n' );
		} else {
			$targetMonth = $month;
		}

		$daysInMonth = cal_days_in_month( CAL_GREGORIAN, $targetMonth, $year );
		$targetDay   = min( $day, $daysInMonth );

		$due = clone $now;
		$due->setDate( $year, $targetMonth, $targetDay );
		$due->setTime( 0, 0, 0 );

		return (string) $due->format( 'Y-m-d' ) === (string) $today;
	}

	/**
	 * Reset routine for a single company.
	 *
	 * @param int $company_id Company post ID.
	 * @return void
	 */
	protected function reset_company_credits( $company_id ) {
		$enabled = get_post_meta( $company_id, 'ccp_credit_expiration_enabled', true );
		if ( 'yes' !== $enabled ) {
			return;
		}

		$starting_balance = get_post_meta( $company_id, 'ccp_credit_expiration_starting_balance', true );
		$starting_balance = is_numeric( $starting_balance ) ? (float) $starting_balance : 0.0;
		$starting_balance = max( 0, $starting_balance );

		$owner_ids   = get_post_meta( $company_id, 'ccp_company_users_owner', true );
		$manager_ids = get_post_meta( $company_id, 'ccp_company_users_manager', true );
		$member_ids  = get_post_meta( $company_id, 'ccp_company_users_member', true );

		$assigned_user_ids = array_unique(
			array_filter(
				array_map(
					'absint',
					array_merge(
						(array) $owner_ids,
						(array) $manager_ids,
						(array) $member_ids
					)
				)
			)
		);

		$user_count = count( $assigned_user_ids );
		if ( $user_count <= 0 ) {
			update_post_meta( $company_id, 'ccp_credit_expiration_last_run', $this->get_today_ymd_in_wp_timezone() );
			return;
		}

		$total_starting = round( $starting_balance * $user_count, 2 );

		// Compute raw pool totals (no baseline subtraction) to set a fresh baseline snapshot.
		$raw_totals = $this->get_raw_company_pool_totals( $company_id );

		update_post_meta(
			$company_id,
			'ccp_credit_logs_reset_baseline',
			array(
				'credit'   => round( $raw_totals['credit'], 2 ),
				'consumed' => round( $raw_totals['consumed'], 2 ),
			)
		);

		if ( $total_starting > 0 ) {
			ccp_add_company_credit(
				array(
					'company_id' => $company_id,
					'order_id'   => '',
					'amount'     => $total_starting,
					'event'      => __( 'Company Credit Expiration Reset', 'woocommerce-wholesale-pricing' ),
				)
			);
		}

		// Reseed member limits + wallet balances for the new cycle.
		$this->reseed_assigned_users( $company_id, $assigned_user_ids, $starting_balance );

		update_post_meta( $company_id, 'ccp_credit_expiration_last_run', $this->get_today_ymd_in_wp_timezone() );
	}

	/**
	 * Get raw company pool totals from logs (no baseline subtraction).
	 *
	 * @param int $company_id Company post ID.
	 * @return array{credit:float,consumed:float}
	 */
	protected function get_raw_company_pool_totals( $company_id ) {
		$credit   = 0.0;
		$consumed = 0.0;

		$logs = get_posts(
			array(
				'post_type'      => 'ccp_credit_logs',
				'posts_per_page' => -1,
				'meta_query'     => array(
					array(
						'key'   => 'company_id',
						'value' => $company_id,
					),
				),
			)
		);

		if ( empty( $logs ) || ! is_array( $logs ) ) {
			return array( 'credit' => 0.0, 'consumed' => 0.0 );
		}

		foreach ( $logs as $log ) {
			$affects_pool = get_post_meta( $log->ID, 'ccp_affects_pool', true );
			if ( 'no' === $affects_pool ) {
				continue;
			}

			$amount = get_post_meta( $log->ID, 'amount', true );
			if ( ! is_numeric( $amount ) ) {
				continue;
			}

			$amount = (float) $amount;
			if ( $amount < 0 ) {
				$consumed = round( $consumed + $amount, 2 );
			} else {
				$credit = round( $credit + $amount, 2 );
			}
		}

		return array( 'credit' => $credit, 'consumed' => $consumed );
	}

	/**
	 * Reseed assigned user credit limits + wallet balances.
	 *
	 * @param int   $company_id Company post ID.
	 * @param array $user_ids Assigned user IDs.
	 * @param float $starting_balance Starting balance per user.
	 * @return void
	 */
	protected function reseed_assigned_users( $company_id, $user_ids, $starting_balance ) {
		$starting_balance = round( (float) $starting_balance, 2 );
		if ( $starting_balance < 0 ) {
			$starting_balance = 0.0;
		}

		$user_limits = get_post_meta( $company_id, 'ccp_user_credit_limits', true );
		if ( ! is_array( $user_limits ) ) {
			$user_limits = array();
		}

		$wallets = get_post_meta( $company_id, 'ccp_user_wallet_balances', true );
		if ( ! is_array( $wallets ) ) {
			$wallets = array();
		}

		foreach ( $user_ids as $user_id ) {
			$user_id = absint( $user_id );
			if ( empty( $user_id ) ) {
				continue;
			}

			$user_limits[ $user_id ] = (string) $starting_balance;
			$wallets[ $user_id ]     = (string) $starting_balance;
		}

		update_post_meta( $company_id, 'ccp_user_credit_limits', $user_limits );
		update_post_meta( $company_id, 'ccp_user_wallet_balances', $wallets );
	}

	/**
	 * Current time in WordPress timezone as a DateTime.
	 *
	 * @return DateTime
	 */
	protected function get_now_in_wp_timezone() {
		if ( function_exists( 'wp_timezone' ) ) {
			return new DateTime( 'now', wp_timezone() );
		}

		$tz_string = get_option( 'timezone_string' );
		if ( ! empty( $tz_string ) ) {
			return new DateTime( 'now', new DateTimeZone( $tz_string ) );
		}

		return new DateTime( 'now' );
	}

	/**
	 * Today's Y-m-d in WP timezone.
	 *
	 * @return string
	 */
	protected function get_today_ymd_in_wp_timezone() {
		return $this->get_now_in_wp_timezone()->format( 'Y-m-d' );
	}
}
