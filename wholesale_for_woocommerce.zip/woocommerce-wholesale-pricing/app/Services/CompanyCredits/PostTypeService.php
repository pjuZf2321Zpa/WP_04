<?php

namespace WooCommerceWholesalePricing\App\Services\CompanyCredits;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\Init;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Registers company credits post types and admin UI.
 *
 * @extends Init
 */
class PostTypeService extends Init implements ServiceInterface {

	use WholesaleSettings;

	/**
	 * Company post type slug.
	 *
	 * @var string
	 */
	public $slug;

	/**
	 * Credit logs post type slug.
	 *
	 * @var string
	 */
	public $logs_slug;

	/**
	 * Active company list search term (title/email).
	 *
	 * @var string
	 */
	private $company_search_term = '';

	/**
	 * PostTypeService constructor.
	 */
	public function __construct() {
		$this->slug      = wwp_env()->get( 'company_credits_slug' );
		$this->logs_slug = wwp_env()->get( 'company_credit_logs_slug' );

		add_action( 'add_meta_boxes', array( $this, 'meta_boxes' ) );
		add_action( 'save_post_' . $this->slug, array( $this, 'save' ), 10, 2 );
		add_action( 'admin_notices', array( $this, 'company_post_validation' ) );

		add_filter( 'manage_' . $this->slug . '_posts_columns', array( $this, 'company_columns' ) );
		add_action( 'manage_' . $this->slug . '_posts_custom_column', array( $this, 'company_column_values' ), 10, 2 );
		add_filter( 'post_row_actions', array( $this, 'company_row_actions' ), 10, 2 );
		add_filter( 'manage_' . $this->logs_slug . '_posts_columns', array( $this, 'credit_log_columns' ) );
		add_action( 'manage_' . $this->logs_slug . '_posts_custom_column', array( $this, 'credit_log_column_values' ), 10, 2 );
		add_filter( 'post_row_actions', array( $this, 'credit_log_row_actions' ), 10, 2 );
		add_action( 'restrict_manage_posts', array( $this, 'render_company_list_filters' ) );
		add_action( 'pre_get_posts', array( $this, 'filter_companies_query' ) );
		add_action( 'pre_get_posts', array( $this, 'filter_credit_logs_query' ) );
		add_filter( 'posts_join', array( $this, 'company_search_join' ), 10, 2 );
		add_filter( 'posts_where', array( $this, 'company_search_where' ), 10, 2 );
		add_filter( 'posts_distinct', array( $this, 'company_search_distinct' ), 10, 2 );
		add_filter( 'wp_insert_post_data', array( $this, 'require_company_title' ), 10, 2 );
		add_filter( 'enter_title_here', array( $this, 'company_title_placeholder' ), 10, 2 );
		add_action( 'wp_ajax_ccp_search_company_users', array( $this, 'search_company_users' ) );
		add_action( 'before_delete_post', array( $this, 'release_company_users' ) );
		add_action( 'wp_trash_post', array( $this, 'release_company_users' ) );
		add_action( 'untrash_post', array( $this, 'restore_company_users' ) );

		parent::__construct();
	}

	/**
	 * Register post types when module is enabled.
	 *
	 * @return void
	 */
	public function register() {
		$settings = self::get_pricing_settings();

		if ( ! isset( $settings['b2b_company_credits'] ) || 'no' === $settings['b2b_company_credits'] ) {
			return;
		}

		$company_labels = array(
			'name'               => _x( 'Companies', 'Post Type General Name', 'woocommerce-wholesale-pricing' ),
			'singular_name'      => _x( 'Companies', 'Post Type Singular Name', 'woocommerce-wholesale-pricing' ),
			'menu_name'          => __( 'Companies', 'woocommerce-wholesale-pricing' ),
			'parent_item_colon'  => __( 'Parent Company', 'woocommerce-wholesale-pricing' ),
			'all_items'          => __( 'All Company', 'woocommerce-wholesale-pricing' ),
			'view_item'          => __( 'View Company', 'woocommerce-wholesale-pricing' ),
			'add_new_item'       => __( 'Add New Company', 'woocommerce-wholesale-pricing' ),
			'add_new'            => __( 'Add New', 'woocommerce-wholesale-pricing' ),
			'edit_item'          => __( 'Edit Company', 'woocommerce-wholesale-pricing' ),
			'update_item'        => __( 'Update Company', 'woocommerce-wholesale-pricing' ),
			'search_items'       => __( 'Search Company', 'woocommerce-wholesale-pricing' ),
			'not_found'          => __( 'Not Found', 'woocommerce-wholesale-pricing' ),
			'not_found_in_trash' => __( 'Not found in Trash', 'woocommerce-wholesale-pricing' ),
		);

		$company_args = array(
			'label'               => __( 'Company', 'woocommerce-wholesale-pricing' ),
			'description'         => __( 'Company', 'woocommerce-wholesale-pricing' ),
			'labels'              => $company_labels,
			'supports'            => array( 'title' ),
			'hierarchical'        => false,
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => false,
			'show_in_nav_menus'   => false,
			'show_in_admin_bar'   => false,
			'can_export'          => true,
			'has_archive'         => false,
			'exclude_from_search' => false,
			'publicly_queryable'  => false,
			'capability_type'     => 'post',
			'show_in_rest'        => true,
		);

		/**
		 * Filter the company register post type arguments.
		 *
		 * @since 3.4.0
		 *
		 * @param array $company_args The company register post type arguments.
		 */
		register_post_type( $this->slug, apply_filters( 'ccp_company_register_post_type', $company_args ) );

		$logs_labels = array(
			'name'               => _x( 'Credit Logs', 'Post Type General Name', 'woocommerce-wholesale-pricing' ),
			'singular_name'      => _x( 'Credit Logs', 'Post Type Singular Name', 'woocommerce-wholesale-pricing' ),
			'menu_name'          => __( 'Credit Logs', 'woocommerce-wholesale-pricing' ),
			'parent_item_colon'  => __( 'Parent Credit Logs', 'woocommerce-wholesale-pricing' ),
			'all_items'          => __( 'Credit Logs', 'woocommerce-wholesale-pricing' ),
			'view_item'          => __( 'View Credit Logs', 'woocommerce-wholesale-pricing' ),
			'add_new_item'       => __( 'Add New Credit Logs', 'woocommerce-wholesale-pricing' ),
			'add_new'            => __( 'Add New', 'woocommerce-wholesale-pricing' ),
			'edit_item'          => __( 'Edit Credit Logs', 'woocommerce-wholesale-pricing' ),
			'update_item'        => __( 'Update Credit Logs', 'woocommerce-wholesale-pricing' ),
			'search_items'       => __( 'Search Credit Logs', 'woocommerce-wholesale-pricing' ),
			'not_found'          => __( 'Not Found', 'woocommerce-wholesale-pricing' ),
			'not_found_in_trash' => __( 'Not found in Trash', 'woocommerce-wholesale-pricing' ),
		);

		$logs_args = array(
			'label'               => __( 'Credit Logs', 'woocommerce-wholesale-pricing' ),
			'description'         => __( 'Credit Logs', 'woocommerce-wholesale-pricing' ),
			'labels'              => $logs_labels,
			'supports'            => array( 'title' ),
			'hierarchical'        => false,
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => 'tools.php',
			'show_in_nav_menus'   => false,
			'show_in_admin_bar'   => false,
			'can_export'          => false,
			'has_archive'         => false,
			'exclude_from_search' => false,
			'publicly_queryable'  => false,
			'capability_type'     => 'post',
			'capabilities'        => array( 'create_posts' => false ),
			'map_meta_cap'        => true,
			'show_in_rest'        => false,
		);

		/**
		 * Filter the credit logs register post type arguments.
		 *
		 * @since 3.4.0
		 *
		 * @param array $logs_args The credit logs register post type arguments.
		 */
		register_post_type( $this->logs_slug, apply_filters( 'ccp_credit_logs_register_post_type', $logs_args ) );

		$share_cart_labels = array(
			'name'          => _x( 'Shared Carts', 'Post Type General Name', 'woocommerce-wholesale-pricing' ),
			'singular_name' => _x( 'Shared Cart', 'Post Type Singular Name', 'woocommerce-wholesale-pricing' ),
		);

		$share_cart_args = array(
			'label'               => __( 'Shared Cart', 'woocommerce-wholesale-pricing' ),
			'labels'              => $share_cart_labels,
			'supports'            => array( 'title' ),
			'hierarchical'        => false,
			'public'              => false,
			'show_ui'             => false,
			'show_in_menu'        => false,
			'show_in_nav_menus'   => false,
			'show_in_admin_bar'   => false,
			'can_export'          => false,
			'has_archive'         => false,
			'exclude_from_search' => true,
			'publicly_queryable'  => false,
			'capability_type'     => 'post',
			'show_in_rest'        => false,
		);

		/**
		 * Filter the shared cart register post type arguments.
		 *
		 * @since 3.4.0
		 *
		 * @param array $share_cart_args The shared cart register post type arguments.
		 */
		register_post_type( 'ccp_sahre_cart', apply_filters( 'ccp_share_cart_register_post_type', $share_cart_args ) );
	}

	/**
	 * Register company metaboxes.
	 *
	 * @return void
	 */
	public function meta_boxes() {
		if ( ! is_company_credits_enabled() ) {
			return;
		}

		add_meta_box( 'ccp-company-profile', __( 'Company Profile & Wholesale Pricing', 'woocommerce-wholesale-pricing' ), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'company-profile' ) );
		add_meta_box( 'ccp-company-credit-option', __( 'Company Credit Option', 'woocommerce-wholesale-pricing' ), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'company-credit-option' ) );
		add_meta_box( 'ccp-company-users', __( 'Company Users', 'woocommerce-wholesale-pricing' ), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'company-users' ) );
		add_meta_box( 'ccp-credit-limit', __( 'Credit Limit', 'woocommerce-wholesale-pricing' ), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'credit-limit' ) );
		add_meta_box( 'ccp-category-restriction', __( 'Category/Product Restriction', 'woocommerce-wholesale-pricing' ), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'category-product-restriction' ) );
		add_meta_box( 'ccp-credit-requests', __( 'Credit Requests', 'woocommerce-wholesale-pricing' ), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'credit-requests' ) );
		// Side metabox (right column).
		add_meta_box( 'ccp-credit-expiration', __( 'Credits Expiration', 'woocommerce-wholesale-pricing' ), array( $this, 'callback' ), $this->slug, 'side', 'default', array( 'file' => 'credits-expiration' ) );
	}

	/**
	 * Metabox view callback.
	 *
	 * @param \WP_Post $post Current post.
	 * @param array    $args Metabox args.
	 * @return void
	 */
	public function callback( $post, $args ) {
		$post_id = $post->ID;
		wwp_view( 'admin.company-credits.meta-box.' . $args['args']['file'], compact( 'post_id', 'post' ) );
	}

	/**
	 * Companies list table columns.
	 *
	 * @param array $columns Existing columns.
	 * @return array
	 */
	public function company_columns( $columns ) {
		$temp = $columns['date'];
		unset($columns['date']);
		$columns['title']           = __( 'Company Name', 'woocommerce-wholesale-pricing' );
		$columns['email']             = __( 'Email', 'woocommerce-wholesale-pricing' );
		$columns['credits']           = __( 'Credits', 'woocommerce-wholesale-pricing' );
		$columns['users']             = __( 'Users', 'woocommerce-wholesale-pricing' );
		$columns['wholesale_pricing'] = __( 'Wholesaler Pricing', 'woocommerce-wholesale-pricing' );
		$columns['date']           = $temp;

		return $columns;
	}

	/**
	 * Render companies list column values.
	 *
	 * @param string $column Column key.
	 * @param int    $post_id Post ID.
	 * @return void
	 */
	public function company_column_values( $column, $post_id ) {
		switch ( $column ) {
			case 'company_name':
				$edit_link = get_edit_post_link( $post_id );
				echo '<a href="' . esc_url( $edit_link ) . '">' . esc_html( get_the_title( $post_id ) ) . '</a>';
				break;

			case 'email':
				echo esc_html( get_post_meta( $post_id, 'ccp_company_email', true ) );
				break;

			case 'credits':
				$credits   = ccp_company_credits( $post_id );
				$available = isset( $credits['remaining'] ) ? $credits['remaining'] : 0;
				$total     = isset( $credits['credit'] ) ? $credits['credit'] : 0;
				echo '<span class="wwp-ccp-badge wwp-ccp-badge--active">' . esc_html( $available . ' / ' . $total ) . '</span>';
				break;

			case 'users':
				echo esc_html( wwp_ccp_count_company_users( $post_id ) );
				break;

			case 'wholesale_pricing':
				$role_id = get_post_meta( $post_id, 'ccp_wholesale_role_id', true );
				if ( ! empty( $role_id ) ) {
					$term = get_term( absint( $role_id ), 'wholesale_user_roles' );
					if ( $term && ! is_wp_error( $term ) ) {
						echo esc_html( $term->name );
					}
				}
				break;
		}
	}

	/**
	 * Hide default row actions on companies list.
	 *
	 * @param array   $actions Row actions.
	 * @param \WP_Post $post Post object.
	 * @return array
	 */
	public function company_row_actions( $actions, $post ) {
		if ( $this->slug === $post->post_type ) {
			unset( $actions['view'] );
		}

		return $actions;
	}

	/**
	 * Credit logs list table columns.
	 *
	 * @param array $columns Existing columns.
	 * @return array
	 */
	public function credit_log_columns( $columns ) {
		unset( $columns['author'], $columns['title'], $columns['date'] );

		$columns['serial_number'] = __( 'S.NO', 'woocommerce-wholesale-pricing' );
		$columns['company']       = __( 'Company', 'woocommerce-wholesale-pricing' );
		$columns['order_id']      = __( 'Order #', 'woocommerce-wholesale-pricing' );
		$columns['user_email']    = __( 'User Email', 'woocommerce-wholesale-pricing' );
		$columns['amount']        = __( 'Amount', 'woocommerce-wholesale-pricing' );
		$columns['event']         = __( 'Event', 'woocommerce-wholesale-pricing' );
		$columns['created']       = __( 'Created On', 'woocommerce-wholesale-pricing' );

		/**
		 * Filter the credit logs list table columns.
		 *
		 * @since 3.4.0
		 *
		 * @param array $columns The columns array.
		 */
		return apply_filters( 'ccp_credit_logs_posts_columns', $columns );
	}

	/**
	 * Render credit log column values.
	 *
	 * @param string $column Column key.
	 * @param int    $post_id Post ID.
	 * @return void
	 */
	public function credit_log_column_values( $column, $post_id ) {
		switch ( $column ) {
			case 'serial_number':
				echo esc_html( $post_id );
				break;

			case 'company':
				$company_id   = get_post_meta( $post_id, 'company_id', true );
				$company_data = get_post( $company_id );
				if ( ! empty( $company_id ) && ! empty( $company_data->post_title ) ) {
					echo '<a target="_blank" href="' . esc_url( admin_url( 'post.php?post=' . $company_id . '&action=edit' ) ) . '">' . esc_html( $company_data->post_title ) . '</a>';
				} else {
					echo '-';
				}
				break;

			case 'order_id':
				$order_id = get_post_meta( $post_id, 'order_id', true );
				if ( ! empty( $order_id ) ) {
					echo '<a target="_blank" href="' . esc_url( admin_url( 'post.php?post=' . $order_id . '&action=edit' ) ) . '">#' . esc_html( $order_id ) . '</a>';
				} else {
					echo '<span class="wwp-ccp-empty">—</span>';
				}
				break;

			case 'user_email':
				echo esc_html( get_post_meta( $post_id, 'user_email', true ) );
				break;

			case 'amount':
				$amount = get_post_meta( $post_id, 'amount', true );
				if ( '' !== $amount && null !== $amount ) {
					$amount  = round( (float) $amount, 2 );
					$class   = ( $amount > 0 ) ? 'wwp-ccp-amount--positive' : 'wwp-ccp-amount--negative';
					$prefix  = ( $amount > 0 ) ? '+' : '';
					echo '<span class="' . esc_attr( $class ) . '">' . esc_html( $prefix . $amount ) . '</span>';
				}
				break;

			case 'event':
				echo esc_html( get_post_meta( $post_id, 'event', true ) );
				break;

			case 'created':
				$created = get_post( $post_id );
				if ( $created ) {
					echo esc_html( date_i18n( 'Y-m-d H:i:s', strtotime( $created->post_date_gmt ) ) );
				}
				break;
		}

		/**
		 * Action to add custom column values to credit logs list.
		 *
		 * @since 3.4.0
		 *
		 * @param string $column Column key.
		 * @param int $post_id Post ID.
		 */
		do_action( 'ccp_credit_logs_posts_custom_column', $column, $post_id );
	}

	/**
	 * Remove row actions from credit logs list.
	 *
	 * @param array   $actions Row actions.
	 * @param \WP_Post $post Post object.
	 * @return array
	 */
	public function credit_log_row_actions( $actions, $post ) {
		if ( $this->logs_slug === $post->post_type ) {
			unset( $actions['view'], $actions['edit'], $actions['inline hide-if-no-js'] );
		}

		return $actions;
	}

	/**
	 * Render wholesale role filter on companies list table.
	 *
	 * @param string $post_type Current post type.
	 * @return void
	 */
	public function render_company_list_filters( $post_type ) {
		if ( $this->slug !== $post_type ) {
			return;
		}

		$view = WWP_PLUGIN_PATH . 'resources/views/admin/company-credits/list-filters.php';
		if ( file_exists( $view ) ) {
			include $view;
		}
	}

	/**
	 * Filter companies by wholesale role and prepare title/email search.
	 *
	 * @param \WP_Query $query Query object.
	 * @return void
	 */
	public function filter_companies_query( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() ) {
			return;
		}

		if ( $this->slug !== $this->get_admin_query_post_type( $query ) ) {
			return;
		}

		$get     = ccp_get_data();
		$role_id = isset( $get['ccp_wholesale_role_id'] ) ? absint( $get['ccp_wholesale_role_id'] ) : 0;
		if ( ! empty( $role_id ) ) {
			$meta_query = $query->get( 'meta_query' );
			if ( ! is_array( $meta_query ) ) {
				$meta_query = array();
			}

			$meta_query[] = array(
				'key'     => 'ccp_wholesale_role_id',
				'value'   => $role_id,
				'compare' => '=',
			);

			$query->set( 'meta_query', $meta_query );
		}

		// Capture search term, then disable core `s` handling so we can OR title + email.
		$search = $query->get( 's' );
		if ( ! is_string( $search ) || '' === trim( $search ) ) {
			$search = isset( $get['s'] ) ? (string) $get['s'] : '';
		}

		$search = trim( $search );
		if ( '' === $search ) {
			$this->company_search_term = '';
			return;
		}

		$this->company_search_term = $search;
		$query->set( 's', '' );
	}

	/**
	 * Resolve post type for an admin query (query var, typenow, or request).
	 *
	 * @param \WP_Query $query Query object.
	 * @return string
	 */
	private function get_admin_query_post_type( $query ) {
		$post_type = $query instanceof \WP_Query ? $query->get( 'post_type' ) : '';

		if ( is_array( $post_type ) ) {
			$post_type = reset( $post_type );
		}

		if ( empty( $post_type ) && ! empty( $GLOBALS['typenow'] ) ) {
			$post_type = $GLOBALS['typenow'];
		}

		if ( empty( $post_type ) && isset( $_GET['post_type'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$post_type = sanitize_key( wp_unslash( $_GET['post_type'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		return is_string( $post_type ) ? $post_type : '';
	}

	/**
	 * Whether custom company title/email search should apply to this query.
	 *
	 * @param \WP_Query $query Query object.
	 * @return bool
	 */
	private function is_company_admin_search( $query ) {
		if ( ! is_admin() || ! $query instanceof \WP_Query || ! $query->is_main_query() ) {
			return false;
		}

		if ( $this->slug !== $this->get_admin_query_post_type( $query ) ) {
			return false;
		}

		return '' !== $this->company_search_term;
	}

	/**
	 * Join company email meta for admin list search.
	 *
	 * @param string    $join  Join SQL.
	 * @param \WP_Query $query Query object.
	 * @return string
	 */
	public function company_search_join( $join, $query ) {
		global $wpdb;

		if ( ! $this->is_company_admin_search( $query ) ) {
			return $join;
		}

		if ( false !== strpos( $join, 'ccp_email_search' ) ) {
			return $join;
		}

		$join .= " LEFT JOIN {$wpdb->postmeta} AS ccp_email_search ON ({$wpdb->posts}.ID = ccp_email_search.post_id AND ccp_email_search.meta_key = 'ccp_company_email') ";

		return $join;
	}

	/**
	 * Match company title or email in admin list search.
	 *
	 * @param string    $where Where SQL.
	 * @param \WP_Query $query Query object.
	 * @return string
	 */
	public function company_search_where( $where, $query ) {
		global $wpdb;

		if ( ! $this->is_company_admin_search( $query ) ) {
			return $where;
		}

		$like = '%' . $wpdb->esc_like( $this->company_search_term ) . '%';

		$where .= $wpdb->prepare(
			" AND (
				({$wpdb->posts}.post_title LIKE %s)
				OR (ccp_email_search.meta_value LIKE %s)
			)",
			$like,
			$like
		);

		return $where;
	}

	/**
	 * Avoid duplicate rows when joining email meta for search.
	 *
	 * @param string    $distinct Distinct SQL.
	 * @param \WP_Query $query    Query object.
	 * @return string
	 */
	public function company_search_distinct( $distinct, $query ) {
		if ( $this->is_company_admin_search( $query ) ) {
			return 'DISTINCT';
		}

		return $distinct;
	}

	/**
	 * Require a non-empty company title for non-auto-draft saves.
	 *
	 * @param array $data    Post data.
	 * @param array $postarr Raw post array.
	 * @return array
	 */
	public function require_company_title( $data, $postarr ) {
		if ( empty( $data['post_type'] ) || $this->slug !== $data['post_type'] ) {
			return $data;
		}

		$status = isset( $data['post_status'] ) ? $data['post_status'] : '';
		if ( in_array( $status, array( 'auto-draft', 'trash' ), true ) ) {
			return $data;
		}

		if ( '' !== trim( (string) $data['post_title'] ) ) {
			return $data;
		}

		$data['post_status'] = 'draft';

		$post_id = ! empty( $postarr['ID'] ) ? absint( $postarr['ID'] ) : 0;
		$message = __( 'Company name is required.', 'woocommerce-wholesale-pricing' );

		if ( $post_id ) {
			set_transient( 'ccp_company_post_validation_' . $post_id, $message, 60 );
		} else {
			set_transient( 'ccp_company_post_validation_user_' . get_current_user_id(), $message, 60 );
		}

		return $data;
	}

	/**
	 * Placeholder text for the company title field.
	 *
	 * @param string   $title Placeholder.
	 * @param \WP_Post $post  Post object.
	 * @return string
	 */
	public function company_title_placeholder( $title, $post ) {
		if ( $post instanceof \WP_Post && $this->slug === $post->post_type ) {
			return __( 'Add company name', 'woocommerce-wholesale-pricing' );
		}

		return $title;
	}

	/**
	 * Filter credit logs by company ID query arg.
	 *
	 * @param \WP_Query $query Query object.
	 * @return void
	 */
	public function filter_credit_logs_query( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() ) {
			return;
		}

		if ( $this->logs_slug !== $query->get( 'post_type' ) ) {
			return;
		}

		$get = ccp_get_data();
		if ( isset( $get['company_id'] ) && ! empty( $get['company_id'] ) ) {
			$meta_query = array(
				array(
					'key'     => 'company_id',
					'value'   => absint( $get['company_id'] ),
					'compare' => '==',
				),
			);
			$query->set( 'meta_query', $meta_query );
		}

		$query->set( 'orderby', 'ID' );
		$query->set( 'order', 'DESC' );
	}

	/**
	 * AJAX: search users not already assigned to any company.
	 *
	 * @return void
	 */
	public function search_company_users() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json( array() );
		}

		$term = isset( $_GET['term'] ) ? sanitize_text_field( wp_unslash( $_GET['term'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( '' === $term ) {
			wp_send_json( array() );
		}

		$current_company_id = isset( $_GET['post_ID'] ) ? absint( wp_unslash( $_GET['post_ID'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$query = new \WP_User_Query(
			array(
				'search'         => '*' . $term . '*',
				'search_columns' => array( 'user_login', 'user_nicename', 'user_email', 'display_name' ),
				'number'         => 50,
				'orderby'        => 'display_name',
				'order'          => 'ASC',
			)
		);

		$found = array();
		foreach ( (array) $query->get_results() as $user ) {
			if ( ! $user instanceof \WP_User ) {
				continue;
			}

			if ( $this->user_belongs_to_other_company( $user->ID, $current_company_id ) ) {
				continue;
			}

			$found[ $user->ID ] = sprintf(
				'%1$s (#%2$s – %3$s)',
				$user->display_name,
				absint( $user->ID ),
				$user->user_email
			);
		}

		wp_send_json( $found );
	}

	/**
	 * Keep each user in a single role and drop users already on another company.
	 *
	 * @param array $owners    Posted owner IDs.
	 * @param array $managers  Posted manager IDs.
	 * @param array $members   Posted member IDs.
	 * @param int   $company_id Current company post ID.
	 * @return array{owners:array,managers:array,members:array,notice:string}
	 */
	private function sanitize_unique_company_role_lists( $owners, $managers, $members, $company_id ) {
		$owners   = array_values( array_unique( array_filter( array_map( 'absint', (array) $owners ) ) ) );
		$managers = array_values( array_unique( array_filter( array_map( 'absint', (array) $managers ) ) ) );
		$members  = array_values( array_unique( array_filter( array_map( 'absint', (array) $members ) ) ) );
		$company_id = absint( $company_id );

		$keep_owners   = array();
		$keep_managers = array();
		$keep_members  = array();
		$claimed       = array();
		$other_company = array();
		$duplicates    = array();

		foreach ( $owners as $user_id ) {
			if ( $this->user_belongs_to_other_company( $user_id, $company_id ) ) {
				$other_company[] = $this->format_company_user_label( $user_id );
				continue;
			}
			$claimed[ $user_id ] = 'owner';
			$keep_owners[]       = $user_id;
		}

		foreach ( $managers as $user_id ) {
			if ( $this->user_belongs_to_other_company( $user_id, $company_id ) ) {
				$other_company[] = $this->format_company_user_label( $user_id );
				continue;
			}
			if ( isset( $claimed[ $user_id ] ) ) {
				$duplicates[] = $this->format_company_user_label( $user_id );
				continue;
			}
			$claimed[ $user_id ] = 'manager';
			$keep_managers[]     = $user_id;
		}

		foreach ( $members as $user_id ) {
			if ( $this->user_belongs_to_other_company( $user_id, $company_id ) ) {
				$other_company[] = $this->format_company_user_label( $user_id );
				continue;
			}
			if ( isset( $claimed[ $user_id ] ) ) {
				$duplicates[] = $this->format_company_user_label( $user_id );
				continue;
			}
			$claimed[ $user_id ] = 'member';
			$keep_members[]      = $user_id;
		}

		$parts = array();
		$other_company = array_values( array_unique( array_filter( $other_company ) ) );
		$duplicates    = array_values( array_unique( array_filter( $duplicates ) ) );

		if ( ! empty( $other_company ) ) {
			$parts[] = sprintf(
				/* translators: %s: comma-separated user labels */
				__( 'Skipped users already assigned to another company: %s.', 'woocommerce-wholesale-pricing' ),
				implode( ', ', $other_company )
			);
		}

		if ( ! empty( $duplicates ) ) {
			$parts[] = sprintf(
				/* translators: %s: comma-separated user labels */
				__( 'Each user can have only one company role. Kept the highest role (Owner, then Manager, then Member) for: %s.', 'woocommerce-wholesale-pricing' ),
				implode( ', ', $duplicates )
			);
		}

		return array(
			'owners'   => $keep_owners,
			'managers' => $keep_managers,
			'members'  => $keep_members,
			'notice'   => implode( ' ', $parts ),
		);
	}

	/**
	 * Whether a user is already assigned to a different company.
	 *
	 * @param int $user_id    User ID.
	 * @param int $company_id Current company post ID.
	 * @return bool
	 */
	private function user_belongs_to_other_company( $user_id, $company_id ) {
		$assigned = absint( get_user_meta( absint( $user_id ), 'ccp_company_id', true ) );
		if ( empty( $assigned ) || absint( $company_id ) === $assigned ) {
			return false;
		}

		return function_exists( 'ccp_is_active_company' ) ? ccp_is_active_company( $assigned ) : true;
	}

	/**
	 * Display label for a company user in admin notices.
	 *
	 * @param int $user_id User ID.
	 * @return string
	 */
	private function format_company_user_label( $user_id ) {
		$user = get_user_by( 'id', absint( $user_id ) );
		if ( ! $user ) {
			return '#' . absint( $user_id );
		}

		return sprintf( '%s (%s)', $user->display_name, $user->user_email );
	}

	/**
	 * Save company metabox data.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post Post object.
	 * @return void
	 */
	public function save( $post_id, $post ) {
		unset( $post );

		$request = ccp_post_data();
		if ( ! isset( $request['global_notice_nonce'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( $request['global_notice_nonce'], 'global_notice_nonce' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		$ccp_credit_assign          = isset( $request['ccp_credit_assign'] ) ? sanitize_text_field( $request['ccp_credit_assign'] ) : '';
		$ccp_company_email          = isset( $request['ccp_company_email'] ) ? sanitize_text_field( $request['ccp_company_email'] ) : '';

		$ccp_company_users_owner    = isset( $request['ccp_company_users_owner'] ) ? array_map( 'absint', (array) wc_clean( $request['ccp_company_users_owner'] ) ) : array();
		$ccp_company_users_manager  = isset( $request['ccp_company_users_manager'] ) ? array_map( 'absint', (array) wc_clean( $request['ccp_company_users_manager'] ) ) : array();
		$ccp_company_users_member   = isset( $request['ccp_company_users_member'] ) ? array_map( 'absint', (array) wc_clean( $request['ccp_company_users_member'] ) ) : array();
		$unique_company_users       = $this->sanitize_unique_company_role_lists( $ccp_company_users_owner, $ccp_company_users_manager, $ccp_company_users_member, $post_id );
		$ccp_company_users_owner    = $unique_company_users['owners'];
		$ccp_company_users_manager  = $unique_company_users['managers'];
		$ccp_company_users_member   = $unique_company_users['members'];
		$unique_users_notice        = $unique_company_users['notice'];
		$ccp_wholesale_role_id      = isset( $request['ccp_wholesale_role_id'] ) ? absint( $request['ccp_wholesale_role_id'] ) : 0;
		$ccp_bulk_credit_limit      = isset( $request['ccp_bulk_credit_limit'] ) ? sanitize_text_field( $request['ccp_bulk_credit_limit'] ) : '';
		$ccp_user_credit_limits_raw = isset( $request['ccp_user_credit_limits'] ) ? wc_clean( $request['ccp_user_credit_limits'] ) : array();
		$unlocked_user_ids          = isset( $request['ccp_user_credit_limits_unlock'] ) ? array_map( 'absint', (array) wc_clean( $request['ccp_user_credit_limits_unlock'] ) ) : array();
		$apply_bulk_to_all          = ! empty( $request['ccp_apply_bulk_credit_limit'] );
		$ccp_restriction_type       = isset( $request['ccp_restriction_type'] ) ? sanitize_text_field( $request['ccp_restriction_type'] ) : 'all_products';
		$ccp_restricted_products    = isset( $request['ccp_restricted_products'] ) ? array_map( 'absint', (array) wc_clean( $request['ccp_restricted_products'] ) ) : array();
		$ccp_restricted_categories  = isset( $request['ccp_restricted_categories'] ) ? ccp_sanitize_restricted_categories( (array) wc_clean( $request['ccp_restricted_categories'] ) ) : array();
		$ccp_company_approved_orders = isset( $request['ccp_company_approved_orders'] ) ? 'yes' : 'no';
		$ccp_manager_approval       = ( 'yes' === $ccp_company_approved_orders && isset( $request['ccp_manager_approval'] ) ) ? 'yes' : 'no';
		$ccp_credit_expiration_enabled = isset( $request['ccp_credit_expiration_enabled'] ) ? 'yes' : 'no';
		$ccp_credit_expiration_mode    = isset( $request['ccp_credit_expiration_mode'] ) ? sanitize_text_field( $request['ccp_credit_expiration_mode'] ) : 'monthly';
		$ccp_credit_expiration_month   = isset( $request['ccp_credit_expiration_month'] ) ? absint( $request['ccp_credit_expiration_month'] ) : 1;
		$ccp_credit_expiration_day     = isset( $request['ccp_credit_expiration_day'] ) ? absint( $request['ccp_credit_expiration_day'] ) : 1;
		$ccp_credit_expiration_starting_balance_raw = isset( $request['ccp_credit_expiration_starting_balance'] ) ? wc_clean( $request['ccp_credit_expiration_starting_balance'] ) : '';
		$ccp_credit_expiration_starting_balance     = is_numeric( $ccp_credit_expiration_starting_balance_raw ) ? (float) $ccp_credit_expiration_starting_balance_raw : 0.0;
		$all_company_users          = array_unique(
			array_filter(
				array_merge( $ccp_company_users_owner, $ccp_company_users_manager, $ccp_company_users_member )
			)
		);

		$previous_bulk_limit = get_post_meta( $post_id, 'ccp_bulk_credit_limit', true );
		$previous_bulk_limit = is_scalar( $previous_bulk_limit ) ? sanitize_text_field( $previous_bulk_limit ) : '';
		$existing_user_limits = get_post_meta( $post_id, 'ccp_user_credit_limits', true );
		if ( ! is_array( $existing_user_limits ) ) {
			$existing_user_limits = array();
		}

		$old_owners   = get_post_meta( $post_id, 'ccp_company_users_owner', true );
		$old_managers = get_post_meta( $post_id, 'ccp_company_users_manager', true );
		$old_members  = get_post_meta( $post_id, 'ccp_company_users_member', true );
		$previous_assigned_users = array_unique(
			array_filter(
				array_merge(
					is_array( $old_owners ) ? array_map( 'absint', $old_owners ) : array(),
					is_array( $old_managers ) ? array_map( 'absint', $old_managers ) : array(),
					is_array( $old_members ) ? array_map( 'absint', $old_members ) : array()
				)
			)
		);

		// Keep existing bulk when the field is submitted empty (avoid accidental wipe).
		if ( '' === $ccp_bulk_credit_limit && '' !== $previous_bulk_limit ) {
			$ccp_bulk_credit_limit = $previous_bulk_limit;
		}

		// Snapshot previous effective limits before meta changes (used for wallet delta sync).
		$previous_effective_limits = array();
		foreach ( $all_company_users as $user_id ) {
			$previous_effective_limits[ $user_id ] = round( (float) ccp_get_effective_user_credit_limit( $post_id, $user_id ), 2 );
		}

		$unlocked_user_ids = array_values(
			array_unique(
				array_intersect(
					array_filter( $unlocked_user_ids ),
					array_map( 'absint', $all_company_users )
				)
			)
		);

		$bulk_changed = (string) wc_format_decimal( (float) $ccp_bulk_credit_limit, 2 ) !== (string) wc_format_decimal( (float) $previous_bulk_limit, 2 )
			&& ( '' !== $ccp_bulk_credit_limit || '' !== $previous_bulk_limit );

		$merged_user_limits = $existing_user_limits;

		if ( $apply_bulk_to_all && '' !== $ccp_bulk_credit_limit ) {
			$merged_user_limits = array();
			foreach ( $all_company_users as $user_id ) {
				$merged_user_limits[ absint( $user_id ) ] = $ccp_bulk_credit_limit;
			}
		} else {
			foreach ( $unlocked_user_ids as $user_id ) {
				$posted_limit = ccp_get_stored_user_credit_limit( $ccp_user_credit_limits_raw, $user_id );
				$merged_user_limits[ $user_id ] = null !== $posted_limit ? $posted_limit : '0';
			}

			// Changing bulk must not rewrite locked members' effective limits or remaining balances.
			if ( $bulk_changed ) {
				foreach ( $all_company_users as $user_id ) {
					$user_id = absint( $user_id );
					if ( empty( $user_id ) || in_array( $user_id, $unlocked_user_ids, true ) ) {
						continue;
					}
					if ( isset( $previous_effective_limits[ $user_id ] ) ) {
						$merged_user_limits[ $user_id ] = wc_format_decimal( $previous_effective_limits[ $user_id ], 2 );
					}
				}
			}
		}

		$ccp_user_credit_limits = ccp_normalize_user_credit_limit_overrides( $merged_user_limits, $ccp_bulk_credit_limit );

		if ( 'yes' === $ccp_credit_expiration_enabled ) {
			if ( ! in_array( $ccp_credit_expiration_mode, array( 'monthly', 'yearly' ), true ) ) {
				set_transient(
					'ccp_company_post_validation_' . $post_id,
					__( 'Credits Expiration: invalid recurrence mode.', 'woocommerce-wholesale-pricing' ),
					60
				);
				return;
			}

			if ( 'yearly' === $ccp_credit_expiration_mode && ( $ccp_credit_expiration_month < 1 || $ccp_credit_expiration_month > 12 ) ) {
				set_transient(
					'ccp_company_post_validation_' . $post_id,
					__( 'Credits Expiration: month is required and must be between 1 and 12 for yearly mode.', 'woocommerce-wholesale-pricing' ),
					60
				);
				return;
			}

			if ( $ccp_credit_expiration_day < 1 || $ccp_credit_expiration_day > 31 ) {
				set_transient(
					'ccp_company_post_validation_' . $post_id,
					__( 'Credits Expiration: day of month must be between 1 and 31.', 'woocommerce-wholesale-pricing' ),
					60
				);
				return;
			}

			if ( '' === $ccp_credit_expiration_starting_balance_raw || ! is_numeric( $ccp_credit_expiration_starting_balance_raw ) ) {
				set_transient(
					'ccp_company_post_validation_' . $post_id,
					__( 'Credits Expiration: starting balance must be a valid number.', 'woocommerce-wholesale-pricing' ),
					60
				);
				return;
			}

			if ( $ccp_credit_expiration_starting_balance < 0 ) {
				set_transient(
					'ccp_company_post_validation_' . $post_id,
					__( 'Credits Expiration: starting balance must be >= 0.', 'woocommerce-wholesale-pricing' ),
					60
				);
				return;
			}
		}

		$company                  = ccp_company_credits( $post_id );
		$current_company_balance  = isset( $company['remaining'] ) ? (float) $company['remaining'] : 0.0;
		$credit_assign_amount     = is_numeric( $ccp_credit_assign ) ? (float) $ccp_credit_assign : 0.0;
		$available_after_adjust   = round( $current_company_balance + $credit_assign_amount, 2 );
		$total_requested_limits   = $this->calculate_total_requested_limits( $all_company_users, $ccp_user_credit_limits, $ccp_bulk_credit_limit );
		$previous_total_limits    = round( array_sum( $previous_effective_limits ), 2 );
		$limits_increase          = round( max( 0, $total_requested_limits - $previous_total_limits ), 2 );

		if ( $available_after_adjust < 0 ) {
			$error_msg = 'Failed! Your Available Credit: ' . $current_company_balance;
			set_transient( 'ccp_company_post_validation_' . $post_id, $error_msg, 60 );
			return;
		}

		// Only the increase in aggregate user limits must be covered by company available credit.
		// Comparing the full sum blocked bulk updates on active companies (e.g. 8 x 300 = 2400).
		if ( $limits_increase > $available_after_adjust ) {
			$error_msg = sprintf(
				/* translators: 1: increase in user credit limits, 2: available company balance */
				__( 'Failed! Increasing user credit limits by %1$s exceeds available company balance (%2$s). Add company credit first, then try again.', 'woocommerce-wholesale-pricing' ),
				wc_format_decimal( $limits_increase, 2 ),
				wc_format_decimal( $available_after_adjust, 2 )
			);
			set_transient( 'ccp_company_post_validation_' . $post_id, $error_msg, 60 );
			return;
		}

		update_post_meta( $post_id, 'ccp_company_email', $ccp_company_email );
		update_post_meta( $post_id, 'ccp_credit_assign', $ccp_credit_assign );
		update_post_meta( $post_id, 'ccp_wholesale_role_id', $ccp_wholesale_role_id );
		update_post_meta( $post_id, 'ccp_bulk_credit_limit', $ccp_bulk_credit_limit );
		update_post_meta( $post_id, 'ccp_user_credit_limits', $ccp_user_credit_limits );
		update_post_meta( $post_id, 'ccp_restriction_type', $ccp_restriction_type );
		update_post_meta( $post_id, 'ccp_restricted_products', $ccp_restricted_products );
		update_post_meta( $post_id, 'ccp_restricted_categories', $ccp_restricted_categories );
		update_post_meta( $post_id, 'ccp_company_approved_orders', $ccp_company_approved_orders );
		update_post_meta( $post_id, 'ccp_manager_approval', $ccp_manager_approval );
		update_post_meta( $post_id, 'ccp_credit_expiration_enabled', 'yes' === $ccp_credit_expiration_enabled ? 'yes' : 'no' );
		update_post_meta( $post_id, 'ccp_credit_expiration_mode', in_array( $ccp_credit_expiration_mode, array( 'monthly', 'yearly' ), true ) ? $ccp_credit_expiration_mode : 'monthly' );
		update_post_meta( $post_id, 'ccp_credit_expiration_month', absint( $ccp_credit_expiration_month ) );
		update_post_meta( $post_id, 'ccp_credit_expiration_day', absint( $ccp_credit_expiration_day ) );
		update_post_meta( $post_id, 'ccp_credit_expiration_starting_balance', round( (float) $ccp_credit_expiration_starting_balance, 2 ) );

		$old_owners   = is_array( $old_owners ) ? $old_owners : array();
		$old_managers = is_array( $old_managers ) ? $old_managers : array();
		$old_members  = is_array( $old_members ) ? $old_members : array();

		$this->clear_company_user_assignments( $old_owners, $post_id );
		$this->clear_company_user_assignments( $old_managers, $post_id );
		$this->clear_company_user_assignments( $old_members, $post_id );

		update_post_meta( $post_id, 'ccp_company_users_owner', $ccp_company_users_owner );
		update_post_meta( $post_id, 'ccp_company_users_manager', $ccp_company_users_manager );
		update_post_meta( $post_id, 'ccp_company_users_member', $ccp_company_users_member );

		$this->assign_company_users( $ccp_company_users_owner, 'ccp_owner', $post_id );
		$this->assign_company_users( $ccp_company_users_manager, 'ccp_manager', $post_id );
		$this->assign_company_users( $ccp_company_users_member, 'ccp_member', $post_id );

		if ( ! empty( $unique_users_notice ) ) {
			set_transient( 'ccp_company_post_validation_' . $post_id, $unique_users_notice, 60 );
		}

		$new_company_users = array_values(
			array_diff(
				array_map( 'absint', $all_company_users ),
				$previous_assigned_users
			)
		);

		if ( $apply_bulk_to_all && '' !== $ccp_bulk_credit_limit ) {
			$wallet_sync_users = array_map( 'absint', $all_company_users );
			$force_wallet_users = $wallet_sync_users;
		} else {
			$wallet_sync_users  = array_unique( array_merge( $unlocked_user_ids, $new_company_users ) );
			$force_wallet_users = $new_company_users;
		}

		$this->sync_company_user_wallets(
			$post_id,
			$wallet_sync_users,
			$previous_effective_limits,
			$force_wallet_users
		);

		if ( 0.0 !== $credit_assign_amount ) {
			ccp_add_company_credit(
				array(
					'company_id' => $post_id,
					'order_id'   => '',
					'amount'     => $credit_assign_amount,
					'event'      => __( 'Company Credit Added', 'woocommerce-wholesale-pricing' ),
				)
			);
		}

		// Mirror wallet top-ups from higher limits into the company pool.
		if ( $limits_increase > 0 ) {
			ccp_add_company_credit(
				array(
					'company_id' => $post_id,
					'order_id'   => '',
					'amount'     => -1 * $limits_increase,
					'event'      => __( 'Credit Allocated via User Limits', 'woocommerce-wholesale-pricing' ),
				)
			);
		}
	}

	/**
	 * Sync selected users' spendable wallets to their configured credit limits.
	 *
	 * Existing members are updated only when their limit actually changed.
	 * Newly assigned users always receive a wallet matching their limit.
	 *
	 * @param int   $company_id      Company post ID.
	 * @param array $user_ids        Company user IDs to consider.
	 * @param array $previous_limits Previous effective limits keyed by user ID.
	 * @param array $force_user_ids  User IDs that must be seeded even if the limit is unchanged.
	 * @return void
	 */
	private function sync_company_user_wallets( $company_id, $user_ids, $previous_limits = array(), $force_user_ids = array() ) {
		if ( ! function_exists( 'ccp_get_effective_user_credit_limit' ) ) {
			return;
		}

		$user_ids       = array_unique( array_filter( array_map( 'absint', (array) $user_ids ) ) );
		$force_user_ids = array_unique( array_filter( array_map( 'absint', (array) $force_user_ids ) ) );
		if ( empty( $user_ids ) ) {
			return;
		}

		if ( function_exists( 'ccp_maybe_migrate_company_wallets' ) ) {
			ccp_maybe_migrate_company_wallets( $company_id );
		}

		$wallets = get_post_meta( $company_id, 'ccp_user_wallet_balances', true );
		if ( ! is_array( $wallets ) ) {
			$wallets = array();
		}

		$changed = false;
		foreach ( $user_ids as $user_id ) {
			$new_limit = round( (float) ccp_get_effective_user_credit_limit( $company_id, $user_id ), 2 );
			$old_limit = isset( $previous_limits[ $user_id ] ) ? round( (float) $previous_limits[ $user_id ], 2 ) : null;
			$force     = in_array( $user_id, $force_user_ids, true );

			if ( ! $force && null !== $old_limit && abs( $new_limit - $old_limit ) < 0.00001 ) {
				continue;
			}

			$wallets[ $user_id ] = $new_limit;
			$changed             = true;
		}

		if ( $changed ) {
			update_post_meta( $company_id, 'ccp_user_wallet_balances', $wallets );
		}
	}

	/**
	 * Sum requested effective credit limits for company users.
	 *
	 * @param array  $user_ids     Company user IDs.
	 * @param array  $user_limits  Posted user overrides.
	 * @param string $bulk_limit   Posted bulk limit.
	 * @return float
	 */
	private function calculate_total_requested_limits( $user_ids, $user_limits, $bulk_limit ) {
		$total      = 0.0;
		$bulk_limit = is_numeric( $bulk_limit ) ? (float) $bulk_limit : 0.0;

		foreach ( (array) $user_ids as $user_id ) {
			$user_id = absint( $user_id );
			if ( empty( $user_id ) ) {
				continue;
			}

			$override = ccp_get_stored_user_credit_limit( $user_limits, $user_id );
			$limit    = null !== $override && is_numeric( $override ) ? (float) $override : $bulk_limit;
			$total   += max( 0, $limit );
		}

		return round( $total, 2 );
	}

	/**
	 * Clear user company assignment meta and remove from company lists.
	 *
	 * @param array $user_ids User IDs.
	 * @param int   $company_id Company post ID.
	 * @return void
	 */
	private function clear_company_user_assignments( $user_ids, $company_id ) {
		if ( empty( $user_ids ) || ! is_array( $user_ids ) ) {
			return;
		}

		foreach ( $user_ids as $user_id ) {
			$user_id = absint( $user_id );
			if ( empty( $user_id ) ) {
				continue;
			}

			ccp_remove_user_from_company_lists( $user_id, $company_id );
			ccp_clear_user_company_assignment( $user_id );
		}
	}

	/**
	 * Assign users to a company with a role.
	 *
	 * @param array  $user_ids User IDs.
	 * @param string $role Company role slug.
	 * @param int    $post_id Company post ID.
	 * @return void
	 */
	private function assign_company_users( $user_ids, $role, $post_id ) {
		if ( empty( $user_ids ) || ! is_array( $user_ids ) ) {
			return;
		}

		foreach ( $user_ids as $user_id ) {
			$user_id = absint( $user_id );
			if ( empty( $user_id ) ) {
				continue;
			}

			$previous_company_id = absint( get_user_meta( $user_id, 'ccp_company_id', true ) );
			if ( $this->user_belongs_to_other_company( $user_id, $post_id ) ) {
				continue;
			}
			if ( ! empty( $previous_company_id ) && absint( $post_id ) !== $previous_company_id ) {
				ccp_clear_user_company_assignment( $user_id );
			}

			update_user_meta( $user_id, 'ccp_company_role', $role );
			update_user_meta( $user_id, 'ccp_company_id', $post_id );
			ccp_assign_user_to_company_lists( $user_id, $post_id, $role );
		}
	}

	/**
	 * Collect owner, manager, and member IDs stored on a company.
	 *
	 * @param int $company_id Company post ID.
	 * @return int[]
	 */
	private function get_company_assigned_user_ids( $company_id ) {
		$user_ids = array();
		foreach ( array( 'ccp_company_users_owner', 'ccp_company_users_manager', 'ccp_company_users_member' ) as $meta_key ) {
			$ids = get_post_meta( $company_id, $meta_key, true );
			if ( is_array( $ids ) ) {
				$user_ids = array_merge( $user_ids, $ids );
			}
		}

		return array_values( array_unique( array_filter( array_map( 'absint', $user_ids ) ) ) );
	}

	/**
	 * Release users when a company is trashed or deleted so they can be assigned again.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public function release_company_users( $post_id ) {
		$post_id = absint( $post_id );
		if ( empty( $post_id ) || get_post_type( $post_id ) !== $this->slug ) {
			return;
		}

		foreach ( $this->get_company_assigned_user_ids( $post_id ) as $user_id ) {
			$assigned = absint( get_user_meta( $user_id, 'ccp_company_id', true ) );
			if ( $assigned === $post_id ) {
				ccp_clear_user_company_assignment( $user_id );
			}
		}
	}

	/**
	 * Re-bind users after a company is restored from trash.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public function restore_company_users( $post_id ) {
		$post_id = absint( $post_id );
		if ( empty( $post_id ) || get_post_type( $post_id ) !== $this->slug ) {
			return;
		}

		$this->assign_company_users( (array) get_post_meta( $post_id, 'ccp_company_users_owner', true ), 'ccp_owner', $post_id );
		$this->assign_company_users( (array) get_post_meta( $post_id, 'ccp_company_users_manager', true ), 'ccp_manager', $post_id );
		$this->assign_company_users( (array) get_post_meta( $post_id, 'ccp_company_users_member', true ), 'ccp_member', $post_id );
	}

	/**
	 * Display company save validation notices.
	 *
	 * @return void
	 */
	public function company_post_validation() {
		global $post;

		$msg = false;

		if ( ! empty( $post->ID ) ) {
			$msg = get_transient( 'ccp_company_post_validation_' . $post->ID );
			if ( false !== $msg && ! empty( $msg ) ) {
				delete_transient( 'ccp_company_post_validation_' . $post->ID );
			}
		}

		if ( ( false === $msg || empty( $msg ) ) ) {
			$user_key = 'ccp_company_post_validation_user_' . get_current_user_id();
			$user_msg = get_transient( $user_key );
			if ( false !== $user_msg && ! empty( $user_msg ) ) {
				delete_transient( $user_key );
				$msg = $user_msg;
			}
		}

		if ( ! empty( $msg ) ) {
			echo '<div class="error notice is-dismissible"><p>' . esc_html( $msg ) . '</p></div>';
		}
	}

	/**
	 * Whether this service should load.
	 *
	 * @return bool
	 */
	public static function resolveDependency() {
		return is_company_credits_enabled();
	}
}
