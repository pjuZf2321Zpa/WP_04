<?php
/**
 * QuoteListService class.
 *
 * Handles complex quote list post type registration and management, including dependency checks for enabling quote list features.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services\Quote;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

use WooCommerceWholesalePricing\App\Modules\Quote\QuoteProcess;

/**
 * Service responsible for hiding products from non-wholesalers and controlling access.
 * 
 * @implements ServiceInterface
 */
class ListService implements ServiceInterface {
	use WholesaleSettings;

	private $quote_settings;

	private $quote_expire;

	private $expiration_days;

	public function __construct() {

		$this->quote_settings['general'] = get_option('wc_quote_general', false);
		$this->quote_expire = isset($this->quote_settings['general']['quote_expire']) ? $this->quote_settings['general']['quote_expire'] : '0';
		$this->expiration_days = isset($this->quote_settings['general']['expiration_days']) ? $this->quote_settings['general']['expiration_days'] : '';

		add_action('add_meta_boxes', array( $this, 'wc_quote_register_metabox' ));
		add_action('save_post_wc-quote', array( $this, 'wc_quote_save_quote' ), 10, 3);
		add_filter('manage_wc-quote_posts_columns', array( $this, 'wc_quote_modify_column_names' ));
		add_action('manage_wc-quote_posts_custom_column', array( $this, 'wc_quote_add_column_data' ), 9, 2);
		add_filter('bulk_actions-edit-wc-quote', array( $this, 'wc_quote_status_bulk_actions' ));
		add_filter('handle_bulk_actions-edit-wc-quote', array( $this, 'wc_quote_status_actions_handlers' ), 10, 3);
		add_action('views_edit-wc-quote', array( $this, 'wc_quote_add_export_csv_button' ));
		add_action( 'restrict_manage_posts', array( $this, 'wc_quote_add_admin_filters' ) );
		add_action( 'pre_get_posts', array( $this, 'wc_quote_filter_admin_queries' ) );
		add_action('wp', array( $this, 'wc_quote_schedule_expiry_event' ));
		add_action('wc_quote_expiry_event', array( $this, 'wc_quote_expire_callback' ));
		add_action('wc_quote_status_updated', array( $this, 'wc_quote_handle_expiry_date_on_status_change' ), 10, 3);
		add_action('wp_loaded', array( $this, 'wc_quote_handle_custom_action' ));
	}

	/**
	 * Register metabox for wc-quote.
	 */
	public function wc_quote_register_metabox() {

		remove_meta_box('submitdiv', 'wc-quote', 'side');
		add_meta_box( 
			'wc-quote-user-data',
			__('Customer Information', 'woocommerce-wholesale-pricing'),
			array( $this, 'wc_quote_main_meta_info_html' ),
			'wc-quote',
			'normal',
			'high'
		);

		add_meta_box( 
			'wc-quote-items',
			__('Quote Details', 'woocommerce-wholesale-pricing'),
			array( $this, 'wc_quote_main_meta_details_html' ),
			'wc-quote',
			'normal',
			'high'
		);

		add_meta_box( 
			'wc-quote-actions', 
			__('Quote Actions', 'woocommerce-wholesale-pricing'),
			array( $this, 'wc_quote_side_meta_actions_html' ),
			'wc-quote',
			'side',
			'high'
		);

		$screen_id = get_current_screen() ? get_current_screen()->id : '';

		$order_id = 0;
		if (isset($_GET['post'])) {
			$order_id = absint($_GET['post']); // Classic orders
		} elseif (isset($_GET['id'])) {
			$order_id = absint($_GET['id']); // HPOS
		}

		// Get order object
		$order = $order_id > 0 ? wc_get_order($order_id) : false;
		$quote_id = '';

		// Only get quote_id if order exists and is a valid order object
		if ($order && is_a($order, 'WC_Order')) {
			$quote_id = $order->get_meta('quote_id');
			$quote_id = !empty($quote_id) ? $quote_id : '';
		}

		// Check your setting to display the meta box
		$enable_show_quote_details = isset($this->quote_settings['general']['enable_show_quote_details'])
			? $this->quote_settings['general']['enable_show_quote_details']
			: '0';

		if ( $quote_id && '1' == $enable_show_quote_details ) {
			if ( in_array($screen_id, array( 'shop_order', 'woocommerce_page_wc-orders' )) ) {
				add_meta_box(
					'custom_quote_details',
					__('Quote Details', 'woocommerce-wholesale-pricing'),
					array( $this, 'custom_quote_details_meta_box_content' ),
					$screen_id,
					'normal',
					'high'
				);
			}
		}
	}

	public function wc_quote_main_meta_info_html( $post ) {
		wwp_view('admin.quote.list.metabox.customer-info', compact( 'post' ));
	}

	public function wc_quote_main_meta_details_html( $post ) {
		$quote_general = get_option('wc_quote_general', false);
		wwp_view('admin.quote.list.metabox.quote-details', compact( 'post', 'quote_general' ));
	}

	public function wc_quote_side_meta_actions_html( $post ) {
		wwp_view('admin.quote.list.metabox.actions', compact( 'post' ));
	}

	public function custom_quote_details_meta_box_content( $post ) {
		$order_id = isset($_GET['id']) ? absint($_GET['id']) : absint($post->ID); 
		$order_data = wc_get_order($order_id);
		$quote_id = $order_data->get_meta('quote_id');

		wwp_view('admin.quote.order.quote-details-order', compact( 'post', 'quote_id' ));
	}

	/**
	 * Modify the columns displayed in the WC Quote admin list table.
	 */
	public function wc_quote_modify_column_names( $columns ) {
		unset($columns['date']);
		$columns['quote_user'] = esc_html__('User', 'woocommerce-wholesale-pricing');
		$columns['quote_status'] = esc_html__('Status', 'woocommerce-wholesale-pricing');
		$columns['total'] = esc_html__('Total', 'woocommerce-wholesale-pricing');
		$columns['date'] = esc_html__('Date', 'woocommerce-wholesale-pricing');
		return $columns;
	}

	/**
	 * Add column data for new added columns in wc-quote.
	 */
	public function wc_quote_add_column_data( $column, $postId ) {
		if ('0' === get_post($postId)->post_author) {
			$quote_user = 'Guest';
		} else {
			$quote_user = get_the_author_meta('display_name', get_post($postId)->post_author);
		}
		switch ($column) {

			case 'quote_user':
				printf('<a href="%s" >%s</a>', esc_url('edit.php?post_type=wc-quote&author=' . get_post($postId)->post_author), esc_html($quote_user));
				break;

			case 'quote_status':
				$current_status = get_post_status($postId);
				$status_object = get_post_status_object($current_status);
				$inline_style = $this->wc_quote_get_status_inline_style($current_status);
				printf(
					'<mark class="order-status %1$s tips" style="%2$s"><span>%3$s</span></mark>',
					esc_attr(sanitize_html_class('status-' . $current_status)),
					esc_attr($inline_style),
					esc_html($status_object ? $status_object->label : $current_status)
				);
				break;
			case 'total':
				$quote_contents = (array) get_post_meta($postId, 'quote_contents', true);
				$wc_quote       = new QuoteProcess($quote_contents);
				$quote_totals = $wc_quote->get_calculated_totals($quote_contents);
				echo wp_kses_post(wc_price($quote_totals['_offered_total']));
				break;

		}    
	}

	/**
	 * Register custom bulk actions for WC Quote posts.
	 */
	public function wc_quote_status_bulk_actions( $actions ) {
		// Predefined statuses
		$predefined_statuses = array(
			'quote_new'      => esc_html__('Change status to New', 'woocommerce-wholesale-pricing'),
			'quote_draft'    => esc_html__('Change status to Draft', 'woocommerce-wholesale-pricing'),
			'quote_quoted'   => esc_html__('Change status to Quoted', 'woocommerce-wholesale-pricing'),
			'quote_accepted' => esc_html__('Change status to Accepted', 'woocommerce-wholesale-pricing'),
			'quote_converted'=> esc_html__('Change status to Converted', 'woocommerce-wholesale-pricing'),
			'quote_rejected' => esc_html__('Change status to Rejected', 'woocommerce-wholesale-pricing'),
			'quote_expired'  => esc_html__('Change status to Expired', 'woocommerce-wholesale-pricing'),
		);

		$custom_statuses = array();
		// Check if custom statuses are enabled in settings
		if ( check_quote_status() ) {
			// Fetch custom statuses
			$custom_posts = get_posts(array(
				'post_type'   => 'wc-quote-status',
				'post_status' => 'any',
				'numberposts' => -1,
				'orderby'     => array(
					'menu_order' => 'DESC', // Sort by priority (menu_order) first
					'modified'   => 'ASC', // In case of ties, sort by last modified date
				),
			));

			// Process custom statuses
			if (!empty($custom_posts)) {
				foreach ($custom_posts as $post) {
					$quote_meta_status = get_post_meta($post->ID, 'wc_quote_status', true);
					$quote_status = isset($quote_meta_status['quote_status']) ? $quote_meta_status['quote_status'] : $post->post_name;

					// Add to custom statuses if enabled
					$enable_quote_status = isset($quote_meta_status['enable_quote_status']) ? $quote_meta_status['enable_quote_status'] : '';
					if ('1' === $enable_quote_status) {
						$custom_statuses[$quote_status] = esc_html__('Change status to ', 'woocommerce-wholesale-pricing') . $post->post_title;
					}
				}
			}
		}

		// Combine predefined and custom statuses with existing actions
		$actions = array_merge($actions, $predefined_statuses, $custom_statuses);

		/**
		 * Filter wc_quote_bulk_actions
		 * 
		 * @since 1.0
		**/
		return apply_filters('wc_quote_bulk_actions', $actions);
	}

	/**
	 *  Handle custom bulk actions for WC Quote posts.
	 */
	public function wc_quote_status_actions_handlers( $redirect, $doaction, $object_ids ) {
		$success_message = array();
			
		foreach ( $object_ids as $object_id ) {
			$quote = get_post($object_id);
			
			$quote_status = array( 'quote_new', 'quote_draft', 'quote_quoted', 'quote_accepted', 'quote_converted', 'quote_expired', 'quote_rejected' );
			if ( check_quote_status() ) {
			// Dynamically fetch statuses from custom posts
				$custom_posts = get_posts(array(
					'post_type'   => 'wc-quote-status',
					'post_status' => 'any',
					'numberposts' => -1,
					'orderby'     => array(
						'menu_order' => 'DESC', // Sort by priority (menu_order) first
						'modified'   => 'ASC', // In case of ties, sort by last modified date
					),
				));

				if (!empty($custom_posts)) {
					foreach ($custom_posts as $post) {
						$quote_meta_status = get_post_meta($post->ID, 'wc_quote_status', true);
						$quote_status_key = isset($quote_meta_status['quote_status']) ? $quote_meta_status['quote_status'] : $post->post_name;

						// Add dynamically fetched statuses to the list
						$quote_status[] = $quote_status_key;
					}
				}
			}
					
			if (in_array($doaction, $quote_status) ) {
		
				$query = array(
				'ID' => $quote->ID,
				'post_status' => $doaction,
				);
				wp_update_post($query, true);
				
				if ('quote_converted' == $doaction) {
				
					$quote_contents = get_post_meta($quote->ID, 'quote_contents', true);
					$quotes         = $quote_contents;
					$quote_order    = wc_create_order();

						
					// ================= custom pdf sprint 2.7 Start IN PROGRESS===================
						
					$wc_quote = new QuoteProcess($quote_contents, $quote->ID);
					$quote_totals = $wc_quote->get_calculated_totals($quote_contents, $quote->ID);
						
					$shipping_amount = $quote_totals['_shipping'];

						
					$shipping_method = new \WC_Shipping_Rate(
						'flat_rate_shipping', // Unique rate ID
						'Flat Rate Shipping', // Method title
						$shipping_amount, // Cost
						array(), // Taxes (empty if not used)
						// $taxes,
						'flat_rate' // Method ID
					);

					$quote_order->add_shipping($shipping_method);
						
					// ======================== custom pdf sprint 2.7 End ===========================
					
					$customer_id = $quote->post_author;
						
					if (! empty(intval($customer_id)) ) {
						$customer = new \WC_Customer($customer_id);
					} else {
						$customer = new \WC_Customer(0);
					}
					foreach ( $quote_contents as $quote_item_key => $quote_item ) {


						if (isset($quote_item['data']) ) {
							$product = $quote_item['data'];
						} else {
							continue;
						}

						if (! is_object($product) ) {
							continue;
						}

						$price         = $product->get_price();
						$qty_display   = $quote_item['quantity'];
						$offered_price = isset($quote_item['offered_price']) ? floatval($quote_item['offered_price']) : $price;

						$product->set_price($offered_price);

						$item_id = $quote_order->add_product($product, $qty_display);

						if ($product->get_type() === 'subscription' || $product->get_type() === 'variable-subscription' ) :
							$sub = wcs_create_subscription(
								array(
								'order_id' => $quote_order->get_id(),
								'status' => 'pending', // Status should be initially set to pending to match how normal checkout process goes
								'billing_period' => \WC_Subscriptions_Product::get_period($product),
								'billing_interval' => \WC_Subscriptions_Product::get_interval($product),
								'customer_id' => $customer->get_id(),
								)
							);


							if (is_wp_error($sub) ) {
										return false;
							} 

							// Modeled after WC_Subscriptions_Cart::calculate_subscription_totals()
							$start_date = gmdate('Y-m-d H:i:s');
							// Add product to subscription
							$sub->add_product($product, $qty_display);

							$dates = array(
							'trial_end'    => \WC_Subscriptions_Product::get_trial_expiration_date($product, $start_date),
							'next_payment' => \WC_Subscriptions_Product::get_first_renewal_payment_date($product, $start_date),
							'end'          => \WC_Subscriptions_Product::get_expiration_date($product, $start_date),
							);

							$sub->update_dates($dates);
							$sub->calculate_totals();
							$sub->save(); // Save the subscription data.
						endif;

						$item    = $quote_order->get_item($item_id);
						/**
						 * Action wc_quote_create_order_line_item
						 * 
						 * @since 1.0
						**/
						do_action('wc_quote_create_order_line_item', $item, $quote_item_key, $quote_item, $quote_order);

						if (! empty($quote_item['addons']) && class_exists('WC_Product_Addons_Helper') ) {
							foreach ( $quote_item['addons'] as $addon ) {
								$key           = $addon['name'];
								$price_type    = $addon['price_type'];
								$product       = $item->get_product();
								$product_price = $product->get_price();

								/*
								* For percentage based price type we want
								* to show the calculated price instead of
								* the price of the add-on itself and in this
								* case its not a price but a percentage.
								* Also if the product price is zero, then there
								* is nothing to calculate for percentage so
								* don't show any price.
								*/
								if ($addon['price'] && 'percentage_based' === $price_type && 0 != $product_price ) {
												$addon_price = $product_price * ( $addon['price'] / 100 );
								} else {
									$addon_price = $addon['price'];
								}
								$price = html_entity_decode(
									wp_strip_all_tags(wc_price(\WC_Product_Addons_Helper::get_product_addon_price_for_display($addon_price, $product))),
									ENT_QUOTES,
									get_bloginfo('charset')
								);

								/*
								* If there is an add-on price, add the price of the add-on
								* to the label name.
								*/
								/**
								* Filter woocommerce_addons_add_price_to_name
								* 
								* @since 1.0
								**/
								if ($addon['price'] && apply_filters('woocommerce_addons_add_price_to_name', true) ) {
													$key .= ' (' . $price . ')';
								}

								if ('custom_price' === $addon['field_type'] ) {
												$addon['value'] = $addon['price'];
								}

								$item->add_meta_data($key, $addon['value']);
								$item->save();
							}
						}
					}

					$customer_name  = get_the_author_meta('first_name', get_post($quote->ID)->post_author);
					$customer_email = get_the_author_meta('user_email', get_post($quote->ID)->post_author);
					$quote_fields = get_quote_fields();

					foreach ( $quote_fields['components'] as $key => $field ) {
						if ('email' === $field['type'] ) {
							$field_data = get_post_meta($quote->ID, 'quote_fields', true);
							$field_key  = $field['key'];
							if (!empty($field_data[$field_key]) ) {
								$customer_email = $field_data[$field_key];
							}
							break;
						}
					}



					$billing_address = (array) $customer->get_billing();
					$shipping_address = (array) $customer->get_shipping();

					$billing_address['email'] = $customer_email;
					$shipping_address['email'] = $customer_email;
					$billing_address['first_name'] = $customer_name;
					$shipping_address['first_name'] = $customer_name;

					$quote_order->set_address($billing_address, 'billing');
					$quote_order->set_address($shipping_address, 'shipping');
					$quote_order->set_customer_id(intval($customer_id));

					$quote_order->calculate_totals(); // updating totals.

					$quote_order->save(); // Save the order data.

					$current_admin = wp_get_current_user();

					$current_admin = isset($current_admin->ID) ? (string) $current_admin->user_login : 'Admin';
						
					// $wpdb->update($wpdb->prefix . 'posts', array( 'post_status' => 'quote_converted' ), array( 'ID' => $post->ID ));
						
					clean_post_cache($quote->ID);
						
					update_post_meta($quote->ID, 'converted_by_user', $current_admin);
					update_post_meta($quote->ID, 'converted_by', __('Administrator', 'woocommerce-wholesale-pricing'));

						
					/**
					* Action wc_quote_converted_to_order
					* 
					* @since 1.0
					**/
					do_action('wc_quote_converted_to_order', $quote_order, $quote->ID);
						
						

					// wp_safe_redirect($quote_order->get_edit_order_url());
					$order_ids[] = $quote_order->get_id();
					$quote_ids[] = $quote->ID;

				}

				/**
				 * Action wc_quote_send_quote_email_to_admin
				 * 
				 * @since 1.0
				**/
				do_action('wc_quote_send_quote_email_to_admin', $quote->ID);
				/**
				 * Action wc_quote_send_quote_email_to_customer
				 * 
				 * @since 1.0
				**/
				do_action('wc_quote_send_quote_email_to_customer', $quote->ID);
					
					
				
			}
				
			
		}
		if ('quote_converted' == $doaction) {
			$success_order_id = implode(',', $order_ids);
			$quote_ids = implode(',', $quote_ids);
				
						
			wp_safe_redirect(wp_get_referer() ? wp_get_referer() . '&wc-quote-order-convert=true&quote_id=' . $quote_ids . '&success=' . $success_order_id : admin_url('admin.php?page=wc-quote-settings&wc-quote-order-convert=true&quote_id=' . $quote_ids . '&success=' . $success_order_id));
			
			exit;
		}
			
		return $redirect;
	}

	/**
	 * Display an "Export CSV" button on the WC Quote admin list page.
	 */
	public function wc_quote_add_export_csv_button( $views ) {
		$wc_quote = get_posts( array(
			'post_type'   => 'wc-quote',
			'post_status' => 'any',
			'numberposts' => -1,
		) );

		if (!empty($wc_quote) && count($wc_quote) > 0 ) {
			?>
			<form method="post" id="wc-quote-export-csv-form">
				<input type="hidden" name="action" value="wc_quote_export_csv">
			<?php wp_nonce_field('wc_quote_export_csv'); ?>
				<a href="#" class="wc_quote_csv page-title-action" onclick="document.getElementById('wc-quote-export-csv-form').submit();"><?php esc_html_e('Export CSV', 'woocommerce-wholesale-pricing'); ?></a>
			</form>
			<?php
		}
		return $views;
	}

	/**
	 * Add custom dropdown filters for WC Quote admin list page.
	 */
	public function wc_quote_add_admin_filters() {
		global $typenow;

		$current_status = isset($_GET['post_status']) ? sanitize_text_field($_GET['post_status']) : '';

		if ( 'wc-quote' === $typenow && 'trash' !== $current_status) {

			/**
			 * Filter wc_quote_register_post_statuses
			 * 
			 * @since 1.0
			**/
			$quote_statuses = apply_filters('wc_quote_register_post_statuses', array(
				'quote_draft'    => array( 'label' => __('Draft', 'woocommerce-wholesale-pricing') ),
				'quote_new'      => array( 'label' => __('New', 'woocommerce-wholesale-pricing') ),
				'quote_quoted'   => array( 'label' => __('Quoted', 'woocommerce-wholesale-pricing') ),
				'quote_accepted' => array( 'label' => __('Accepted', 'woocommerce-wholesale-pricing') ),
				'quote_converted' => array( 'label' => __('Converted To Order', 'woocommerce-wholesale-pricing') ),
				'quote_rejected' => array( 'label' => __('Rejected', 'woocommerce-wholesale-pricing') ),
				'quote_expired'  => array( 'label' => __('Expired', 'woocommerce-wholesale-pricing') ),
			));

			if ( check_quote_status() ) {
				// Dynamically fetch statuses from `wc-quote-status` post type
				$custom_posts = get_posts(array(
					'post_type'   => 'wc-quote-status',
					'post_status' => 'any',
					'numberposts' => -1,
					'orderby'     => array(
						'menu_order' => 'DESC', // Sort by priority (menu_order) first
						'modified'   => 'ASC', // In case of ties, sort by last modified date
					),
				));

				foreach ($custom_posts as $post) {
					$quote_meta_status = get_post_meta($post->ID, 'wc_quote_status', true);
					$quote_status = isset($quote_meta_status['quote_status']) ? $quote_meta_status['quote_status'] : $post->post_name;
					$enable_quote_status = isset($quote_meta_status['enable_quote_status']) ? $quote_meta_status['enable_quote_status'] : '';

					// Only add the status if 'enable_quote_status' is set to true
					if ( '1' === $enable_quote_status ) {
						$quote_statuses[$quote_status] = array( 'label' => $post->post_title );
					}
				}
			}

			// Generate the dropdown menu
			?>
			<select name="post_status" id="post_status">
				<option value=""><?php echo esc_html__('All Status', 'woocommerce-wholesale-pricing'); ?></option>
				<?php foreach ($quote_statuses as $status_key => $status_data) : ?>
					<option value="<?php echo esc_attr($status_key); ?>" <?php selected($status_key === $current_status); ?>>
						<?php echo esc_html($status_data['label']); ?>
					</option>
				<?php endforeach; ?>
			</select>
			<?php
		}
	}

	/**
	 * Filter admin list queries for WC Quote post type.
	 */
	public function wc_quote_filter_admin_queries( $query ) {
		global $pagenow;

		if (is_admin() && 'edit.php' === $query->get('pagenow') && 'wc-quote' === $query->get('post_type') ) {

			$current_status = sanitize_text_field($query->get('post_status'));

			if (! empty($current_status) ) {
				$meta_query = array(
					array(
					'key'   => 'post_status',
					'value' => $current_status,
					),
				);
				$query->set('meta_query', $meta_query);
			}
			$search_query = sanitize_text_field($query->get('s'));

			if (! empty($search_query) ) {
				$query->set('s', $search_query);
			}
		}
	}

	/**
	 * Schedule a daily event to check and process WC Quote expirations.
	 */
	public function wc_quote_schedule_expiry_event() {
		if (!wp_next_scheduled('wc_quote_expiry_event') && '1' === $this->quote_expire && $this->expiration_days > 0 ) {
			wp_schedule_event(time(), 'daily', 'wc_quote_expiry_event');
		}
	}

	/**
	 * Handle automatic expiration of WC Quotes via scheduled event.
	 */
	public function wc_quote_expire_callback() {
		$statuses = array( 'quote_quoted', 'quote_rejected' );
		/**
		* Filter wc_quote_statuses_array
		* 
		* @since 1.0
		**/
		$statuses = apply_filters('wc_quote_statuses_array', $statuses);
		
		$all_quotes = get_posts(
			array(
			'numberposts' => -1,
			'post_type'   => 'wc-quote',
			'post_status' => $statuses,
			)
		);
			
		foreach ( $all_quotes as $quote ) {
			$quote_expiry_date = get_post_meta($quote->ID, 'wc_quote_expire_date', true);
			$current_date = date_i18n(get_option('date_format'), time());
			if ($quote_expiry_date >= $current_date ) {
				$query = array(
					'ID' => $quote->ID,
					'post_status' => 'quote_expired',
				);
				wp_update_post($query, true);
			}
		}
	}

	/**
	 * Add or remove WC Quote expiry date based on status changes.
	 */
	public function wc_quote_handle_expiry_date_on_status_change( $post_id, $new_status, $old_status ) {
		if ('1' === $this->quote_expire && $this->expiration_days > 0 ) {
			if ('quote_quoted' === $new_status ) {
				$expiry_date = date_i18n(get_option('date_format'), strtotime(' + ' . $this->expiration_days . ' days'));
				update_post_meta($post_id, 'wc_quote_expire_date', $expiry_date);
			}
			if (in_array($new_status, array( 'quote_new', 'quote_accepted', 'quote_converted' )) ) {
				delete_post_meta($post_id, 'wc_quote_expire_date');
			}
		}
	}

	public function wc_quote_handle_custom_action() {

		$data = $_REQUEST;
		$action = ! empty($data['action']) ? $data['action'] : '' ;
		if ('wc_quote_export_csv' == $action ) { 
			check_admin_referer('wc_quote_export_csv');
			global $wp_post_statuses;
			$statuses = array( 'quote_new', 'quote_quoted', 'quote_accepted', 'quote_rejected', 'quote_converted', 'quote_expired' );
			if ( check_quote_status() ) {
				// Fetch dynamic statuses
				$custom_posts = get_posts(array(
					'post_type'   => 'wc-quote-status',
					'post_status' => 'any',
					'numberposts' => -1,
					'orderby'     => array(
						'menu_order' => 'DESC', // Sort by priority (menu_order) first
						'modified'   => 'ASC', // In case of ties, sort by last modified date
					),
				));
				$quote_statuses = array();
				foreach ($custom_posts as $post) {
					$quote_meta_status = get_post_meta($post->ID, 'wc_quote_status', true);
					$quote_status = isset($quote_meta_status['quote_status']) ? $quote_meta_status['quote_status'] : $post->post_name;
					$quote_statuses[$quote_status] = array( 'label' => $post->post_title );
				}

				// Merge statuses
				$statuses = array_merge($statuses, array_keys($quote_statuses));
			}
			/**
			* Filter wc_quote_statuses_array
			* 
			* @since 1.0
			**/
			$statuses = apply_filters('wc_quote_statuses_array', $statuses);
			$quotes = get_posts(
				array(
				'numberposts' => -1,
				'post_type' => 'wc-quote',
				'post_status' => $statuses,
				)
			);

			$quoteData = array();
			foreach ($quotes as $quote) {
						$quote_contents = (array) get_post_meta($quote->ID, 'quote_contents', true);
						$wc_quote = new QuoteProcess($quote_contents);
						$quote_totals = $wc_quote->get_calculated_totals($quote_contents);
						$products = array(); // Initialize $products array here
				foreach ($quote_contents as $key => $value) {
					if (is_array($value) && isset($value['product_id'])) {
						$product = wc_get_product($value['product_id']);
						$products[] = $product->get_name();
					}
				}

				$data = array(
				'Quote Title' => isset($quote->post_title) ? $quote->post_title : '',
				'Username' => isset($quote->post_author) ? get_the_author_meta('display_name', $quote->post_author) : '',
				'Product Title' => isset($products) ? implode(', ', $products) : '',
				'Status' => get_post_status_object(get_post_status($quote->ID))->label,
				'Total' => isset($quote_totals['_offered_total']) ? $quote_totals['_offered_total'] : '',
				'Date' => isset($quote->post_modified_gmt) ? gmdate('m-d-y', strtotime($quote->post_modified_gmt)) : gmdate('m-d-y', time()),
				);
				$quoteData[] = $data;
			}
			/**
			* Filter wc_quote_export_csv
			* 
			* @since 1.0
			**/
			$quoteData = apply_filters('wc_quote_export_csv', $quoteData);
			$filename = gmdate('YmdHis') . '_wc_quote_export.csv';
			$now = gmdate('D, d M Y H:i:s');
			header('Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate');
			header("Last-Modified: {$now} GMT");
			header('Content-Type: application/force-download');
			header('Content-Type: application/octet-stream');
			header('Content-Type: application/download');
			header("Content-Disposition: attachment;filename={$filename}");
			header('Content-Transfer-Encoding: binary');

			ob_clean();
			ob_start();
			$df = fopen('php://output', 'w');
			// fputcsv($df, array_keys($quoteData[0])); //PHP Compatibility Test - Warning
			fputcsv($df, array_keys($quoteData[0]), ',', '"', '\\');

			foreach ($quoteData as $row) {

				// fputcsv($df, $row); // PHP Compatibility Test - Warning
				fputcsv($df, $row, ',', '"', '\\');
			}
						

			fclose($df);
			ob_end_flush();

			exit();
		}
	}

	/**
	 * Save post meta foreach quote created by admin.
	 */
	public function wc_quote_save_quote( $post_id, $post ) {

		global $wpdb;
			
		if (! 'wc-quote' === $post->post_type ) {
			return;
		}

		if (!isset($_POST['wc-quote-save-post']) ) {
			return;
		}

		// if our nonce isn't there, or we can't verify it, return
		if (isset($_POST['wc-quote-save-post']) && ! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wc-quote-save-post'])), 'wc-quote-save-post') ) {
			return;
		}
		// Update Quote
		$form_data = sanitize_meta('', wp_unslash($_POST), '');

		if (!empty($form_data) ) {
			$form_data['post_author'] = isset($form_data['post_author_override']) ? $form_data['post_author_override'] : 0;

			$quote_contents = !empty(get_post_meta($post_id, 'quote_contents', true)) ? get_post_meta($post_id, 'quote_contents', true) : array( 0 => 0 );

			foreach ( $quote_contents as $quote_item_key => $quote_item ) {

				if (isset($form_data['quote_qty'][ $quote_item_key ]) ) {
					$quote_contents[ $quote_item_key ]['quantity'] = intval($form_data['quote_qty'][ $quote_item_key ]);
				}

				if (isset($form_data['offered_price'][ $quote_item_key ]) ) {
					$quote_contents[ $quote_item_key ]['offered_price'] = floatval($form_data['offered_price'][ $quote_item_key ]);
				}
				if (isset($form_data['offered_signup'][ $quote_item_key ]) ) {
					$quote_contents[ $quote_item_key ]['offered_signup'] = floatval($form_data['offered_signup'][ $quote_item_key ]);
				}
			}

			// Save Quote Data
			update_post_meta($post_id, 'quote_contents', $quote_contents);

			// Save Quote Fields
			if (isset($form_data['data']) ) :
				$quote_fields = get_quote_fields();

				foreach ( $quote_fields['components'] as $key => $field ) {
					$wc_quote_field_name  = $field['key'];
					$wc_quote_field_type  = $field['type'];
					if ('radio' === $wc_quote_field_type  ) :
							$radio_value = ! empty($form_data['data'][$wc_quote_field_name]) ? $form_data['data'][$wc_quote_field_name] : array();
							$form_data['data'][$wc_quote_field_name] = reset($radio_value);
					endif;
				}
				update_post_meta($post_id, 'quote_fields', $form_data['data']);
			endif;

			$wpdb->update($wpdb->prefix . 'posts', array( 'post_author' => $form_data['post_author'] ), array( 'ID' => $post_id ));
			/**
			 * Action wc_quote_contents_updated
			 * 
			 * @since 1.0
			**/
			do_action('wc_quote_contents_updated', $post_id);

			if (isset($form_data['post_status']) ) {

				$old_status = $post->post_status;
				/**
				 * Action wc_quote_status_updated
				 * 
				 * @since 1.0
				**/
				do_action('wc_quote_status_updated', $post_id, $form_data['post_status'], $old_status);
			}
			
			if ('quote_converted' == $form_data['post_status'] || isset($form_data['wc_quote_convert_to_order'])  ) {
				$quote_order    = wc_create_order();

					
				// ================= custom pdf sprint 2.7 Start Start===================
					
				// For Add Shipping In Converted Order 
				$wc_quote = new QuoteProcess($quote_contents, $post_id);
				$quote_totals = $wc_quote->get_calculated_totals($quote_contents, $post_id);

				$shipping_amount = $quote_totals['_shipping'];

					
				$shipping_method = new \WC_Shipping_Rate(
					'flat_rate_shipping', // Unique rate ID
					'Flat Rate Shipping', // Method title
					$shipping_amount, // Cost
					array(), // Taxes (empty if not used)
					'flat_rate' // Method ID
				);
						
				$quote_order->add_shipping($shipping_method);
						
				// ================= custo m pdf sprint 2.7 Start End===================

				$customer_id = $form_data['post_author'];

				if (! empty(intval($customer_id)) ) {
							$customer = new \WC_Customer($customer_id);
				} else {
					$customer = new \WC_Customer(0);
				}
				foreach ( $quote_contents as $quote_item_key => $quote_item ) {


					if (isset($quote_item['data']) ) {
						$product = $quote_item['data'];
					} else {
						continue;
					}

					if (! is_object($product) ) {
						continue;
					}

					$price         = $product->get_price();
					$qty_display   = $quote_item['quantity'];
					$offered_price = isset($quote_item['offered_price']) ? floatval($quote_item['offered_price']) : $price;

					$product->set_price($offered_price);

					$item_id = $quote_order->add_product($product, $qty_display);

					if ($product->get_type() === 'subscription' || $product->get_type() === 'variable-subscription' ) :
						$sub = wcs_create_subscription(
							array(
							'order_id' => $quote_order->get_id(),
							'status' => 'pending', // Status should be initially set to pending to match how normal checkout process goes
							'billing_period' => \WC_Subscriptions_Product::get_period($product),
							'billing_interval' => \WC_Subscriptions_Product::get_interval($product),
							'customer_id' => $customer->get_id(),
							)
						);


						if (is_wp_error($sub) ) {
								return false;
						} 

						// Modeled after WC_Subscriptions_Cart::calculate_subscription_totals()
						$start_date = gmdate('Y-m-d H:i:s');
						// Add product to subscription
						$sub->add_product($product, $qty_display);

						$dates = array(
						'trial_end'    => \WC_Subscriptions_Product::get_trial_expiration_date($product, $start_date),
						'next_payment' => \WC_Subscriptions_Product::get_first_renewal_payment_date($product, $start_date),
						'end'          => \WC_Subscriptions_Product::get_expiration_date($product, $start_date),
						);

						$sub->update_dates($dates);
						$sub->calculate_totals();
						$sub->save(); // Save the subscription data.
					endif;

					$item    = $quote_order->get_item($item_id);
					/**
					 * Action wc_quote_create_order_line_item
					 * 
					 * @since 1.0
					**/
					do_action('wc_quote_create_order_line_item', $item, $quote_item_key, $quote_item, $quote_order);

					if (! empty($quote_item['addons']) && class_exists('WC_Product_Addons_Helper') ) {
						foreach ( $quote_item['addons'] as $addon ) {
							$key           = $addon['name'];
							$price_type    = $addon['price_type'];
							$product       = $item->get_product();
							$product_price = $product->get_price();

							/*
							* For percentage based price type we want
							* to show the calculated price instead of
							* the price of the add-on itself and in this
							* case its not a price but a percentage.
							* Also if the product price is zero, then there
							* is nothing to calculate for percentage so
							* don't show any price.
							*/
							if ($addon['price'] && 'percentage_based' === $price_type && 0 != $product_price ) {
									$addon_price = $product_price * ( $addon['price'] / 100 );
							} else {
								$addon_price = $addon['price'];
							}
							$price = html_entity_decode(
								wp_strip_all_tags(wc_price(\WC_Product_Addons_Helper::get_product_addon_price_for_display($addon_price, $product))),
								ENT_QUOTES,
								get_bloginfo('charset')
							);

							/*
							* If there is an add-on price, add the price of the add-on
							* to the label name.
							*/
							/**
							* Filter woocommerce_addons_add_price_to_name
							* 
							* @since 1.0
							**/
							if ($addon['price'] && apply_filters('woocommerce_addons_add_price_to_name', true) ) {
									$key .= ' (' . $price . ')';
							}

							if ('custom_price' === $addon['field_type'] ) {
									$addon['value'] = $addon['price'];
							}

							$item->add_meta_data($key, $addon['value']);
							$item->save();
						}
					}

					if (!empty($quote_item['booking'])) {
						$booking = $quote_item['booking'];

						$year  = intval($booking['_year']);
						$month = str_pad(intval($booking['_month']), 2, '0', STR_PAD_LEFT);
						$day   = str_pad(intval($booking['_day']), 2, '0', STR_PAD_LEFT);

						$formatted_date = date_i18n('F j, Y', strtotime("$year-$month-$day"));

						// ✅ Save Booking Date
						$item->add_meta_data('Booking Date', $formatted_date);

						// ✅ Save Booking Time
						if (!empty($booking['_time'])) {
							$item->add_meta_data('Booking Time', date_i18n('g:i a', strtotime($booking['_time'])));
						} elseif (!empty($booking['time'])) {
							$item->add_meta_data('Booking Time', $booking['time']);
						}

						// ✅ Save Booking Type (resource)
						if (!empty($booking['_resource_id'])) {
							$resource_post = get_post($booking['_resource_id']);
							if ($resource_post && !is_wp_error($resource_post)) {
								$item->add_meta_data('Booking Type', $resource_post->post_title);
							}
						} elseif (!empty($booking['type'])) {
							$item->add_meta_data('Booking Type', $booking['type']);
						}

						// ✅ Save Duration
						if (!empty($booking['duration'])) {
							$item->add_meta_data('Duration', $booking['duration']);
						} elseif (!empty($booking['_duration']) && !empty($booking['_duration_unit'])) {
							$duration    = $booking['_duration'];
							$unit        = $booking['_duration_unit'];
							$unit_label  = $duration > 1 ? $unit . 's' : $unit;
							$item->add_meta_data('Duration', $duration . ' ' . $unit_label);
						}

						$item->save();
					}
				}

				$customer_name  = get_the_author_meta('first_name', get_post($post_id)->post_author);
				$customer_email = get_the_author_meta('user_email', get_post($post_id)->post_author);
				$quote_fields = get_quote_fields();

				foreach ( $quote_fields['components'] as $key => $field ) {
					if ('email' === $field['type'] ) {
						$field_data = get_post_meta($post_id, 'quote_fields', true);
						$field_key  = $field['key'];
						if (!empty($field_data[$field_key]) ) {
							$customer_email = $field_data[$field_key];
						}
						break;
					}
				}

				$billing_address = (array) $customer->get_billing();
				$shipping_address = (array) $customer->get_shipping();

				$billing_address['email'] = $customer_email;
				$shipping_address['email'] = $customer_email;
				$billing_address['first_name'] = $customer_name;
				$shipping_address['first_name'] = $customer_name;

				$quote_order->set_address($billing_address, 'billing');
				$quote_order->set_address($shipping_address, 'shipping');
				$quote_order->set_customer_id(intval($customer_id));

				$quote_order->calculate_totals(); // updating totals.

				$quote_order->add_meta_data('quote_id', $post_id);

				$quote_order->save(); // Save the order data.

				$current_admin = wp_get_current_user();

				$current_admin = isset($current_admin->ID) ? (string) $current_admin->user_login : 'Admin';

				$wpdb->update($wpdb->prefix . 'posts', array( 'post_status' => 'quote_converted' ), array( 'ID' => $post->ID ));
					
				clean_post_cache($post_id);
					
				update_post_meta($post_id, 'converted_by_user', $current_admin);
				update_post_meta($post_id, 'converted_by', __('Administrator', 'woocommerce-wholesale-pricing'));
				/**
				* Action wc_quote_converted_to_order
				* 
				* @since 1.0
				**/
				do_action('wc_quote_converted_to_order', $quote_order, $post_id);
				/**
				* Action wc_quote_send_quote_email_to_admin
				* 
				* @since 1.0
				**/
				do_action('wc_quote_send_quote_email_to_admin', $post->ID);
				/**
				* Action wc_quote_send_quote_email_to_customer
				* 
				* @since 1.0
				**/
				do_action('wc_quote_send_quote_email_to_customer', $post->ID);

				update_post_meta($quote_order->get_id(), '_quote_id', $post->ID);

				wp_safe_redirect($quote_order->get_edit_order_url());
				exit;
			}
			/**
			 * Action wc_quote_send_quote_email_to_admin
			 * 
			 * @since 1.0
			**/
			do_action('wc_quote_send_quote_email_to_admin', $post_id);
			/**
			 * Action wc_quote_send_quote_email_to_customer
			 * 
			 * @since 1.0
			**/
			do_action('wc_quote_send_quote_email_to_customer', $post_id);

		}
	}

	public static function resolveDependency() {
		$settings = self::get_pricing_settings();
		return ( isset( $settings['enable_quote'] ) && 'yes' === $settings['enable_quote'] );
	}

	/**
	 * Resolve custom quote status colors for admin table badge.
	 */
	private function wc_quote_get_status_inline_style( $status_key ) {
		if ( empty($status_key) || ! quote_check_status() ) {
			return '';
		}

		static $status_styles = null;

		if ( null === $status_styles ) {
			$status_styles = array();
			$custom_posts  = get_quote_custom_status_posts();

			foreach ( $custom_posts as $post ) {
				$quote_meta_status   = get_post_meta( $post->ID, 'wc_quote_status', true );
				$enable_quote_status = isset( $quote_meta_status['enable_quote_status'] ) ? $quote_meta_status['enable_quote_status'] : '';

				if ( '1' !== $enable_quote_status ) {
					continue;
				}

				$quote_status = isset( $quote_meta_status['quote_status'] ) ? $quote_meta_status['quote_status'] : $post->post_name;
				$style_rules  = array();
				$label_color  = isset( $quote_meta_status['label_Color'] ) ? sanitize_hex_color( $quote_meta_status['label_Color'] ) : '';
				$background_color = isset( $quote_meta_status['background_color'] ) ? sanitize_hex_color( $quote_meta_status['background_color'] ) : '';

				if ( ! empty( $label_color ) ) {
					$style_rules[] = 'color: ' . $label_color;
				}

				if ( ! empty( $background_color ) ) {
					$style_rules[] = 'background: ' . $background_color;
				}

				$status_styles[ $quote_status ] = implode( '; ', $style_rules );
			}
		}

		return isset( $status_styles[ $status_key ] ) ? $status_styles[ $status_key ] : '';
	}
}