<?php
/**
 * Programmatic CRUD for wc-quote-rules posts.
 *
 * @package WooCommerceWholesalePricing\App\Services\Quote
 */

namespace WooCommerceWholesalePricing\App\Services\Quote;

/**
 * API-oriented service for quote rule management.
 */
class WholesaleQuoteRuleService {

	/**
	 * Valid user role modes.
	 *
	 * @var list<string>
	 */
	const USER_ROLE_MODES = array( 'all', 'specific', 'specific_users' );

	/**
	 * Valid include modes.
	 *
	 * @var list<string>
	 */
	const INCLUDE_MODES = array( 'all', 'product', 'category', 'tag' );

	/**
	 * Valid exclude modes.
	 *
	 * @var list<string>
	 */
	const EXCLUDE_MODES = array( 'product', 'category', 'tag' );

	/**
	 * Built-in quote statuses.
	 *
	 * @var list<string>
	 */
	const QUOTE_STATUSES = array(
		'quote_new',
		'quote_draft',
		'quote_quoted',
		'quote_accepted',
		'quote_rejected',
		'quote_expired',
	);

	/**
	 * List quote rules.
	 *
	 * @param array<string, mixed> $args Query args.
	 * @return array{rules: list<array<string, mixed>>, total: int}
	 */
	public function list_rules( array $args = array() ) {
		$per_page = max( 1, min( 100, (int) ( isset( $args['per_page'] ) ? $args['per_page'] : 20 ) ) );
		$page     = max( 1, (int) ( isset( $args['page'] ) ? $args['page'] : 1 ) );
		$search   = isset( $args['search'] ) ? sanitize_text_field( (string) $args['search'] ) : '';
		$enabled  = isset( $args['enabled'] ) ? filter_var( $args['enabled'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE ) : null;

		$query_args = array(
			'post_type'      => $this->get_post_type(),
			'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'orderby'        => 'menu_order',
			'order'          => 'ASC',
		);

		if ( '' !== $search ) {
			$query_args['s'] = $search;
		}

		if ( null !== $enabled ) {
			$query_args['meta_query'] = array(
				array(
					'key'     => 'enable_rule',
					'value'   => $enabled ? '1' : '0',
					'compare' => '=',
				),
			);
		}

		$query = new \WP_Query( $query_args );
		$rules = array();

		foreach ( $query->posts as $post ) {
			if ( $post instanceof \WP_Post ) {
				$rules[] = $this->format_rule( (int) $post->ID );
			}
		}

		return array(
			'rules' => $rules,
			'total' => (int) $query->found_posts,
		);
	}

	/**
	 * Get a single quote rule.
	 *
	 * @param int $rule_id Rule post ID.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function get_rule( $rule_id ) {
		$post = $this->resolve_post( $rule_id );
		if ( is_wp_error( $post ) ) {
			return $post;
		}

		return $this->format_rule( (int) $post->ID );
	}

	/**
	 * Create a quote rule.
	 *
	 * @param array<string, mixed> $data Rule payload.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function create_rule( array $data ) {
		$title = isset( $data['title'] ) ? sanitize_text_field( (string) $data['title'] ) : '';
		if ( '' === $title ) {
			return new \WP_Error(
				'wwp_quote_rule_missing_title',
				__( 'Rule title is required.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$stored = $this->build_storage_from_payload( array(), $data );
		if ( is_wp_error( $stored ) ) {
			return $stored;
		}

		$post_id = wp_insert_post(
			array(
				'post_type'   => $this->get_post_type(),
				'post_title'  => $title,
				'post_status' => isset( $data['status'] ) ? sanitize_key( (string) $data['status'] ) : 'publish',
				'menu_order'  => isset( $data['priority'] ) ? (int) $data['priority'] : 0,
			),
			true
		);

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		$this->persist_rule_meta( (int) $post_id, $stored, $data );

		return $this->format_rule( (int) $post_id );
	}

	/**
	 * Update a quote rule.
	 *
	 * @param int                  $rule_id Rule post ID.
	 * @param array<string, mixed> $data    Rule patch.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function update_rule( $rule_id, array $data ) {
		$post = $this->resolve_post( $rule_id );
		if ( is_wp_error( $post ) ) {
			return $post;
		}

		if ( empty( $data ) ) {
			return new \WP_Error(
				'wwp_quote_rule_missing_data',
				__( 'Rule data is required for update.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$existing = get_post_meta( $rule_id, 'wc_quote_rules', true );
		$existing = is_array( $existing ) ? $existing : array();

		$stored = $this->build_storage_from_payload( $existing, $data );
		if ( is_wp_error( $stored ) ) {
			return $stored;
		}

		$post_update = array( 'ID' => $rule_id );
		if ( isset( $data['title'] ) ) {
			$post_update['post_title'] = sanitize_text_field( (string) $data['title'] );
		}
		if ( isset( $data['status'] ) ) {
			$post_update['post_status'] = sanitize_key( (string) $data['status'] );
		}
		if ( isset( $data['priority'] ) ) {
			$post_update['menu_order'] = (int) $data['priority'];
		}

		if ( count( $post_update ) > 1 ) {
			$updated = wp_update_post( $post_update, true );
			if ( is_wp_error( $updated ) ) {
				return $updated;
			}
		}

		$this->persist_rule_meta( $rule_id, $stored, $data );

		return $this->format_rule( $rule_id );
	}

	/**
	 * Delete a quote rule permanently.
	 *
	 * @param int $rule_id Rule post ID.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function delete_rule( $rule_id ) {
		$post = $this->resolve_post( $rule_id );
		if ( is_wp_error( $post ) ) {
			return $post;
		}

		$deleted = wp_delete_post( $rule_id, true );
		if ( ! $deleted ) {
			return new \WP_Error(
				'wwp_quote_rule_delete_failed',
				__( 'Failed to delete quote rule.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		return array(
			'deleted' => true,
			'rule_id' => $rule_id,
			'title'   => (string) $post->post_title,
		);
	}

	/**
	 * Snapshot rule state for undo.
	 *
	 * @param int $rule_id Rule post ID.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function snapshot_rule( $rule_id ) {
		$post = $this->resolve_post( $rule_id );
		if ( is_wp_error( $post ) ) {
			return $post;
		}

		$stored = get_post_meta( $rule_id, 'wc_quote_rules', true );

		return array(
			'rule_id'       => $rule_id,
			'post_title'    => (string) $post->post_title,
			'post_status'   => (string) $post->post_status,
			'menu_order'    => (int) $post->menu_order,
			'enable_rule'   => (string) get_post_meta( $rule_id, 'enable_rule', true ),
			'wc_quote_rules' => is_array( $stored ) ? $stored : array(),
		);
	}

	/**
	 * Restore rule snapshot after update.
	 *
	 * @param array<string, mixed> $snapshot Snapshot data.
	 * @return true|\WP_Error
	 */
	public function restore_rule( array $snapshot ) {
		$rule_id = (int) ( isset( $snapshot['rule_id'] ) ? $snapshot['rule_id'] : 0 );
		if ( $rule_id <= 0 || ! get_post( $rule_id ) ) {
			return new \WP_Error(
				'wwp_quote_rule_restore_invalid_snapshot',
				__( 'Cannot restore quote rule: invalid snapshot.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		wp_update_post(
			array(
				'ID'          => $rule_id,
				'post_title'  => (string) ( isset( $snapshot['post_title'] ) ? $snapshot['post_title'] : '' ),
				'post_status' => (string) ( isset( $snapshot['post_status'] ) ? $snapshot['post_status'] : 'publish' ),
				'menu_order'  => (int) ( isset( $snapshot['menu_order'] ) ? $snapshot['menu_order'] : 0 ),
			)
		);

		update_post_meta( $rule_id, 'enable_rule', (string) ( isset( $snapshot['enable_rule'] ) ? $snapshot['enable_rule'] : '0' ) );
		update_post_meta( $rule_id, 'wc_quote_rules', is_array( isset( $snapshot['wc_quote_rules'] ) ? $snapshot['wc_quote_rules'] : null ) ? $snapshot['wc_quote_rules'] : array() );

		return true;
	}

	/**
	 * Recreate a deleted quote rule from snapshot.
	 *
	 * @param array<string, mixed> $snapshot Snapshot data.
	 * @return int|\WP_Error
	 */
	public function restore_deleted_rule( array $snapshot ) {
		$post_id = wp_insert_post(
			array(
				'post_type'   => $this->get_post_type(),
				'post_title'  => (string) ( isset( $snapshot['post_title'] ) ? $snapshot['post_title'] : __( 'Restored Quote Rule', 'woocommerce-wholesale-pricing' ) ),
				'post_status' => (string) ( isset( $snapshot['post_status'] ) ? $snapshot['post_status'] : 'publish' ),
				'menu_order'  => (int) ( isset( $snapshot['menu_order'] ) ? $snapshot['menu_order'] : 0 ),
			),
			true
		);

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		update_post_meta( $post_id, 'enable_rule', (string) ( isset( $snapshot['enable_rule'] ) ? $snapshot['enable_rule'] : '0' ) );
		update_post_meta( $post_id, 'wc_quote_rules', is_array( isset( $snapshot['wc_quote_rules'] ) ? $snapshot['wc_quote_rules'] : null ) ? $snapshot['wc_quote_rules'] : array() );

		return (int) $post_id;
	}

	/**
	 * Get the post type for quote rules, allowing for dynamic filtering.
	 * 
	 * @return string
	 */
	public function get_post_type() {
		if ( function_exists( 'wwp_env' ) ) {
			$slug = (string) wwp_env()->get( 'quote_rules_slug' );
			if ( '' !== $slug ) {
				return $slug;
			}
		}

		return 'wc-quote-rules';
	}

	/**
	 * Format a quote rule into API representation.
	 * 
	 * @param int $rule_id Rule post ID.
	 * @return array<string, mixed>
	 */
	private function format_rule( $rule_id ) {
		$post = get_post( $rule_id );
		$stored = get_post_meta( $rule_id, 'wc_quote_rules', true );
		$stored = is_array( $stored ) ? $stored : array();

		return array(
			'id'       => $rule_id,
			'title'    => $post ? (string) $post->post_title : '',
			'status'   => $post ? (string) $post->post_status : 'publish',
			'priority' => $post ? (int) $post->menu_order : 0,
			'enabled'  => '1' === (string) get_post_meta( $rule_id, 'enable_rule', true ),
			'rule'     => $this->storage_to_api( $stored ),
		);
	}

	/**
	 * Sanitize and format stored rules array into API representation.
	 * 
	 * @param array<string, mixed> $stored Stored wc_quote_rules array.
	 * @return array<string, mixed>
	 */
	private function storage_to_api( array $stored ) {
		$user_mode    = isset( $stored['user_roles']['toggle'] ) ? (string) $stored['user_roles']['toggle'] : 'all';
		$include_mode = isset( $stored['include_products']['toggle'] ) ? (string) $stored['include_products']['toggle'] : 'all';
		$exclude_mode = isset( $stored['exclude_products']['toggle'] ) ? (string) $stored['exclude_products']['toggle'] : 'product';

		$user_roles = array( 'mode' => $user_mode );
		if ( 'specific' === $user_mode ) {
			$user_roles['roles'] = array_values(
				array_map(
					'strval',
					(array) ( isset( $stored['user_roles']['specific'] ) ? $stored['user_roles']['specific'] : array() )
				)
			);
		} elseif ( 'specific_users' === $user_mode ) {
			$user_roles['users'] = $this->format_user_refs( (array) ( isset( $stored['user_roles']['specific_users'] ) ? $stored['user_roles']['specific_users'] : array() ) );
		}

		return array(
			'user_roles'         => $user_roles,
			'include'            => array(
				'mode'       => $include_mode,
				'products'   => $this->format_product_refs( (array) ( isset( $stored[ 'include_' . $include_mode ] ) ? $stored[ 'include_' . $include_mode ] : array() ), $include_mode ),
				'categories' => $this->format_category_refs( (array) ( isset( $stored[ 'include_' . $include_mode ] ) ? $stored[ 'include_' . $include_mode ] : array() ), $include_mode ),
				'tags'       => $this->format_tag_refs( (array) ( isset( $stored[ 'include_' . $include_mode ] ) ? $stored[ 'include_' . $include_mode ] : array() ), $include_mode ),
			),
			'exclude'            => array(
				'mode'       => $exclude_mode,
				'products'   => $this->format_product_refs( (array) ( isset( $stored[ 'exclude_' . $exclude_mode ] ) ? $stored[ 'exclude_' . $exclude_mode ] : array() ), $exclude_mode ),
				'categories' => $this->format_category_refs( (array) ( isset( $stored[ 'exclude_' . $exclude_mode ] ) ? $stored[ 'exclude_' . $exclude_mode ] : array() ), $exclude_mode ),
				'tags'       => $this->format_tag_refs( (array) ( isset( $stored[ 'exclude_' . $exclude_mode ] ) ? $stored[ 'exclude_' . $exclude_mode ] : array() ), $exclude_mode ),
			),
			'quote_status'       => (string) ( isset( $stored['wc_custom_quote_status'] ) ? $stored['wc_custom_quote_status'] : 'quote_new' ),
			'hide_price'         => $this->to_bool( isset( $stored['hide_price'] ) ? $stored['hide_price'] : '0' ),
			'hide_price_message' => (string) ( isset( $stored['hide_price_msg'] ) ? $stored['hide_price_msg'] : '' ),
			'show_single'        => $this->to_bool( isset( $stored['show_single'] ) ? $stored['show_single'] : '0' ),
			'show_shop'          => $this->to_bool( isset( $stored['show_shop'] ) ? $stored['show_shop'] : '0' ),
			'hide_cart_single'   => $this->to_bool( isset( $stored['hide_cart_single'] ) ? $stored['hide_cart_single'] : '0' ),
			'hide_cart_shop'     => $this->to_bool( isset( $stored['hide_cart_shop'] ) ? $stored['hide_cart_shop'] : '0' ),
			'hide_cart_all'      => $this->to_bool( isset( $stored['hide_cart_all'] ) ? $stored['hide_cart_all'] : '0' ),
		);
	}

	/**
	 * Build storage array from API payload, merging with existing stored data for partial updates.
	 * 
	 * @param array<string, mixed> $existing Existing stored rules.
	 * @param array<string, mixed> $payload  API payload.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function build_storage_from_payload( array $existing, array $payload ) {
		$payload = $this->normalize_incoming_payload( $payload );
		$api    = $this->storage_to_api( $existing );
		$merged = $this->merge_api_patch( $api, $payload );

		$stored = $existing;

		$user_mode = sanitize_key( (string) ( isset( $merged['user_roles']['mode'] ) ? $merged['user_roles']['mode'] : 'all' ) );
		if ( ! in_array( $user_mode, self::USER_ROLE_MODES, true ) ) {
			return new \WP_Error(
				'wwp_quote_rule_invalid_user_role_mode',
				__( 'user_roles.mode must be all, specific, or specific_users.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$include_mode = sanitize_key( (string) ( isset( $merged['include']['mode'] ) ? $merged['include']['mode'] : 'all' ) );
		if ( ! in_array( $include_mode, self::INCLUDE_MODES, true ) ) {
			return new \WP_Error(
				'wwp_quote_rule_invalid_include_mode',
				__( 'include.mode must be all, product, category, or tag.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$exclude_mode = sanitize_key( (string) ( isset( $merged['exclude']['mode'] ) ? $merged['exclude']['mode'] : 'product' ) );
		if ( ! in_array( $exclude_mode, self::EXCLUDE_MODES, true ) ) {
			return new \WP_Error(
				'wwp_quote_rule_invalid_exclude_mode',
				__( 'exclude.mode must be product, category, or tag.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$quote_status = sanitize_key( (string) ( isset( $merged['quote_status'] ) ? $merged['quote_status'] : 'quote_new' ) );
		if ( ! $this->is_valid_quote_status( $quote_status ) ) {
			return new \WP_Error(
				'wwp_quote_rule_invalid_quote_status',
				__( 'Invalid quote_status value.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$user_targets = $this->resolve_user_role_targets( $user_mode, isset( $merged['user_roles'] ) ? $merged['user_roles'] : array() );
		if ( is_wp_error( $user_targets ) ) {
			return $user_targets;
		}

		$include_targets = $this->resolve_product_targets( $include_mode, isset( $merged['include'] ) ? $merged['include'] : array() );
		if ( is_wp_error( $include_targets ) ) {
			return $include_targets;
		}

		$exclude_targets = $this->resolve_product_targets( $exclude_mode, isset( $merged['exclude'] ) ? $merged['exclude'] : array() );
		if ( is_wp_error( $exclude_targets ) ) {
			return $exclude_targets;
		}

		$stored['user_roles'] = array( 'toggle' => $user_mode );
		$stored['user_roles'][ $user_mode ] = $user_targets;

		$stored['include_products'] = array( 'toggle' => $include_mode );
		$stored['exclude_products'] = array( 'toggle' => $exclude_mode );

		foreach ( array( 'product', 'category', 'tag' ) as $type ) {
			unset( $stored[ 'include_' . $type ], $stored[ 'exclude_' . $type ] );
		}

		if ( 'all' !== $include_mode ) {
			$stored[ 'include_' . $include_mode ] = $include_targets;
		}

		$stored[ 'exclude_' . $exclude_mode ] = $exclude_targets;

		$stored['wc_custom_quote_status'] = $quote_status;
		$stored['hide_price']             = $this->from_bool( isset( $merged['hide_price'] ) ? $merged['hide_price'] : false );
		$stored['hide_price_msg']         = isset( $merged['hide_price_message'] ) ? wp_kses_post( (string) $merged['hide_price_message'] ) : (string) ( isset( $stored['hide_price_msg'] ) ? $stored['hide_price_msg'] : '' );
		$stored['show_single']            = $this->from_bool( isset( $merged['show_single'] ) ? $merged['show_single'] : false );
		$stored['show_shop']              = $this->from_bool( isset( $merged['show_shop'] ) ? $merged['show_shop'] : false );
		$stored['hide_cart_single']       = $this->from_bool( isset( $merged['hide_cart_single'] ) ? $merged['hide_cart_single'] : false );
		$stored['hide_cart_shop']         = $this->from_bool( isset( $merged['hide_cart_shop'] ) ? $merged['hide_cart_shop'] : false );
		$stored['hide_cart_all']          = $this->from_bool( isset( $merged['hide_cart_all'] ) ? $merged['hide_cart_all'] : false );

		return $this->normalize_storage( $stored );
	}

	/**
	 * Merge API patch into existing API representation, without modifying the stored format yet.
	 * 
	 * @param array<string, mixed> $api     Current API representation.
	 * @param array<string, mixed> $payload Incoming patch.
	 * @return array<string, mixed>
	 */
	private function merge_api_patch( array $api, array $payload ) {
		if ( isset( $payload['rule'] ) && is_array( $payload['rule'] ) ) {
			$payload = array_merge( $payload, $payload['rule'] );
			unset( $payload['rule'] );
		}

		$map = array(
			'user_roles'         => 'user_roles',
			'include'            => 'include',
			'exclude'            => 'exclude',
			'quote_status'       => 'quote_status',
			'hide_price'         => 'hide_price',
			'hide_price_message' => 'hide_price_message',
			'show_single'        => 'show_single',
			'show_shop'          => 'show_shop',
			'hide_cart_single'   => 'hide_cart_single',
			'hide_cart_shop'     => 'hide_cart_shop',
			'hide_cart_all'      => 'hide_cart_all',
		);

		foreach ( $map as $key => $target ) {
			if ( array_key_exists( $key, $payload ) ) {
				if ( in_array( $key, array( 'user_roles', 'include', 'exclude' ), true ) && is_array( $payload[ $key ] ) ) {
					$api[ $target ] = array_merge( is_array( isset( $api[ $target ] ) ? $api[ $target ] : null ) ? $api[ $target ] : array(), $payload[ $key ] );
				} else {
					$api[ $target ] = $payload[ $key ];
				}
			}
		}

		return $api;
	}

	/**
	 * Normalize AI/API aliases and infer include/exclude modes from target lists.
	 *
	 * @param array<string, mixed> $payload Incoming rule payload.
	 * @return array<string, mixed>
	 */
	private function normalize_incoming_payload( array $payload ) {
		if ( isset( $payload['rule'] ) && is_array( $payload['rule'] ) ) {
			$payload = array_merge( $payload, $payload['rule'] );
			unset( $payload['rule'] );
		}

		if ( isset( $payload['user_roles'] ) && is_array( $payload['user_roles'] ) ) {
			if ( ! isset( $payload['user_roles']['mode'] ) && isset( $payload['user_roles']['scope'] ) ) {
				$payload['user_roles']['mode'] = sanitize_key( (string) $payload['user_roles']['scope'] );
			}
		}

		foreach ( array( 'include', 'exclude' ) as $section ) {
			if ( ! isset( $payload[ $section ] ) || ! is_array( $payload[ $section ] ) ) {
				continue;
			}

			$inferred_mode = $this->infer_product_target_mode( $payload[ $section ] );
			if ( null === $inferred_mode ) {
				continue;
			}

			$current_mode = isset( $payload[ $section ]['mode'] ) ? sanitize_key( (string) $payload[ $section ]['mode'] ) : '';

			if ( '' === $current_mode || ( 'include' === $section && 'all' === $current_mode ) ) {
				$payload[ $section ]['mode'] = $inferred_mode;
			}
		}

		return $payload;
	}

	/**
	 * Infer product/category/tag mode from populated target lists.
	 *
	 * @param array<string, mixed> $section Include or exclude payload section.
	 * @return string|null
	 */
	private function infer_product_target_mode( array $section ) {
		foreach (
			array(
				'products'   => 'product',
				'categories' => 'category',
				'tags'       => 'tag',
			) as $key => $mode
		) {
			if ( $this->has_target_values( isset( $section[ $key ] ) ? $section[ $key ] : null ) ) {
				return $mode;
			}
		}

		return null;
	}

	/**
	 * Whether a target list contains at least one value.
	 *
	 * @param mixed $values Target list.
	 * @return bool
	 */
	private function has_target_values( $values ) {
		if ( ! is_array( $values ) ) {
			return false;
		}

		foreach ( $values as $value ) {
			if ( is_array( $value ) ) {
				if ( ! empty( $value['id'] ) || ! empty( $value['slug'] ) || ! empty( $value['name'] ) ) {
					return true;
				}
				continue;
			}

			if ( null !== $value && '' !== $value ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Mirror admin save normalization.
	 *
	 * @param array<string, mixed> $stored Stored rules.
	 * @return array<string, mixed>
	 */
	private function normalize_storage( array $stored ) {
		$user_type = isset( $stored['user_roles']['toggle'] ) ? (string) $stored['user_roles']['toggle'] : 'all';
		if ( empty( $stored['user_roles'][ $user_type ] ) ) {
			$stored['user_roles']['toggle'] = 'all';
			$stored['user_roles']['all']    = array( 0 => 0 );
		}

		$include_type = isset( $stored['include_products']['toggle'] ) ? (string) $stored['include_products']['toggle'] : 'all';
		if ( 'all' !== $include_type && empty( $stored[ 'include_' . $include_type ] ) ) {
			$stored['include_products']['toggle'] = 'all';
		}

		$exclude_type = isset( $stored['exclude_products']['toggle'] ) ? (string) $stored['exclude_products']['toggle'] : 'product';
		if ( empty( $stored[ 'exclude_' . $exclude_type ] ) ) {
			$stored['exclude_products']['toggle'] = 'product';
		}

		return $stored;
	}

	/**
	 * Persist rule meta after create/update.
	 * 
	 * @param int                  $rule_id Rule post ID.
	 * @param array<string, mixed> $stored  Stored rules array.
	 * @param array<string, mixed> $payload Original payload.
	 * @return void
	 */
	private function persist_rule_meta( $rule_id, array $stored, array $payload ) {
		$enabled = array_key_exists( 'enabled', $payload )
			? ( $payload['enabled'] ? '1' : '0' )
			: ( isset( $payload['rule']['enabled'] ) ? ( $payload['rule']['enabled'] ? '1' : '0' ) : (string) get_post_meta( $rule_id, 'enable_rule', true ) );

		if ( '' === $enabled && ! array_key_exists( 'enabled', $payload ) ) {
			$enabled = '1';
		}

		update_post_meta( $rule_id, 'enable_rule', $enabled ? '1' : '0' );
		update_post_meta( $rule_id, 'wc_quote_rules', $stored );
	}

	/**
	 * Resolve user role/user references to role slugs or user IDs.
	 * 
	 * @param string               $mode    User role mode.
	 * @param array<string, mixed> $payload User roles payload.
	 * @return list<mixed>|\WP_Error
	 */
	private function resolve_user_role_targets( $mode, array $payload ) {
		if ( 'all' === $mode ) {
			return array( 0 => 0 );
		}

		if ( 'specific' === $mode ) {
			$roles = isset( $payload['roles'] ) ? (array) $payload['roles'] : array();
			$roles = array_values(
				array_filter(
					array_map(
						static function ( $role ) {
							return sanitize_key( (string) $role );
						},
						$roles
					)
				)
			);

			if ( empty( $roles ) ) {
				return new \WP_Error(
					'wwp_quote_rule_missing_roles',
					__( 'At least one role is required when user_roles.mode is specific.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			return $roles;
		}

		$users = isset( $payload['users'] ) ? (array) $payload['users'] : ( isset( $payload['user_ids'] ) ? (array) $payload['user_ids'] : array() );
		$ids   = array();

		foreach ( $users as $user_ref ) {
			$user = null;
			if ( is_numeric( $user_ref ) ) {
				$user = get_user_by( 'id', (int) $user_ref );
			} else {
				$email = sanitize_email( (string) $user_ref );
				if ( '' !== $email && is_email( $email ) ) {
					$user = get_user_by( 'email', $email );
				}
				if ( ! $user ) {
					$user = get_user_by( 'login', sanitize_user( (string) $user_ref, true ) );
				}
			}

			if ( ! $user ) {
				return new \WP_Error(
					'wwp_quote_rule_invalid_user',
					sprintf(
						/* translators: %s: user identifier */
						__( 'Unknown user: %s', 'woocommerce-wholesale-pricing' ),
						(string) $user_ref
					),
					array( 'status' => 400 )
				);
			}

			$ids[] = (int) $user->ID;
		}

		if ( empty( $ids ) ) {
			return new \WP_Error(
				'wwp_quote_rule_missing_users',
				__( 'At least one user is required when user_roles.mode is specific_users.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Resolve product/category/tag references to IDs/slugs.
	 * 
	 * @param string               $mode    Target mode.
	 * @param array<string, mixed> $payload Include/exclude payload.
	 * @return list<mixed>|\WP_Error
	 */
	private function resolve_product_targets( $mode, array $payload ) {
		if ( 'all' === $mode ) {
			return array();
		}

		if ( 'product' === $mode ) {
			return $this->resolve_product_ids( isset( $payload['products'] ) ? $payload['products'] : array() );
		}

		if ( 'category' === $mode ) {
			return $this->resolve_category_slugs( isset( $payload['categories'] ) ? $payload['categories'] : array() );
		}

		return $this->resolve_tag_slugs( isset( $payload['tags'] ) ? $payload['tags'] : array() );
	}

	/**
	 * Resolve product references to IDs.
	 * 
	 * @param mixed $products Product refs.
	 * @return list<int>|\WP_Error
	 */
	private function resolve_product_ids( $products ) {
		if ( ! is_array( $products ) ) {
			return array();
		}

		$ids = array();
		foreach ( $products as $product_ref ) {
			if ( is_array( $product_ref ) ) {
				if ( isset( $product_ref['id'] ) && is_numeric( $product_ref['id'] ) ) {
					$product_ref = (int) $product_ref['id'];
				} elseif ( isset( $product_ref['slug'] ) ) {
					$product_ref = (string) $product_ref['slug'];
				} elseif ( isset( $product_ref['name'] ) ) {
					$product_ref = (string) $product_ref['name'];
				}
			}

			$product_id = 0;
			if ( is_numeric( $product_ref ) ) {
				$product_id = (int) $product_ref;
			} else {
				$ref = (string) $product_ref;
				if ( function_exists( 'wc_get_product_id_by_sku' ) ) {
					$product_id = (int) wc_get_product_id_by_sku( $ref );
				}
				if ( $product_id <= 0 ) {
					$posts = get_posts(
						array(
							'name'           => sanitize_title( $ref ),
							'post_type'      => 'product',
							'post_status'    => 'any',
							'posts_per_page' => 1,
							'fields'         => 'ids',
						)
					);
					$product_id = ! empty( $posts ) ? (int) $posts[0] : 0;
				}
				if ( $product_id <= 0 ) {
					$posts = get_posts(
						array(
							'post_type'      => 'product',
							'post_status'    => 'any',
							'posts_per_page' => 10,
							'fields'         => 'ids',
							's'              => $ref,
						)
					);
					foreach ( $posts as $candidate_id ) {
						$candidate = wc_get_product( (int) $candidate_id );
						if ( $candidate && 0 === strcasecmp( (string) $candidate->get_name(), $ref ) ) {
							$product_id = (int) $candidate_id;
							break;
						}
					}
				}
			}

			if ( $product_id <= 0 || ! wc_get_product( $product_id ) ) {
				return new \WP_Error(
					'wwp_quote_rule_invalid_product',
					sprintf(
						/* translators: %s: product identifier */
						__( 'Unknown product: %s', 'woocommerce-wholesale-pricing' ),
						(string) $product_ref
					),
					array( 'status' => 400 )
				);
			}

			$ids[] = $product_id;
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Resolve category references to slugs.
	 * 
	 * @param mixed $categories Category refs.
	 * @return list<string>|\WP_Error
	 */
	private function resolve_category_slugs( $categories ) {
		if ( ! is_array( $categories ) ) {
			return array();
		}

		$slugs = array();
		foreach ( $categories as $category_ref ) {
			if ( is_numeric( $category_ref ) ) {
				$term = get_term( (int) $category_ref, 'product_cat' );
			} else {
				$term = get_term_by( 'slug', sanitize_title( (string) $category_ref ), 'product_cat' );
				if ( ! $term ) {
					$term = get_term_by( 'name', (string) $category_ref, 'product_cat' );
				}
			}

			if ( ! $term || is_wp_error( $term ) ) {
				return new \WP_Error(
					'wwp_quote_rule_invalid_category',
					sprintf(
						/* translators: %s: category identifier */
						__( 'Unknown product category: %s', 'woocommerce-wholesale-pricing' ),
						(string) $category_ref
					),
					array( 'status' => 400 )
				);
			}

			$slugs[] = (string) $term->slug;
		}

		return array_values( array_unique( $slugs ) );
	}

	/**
	 * Resolve tag references to slugs.
	 * 
	 * @param mixed $tags Tag refs.
	 * @return list<string>|\WP_Error
	 */
	private function resolve_tag_slugs( $tags ) {
		if ( ! is_array( $tags ) ) {
			return array();
		}

		$slugs = array();
		foreach ( $tags as $tag_ref ) {
			if ( is_numeric( $tag_ref ) ) {
				$term = get_term( (int) $tag_ref, 'product_tag' );
			} else {
				$term = get_term_by( 'slug', sanitize_title( (string) $tag_ref ), 'product_tag' );
				if ( ! $term ) {
					$term = get_term_by( 'name', (string) $tag_ref, 'product_tag' );
				}
			}

			if ( ! $term || is_wp_error( $term ) ) {
				return new \WP_Error(
					'wwp_quote_rule_invalid_tag',
					sprintf(
						/* translators: %s: tag identifier */
						__( 'Unknown product tag: %s', 'woocommerce-wholesale-pricing' ),
						(string) $tag_ref
					),
					array( 'status' => 400 )
				);
			}

			$slugs[] = (string) $term->slug;
		}

		return array_values( array_unique( $slugs ) );
	}

	/**
	 * Format product references for API output.
	 * 
	 * @param array<int, mixed> $values Stored values.
	 * @param string            $mode   Active mode.
	 * @return list<array<string, mixed>>
	 */
	private function format_product_refs( array $values, $mode ) {
		if ( 'product' !== $mode ) {
			return array();
		}

		$refs = array();
		foreach ( $values as $id ) {
			$product = wc_get_product( (int) $id );
			if ( ! $product ) {
				continue;
			}
			$refs[] = array(
				'id'   => (int) $product->get_id(),
				'slug' => (string) $product->get_slug(),
				'name' => (string) $product->get_name(),
			);
		}

		return $refs;
	}

	/**
	 * Format category references for API output.
	 * 
	 * @param array<int, mixed> $values Stored values.
	 * @param string            $mode   Active mode.
	 * @return list<array<string, mixed>>
	 */
	private function format_category_refs( array $values, $mode ) {
		if ( 'category' !== $mode ) {
			return array();
		}

		$refs = array();
		foreach ( $values as $slug ) {
			$term = get_term_by( 'slug', (string) $slug, 'product_cat' );
			if ( ! $term || is_wp_error( $term ) ) {
				continue;
			}
			$refs[] = array(
				'id'   => (int) $term->term_id,
				'slug' => (string) $term->slug,
				'name' => (string) $term->name,
			);
		}

		return $refs;
	}

	/**
	 * Format tag references for API output.
	 * 
	 * @param array<int, mixed> $values Stored values.
	 * @param string            $mode   Active mode.
	 * @return list<array<string, mixed>>
	 */
	private function format_tag_refs( array $values, $mode ) {
		if ( 'tag' !== $mode ) {
			return array();
		}

		$refs = array();
		foreach ( $values as $slug ) {
			$term = get_term_by( 'slug', (string) $slug, 'product_tag' );
			if ( ! $term || is_wp_error( $term ) ) {
				continue;
			}
			$refs[] = array(
				'id'   => (int) $term->term_id,
				'slug' => (string) $term->slug,
				'name' => (string) $term->name,
			);
		}

		return $refs;
	}

	/**
	 * Format user references for API output.
	 * 
	 * @param array<int, mixed> $values User IDs.
	 * @return list<array<string, mixed>>
	 */
	private function format_user_refs( array $values ) {
		$refs = array();
		foreach ( $values as $user_id ) {
			$user = get_user_by( 'id', (int) $user_id );
			if ( ! $user ) {
				continue;
			}
			$refs[] = array(
				'id'           => (int) $user->ID,
				'user_login'   => (string) $user->user_login,
				'user_email'   => (string) $user->user_email,
				'display_name' => (string) $user->display_name,
			);
		}

		return $refs;
	}

	/**
	 * Indicates whether the given quote status is valid.
	 * 
	 * @param string $status Quote status key.
	 * @return bool
	 */
	private function is_valid_quote_status( $status ) {
		if ( in_array( $status, self::QUOTE_STATUSES, true ) ) {
			return true;
		}

		if ( function_exists( 'check_quote_status' ) && check_quote_status() ) {
			$posts = get_posts(
				array(
					'post_type'      => 'wc-quote-status',
					'post_status'    => 'any',
					'posts_per_page' => -1,
					'fields'         => 'ids',
				)
			);

			foreach ( $posts as $post_id ) {
				$meta = get_post_meta( (int) $post_id, 'wc_quote_status', true );
				$key  = is_array( $meta ) && isset( $meta['quote_status'] ) ? (string) $meta['quote_status'] : get_post_field( 'post_name', (int) $post_id );
				if ( $status === $key ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Transform stored boolean-like values to actual booleans.
	 * 
	 * @param mixed $value Stored value.
	 * @return bool
	 */
	private function to_bool( $value ) {
		return (bool) $value && '0' !== (string) $value && '' !== (string) $value;
	}

	/**
	 * Format boolean for storage as '1' or '0'.
	 * 
	 * @param mixed $value API value.
	 * @return string
	 */
	private function from_bool( $value ) {
		if ( is_bool( $value ) ) {
			return $value ? '1' : '0';
		}

		return in_array( $value, array( '1', 1, 'yes', true ), true ) ? '1' : '0';
	}

	/**
	 * Retrieve and validate the quote rule post.
	 * 
	 * @param int $rule_id Rule post ID.
	 * @return \WP_Post|\WP_Error
	 */
	private function resolve_post( $rule_id ) {
		$post = get_post( $rule_id );
		if ( ! $post || $this->get_post_type() !== $post->post_type ) {
			return new \WP_Error(
				'wwp_quote_rule_not_found',
				__( 'Quote rule not found.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		return $post;
	}
}
