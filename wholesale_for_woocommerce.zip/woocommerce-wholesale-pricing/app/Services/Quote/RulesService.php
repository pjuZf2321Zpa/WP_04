<?php
/**
 * QuoteRulesService class.
 *
 * Handles complex quote rule post type registration and management, including dependency checks for enabling quote rules features.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services\Quote;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Service responsible for hiding products from non-wholesalers and controlling access.
 * 
 * @implements ServiceInterface
 */
class RulesService implements ServiceInterface {
	use WholesaleSettings;

	public function __construct() {

		$slug = wwp_env()->get('quote_rules_slug');

		add_action('add_meta_boxes', array( $this, 'wc_quote_rules_register_metabox' ));
		add_action('save_post_' . $slug, array( $this, 'wc_quote_save_rules' ), 10, 3);
		add_filter('manage_' . $slug . '_posts_columns', array( $this, 'wc_quote_rules_modify_column_names' ));
		add_action('manage_' . $slug . '_posts_custom_column', array( $this, 'wc_quote_rules_add_column_data' ), 9, 2);
		add_filter('manage_edit-' . $slug . '_sortable_columns', array( $this, 'wc_quote_rules_register_sortable' ));
		add_filter('post_row_actions', array( $this, 'get_row_actions' ), 100, 2);
	}

	public function wc_quote_rules_register_metabox() {

		add_meta_box( 
			'wc-quote-rules-data',
			__('Rules Setup', 'woocommerce-wholesale-pricing'),
			array( $this, 'wc_quote_rules_main_meta_html' ),
			'wc-quote-rules',
			'advanced',
			'high'
		);

		add_meta_box( 
			'wc-quote-rules-buttons',
			__('Show Add to Quote Button', 'woocommerce-wholesale-pricing'),
			array( $this, 'wc_quote_rules_show_button_html' ),
			'wc-quote-rules',
			'advanced',
			'high'
		);
	}

	public function wc_quote_rules_main_meta_html( $post ) {
		wwp_view('admin.quote.rules.metabox.rules', compact( 'post' ));
	}

	public function wc_quote_rules_show_button_html( $post ) {
		wwp_view('admin.quote.rules.metabox.buttons', compact( 'post' ));
	}

		
	/**
	 * SAve Rules data 
	 *
	 * @param  mixed $post_id
	 * @param  mixed $post
	 * @return void
	 */
	public function wc_quote_save_rules( $post_id, $post ) {
		if ('wc-quote-rules' !== $post->post_type ) {
			return;
		}

		if (!isset($_POST['_wpnonce']) ) {
			return;
		}

		// if our nonce isn't there, or we can't verify it, return
		if (isset($_POST['_wpnonce']) && ! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'])), 'update-post_' . $post_id) ) {
			return;
		}
		
		update_post_meta( $post_id, 'enable_rule', isset($_REQUEST['enable_rule']) ? sanitize_text_field(wp_unslash($_REQUEST['enable_rule'])) : '0' );

		$rules_data = isset($_REQUEST['wc_quote_rules']) ? sanitize_meta('', wp_unslash($_REQUEST['wc_quote_rules']), '') : '';
			

		$user_type = $rules_data['user_roles']['toggle'];
		if ( !isset($rules_data['user_roles'][$user_type])) {
			$rules_data['user_roles']['toggle'] = 'all';
		}
		$include_type = $rules_data['include_products']['toggle'];
		if (!isset($rules_data['include_' . $include_type]) ) {
			$rules_data['include_products']['toggle'] = 'all';
		}
		$exclude_type = $rules_data['exclude_products']['toggle'];
		if (!isset($rules_data['exclude_' . $exclude_type]) ) {
			$rules_data['exclude_products']['toggle'] = 'product';
		}
		update_post_meta($post_id, 'wc_quote_rules', $rules_data);
		clear_quote_rules_cache();
	}

	/**
	* Modify and add custom columns for the WC Quote Rules post type.
	*/
	public function wc_quote_rules_modify_column_names( $columns ) {
		unset($columns['date']);
		$columns['rules_roles'] = esc_html__('Roles', 'woocommerce-wholesale-pricing');
		$columns['menu_order'] = esc_html__('Priority', 'woocommerce-wholesale-pricing');
		$columns['date'] = esc_html__('Date', 'woocommerce-wholesale-pricing');
		return $columns;
	}

	/**
	 * Populate data for custom columns in WC Quote Rules admin table.
	 */
	public function wc_quote_rules_add_column_data( $column, $postId ) {

		switch ($column) {

			case 'rules_roles':
				$quote_rules = get_post_meta($postId, 'wc_quote_rules', true);
				$user_roles = isset($quote_rules['user_roles']['toggle']) ? $quote_rules['user_roles']['toggle'] : 'all';
				$select_roles = isset($quote_rules['user_roles'][$user_roles]) ? $quote_rules['user_roles'][$user_roles] : array( 0 => 0 );

				if ('specific' === $user_roles && is_array($select_roles) ) :
					$select_roles = implode(', ', $select_roles);
					printf('%s', esc_attr($select_roles));
			else :
				printf('%s', esc_attr($user_roles));
			endif;
				break;
			case 'menu_order':
				$priority = get_post($postId)->menu_order;
				echo esc_attr($priority);
				break;

		}    
	}
	
	/**
	 * Quote rules register sortable columns
	 *
	 * @param  mixed $columns
	 * @return void
	 */
	public function wc_quote_rules_register_sortable( $columns ) {
		$columns['menu_order'] = esc_html__('Priority', 'woocommerce-wholesale-pricing');
		return $columns;
	}

	/**
	 * Remove inline edit for each quote.
	 */
	public function get_row_actions( $actions, $post ) {
		if ('wc-quote' === $post->post_type || 'wc-quote-rules' === $post->post_type ) :
			unset($actions['inline']);
			unset($actions['inline hide-if-no-js']);
		endif;
		return $actions;
	}

	public static function resolveDependency() {
		$settings = self::get_pricing_settings();
		return ( is_admin() && isset( $settings['enable_quote'] ) && 'yes' === $settings['enable_quote'] );
	}
}
