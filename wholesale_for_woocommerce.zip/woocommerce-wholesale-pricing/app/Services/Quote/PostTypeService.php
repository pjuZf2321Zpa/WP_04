<?php

namespace WooCommerceWholesalePricing\App\Services\Quote;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\Init;

/**
 * Service for registering wholesale-related custom post types.
 * 
 * @extends Init
 */
class PostTypeService extends Init {
	use WholesaleSettings;

	public function __construct() {
		parent::__construct();        
	}

	public function register() {
		
		$settings = self::get_pricing_settings();

		if ( ! isset( $settings['enable_quote'] ) || 'no' === $settings['enable_quote'] ) {
			return;
		}

		$quote_count = is_admin() ? get_quotes_count( 'quote_new' ) : 0;
		register_post_type(
			'wc-quote',
			/**
			* Filter wc_quote_register_post_type
			* 
			* @since 1.0
			**/
			apply_filters(
				'wc_quote_register_post_type',
				array(
				'labels'              => array(
				'name'                  => __('Quotes', 'woocommerce-wholesale-pricing'),
				'singular_name'         => _x('Quote', 'wc-quote post type singular name', 'woocommerce-wholesale-pricing'),
				'all_items'             => $quote_count ? __('Quotes', 'woocommerce-wholesale-pricing') . ' <span class="awaiting-mod count-' . esc_attr($quote_count) . '"><span class="new-count">' . number_format_i18n($quote_count) . '</span></span>' : __('Quotes', 'woocommerce-wholesale-pricing'),
				'add_new'               => __('Add quote', 'woocommerce-wholesale-pricing'),
				'add_new_item'          => __('Add new quote', 'woocommerce-wholesale-pricing'),
				'edit'                  => __('Edit', 'woocommerce-wholesale-pricing'),
				'edit_item'             => __('Edit quote', 'woocommerce-wholesale-pricing'),
				'new_item'              => __('New quote', 'woocommerce-wholesale-pricing'),
				'view_item'             => __('View quote', 'woocommerce-wholesale-pricing'),
				'search_items'          => __('Search quotes', 'woocommerce-wholesale-pricing'),
				'not_found'             => __('No quotes found', 'woocommerce-wholesale-pricing'),
				'not_found_in_trash'    => __('No quotes found in trash', 'woocommerce-wholesale-pricing'),
				'parent'                => __('Parent quotes', 'woocommerce-wholesale-pricing'),
				'menu_name'             => _x('WC Quote', 'Admin menu name', 'woocommerce-wholesale-pricing'),
				'filter_items_list'     => __('Filter quotes', 'woocommerce-wholesale-pricing'),
				'items_list_navigation' => __('Quotes navigation', 'woocommerce-wholesale-pricing'),
				'items_list'            => __('Quotes list', 'woocommerce-wholesale-pricing'),
					),
					'description'         => __('This is where quotes are stored.', 'woocommerce-wholesale-pricing'),
					'public'              => false,
					'show_ui'             => true,
					'map_meta_cap'        => true,
					'publicly_queryable'  => false,
					'exclude_from_search' => true,
					'show_in_menu'        => 'wc-quote',
					'hierarchical'        => false,
					'show_in_nav_menus'   => false,
					'rewrite'             => false,
					'query_var'           => false,
					'supports'            => array( 'title' ),
					'has_archive'         => false,
				)
			)
		);
		/**
		* Filter wc_quote_register_post_statuses
		* 
		* @since 1.0
		**/
		$quote_statuses = apply_filters(
			'wc_quote_register_post_statuses',
			array(
			'quote_draft'    => array(
			'label'                     => _x('Draft', 'Quote status', 'woocommerce-wholesale-pricing'),
			'public'                    => true,
			'exclude_from_search'       => false,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			/* translators: %s: number of quotes */
			'label_count'               => _n_noop('Draft <span class="count">(%s)</span>', 'Draft <span class="count">(%s)</span>', 'woocommerce-wholesale-pricing'),
			),
			'quote_new'    => array(
					'label'                     => _x('New', 'Quote status', 'woocommerce-wholesale-pricing'),
					'public'                    => true,
					'exclude_from_search'       => false,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
					/* translators: %s: number of quotes */
					'label_count'               => _n_noop('New <span class="count">(%s)</span>', 'New <span class="count">(%s)</span>', 'woocommerce-wholesale-pricing'),
			),
			'quote_quoted'    => array(
					'label'                     => _x('Quoted', 'Quote status', 'woocommerce-wholesale-pricing'),
					'public'                    => true,
					'exclude_from_search'       => false,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
					/* translators: %s: number of quotes */
					'label_count'               => _n_noop('Quoted <span class="count">(%s)</span>', 'Quoted <span class="count">(%s)</span>', 'woocommerce-wholesale-pricing'),
			),
			'quote_accepted'    => array(
					'label'                     => _x('Accepted', 'Quote status', 'woocommerce-wholesale-pricing'),
					'public'                    => true,
					'exclude_from_search'       => false,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
					/* translators: %s: number of quotes */
					'label_count'               => _n_noop('Accepted <span class="count">(%s)</span>', 'Accepted <span class="count">(%s)</span>', 'woocommerce-wholesale-pricing'),
			),
			'quote_converted'    => array(
					'label'                     => _x('Converted To Order', 'Quote status', 'woocommerce-wholesale-pricing'),
					'public'                    => true,
					'exclude_from_search'       => false,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
					/* translators: %s: number of quotes */
					'label_count'               => _n_noop('Converted To Order <span class="count">(%s)</span>', 'Converted To Order <span class="count">(%s)</span>', 'woocommerce-wholesale-pricing'),
			),
			'quote_rejected'  => array(
					'label'                     => _x('Rejected', 'Quote status', 'woocommerce-wholesale-pricing'),
					'public'                    => true,
					'exclude_from_search'       => false,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
					/* translators: %s: number of quotes */
					'label_count'               => _n_noop('Rejected <span class="count">(%s)</span>', 'Rejected <span class="count">(%s)</span>', 'woocommerce-wholesale-pricing'),
			),
			'quote_expired'  => array(
					'label'                     => _x('Expired', 'Quote status', 'woocommerce-wholesale-pricing'),
					'public'                    => true,
					'exclude_from_search'       => false,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
					/* translators: %s: number of quotes */
					'label_count'               => _n_noop('Expired <span class="count">(%s)</span>', 'Expired <span class="count">(%s)</span>', 'woocommerce-wholesale-pricing'),
			),
			)
		);

		$dynamic_statuses = array();
		// Check if custom statuses are enabled
		if ( check_quote_status() ) {
			$custom_posts = get_quote_custom_status_posts();

			if (!empty($custom_posts)) {
				foreach ($custom_posts as $post) {
					$quote_meta_status = get_post_meta($post->ID, 'wc_quote_status', true);
					$quote_status = isset($quote_meta_status['quote_status']) ? $quote_meta_status['quote_status'] : $post->post_name;

					$enable_quote_status = isset($quote_meta_status['enable_quote_status']) ? $quote_meta_status['enable_quote_status'] : '';
					if ('1' !== $enable_quote_status) {
						continue; // Skip if status is not enabled
					}

					$label = $post->post_title;
					// translators: %s for count
					$label_count = _n_noop('<span class="count">(%s)</span>', '<span class="count">(%s)</span>', 'woocommerce-wholesale-pricing');

					$dynamic_statuses[$quote_status] = array(
						'label'                     => $label,
						'public'                    => true,
						'exclude_from_search'       => false,
						'show_in_admin_all_list'    => true,
						'show_in_admin_status_list' => true,
						'label_count'               => $label_count,
					);


					foreach (array( '0', '1', 'singular', 'plural' ) as $key) {
						if (isset($dynamic_statuses[$quote_status]['label_count'][$key])) {
							$dynamic_statuses[$quote_status]['label_count'][$key] = $label . ' ' . $label_count[$key];
						}
					}




				}
			}
		}

		$quote_statuses = array_merge($quote_statuses, $dynamic_statuses);

		foreach ($quote_statuses as $quote_status => $values) {
			register_post_status($quote_status, $values);
		}

		/**
		 * Register a custom post type called "wc-quote-rules".
		 */
		register_post_type(
			'wc-quote-rules',
			/**
			* Filter wc_quote_rules_register_post_type
			* 
			* @since 1.0
			**/
			apply_filters(
				'wc_quote_rules_register_post_type',
				array(
				'labels'              => array(
				'name'                  => __('Quote Rules', 'woocommerce-wholesale-pricing'),
				'singular_name'         => _x('Quote Rules', 'wc-quote post type singular name', 'woocommerce-wholesale-pricing'),
				'all_items'             => __('Quote Rules', 'woocommerce-wholesale-pricing'),
				'add_new'               => __('Add rule', 'woocommerce-wholesale-pricing'),
				'add_new_item'          => __('Add new rule', 'woocommerce-wholesale-pricing'),
				'edit'                  => __('Edit', 'woocommerce-wholesale-pricing'),
				'edit_item'             => __('Edit rule', 'woocommerce-wholesale-pricing'),
				'new_item'              => __('New rule', 'woocommerce-wholesale-pricing'),
				'view_item'             => __('View rule', 'woocommerce-wholesale-pricing'),
				'search_items'          => __('Search rules', 'woocommerce-wholesale-pricing'),
				'not_found'             => __('No rules found', 'woocommerce-wholesale-pricing'),
				'not_found_in_trash'    => __('No rules found in trash', 'woocommerce-wholesale-pricing'),
				'parent'                => __('Parent rules', 'woocommerce-wholesale-pricing'),
				'filter_items_list'     => __('Filter rules', 'woocommerce-wholesale-pricing'),
				'items_list_navigation' => __('Rules navigation', 'woocommerce-wholesale-pricing'),
				'items_list'            => __('Rules list', 'woocommerce-wholesale-pricing'),
				'attributes'              => __('Rule Priority', 'woocommerce-wholesale-pricing'),
					),
					'description'         => __('This is where rules are stored.', 'woocommerce-wholesale-pricing'),
					'public'              => false,
					'show_ui'             => true,
					'map_meta_cap'        => true,
					'publicly_queryable'  => false,
					'exclude_from_search' => true,
					'show_in_menu'        => 'wc-quote',
					'hierarchical'        => false,
					'show_in_nav_menus'   => false,
					'rewrite'             => false,
					'query_var'           => false,
					'supports'            => array( 'title', 'page-attributes' ),
					'has_archive'         => false,
				)
			)
		);

		if ( check_quote_status() ) {
			/**
			 * Register a custom post type called "wc-quote-status".
			 */
			register_post_type(
				'wc-quote-status',
				/**
				* Filter wc_quote_rules_register_post_type
				* 
				* @since 1.0
				**/
				apply_filters(
					'wc_quote_status_register_post_type',
					array(
					'labels'              => array(
					'name'                  => __('Custom Quote Status', 'woocommerce-wholesale-pricing'),
					'singular_name'         => _x('Custom Quote Status', 'wc-quote post type singular name', 'woocommerce-wholesale-pricing'),
					'all_items'             => __('Custom Quote Status', 'woocommerce-wholesale-pricing'),
					'add_new'               => __('Add rule', 'woocommerce-wholesale-pricing'),
					'add_new_item'          => __('Add New', 'woocommerce-wholesale-pricing'),
					'edit'                  => __('Edit', 'woocommerce-wholesale-pricing'),
					'edit_item'             => __('Custom Quote Status', 'woocommerce-wholesale-pricing'),
					'new_item'              => __('New rule', 'woocommerce-wholesale-pricing'),
					'view_item'             => __('View rule', 'woocommerce-wholesale-pricing'),
					'search_items'          => __('Search quote custom status', 'woocommerce-wholesale-pricing'),
					'not_found'             => __('No quote custom status found', 'woocommerce-wholesale-pricing'),
					'not_found_in_trash'    => __('No quote custom status found in trash', 'woocommerce-wholesale-pricing'),
					'parent'                => __('Parent rules', 'woocommerce-wholesale-pricing'),
					'filter_items_list'     => __('Filter rules', 'woocommerce-wholesale-pricing'),
					'items_list_navigation' => __('Rules navigation', 'woocommerce-wholesale-pricing'),
					'items_list'            => __('Rules list', 'woocommerce-wholesale-pricing'),
					'attributes'              => __('Quote Status Priority', 'woocommerce-wholesale-pricing'),
						),
						'description'         => __('This is where quote custom status are stored.', 'woocommerce-wholesale-pricing'),
						'public'              => false,
						'show_ui'             => true,
						'map_meta_cap'        => true,
						'publicly_queryable'  => false,
						'exclude_from_search' => true,
						'show_in_menu'        => 'wc-quote',
						'hierarchical'        => false,
						'show_in_nav_menus'   => false,
						'rewrite'             => false,
						'query_var'           => false,
						'supports'            => array( 'title', 'page-attributes' ),
						'has_archive'         => false,
					)
				)
			);
		}

		/**
		 * Register a custom post type called "custom_pdf".
		 */
		$labels = array(
			'name'               => _x('PDF', 'Post Type General Name', 'woocommerce-wholesale-pricing'),
			'wsingular_name'      => _x('PDF', 'Post Type Singular Name', 'woocommerce-wholesale-pricing'),
			'menu_name'          => __('PDF', 'woocommerce-wholesale-pricing'),
			'name_admin_bar'     => __('PDF', 'woocommerce-wholesale-pricing'),
			'add_new'            => __('Add New', 'woocommerce-wholesale-pricing'),
			'add_new_item'       => __('Add New PDF', 'woocommerce-wholesale-pricing'),
			'edit_item'          => __('Edit PDF', 'woocommerce-wholesale-pricing'),
			'new_item'           => __('New PDF', 'woocommerce-wholesale-pricing'),
			'view_item'          => __('View PDF', 'woocommerce-wholesale-pricing'),
			'search_items'       => __('Search PDF', 'woocommerce-wholesale-pricing'),
			'not_found'          => __('No PDF found', 'woocommerce-wholesale-pricing'),
			'not_found_in_trash' => __('No PDF found in Trash', 'woocommerce-wholesale-pricing'),
		);
	
		$args = array(
			'labels'              => $labels,
			'public'              => false,
			'publicly_queryable'  => false,
			'show_ui'             => true,
			'show_in_menu'        => false,
			// 'show_in_menu'        => 'wc-quote',
			'show_in_rest'        => true,
			'query_var'           => false,
			'rewrite'             => array( 'slug' => 'pdf' ),
			'capabilities'      => array(
				'create_posts'           => 'do_not_allow',
				'edit_post'              => 'edit_posts',
				'edit_posts'             => 'edit_posts',
				'edit_others_posts'      => 'edit_others_posts',
				'edit_published_posts'   => 'edit_published_posts',
				'edit_private_posts'     => 'edit_private_posts',
				'publish_posts'          => 'publish_posts',
			),
			'capability_type'     => 'post',
			'has_archive'         => false,
			'hierarchical'        => false,
			'menu_position'       => 20,
			'menu_icon'           => 'dashicons-media-document', // Icon for PDFs
			'supports'            => array( 'title', 'editor', 'thumbnail', 'custom-fields' ),
		);
	
		register_post_type('custom_pdf', $args);

		if ('yes' === get_option('wc_quote_default_pdf_templates_seeded', '')) {
			return;
		}

		// Check if there are any posts of the custom_pdf type
		$pdf_posts = new \WP_Query(
			array(
			'post_type'      => 'custom_pdf',
			'posts_per_page' => 1, // Only check if there is at least one post
			)
		);

		// If no posts are found, create the default three
		if (!$pdf_posts->have_posts()) {
			// Titles for the posts
			// Titles and meta data for the posts

			// image paths 
			$default_image = wc_placeholder_img_src();
			
			$posts_data = array(
			array(
				'title' => 'PDF Template Bronze',
				'meta'  => array(
					'pdf_template_name' => 'bronze',
				),
				'content' => '
				<!-- wp:columns -->
					<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center"} -->
					<div class="wp-block-column is-vertically-aligned-center"><!-- wp:wc-quote/bronze-image {"imageUrl":"' . $default_image . '","altText":"Selected Image"} /--></div>
					<!-- /wp:column -->

					<!-- wp:column {"verticalAlignment":"center","width":""} -->
					<div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading -->
					<h2 class="wp-block-heading"><strong>Dev</strong></h2>
					<!-- /wp:heading -->

					<!-- wp:wc-quote/bronze-tagline {"content":"Just come and buy","fontSize":"S"} /--></div>
					<!-- /wp:column -->

					<!-- wp:column {"verticalAlignment":"top","width":"","fontSize":"normal"} -->
					<div class="wp-block-column is-vertically-aligned-top has-normal-font-size"><!-- wp:heading {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"0","right":"0"}},"elements":{"link":{"color":{"text":"#d3a475"}}},"color":{"text":"#d3a475"}}} -->
					<h2 class="wp-block-heading has-text-color has-link-color" style="color:#d3a475;margin-top:var(--wp--preset--spacing--40);margin-right:0;margin-bottom:var(--wp--preset--spacing--40);margin-left:0"><strong>QUOTATION</strong></h2>
					<!-- /wp:heading -->

					<!-- wp:wc-quote/bronze-quotation-number {"textColor":"#000000","backgroundColor":"#ffffff","fontSize":12,"orderNumber":"Quotation Number : "} /-->

					<!-- wp:wc-quote/bronze-quotation-date {"fontSize":12} /--></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:wc-quote/bronze-product-details /-->

					<!-- wp:columns -->
					<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center","width":"50%","style":{"spacing":{"blockGap":"0"},"border":{"width":"0px","style":"none","radius":"0px"}}} -->
					<div class="wp-block-column is-vertically-aligned-center" style="border-style:none;border-width:0px;border-radius:0px;flex-basis:50%"></div>
					<!-- /wp:column -->

					<!-- wp:column {"verticalAlignment":"top","width":"50%","style":{"spacing":{"blockGap":"0"},"border":{"width":"0px","style":"none"}},"fontSize":"normal"} -->
					<div class="wp-block-column is-vertically-aligned-top has-normal-font-size" style="border-style:none;border-width:0px;flex-basis:50%"><!-- wp:wc-quote/bronze-total {"shipping":"Shipping :","tax":"Tax(standard):","taxOffered":"Tax(offered):","titleColor":"#000000","itemColor":"#ffffff","align":"wide","borderColor":"#ffffff"} /--></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:columns -->
					<div class="wp-block-columns"><!-- wp:column {"width":"50%"} -->
					<div class="wp-block-column" style="flex-basis:50%"><!-- wp:wc-quote/bronze-customer-info {"headingBgColor":"#ffffff","headingTextColor":"#000000","itemTextColor":"#000000","borderColor":"#ededed","topHeadingText":"Customer Informations","topHeadingFontColor":"#000000","topHeadingBgColor":"#ffffff","email":"Emails"} /--></div>
					<!-- /wp:column -->

					<!-- wp:column {"width":"50%"} -->
					<div class="wp-block-column" style="flex-basis:50%"></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:paragraph -->
					<p></p>
					<!-- /wp:paragraph -->
				
				',
			),

			array(
				'title' => 'PDF Template Darkblue',
				'meta'  => array(
					'pdf_template_name' => 'darkblue',
				),
				'content' => '
				<!-- wp:columns -->
					<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center"} -->
					<div class="wp-block-column is-vertically-aligned-center"><!-- wp:wc-quote/darkblue-image {"imageUrl":"' . $default_image . '","altText":"Selected Image"} /--></div>
					<!-- /wp:column -->

					<!-- wp:column {"verticalAlignment":"center"} -->
					<div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"style":{"color":{"text":"#001137"},"elements":{"link":{"color":{"text":"#001137"}}}}} -->
					<h2 class="wp-block-heading has-text-color has-link-color" style="color:#001137"><strong>Dev</strong></h2>
					<!-- /wp:heading -->

					<!-- wp:wc-quote/darkblue-tagline {"content":"Just come and buy","fontSize":"S","textColor":"#001137"} /--></div>
					<!-- /wp:column -->

					<!-- wp:column {"verticalAlignment":"top"} -->
					<div class="wp-block-column is-vertically-aligned-top"><!-- wp:heading {"style":{"color":{"text":"#001137"},"elements":{"link":{"color":{"text":"#001137"}}},"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}}}} -->
					<h2 class="wp-block-heading has-text-color has-link-color" style="color:#001137;margin-top:var(--wp--preset--spacing--20);margin-bottom:var(--wp--preset--spacing--20)"><strong>QUOTATION</strong></h2>
					<!-- /wp:heading -->

					<!-- wp:wc-quote/darkblue-quotation-number {"fontSize":12,"orderNumber":"Quotation Number : "} /-->

					<!-- wp:wc-quote/darkblue-quotation-date {"fontSize":12,"quotationDate":"Quotation Date : "} /--></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:wc-quote/darkblue-product-details /-->

					<!-- wp:columns -->
					<div class="wp-block-columns"><!-- wp:column -->
					<div class="wp-block-column"></div>
					<!-- /wp:column -->

					<!-- wp:column {"verticalAlignment":"top"} -->
					<div class="wp-block-column is-vertically-aligned-top"><!-- wp:wc-quote/darkblue-total {"shipping":"Shipping :","tax":"Tax(standard):","taxOffered":"Tax(offered):","align":"wide"} /--></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:columns -->
					<div class="wp-block-columns"><!-- wp:column -->
					<div class="wp-block-column"><!-- wp:wc-quote/darkblue-customer-info /--></div>
					<!-- /wp:column -->

					<!-- wp:column -->
					<div class="wp-block-column"></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:paragraph -->
					<p></p>
					<!-- /wp:paragraph -->
				',
			),

			array(
				'title' => 'PDF Template Lightblue',
				'meta'  => array(
					'pdf_template_name' => 'lightblue',
				),
				'content' => '
				<!-- wp:columns -->
					<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center"} -->
					<div class="wp-block-column is-vertically-aligned-center"><!-- wp:wc-quote/lightblue-image {"imageUrl":"' . $default_image . '","altText":"Selected Image"} /--></div>
					<!-- /wp:column -->

					<!-- wp:column {"verticalAlignment":"center"} -->
					<div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"style":{"color":{"text":"#03213f"},"elements":{"link":{"color":{"text":"#03213f"}}}}} -->
					<h2 class="wp-block-heading has-text-color has-link-color" style="color:#03213f"><strong>Dev</strong></h2>
					<!-- /wp:heading -->

					<!-- wp:wc-quote/lightblue-tagline {"content":"Just come and buy"} /--></div>
					<!-- /wp:column -->

					<!-- wp:column {"verticalAlignment":"center"} -->
					<div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"style":{"color":{"text":"#03213f"},"elements":{"link":{"color":{"text":"#03213f"}}}}} -->
					<h2 class="wp-block-heading has-text-color has-link-color" style="color:#03213f"><strong>QUOTATION</strong></h2>
					<!-- /wp:heading -->

					<!-- wp:wc-quote/lightblue-quotation-number {"fontSize":12,"orderNumber":"Quotation Number : "} /-->

					<!-- wp:wc-quote/lightblue-quotation-date {"fontSize":12,"quotationDate":"Quotation Date : "} /--></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:wc-quote/lightblue-product-details /-->

					<!-- wp:columns -->
					<div class="wp-block-columns"><!-- wp:column -->
					<div class="wp-block-column"></div>
					<!-- /wp:column -->

					<!-- wp:column -->
					<div class="wp-block-column"><!-- wp:wc-quote/lightblue-total {"shipping":"Shipping :","tax":"Tax(standard):","taxOffered":"Tax(offered):","align":"wide"} /--></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:columns -->
					<div class="wp-block-columns"><!-- wp:column -->
					<div class="wp-block-column"><!-- wp:wc-quote/lightblue-customer-info /--></div>
					<!-- /wp:column -->

					<!-- wp:column -->
					<div class="wp-block-column"></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:paragraph -->
					<p></p>
					<!-- /wp:paragraph -->
				',
			),
			);

			  // Loop through posts data and create posts with meta
			foreach ($posts_data as $post_data) {
				$post_id = wp_insert_post(
					array(
					'post_title'    => $post_data['title'],
					'post_type'     => 'custom_pdf',
					'post_status'   => 'publish',
					'post_content' => $post_data['content'], // Add the block content here
					)
				);

				// Add meta data for each post
				if ($post_id && !is_wp_error($post_id)) {
					foreach ($post_data['meta'] as $meta_key => $meta_value) {
						add_post_meta($post_id, $meta_key, $meta_value);
					}
				}
			}
		}

		// Clean up after WP_Query
		wp_reset_postdata(); 
		update_option('wc_quote_default_pdf_templates_seeded', 'yes');
	}
}
