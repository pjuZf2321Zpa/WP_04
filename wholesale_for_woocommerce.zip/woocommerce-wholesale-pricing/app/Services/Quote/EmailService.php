<?php
/**
 * WC Quote Email Controller.
 *
 * The WooCommerce quote class stores quote data and maintain session of quotes.
 * The quote class also has a price calculation function which calls upon other classes to calculate totals.
 */
namespace WooCommerceWholesalePricing\App\Services\Quote;

use WooCommerceWholesalePricing\App\Modules\Emails\Traits\Quote\Admin;
use WooCommerceWholesalePricing\App\Modules\Emails\Traits\Quote\Customer;
use WooCommerceWholesalePricing\App\Modules\Quote\QuoteProcess;
// Include the main WC_QUOTE_PDF_Controller class.

/**
 * EmailService class.
 */
class EmailService {

	use Admin;
	use Customer;

	/**
	 * Contains an array of quote items.
	 *
	 * @var array
	 */
	private static $email_headers;

	/**
	 * Contains an array of quote settings.
	 *
	 * @var array
	 */
	private $quote_settings;

	/**
	 * Contains an array of quote fields.
	 *
	 * @var array
	 */
	private $quote_fields;

	/**
	 * Constructor for the Email Service class. Loads email headers.
	 */
	public function __construct() {
		$this->quote_settings['general'] = get_option('wc_quote_general', false);
		$this->quote_settings['email'] = get_option('wc_quote_email', false);
		$this->quote_settings['pdf'] = get_option('wc_quote_pdf', false);
		$this->quote_settings['notifications'] = get_option('wc_quote_notifications', false);
		$this->quote_fields = json_decode(get_option('wc_quote_form_builder'), true);
		$this->init();
		add_action('wc_quote_email_header', array( $this, 'get_email_header' ));
		add_action('wc_quote_email_footer', array( $this, 'get_email_footer' ));
		add_action('wc_quote_email_customer_details', array( $this, 'get_customer_info_table' ));
		add_action('wc_quote_email_quote_details', array( $this, 'get_quote_contents_table' ), 10, 2);

		// Action Hooks to send emails.
		add_action('wc_quote_send_quote_email_to_customer', array( $this, 'send_email_to_customer' ));
		add_action('wc_quote_send_quote_email_to_admin', array( $this, 'send_email_to_admins' ));

		add_filter('woocommerce_email_footer_text', array( $this, 'replace_placeholders' ));
	}

	/**
	 * Init function to initialize the necessary actions for emails.
	 */
	public function init() {
		self::$email_headers = $this->get_email_headers();
	}

	/**
	 * Load the template of email header.
	 */
	public function get_email_header( $email_heading ) {
		wwp_view( 'quote.emails.email-header', compact( 'email_heading' ), true );
	}

	/**
	 * Load the template of email footer.
	 */
	public function get_email_footer() {
		wwp_view('quote.emails.email-footer', array(), true);
	}

	/**
	 * Apply inline styles to dynamic content.
	 *
	 * We only inline CSS for html emails, and to do so we use Emogrifier library (if supported).
	 *
	 * @version 4.0.0
	 * @param   string|null $content Content that will receive inline styles.
	 * @return  string
	 */
	public function style_inline( $content ) {
		$css = $this->get_quote_email_styles();
		
		$emogrifier_class = 'Pelago\\Emogrifier';
		if (class_exists($emogrifier_class) ) {
			try {
				$emogrifier = new $emogrifier_class($content, $css);
				/**
				* Action wc_quote_emogrifier
				* 
				* @since 1.0
				**/
				do_action('wc_quote_emogrifier', $emogrifier, $this);

				$content    = $emogrifier->emogrify();
				$html_prune = \Pelago\Emogrifier\HtmlProcessor\HtmlPruner::fromHtml($content);
				$html_prune->removeElementsWithDisplayNone();
				$content = $html_prune->render();
			} catch ( \Exception $e ) {
				$content = '<style type="text/css">' . $css . '</style>' . $content;
			}
		} else {
			$content = '<style type="text/css">' . $css . '</style>' . $content;
		}

		return $content;
	}

	/**
	 * Build and filter css used for quote emails.
	 *
	 * @return string
	 */
	private function get_quote_email_styles() {
		ob_start();
		wc_get_template('emails/email-styles.php');
		/**
		 * Filter wc_quote_email_styles
		 * 
		 * @since 1.0
		**/
		return (string) apply_filters('wc_quote_email_styles', ob_get_clean(), $this);
	}

	/**
	 * Get blog name formatted for emails.
	 *
	 * @return string
	 */
	private function get_blogname() {
		return wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);
	}

	/**
	 * Replace placeholder text in strings.
	 *
	 * @since  3.7.0
	 * @param  string $string Email footer text.
	 * @return string         Email footer text with any replacements done.
	 */
	public function replace_placeholders( $string ) {
		$domain = wp_parse_url(home_url(), PHP_URL_HOST);

		return str_replace(
			array(
			'{site_title}',
			'{site_address}',
			'{site_url}',
			'{woocommerce}',
			'{WooCommerce}',
			),
			array(
			$this->get_blogname(),
			$domain,
			$domain,
			'<a href="https://woocommerce.com">WooCommerce</a>',
			'<a href="https://woocommerce.com">WooCommerce</a>',
			),
			$string
		);
	}


	/**
	 * Load the template of email footer.
	 */
	public function get_quote_contents_table( $quote_id, $email ) {

		if ( isset( $this->quote_settings['pdf']['enable_pdf'], $this->quote_settings['pdf']['enable_pdf_attach'], $this->quote_settings['pdf']['hide_product_list'] ) && '1' === $this->quote_settings['pdf']['enable_pdf'] && '1' === $this->quote_settings['pdf']['enable_pdf_attach'] && '1' === $this->quote_settings['pdf']['hide_product_list'] ) {
			return;
		}

		$quote_contents = get_post_meta($quote_id, 'quote_contents', true);

		$wc_quote = new QuoteProcess($quote_contents);

		$price_display    = isset($this->quote_settings['general']['enable_standard']) ? $this->quote_settings['general']['enable_standard'] : '0';
		$quote_enable_pdf = isset($this->quote_settings['pdf']['enable_pdf']) ? $this->quote_settings['pdf']['enable_pdf'] : '0';
		$quote_custom_pdf    = isset($this->quote_settings['pdf']) ? $this->quote_settings['pdf'] : '';

		$colspan  = 2;
		$colspan  = '1' === $price_display ? $colspan + 1 : $colspan;
		$colspan  = 'quote_new' === get_post($quote_id)->post_status || 'quote_quoted' === get_post($quote_id)->post_status || 'quote_accepted' === get_post($quote_id)->post_status || 'quote_rejected' === get_post($quote_id)->post_status ? $colspan + 1 : $colspan;
		$totals = $wc_quote->get_calculated_totals($quote_contents, $quote_id);
		$quote_subtotal = isset($totals['_subtotal']) ? $totals['_subtotal'] : 0;
		$vat_total      = isset($totals['_tax_total']) ? $totals['_tax_total'] : 0;
		$quote_total    = isset($totals['_total']) ? $totals['_total'] : 0;
		$offered_total  = isset($totals['_offered_total']) ? $totals['_offered_total'] : 0;
		$display_tax = isset($this->quote_settings['general']['display_tax']) ? $this->quote_settings['general']['display_tax'] : '0';
		$admin_email = isset($this->quote_settings['email']['admin_email']) && ! empty($this->quote_settings['email']['admin_email']) ? $this->quote_settings['email']['admin_email'] : get_bloginfo('admin_email');
		$hide_product_list = isset($this->quote_settings['pdf']['hide_product_list']) ? $this->quote_settings['pdf']['hide_product_list'] : '0';

		// ===== custom pdf sprint 2.7 start ======
		$tax_label = $totals['_tax_label'] ? $totals['_tax_label'] : 'Tax(Standard)';
		$tax_offered = isset($totals['_tax_total_offered']) ? $totals['_tax_total_offered'] : 0;
		$shipping = isset($totals['_shipping']) ? $totals['_shipping'] : 0;
		$total_offered = isset($totals['cal_offered_total']) ? $totals['cal_offered_total'] : 0;
		// ====== custom pdf sprint 2.7 end =======

		if (empty($quote_contents) ) {
			return;
		}

		wwp_view( 'quote.emails.contents-table', compact( 'admin_email', 'email', 'quote_contents', 'quote_id', 'price_display', 'quote_custom_pdf', 'colspan', 'quote_subtotal', 'vat_total', 'quote_total', 'offered_total', 'display_tax', 'tax_label', 'tax_offered', 'shipping', 'total_offered', 'hide_product_list' ) );
	}

	/**
	 * Load the template of email userinfo.
	 */
	public function get_customer_info_table( $quote_id ) {

		$customer_info = $this->get_quote_user_info($quote_id);

		if (empty($customer_info) ) {
			return;
		}
		
		wwp_view( 'quote.emails.customer-info', compact( 'customer_info' ), true );
	}

	/**
	 * Load the customer info and extra field data in array.
	 */
	public function get_quote_user_info( $quote_id ) {

		$customer_info = array();
		$quote_date    = date_i18n(get_option('date_format'), get_post_time('U', false, $quote_id, true));
		  
		$quote_expiry_date = get_post_meta($quote_id, 'wc_quote_expire_date', true);
		$quote_expire = isset($this->quote_settings['general']['quote_expire']) ? $this->quote_settings['general']['quote_expire'] : '0';

		$customer_info['quote_id']   = array(
		'label' => __('Quote Number', 'woocommerce-wholesale-pricing'),
		'value' => $quote_id,
		);
		$customer_info['quote_date'] = array(
		'label' => __('Quote Date', 'woocommerce-wholesale-pricing'),
		'value' => $quote_date,
		);

		if ('1' === $quote_expire && !in_array(get_post($quote_id)->post_status, array( 'quote_accepted', 'quote_converted', 'quote_new' )) && !empty($quote_expiry_date) ) :
			$customer_info['quote_expiry_date'] = array(
			'label' => __('Expiration Date', 'woocommerce-wholesale-pricing'),
			'value' => $quote_expiry_date,
			);
		endif;
		  
		$quote_fields = $this->quote_fields;

		if (empty($quote_fields) ) {
			return $customer_info;
		}

		foreach ( $quote_fields['components'] as $key => $field ) {

			$wc_quote_field_name  = $field['key'];
			$wc_quote_field_type  = $field['type'];
			$wc_quote_field_label = $field['label'];
			$field_data        = get_post_meta($quote_id, 'quote_fields', true);
			$field_data = isset($field_data[$wc_quote_field_name]) ? $field_data[$wc_quote_field_name] : '';

			if (is_array($field_data) ) {
				$field_data = implode(', ', $field_data);
			}

			if (in_array($wc_quote_field_type, array( 'select', 'radio', 'mutliselect' ), true) ) {
				$field_data = ucwords($field_data);
			}

			// Handle file type fields
			if ('file' == $wc_quote_field_type && !empty($field_data)) {
				$file_data = json_decode($field_data, true);
			
				if ($file_data && is_array($file_data)) {
					$upload_dir = wp_upload_dir();
					$zip = new \ZipArchive();
					$zip_file_name = 'quote-files-' . time() . '.zip';
					$zip_file_path = $upload_dir['path'] . '/' . $zip_file_name;
			
					if ($zip->open($zip_file_path, \ZipArchive::CREATE) === true) {
						foreach ($file_data as $file) {
							if (!empty($file['url']) && !empty($file['originalName'])) {
								$base64_str = substr($file['url'], strpos($file['url'], ',') + 1);
								$image_data = base64_decode($base64_str);
								$file_name  = sanitize_file_name($file['originalName']);
								$temp_file_path = $upload_dir['path'] . '/' . $file_name;
			
								// Save file temporarily
								file_put_contents($temp_file_path, $image_data);
			
								// Add to ZIP
								$zip->addFile($temp_file_path, $file_name);
							}
						}
						$zip->close();
			
						// Download link
						$file_url = $upload_dir['url'] . '/' . $zip_file_name;
						$field_data = '<a href="' . esc_url($file_url) . '" download="' . esc_attr($zip_file_name) . '">' . esc_html__('Download File', 'woocommerce-wholesale-pricing') . '</a>';
					}
				}
			}

			if ( '[]' == $field_data ) {
				$field_data = '';
			}

			if ( !empty($field_data) ) {

				$customer_info[ $wc_quote_field_name ] = array(
				'label' => $wc_quote_field_label,
				'value' => $field_data,
				);
			}

		}


		return $customer_info;
	}

	/**
	 * Get WooCommerce settings and return the header of email.
	 *
	 * @return string
	 */
	public function get_email_headers() {

		// Get settings from WooCommerce.
		$from_name  = get_option('woocommerce_email_from_name');
		$from_email = isset($this->quote_settings['email']['admin_email']) ? $this->quote_settings['email']['admin_email'] : get_bloginfo('admin_email');
		$from_email = !empty($from_email) ? $from_email : get_option('woocommerce_email_from_address');

		// More headers.
		$headers[] = 'MIME-Version: 1.0';
		$headers[] = 'Content-Type: text/html; charset=UTF-8';
		$headers[] = 'From: ' . $from_name . ' <' . $from_email . '>';

		return $headers;
	}
}
