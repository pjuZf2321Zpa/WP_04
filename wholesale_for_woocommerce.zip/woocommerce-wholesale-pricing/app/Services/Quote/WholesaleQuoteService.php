<?php
/**
 * Programmatic read/update for wc-quote posts.
 *
 * @package WooCommerceWholesalePricing\App\Services\Quote
 */

namespace WooCommerceWholesalePricing\App\Services\Quote;

use WooCommerceWholesalePricing\App\Modules\Quote\QuoteProcess;

/**
 * API-oriented service for quote management.
 */
class WholesaleQuoteService {

	/**
	 * Built-in quote statuses.
	 *
	 * @var list<string>
	 */
	const QUOTE_STATUSES = array(
		'quote_draft',
		'quote_new',
		'quote_quoted',
		'quote_accepted',
		'quote_converted',
		'quote_rejected',
		'quote_expired',
	);

	/**
	 * List quotes.
	 *
	 * @param array<string, mixed> $args Query args.
	 * @return array{quotes: list<array<string, mixed>>, total: int}
	 */
	public function list_quotes( array $args = array() ) {
		$per_page = max( 1, min( 100, (int) ( isset( $args['per_page'] ) ? $args['per_page'] : 20 ) ) );
		$page     = max( 1, (int) ( isset( $args['page'] ) ? $args['page'] : 1 ) );
		$search   = isset( $args['search'] ) ? sanitize_text_field( (string) $args['search'] ) : '';
		$status   = isset( $args['status'] ) ? sanitize_key( (string) $args['status'] ) : '';
		$user_id  = isset( $args['customer_user_id'] ) ? (int) $args['customer_user_id'] : 0;

		$query_args = array(
			'post_type'      => $this->get_post_type(),
			'post_status'    => '' !== $status ? $status : $this->get_all_statuses(),
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		if ( $user_id > 0 ) {
			$query_args['author'] = $user_id;
		}

		if ( '' !== $search ) {
			$query_args['s'] = $search;
		}

		$query  = new \WP_Query( $query_args );
		$quotes = array();

		foreach ( $query->posts as $post ) {
			if ( $post instanceof \WP_Post ) {
				$quotes[] = $this->format_quote_summary( (int) $post->ID );
			}
		}

		return array(
			'quotes' => $quotes,
			'total'  => (int) $query->found_posts,
		);
	}

	/**
	 * Get a single quote.
	 *
	 * @param int $quote_id Quote post ID.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function get_quote( $quote_id ) {
		$post = $this->resolve_post( $quote_id );
		if ( is_wp_error( $post ) ) {
			return $post;
		}

		return $this->format_quote( (int) $post->ID );
	}

	/**
	 * Update a quote.
	 *
	 * @param int                  $quote_id Quote post ID.
	 * @param array<string, mixed> $data     Update payload.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function update_quote( $quote_id, array $data ) {
		$post = $this->resolve_post( $quote_id );
		if ( is_wp_error( $post ) ) {
			return $post;
		}

		if ( empty( $data ) ) {
			return new \WP_Error(
				'wwp_quote_missing_data',
				__( 'Quote data is required for update.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$payload = $this->normalize_payload( $data );
		$changed = false;

		if ( isset( $payload['customer_user_id'] ) ) {
			$author_id = (int) $payload['customer_user_id'];
			if ( $author_id > 0 && ! get_user_by( 'id', $author_id ) ) {
				return new \WP_Error(
					'wwp_quote_invalid_customer',
					__( 'Customer user not found.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			wp_update_post(
				array(
					'ID'          => $quote_id,
					'post_author' => max( 0, $author_id ),
				)
			);
			$changed = true;
		}

		if ( isset( $payload['fields'] ) && is_array( $payload['fields'] ) ) {
			$existing_fields = get_post_meta( $quote_id, 'quote_fields', true );
			$existing_fields = is_array( $existing_fields ) ? $existing_fields : array();
			update_post_meta( $quote_id, 'quote_fields', array_merge( $existing_fields, $payload['fields'] ) );
			$changed = true;
		}

		$contents_changed = $this->apply_line_item_updates( $quote_id, $payload );
		if ( is_wp_error( $contents_changed ) ) {
			return $contents_changed;
		}
		if ( $contents_changed ) {
			$changed = true;
		}

		if ( array_key_exists( 'shipping', $payload ) ) {
			update_post_meta( $quote_id, 'quote_content_shipping', $this->normalize_amount( $payload['shipping'] ) );
			$changed = true;
		}

		if ( array_key_exists( 'shipping_tax', $payload ) ) {
			update_post_meta( $quote_id, 'quote_content_shipping_tax', $this->normalize_amount( $payload['shipping_tax'] ) );
			$changed = true;
		}

		if ( isset( $payload['status'] ) ) {
			$status = sanitize_key( (string) $payload['status'] );
			if ( ! $this->is_valid_status( $status ) ) {
				return new \WP_Error(
					'wwp_quote_invalid_status',
					__( 'Invalid quote status.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			if ( 'quote_converted' === $status ) {
				return new \WP_Error(
					'wwp_quote_convert_not_supported',
					__( 'Converting a quote to an order is not supported via the AI ability. Use the WooCommerce admin quote screen.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			$old_status = (string) $post->post_status;
			if ( $old_status !== $status ) {
				wp_update_post(
					array(
						'ID'          => $quote_id,
						'post_status' => $status,
					)
				);
				/**
				 * Action wc_quote_status_updated
				 *
				 * @since 1.0
				 */
				do_action( 'wc_quote_status_updated', $quote_id, $status, $old_status );
				$changed = true;
			}
		}

		if ( ! $changed ) {
			return new \WP_Error(
				'wwp_quote_no_changes',
				__( 'No supported quote fields were provided for update.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		return $this->format_quote( $quote_id );
	}

	/**
	 * Snapshot quote state for undo.
	 *
	 * @param int $quote_id Quote post ID.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function snapshot_quote( $quote_id ) {
		$post = $this->resolve_post( $quote_id );
		if ( is_wp_error( $post ) ) {
			return $post;
		}

		$fields = get_post_meta( $quote_id, 'quote_fields', true );

		return array(
			'quote_id'                    => $quote_id,
			'post_title'                  => (string) $post->post_title,
			'post_status'                 => (string) $post->post_status,
			'post_author'                 => (int) $post->post_author,
			'quote_contents'                => get_post_meta( $quote_id, 'quote_contents', true ),
			'quote_fields'                => is_array( $fields ) ? $fields : array(),
			'quote_content_shipping'      => get_post_meta( $quote_id, 'quote_content_shipping', true ),
			'quote_content_shipping_tax'  => get_post_meta( $quote_id, 'quote_content_shipping_tax', true ),
		);
	}

	/**
	 * Restore quote snapshot after update.
	 *
	 * @param array<string, mixed> $snapshot Snapshot data.
	 * @return true|\WP_Error
	 */
	public function restore_quote( array $snapshot ) {
		$quote_id = (int) ( isset( $snapshot['quote_id'] ) ? $snapshot['quote_id'] : 0 );
		if ( $quote_id <= 0 || ! get_post( $quote_id ) ) {
			return new \WP_Error(
				'wwp_quote_restore_invalid_snapshot',
				__( 'Cannot restore quote: invalid snapshot.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		wp_update_post(
			array(
				'ID'          => $quote_id,
				'post_title'  => (string) ( isset( $snapshot['post_title'] ) ? $snapshot['post_title'] : '' ),
				'post_status' => (string) ( isset( $snapshot['post_status'] ) ? $snapshot['post_status'] : 'quote_new' ),
				'post_author' => (int) ( isset( $snapshot['post_author'] ) ? $snapshot['post_author'] : 0 ),
			)
		);

		update_post_meta( $quote_id, 'quote_contents', isset( $snapshot['quote_contents'] ) ? $snapshot['quote_contents'] : array() );
		update_post_meta( $quote_id, 'quote_fields', is_array( isset( $snapshot['quote_fields'] ) ? $snapshot['quote_fields'] : null ) ? $snapshot['quote_fields'] : array() );
		update_post_meta( $quote_id, 'quote_content_shipping', isset( $snapshot['quote_content_shipping'] ) ? $snapshot['quote_content_shipping'] : '' );
		update_post_meta( $quote_id, 'quote_content_shipping_tax', isset( $snapshot['quote_content_shipping_tax'] ) ? $snapshot['quote_content_shipping_tax'] : '' );

		return true;
	}

	/**
	 * Get the post type for quotes, allowing for custom slugs.
	 * 
	 * @return string
	 */
	public function get_post_type() {
		if ( function_exists( 'wwp_env' ) ) {
			$slug = (string) wwp_env()->get( 'quote_slug' );
			if ( '' !== $slug ) {
				return $slug;
			}
		}

		return 'wc-quote';
	}

	/**
	 * Get all quote statuses, including custom ones.
	 * 
	 * @return list<string>
	 */
	public function get_all_statuses() {
		$statuses = self::QUOTE_STATUSES;

		if ( function_exists( 'check_quote_status' ) && check_quote_status() ) {
			$custom_posts = get_posts(
				array(
					'post_type'      => 'wc-quote-status',
					'post_status'    => 'any',
					'posts_per_page' => -1,
					'fields'         => 'ids',
				)
			);

			foreach ( $custom_posts as $post_id ) {
				$meta   = get_post_meta( (int) $post_id, 'wc_quote_status', true );
				$status = is_array( $meta ) && isset( $meta['quote_status'] ) ? (string) $meta['quote_status'] : get_post_field( 'post_name', (int) $post_id );
				if ( '' !== $status ) {
					$statuses[] = $status;
				}
			}
		}

		return array_values( array_unique( $statuses ) );
	}

	/**
	 * Format customer data for quote summary.
	 * 
	 * @param int $quote_id Quote post ID.
	 * @return array<string, mixed>
	 */
	private function format_quote_summary( $quote_id ) {
		$post   = get_post( $quote_id );
		$status = $post ? (string) $post->post_status : 'quote_new';

		return array(
			'id'            => $quote_id,
			'title'         => $post ? (string) $post->post_title : '',
			'status'        => $status,
			'status_label'  => $this->get_status_label( $status ),
			'customer'      => $this->format_customer( $post ? (int) $post->post_author : 0 ),
			'totals'        => $this->calculate_totals( $quote_id ),
			'item_count'    => $this->count_items( $quote_id ),
			'date_modified' => $post ? (string) $post->post_modified_gmt : '',
		);
	}

	/**
	 * Format a single quote with line items and fields.
	 * 
	 * @param int $quote_id Quote post ID.
	 * @return array<string, mixed>
	 */
	private function format_quote( $quote_id ) {
		$summary = $this->format_quote_summary( $quote_id );
		$fields  = get_post_meta( $quote_id, 'quote_fields', true );

		return array_merge(
			$summary,
			array(
				'customer_user_id' => (int) get_post_field( 'post_author', $quote_id ),
				'fields'           => is_array( $fields ) ? $fields : array(),
				'shipping'         => $this->normalize_amount( get_post_meta( $quote_id, 'quote_content_shipping', true ) ),
				'shipping_tax'     => $this->normalize_amount( get_post_meta( $quote_id, 'quote_content_shipping_tax', true ) ),
				'items'            => $this->format_items( $quote_id ),
			)
		);
	}

	/**
	 * Format line items for quote summary.
	 * 
	 * @param int $quote_id Quote post ID.
	 * @return list<array<string, mixed>>
	 */
	private function format_items( $quote_id ) {
		$quote_contents = (array) get_post_meta( $quote_id, 'quote_contents', true );
		$items          = array();

		foreach ( $quote_contents as $item_key => $item ) {
			if ( ! is_array( $item ) || empty( $item['product_id'] ) ) {
				continue;
			}

			$product = $this->resolve_item_product( $item );
			if ( ! $product ) {
				continue;
			}

			$quantity      = isset( $item['quantity'] ) ? (float) $item['quantity'] : 0;
			$price         = (float) $product->get_price();
			$offered_price = isset( $item['offered_price'] ) ? (float) $item['offered_price'] : $price;
			$offered_signup = isset( $item['offered_signup'] ) ? (float) $item['offered_signup'] : 0;

			$items[] = array(
				'key'              => (string) $item_key,
				'product_id'       => (int) $item['product_id'],
				'variation_id'     => isset( $item['variation_id'] ) ? (int) $item['variation_id'] : 0,
				'name'             => (string) $product->get_name(),
				'sku'              => (string) $product->get_sku(),
				'quantity'         => $quantity,
				'cost'             => $price,
				'offered_price'    => $offered_price,
				'offered_signup'   => $offered_signup,
				'line_subtotal'    => $price * $quantity,
				'offered_subtotal' => ( $offered_price + $offered_signup ) * $quantity,
			);
		}

		return $items;
	}

	/**
	 * Calculate quote totals based on line items and shipping.
	 * 
	 * @param int $quote_id Quote post ID.
	 * @return array<string, float|string>
	 */
	private function calculate_totals( $quote_id ) {
		$quote_contents = (array) get_post_meta( $quote_id, 'quote_contents', true );
		$wc_quote       = new QuoteProcess( $quote_contents );
		$totals         = $wc_quote->get_calculated_totals( $quote_contents, $quote_id );

		return array(
			'subtotal'       => isset( $totals['_subtotal'] ) ? (float) $totals['_subtotal'] : 0.0,
			'offered_total'  => isset( $totals['_offered_total'] ) ? (float) $totals['_offered_total'] : 0.0,
			'tax'            => isset( $totals['_tax_total'] ) ? (float) $totals['_tax_total'] : 0.0,
			'shipping'       => isset( $totals['_shipping'] ) ? (float) $totals['_shipping'] : 0.0,
			'total'          => isset( $totals['_total'] ) ? (float) $totals['_total'] : 0.0,
			'offered_grand_total' => isset( $totals['cal_offered_total'] ) ? (float) $totals['cal_offered_total'] : 0.0,
		);
	}

	/**
	 * Count the number of line items in a quote.
	 * 
	 * @param int $quote_id Quote post ID.
	 * @return int
	 */
	private function count_items( $quote_id ) {
		$quote_contents = (array) get_post_meta( $quote_id, 'quote_contents', true );
		$count          = 0;

		foreach ( $quote_contents as $item ) {
			if ( is_array( $item ) && ! empty( $item['product_id'] ) ) {
				++$count;
			}
		}

		return $count;
	}

	/**
	 * Format customer data for quote summary.
	 * 
	 * @param int $author_id Post author ID.
	 * @return array<string, mixed>
	 */
	private function format_customer( $author_id ) {
		if ( $author_id <= 0 ) {
			return array(
				'id'           => 0,
				'display_name' => __( 'Guest', 'woocommerce-wholesale-pricing' ),
				'email'        => '',
			);
		}

		$user = get_user_by( 'id', $author_id );
		if ( ! $user ) {
			return array(
				'id'           => $author_id,
				'display_name' => '',
				'email'        => '',
			);
		}

		return array(
			'id'           => (int) $user->ID,
			'display_name' => (string) $user->display_name,
			'email'        => (string) $user->user_email,
		);
	}

	/**
	 * Get human-readable label for quote status.
	 * 
	 * @param string $status Quote status slug.
	 * @return string
	 */
	private function get_status_label( $status ) {
		$object = get_post_status_object( $status );
		if ( $object && ! empty( $object->label ) ) {
			return (string) $object->label;
		}

		return $status;
	}

	/**
	 * Normalize payload to flatten quote data.
	 * 
	 * @param array<string, mixed> $data Raw payload.
	 * @return array<string, mixed>
	 */
	private function normalize_payload( array $data ) {
		if ( isset( $data['quote'] ) && is_array( $data['quote'] ) ) {
			$data = array_merge( $data, $data['quote'] );
			unset( $data['quote'] );
		}

		return $data;
	}

	/**
	 * Apply line item updates to quote contents.
	 * 
	 * @param int                  $quote_id Quote post ID.
	 * @param array<string, mixed> $payload  Normalized payload.
	 * @return bool|\WP_Error
	 */
	private function apply_line_item_updates( $quote_id, array $payload ) {
		$quote_contents = (array) get_post_meta( $quote_id, 'quote_contents', true );
		$changed        = false;

		if ( ! empty( $payload['remove_items'] ) && is_array( $payload['remove_items'] ) ) {
			foreach ( $payload['remove_items'] as $item_key ) {
				$key = (string) $item_key;
				if ( isset( $quote_contents[ $key ] ) ) {
					unset( $quote_contents[ $key ] );
					$changed = true;
				}
			}
		}

		if ( ! empty( $payload['items'] ) && is_array( $payload['items'] ) ) {
			foreach ( $payload['items'] as $item_patch ) {
				if ( ! is_array( $item_patch ) ) {
					continue;
				}

				if ( ! empty( $item_patch['key'] ) ) {
					$key = (string) $item_patch['key'];
					if ( ! isset( $quote_contents[ $key ] ) ) {
						return new \WP_Error(
							'wwp_quote_item_not_found',
							sprintf(
								/* translators: %s: quote item key */
								__( 'Quote line item not found: %s', 'woocommerce-wholesale-pricing' ),
								$key
							),
							array( 'status' => 404 )
						);
					}

					if ( isset( $item_patch['quantity'] ) ) {
						$quote_contents[ $key ]['quantity'] = max( 0, (float) $item_patch['quantity'] );
						$changed = true;
					}
					if ( isset( $item_patch['offered_price'] ) ) {
						$quote_contents[ $key ]['offered_price'] = (float) $item_patch['offered_price'];
						$changed = true;
					}
					if ( isset( $item_patch['offered_signup'] ) ) {
						$quote_contents[ $key ]['offered_signup'] = (float) $item_patch['offered_signup'];
						$changed = true;
					}
					continue;
				}

				$product_id = isset( $item_patch['product_id'] ) ? (int) $item_patch['product_id'] : 0;
				if ( $product_id <= 0 ) {
					continue;
				}

				$quantity     = isset( $item_patch['quantity'] ) ? max( 1, (float) $item_patch['quantity'] ) : 1;
				$variation_id = isset( $item_patch['variation_id'] ) ? (int) $item_patch['variation_id'] : 0;
				$quote_process = new QuoteProcess( $quote_contents );
				$new_contents  = $quote_process->add_to_quote( array(), $product_id, $quantity, $variation_id, array(), array(), true );

				if ( ! is_array( $new_contents ) ) {
					return new \WP_Error(
						'wwp_quote_add_item_failed',
						__( 'Failed to add product to quote.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}

				$quote_contents = $new_contents;
				$changed        = true;

				if ( isset( $item_patch['offered_price'] ) || isset( $item_patch['offered_signup'] ) ) {
					$item_key = $quote_process->find_product_in_quote(
						$quote_process->generate_quote_id( $product_id, $variation_id )
					);
					if ( $item_key && isset( $quote_contents[ $item_key ] ) ) {
						if ( isset( $item_patch['offered_price'] ) ) {
							$quote_contents[ $item_key ]['offered_price'] = (float) $item_patch['offered_price'];
						}
						if ( isset( $item_patch['offered_signup'] ) ) {
							$quote_contents[ $item_key ]['offered_signup'] = (float) $item_patch['offered_signup'];
						}
					}
				}
			}
		}

		if ( $changed ) {
			update_post_meta( $quote_id, 'quote_contents', $quote_contents );
			/**
			 * Action wc_quote_contents_updated
			 *
			 * @since 1.0
			 */
			do_action( 'wc_quote_contents_updated', $quote_id );
		}

		return $changed;
	}

	/**
	 * Resolve quote line item product.
	 * 
	 * @param array<string, mixed> $item Quote line item.
	 * @return \WC_Product|null
	 */
	private function resolve_item_product( array $item ) {
		if ( isset( $item['data'] ) && is_object( $item['data'] ) && is_a( $item['data'], 'WC_Product' ) ) {
			return $item['data'];
		}

		$product_id = isset( $item['product_id'] ) ? (int) $item['product_id'] : 0;
		if ( $product_id <= 0 ) {
			return null;
		}

		$product = wc_get_product( $product_id );
		return $product ? $product : null;
	}

	/**
	 * Normalize stored amount to float.
	 * 
	 * @param mixed $value Stored amount.
	 * @return float
	 */
	private function normalize_amount( $value ) {
		if ( '' === $value || null === $value ) {
			return 0.0;
		}

		return (float) $value;
	}

	/**
	 * Is the provided status a valid quote status?
	 * 
	 * @param string $status Quote status slug.
	 * @return bool
	 */
	private function is_valid_status( $status ) {
		return in_array( $status, $this->get_all_statuses(), true );
	}

	/**
	 * Resolve quote post by ID and validate post type.
	 * 
	 * @param int $quote_id Quote post ID.
	 * @return \WP_Post|\WP_Error
	 */
	private function resolve_post( $quote_id ) {
		$post = get_post( $quote_id );
		if ( ! $post || $this->get_post_type() !== $post->post_type ) {
			return new \WP_Error(
				'wwp_quote_not_found',
				__( 'Quote not found.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		return $post;
	}
}
