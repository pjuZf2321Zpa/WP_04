<?php
/**
 * PaymentMethodService class.
 *
 * Handles the integration and conditional loading of custom wholesale payment
 * methods into WooCommerce's payment gateway system.
 *
 * @package    WooCommerceWholesalePricing\Services
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

/**
 * Service for managing custom wholesale payment gateways.
 */
class PaymentMethodService {


	/**
	 * Includes methods for retrieving general wholesale settings.
	 */
	use WholesaleSettings;

	/**
	 * Constructor.
	 *
	 * Registers the filter to hook into WooCommerce's payment gateways.
	 *
	 * @return void
	 */
	public function __construct() {
		add_filter('woocommerce_payment_gateways', array( $this, 'wholesalePaymentGateways' ));
	}    

	/**
	 * Conditionally registers custom wholesale payment gateways.
	 *
	 * This function checks global settings and the user's wholesale role to determine
	 * if the custom payment method should be loaded, and uses the appropriate name
	 * (either global or role-specific).
	 *
	 * @filter woocommerce_payment_gateways
	 * @param  array $gateways Array of available WooCommerce payment gateway objects.
	 * @return array Modified array of payment gateway objects.
	 */
	public function wholesalePaymentGateways( $gateways ) {
		$current_user_id    = get_current_user_id();
		$is_wholesaler      = is_wholesaler_user($current_user_id);
		$request_uri        = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field( $_SERVER['REQUEST_URI'] ) : '';
		$is_wc_admin_api    = str_contains($request_uri, 'wc-admin/settings/payments/providers');
		$settings           = self::get_pricing_settings();
		
		if (!isset($settings['enable_custom_payment_method']) || 'yes' != $settings['enable_custom_payment_method'] ) {
			return $gateways;
		}
		if ( ! $is_wholesaler && ! is_admin() && ! $is_wc_admin_api ) {
			return $gateways;
		}
		
		$role = get_current_user_role_id();

		if ($role) {  
			$payment_method_name = get_term_meta($role, 'wwp_wholesale_payment_method_name', true);
		} else {
			$payment_method_name =  $settings['payment_method_name'];
		}
		foreach ( (array) $payment_method_name as  $key => $wholesale_custom_gateway ) {
			if (array_key_exists($key, $settings['payment_method_name']) ) {
				
				$class = 'WooCommerceWholesalePricing\App\Modules\PaymentGateway\PaymentMethod';
				if (class_exists($class) ) { 
					if ($is_wholesaler ) {
						if ('yes' == $wholesale_custom_gateway ) {
							$gateways[] = new $class($key);
						}
					} else {
						$gateways[] = new $class($key);
					} 
				}
			}
		}

		return $gateways;
	}
}
