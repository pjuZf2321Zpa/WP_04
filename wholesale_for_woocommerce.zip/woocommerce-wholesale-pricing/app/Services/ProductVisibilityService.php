<?php
/**
 * ProductVisibilityService class.
 *
 * Handles complex product exclusion logic across the WooCommerce frontend
 * based on user roles (visitor, customer, wholesaler) and plugin settings,
 * controlling visibility on shop pages, shortcodes, and single product pages.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Service responsible for hiding products from non-wholesalers and controlling access.
 * 
 * @implements ServiceInterface
 */
class ProductVisibilityService implements ServiceInterface {

	/**
	 * Includes methods for retrieving general wholesale settings.
	 */
	use WholesaleSettings;

	/**
	 *  Internal list of product IDs to be excluded from certain queries.
	 * 
	 * @var array<int> $excluded
	 */
	protected $excluded = array();

	/**
	 * Main list of product IDs dynamically calculated for exclusion.
	 * 
	 * @var array<int> $exclude_ids 
	 */
	public $exclude_ids = array();

	/**
	 * Constructor.
	 *
	 * Hooks into various WordPress and WooCommerce actions/filters to implement
	 * product visibility and purchasability rules.
	 *
	 * @return void
	 */
	public function __construct() {

		add_action( 'init', array( $this, 'wwp_get_excluded_products' ) );
		// Run before other handlers so a trashed Shop page still resolves as the product archive.
		add_action( 'pre_get_posts', array( $this, 'restore_shop_archive_when_page_trashed' ), 1, 1 );
		// Main query exclusion for archive/shop pages.
		add_action('pre_get_posts', array( $this, 'default_wholesaler_products_only' ), 999, 1 );
		add_filter( 'woocommerce_product_subcategories_args', array( $this, 'hide_excluded_categories_from_shop' ), 999 );

		// Query exclusion for WooCommerce blocks/widgets (modifies query vars).
		add_filter('parse_query', array( $this, 'default_wholesaler_products_hide_from_blocks' ), 10, 1);

		// B2B Bundle support (WooCommerce Product Table) integration.
		add_filter('wcpt_product_table_args', array( $this, 'wcpt_product_table_args' ), 10, 1);

		// Secondary pre_get_posts handler for internal exclusion list.
		add_action('pre_get_posts', array( $this, 'visibility_pre_get_posts' ), 10, 1);

		// Redirect users if they try to access a single hidden product page.
		add_action('template_redirect', array( $this, 'wwp_redirect_products' ));

		// Prevent purchasing of excluded products.
		add_filter('woocommerce_is_purchasable', array( $this, 'wwp_is_purchasable' ), 20, 2);

		 // Modify shortcode queries (e.g., [products]).
		add_filter('woocommerce_shortcode_products_query', array( $this, 'wwp_modiffy_shortcode_query' ), 10, 1);

		// Modify internal WooCommerce product queries (like layered navigation).
		add_action('woocommerce_product_query', array( $this, 'wwp_modiffy_query' ), 10, 1);

		// Placeholder function (no operation).
		add_action('woocommerce_archive_description', array( $this, 'wc_no_products_found' ), 10);
	}

	/**
	 * Adds filters to exclude products from related posts and shortcodes
	 * after the list of excluded IDs has been determined.
	 *
	 * @param  array<int> $all_ids Array of product IDs to exclude.
	 * @return void
	 */
	public function wwp_extra_product_remove( $all_ids ) {
		// Exclude products from "Related Products" section on single product pages.
		add_filter('woocommerce_related_products', array( $this, 'exclude_related_products' ), 10, 3);

		// Exclude products from WooCommerce shortcodes like [products].
		add_filter('woocommerce_shortcode_products_query', array( $this, 'woocommerce_shortcode_products_query' ), 99, 3);
	}

	/**
	 * Main handler for excluding products from the primary WordPress query.
	 *
	 * Applies restrictions based on global settings (store access),
	 * visitor visibility, and logged-in customer visibility settings.
	 *
	 * @hooked pre_get_posts 999
	 * @param  WP_Query $q The WordPress query object (passed by reference).
	 * @return void
	 */
	public function default_wholesaler_products_only( $q ) {
		
		$settings              = self::get_pricing_settings();
		$data                  = '';
		$restrict_store_access = ( isset($settings['restrict_store_access']) && 'yes' == $settings['restrict_store_access'] ) ? 'yes' : 'no';
		if (! isset($_COOKIE['access_store_id']) && 'yes' == $restrict_store_access && $q->is_main_query() && ! is_user_logged_in() && ! current_user_can('manage_options') ) {

			$all_ids = get_products_by_meta();
			
			if (! empty($all_ids) ) {
				$this->exclude_ids = $all_ids;
				$this->wwp_extra_product_remove($this->exclude_ids);
				$q->set('post__not_in', $this->exclude_ids);
			}
		}
	
		if ($q->is_main_query() && ! is_user_logged_in() && ! current_user_can('manage_options') && ! is_wholesaler_user(get_current_user_id()) ) {
			
			$all_ids = get_products_by_meta('_wwp_hide_for_visitor', 'yes');

			if (! empty($all_ids) ) {
				$this->exclude_ids = array_merge($this->exclude_ids, $all_ids);
				$this->wwp_extra_product_remove($this->exclude_ids);
				$q->set('post__not_in', $this->exclude_ids);
			}
		}

		if ($q->is_main_query() && is_user_logged_in() && ! is_wholesaler_user(get_current_user_id()) ) {
			
			$user = wp_get_current_user();
			
			if (in_array('customer', (array) $user->roles) ) {
		
				$all_ids = get_products_by_meta('_wwp_hide_for_customer', 'yes');

				if (! empty($all_ids) ) {
					$this->exclude_ids = array_merge($this->exclude_ids, $all_ids);
					$this->wwp_extra_product_remove($this->exclude_ids);
					$q->set('post__not_in', $this->exclude_ids);
				}
			}
		}
		
		$non_wholesale_product_hide = ( isset($settings['non_wholesale_product_hide']) && 'yes' == $settings['non_wholesale_product_hide'] ) ? 'yes' : 'no';
		if ('yes' == $non_wholesale_product_hide && $q->is_main_query() && is_wholesaler_user(get_current_user_id()) == false && ! current_user_can('manage_options') ) {
			
			// Global price get
			if (empty(self::get_multiuser_pricing_settings()) ) {
				$data = 'no';
			} else {
				$data = '';
			}

			$all_ids = get_products_by_meta();


			if ('no' == $data ) {
			
				$total_ids = multi_wholesale_product_ids();

				if (is_array($total_ids) ) {
					
					$exclude_ids       = array_diff($all_ids, $total_ids);
					$this->exclude_ids = array_merge($this->exclude_ids, $total_ids);
					$q->set('post__not_in', $this->exclude_ids);
					$this->wwp_extra_product_remove($this->exclude_ids);
				} else {
					$this->exclude_ids = array_merge($this->exclude_ids, $all_ids);
					$q->set('post__not_in', $this->exclude_ids);
					$this->wwp_extra_product_remove($this->exclude_ids);
				}
			} else {
					$this->exclude_ids = array_merge($this->exclude_ids, $all_ids);
					$q->set('post__not_in', $this->exclude_ids);
					$this->wwp_extra_product_remove($this->exclude_ids);
			}
		}

		$wholesaler_prod_only = ( isset($settings['wholesaler_prodcut_only']) && 'yes' == $settings['wholesaler_prodcut_only'] ) ? 'yes' : 'no';
			 
		if ('yes' == $wholesaler_prod_only && $q->is_main_query() && ! is_admin() ) {
			
			if (is_wholesaler_user(get_current_user_id()) ) {

				// Global price get
				$data = get_option('wholesale_multi_user_pricing');

				$role = get_current_user_role_id();

				$total_ids = array();
				if (! isset($data[ $role ]) ) {
					
					$cate = array();

					$categories = get_terms(array( 'taxonomy' => 'product_cat' ));
					$ids = array();
					if (is_array($categories) ) {

						foreach ( $categories as $category ) {

							$data = get_term_meta($category->term_id, 'wholesale_multi_user_pricing', true);

							if (isset($data[ $role ]['wholesale_price']) ) {

								$cate[] = $category->term_id;

							}
						}
						if ( ! empty( $cate ) ) {

							$args = array(
								'post_type'   => 'product',
								'numberposts' => -1,
								'fields'      => 'ids',
								'tax_query'   => array(
									array(
										'taxonomy' => 'product_cat',
										'field'    => 'term_id',
										'terms'    => $cate,
										'operator' => 'IN',
	
									),
								),
							);
	
							$ids = get_posts($args);
	
							if (is_array($ids) && ! empty($ids) ) {
	
								foreach ( $ids  as $id ) {
										$total_ids[] = $id;
								}
							}
						}
					}

					$all_ids = get_products_by_meta();
					
					foreach ( $all_ids as $id ) {

						$data = get_post_meta($id, 'wholesale_multi_user_pricing', true);

						if (isset($data[ $role ]) ) {
							$total_ids[] = $id;
						}
					}

					if (is_array($ids) ) {
						foreach ( $ids  as $id ) {
							$total_ids[] = $id;
						}
					}

					if (! empty($total_ids) && is_array($total_ids) ) {

						$total_ids   = array_unique($total_ids);
						$exclude_ids = array_diff($all_ids, $total_ids);
						$q->set('post__not_in', $exclude_ids);
						$this->exclude_ids = $exclude_ids;
						add_filter('woocommerce_related_products', array( $this, 'exclude_related_products' ), 10, 3);
						
					} else {
						$q->set('post__not_in', $all_ids);
					}
				}
			}
		}
	}

	public function hide_excluded_categories_from_shop( $args ) {
		if ( ! is_user_logged_in() && ! current_user_can( 'manage_options' ) && ! is_wholesaler_user( get_current_user_id() ) ) {
			// Get products hidden for visitors
			
			$excluded_categories = $this->get_cached_categories();

			// Exclude from category query
			if ( ! empty( $excluded_categories ) ) {
				$args['exclude'] = isset( $args['exclude'] ) ? array_merge( $args['exclude'], $excluded_categories ) : $excluded_categories;
			}
		}

		if ( is_user_logged_in() && ! current_user_can( 'manage_options' ) && ! is_wholesaler_user( get_current_user_id() ) ) {
			$hidden_product_ids = get_products_by_meta( '_wwp_hide_for_customer', 'yes' );

			if ( empty( $hidden_product_ids ) ) {
				return $args;
			}
			// Get related categories
			$excluded_categories = array();
			foreach ( $hidden_product_ids as $product_id ) {
				$terms = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );
				if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
					$excluded_categories = array_merge( $excluded_categories, $terms );
				}
			}

			$excluded_categories = array_unique( $excluded_categories );

			// Only exclude categories where ALL products are hidden for customers.
			if ( ! empty( $excluded_categories ) ) {
				$filtered = array();
				foreach ( $excluded_categories as $cat_id ) {
					$non_hidden_args = array(
						'post_type'      => 'product',
						'posts_per_page' => 1,
						'fields'         => 'ids',
						'tax_query'      => array(
							array(
								'taxonomy' => 'product_cat',
								'field'    => 'term_id',
								'terms'    => $cat_id,
							),
						),
						'meta_query'     => array(
							'relation' => 'OR',
							array(
								'key'     => '_wwp_hide_for_customer',
								'value'   => 'yes',
								'compare' => '!=',
							),
							array(
								'key'     => '_wwp_hide_for_customer',
								'compare' => 'NOT EXISTS',
							),
						),
					);

					$non_hidden = get_posts( $non_hidden_args );

					if ( empty( $non_hidden ) ) {
						$filtered[] = $cat_id;
					}
				}
				$excluded_categories = $filtered;
			}

			// Exclude from category query
			if ( ! empty( $excluded_categories ) ) {
				$args['exclude'] = isset( $args['exclude'] ) ? array_merge( $args['exclude'], $excluded_categories ) : $excluded_categories;
			}
		}
		return $args;
	}

	/**
	 * Applies product exclusion logic to non-main queries, particularly for blocks (WooCommerce/Gutenberg).
	 *
	 * Modifies the `query_vars` directly via the `parse_query` hook.
	 *
	 * @hooked parse_query 10
	 * @param  WP_Query $q The WordPress query object (passed by reference).
	 * @return WP_Query The modified query object.
	 */
	public function default_wholesaler_products_hide_from_blocks( $q ) {

		if (! function_exists('is_user_logged_in') ) {
			include_once ABSPATH . 'wp-includes/pluggable.php';
		}
		
		$settings              = self::get_pricing_settings();
		$data                  = '';
		$restrict_store_access = ( isset($settings['restrict_store_access']) && 'yes' == $settings['restrict_store_access'] ) ? 'yes' : 'no';
		
		if (! isset($_COOKIE['access_store_id']) && 'yes' == $restrict_store_access && ! is_user_logged_in() && ! current_user_can('manage_options') ) {

			$all_ids = get_products_by_meta();
			
			if (! empty($all_ids) ) {
				$this->exclude_ids = $all_ids;
				$q->query_vars['post__not_in'] = $this->exclude_ids;
			}
		}
	
		if (! is_user_logged_in() && ! current_user_can('manage_options') && ! is_wholesaler_user(get_current_user_id()) ) {
			
			$all_ids = get_products_by_meta('_wwp_hide_for_visitor', 'yes');
			

			if (! empty($all_ids) ) {
				$this->exclude_ids = array_merge($this->exclude_ids, $all_ids);
				$q->query_vars['post__not_in'] = $this->exclude_ids;
			}
		}

		if (is_user_logged_in() && ! is_wholesaler_user(get_current_user_id()) ) {
			
			$user = wp_get_current_user();
			
			if (in_array('customer', (array) $user->roles) ) {
		
				$all_ids = get_products_by_meta('_wwp_hide_for_customer', 'yes');

				if (! empty($all_ids) ) {
					$this->exclude_ids = array_merge($this->exclude_ids, $all_ids);
					$q->query_vars['post__not_in'] = $this->exclude_ids;
				}
			}
		}
		
		$non_wholesale_product_hide = ( isset($settings['non_wholesale_product_hide']) && 'yes' == $settings['non_wholesale_product_hide'] ) ? 'yes' : 'no';

		if ('yes' == $non_wholesale_product_hide && is_wholesaler_user(get_current_user_id()) == false && ! current_user_can('manage_options') ) {
			// Global price get
			if (empty(self::get_multiuser_pricing_settings()) ) {
				$data = 'no';
			} else {
				$data = '';
			}

			$all_ids = get_products_by_meta();


			if ('no' == $data ) {
			
				$total_ids = multi_wholesale_product_ids();

				if (is_array($total_ids) ) {
					
					$exclude_ids       = array_diff($all_ids, $total_ids);
					$this->exclude_ids = array_merge($this->exclude_ids, $total_ids);
					$q->query_vars['post__not_in'] = $this->exclude_ids;
				} else {
					$this->exclude_ids = array_merge($this->exclude_ids, $all_ids);
					$q->query_vars['post__not_in'] = $this->exclude_ids;
				}
			} else {
					$this->exclude_ids = array_merge($this->exclude_ids, $all_ids);
					$q->query_vars['post__not_in'] = $this->exclude_ids;
			}
		}

		if ( ! empty( $this->excluded ) && $this->is_product_listing_query( $q ) ) {
			$role_hidden_ids = $this->excluded;
			if ( ! empty( $role_hidden_ids ) ) {
				$post__not_in = isset( $q->query_vars['post__not_in'] ) ? (array) $q->query_vars['post__not_in'] : array();
				$q->query_vars['post__not_in'] = array_unique( array_merge( $post__not_in, $role_hidden_ids ) );
			}
		}
		
		return $q;
	}

	/**
	 * Modifies the query arguments for WooCommerce Product Table (WCPT) plugin.
	 *
	 * Excludes products based on different visibility rules. This seems to be a dedicated
	 * handler for the B2B Bundle/WCPT integration.
	 *
	 * @hooked wcpt_product_table_args 10
	 * @param  array $wcpt_product_table_args Query arguments for WCPT.
	 * @return array Modified query arguments.
	 */
	public function wcpt_product_table_args( $wcpt_product_table_args ) {
		
		$settings = self::get_pricing_settings();
		if (! is_user_logged_in() && ! current_user_can('manage_options') && ! is_wholesaler_user(get_current_user_id()) ) {

			$all_ids = get_posts(
				array(
					'post_type'   => 'product',
					'numberposts' => -1,
					'post_status' => 'publish',
					'meta_query'  => array(
						array(
							'key'   => '_wwp_hide_for_visitor',
							'value' => 'yes',
						),
					),
					'fields'      => 'ids',
				)
			);
			if (! empty($all_ids) ) {
				$wcpt_product_table_args['post__not_in'] = $all_ids;
			}
		}
			
		if (is_user_logged_in() && ! is_wholesaler_user(get_current_user_id()) ) {

			$user = wp_get_current_user();

			if (in_array('customer', (array) $user->roles) ) {

				$all_ids = get_posts(
					array(
						'post_type'   => 'product',
						'numberposts' => -1,
						'post_status' => 'publish',
						'meta_query'  => array(
							array(
								'key'   => '_wwp_hide_for_customer',
								'value' => 'yes',
							),
						),
						'fields'      => 'ids',
					)
				);
				if (! empty($all_ids) ) {
					$wcpt_product_table_args['post__not_in'] = $all_ids;
				}
			}
		}
		
		$all_ids = $this->wwp_get_excluded_products();
		if (! empty($all_ids) ) {
			$wcpt_product_table_args['post__not_in'] = $all_ids;
		}
			
		return $wcpt_product_table_args;
	}

	/**
	 * Retrieves a list of product IDs that are explicitly hidden from the current user's role.
	 *
	 * @uses   wwp_get_products_multi()
	 * @return array<int>|false Array of excluded product IDs, or false if user role is not whitelisted.
	 */
	public function wwp_get_excluded_products() {

		if (! is_user_logged_in() ) {
			return false;
		}
		$user = get_userdata(get_current_user_id());
		if ( ! $user || empty( $user->roles ) ) {
			return false;
		}

		$products_excluded = array();
		foreach ( (array) $user->roles as $user_role ) {
			if ( term_exists( $user_role, 'wholesale_user_roles' ) ) {
				$products_excluded = array_merge(
					$products_excluded,
					$this->wwp_get_products_multi( $user_role )
				);
			}
		}

		$this->excluded = array_values( array_unique( $products_excluded ) );
		return $this->excluded;
	}

	/**
	 * Fetches product and product category IDs that are explicitly marked as hidden
	 * for a specific wholesale role via the 'wholesale_product_visibility_multi' meta key.
	 *
	 * @param  string $role The user role (term slug) to check visibility for.
	 * @return array<int> Consolidated array of excluded product IDs.
	 */
	public function wwp_get_products_multi( $role ) {
		$excluded_products_1 = array();
		$excluded_products_2 = array();
		$args                = array(
			'post_type'      => array( 'product' ),
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_query'     => array(
				array(
					'key'     => 'wholesale_product_visibility_multi',
					'value'   => sprintf(':"%s";', $role),
					'compare' => 'LIKE',
				),
			),
		);
		$excluded_products_1 = get_posts($args);
		$args                = array(
			'hide_empty'     => true,
			'fields'         => 'ids',
			'posts_per_page' => -1,
			'meta_query'     => array(
				array(
					'key'     => 'wholesale_product_visibility_multi',
					'value'   => sprintf(':"%s";', $role),
					'compare' => 'LIKE',
				),
			),
			'taxonomy'       => 'product_cat',
		);
		$terms               = get_terms($args);
		if (! empty($terms) ) {
			$args                = array(
				'post_type'      => array( 'product' ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'tax_query'      => array(
					array(
						'taxonomy' => 'product_cat',
						'terms'    => $terms,
						'operator' => 'IN',
					),
				),
			);
			$excluded_products_2 = get_posts($args);
		}
		return array_merge($excluded_products_1, $excluded_products_2);
	}

	/**
	 * Modifies WooCommerce shortcode product queries (e.g., [products]).
	 *
	 * Ensures products in `$this->exclude_ids` are removed from results.
	 *
	 * @hooked woocommerce_shortcode_products_query 99
	 * @param  array  $query_args The product query arguments.
	 * @param  array  $attributes The shortcode attributes.
	 * @param  string $type       The shortcode type.
	 * @return array Modified query arguments.
	 */
	public function woocommerce_shortcode_products_query( $query_args, $attributes, $type ) {
		if (isset($query_args['post__in']) && is_array($query_args['post__in']) ) {
			$query_args['post__in'] = array_diff($query_args['post__in'], $this->exclude_ids);
		}
		$query_args['post__not_in'] = $this->exclude_ids;
		return $query_args;
	}

	/**
	 * Excludes hidden products from the list of related products on a single product page.
	 *
	 * @hooked woocommerce_related_products 10
	 * @param  array<int> $related_posts Array of related product IDs.
	 * @param  int        $product_id    The ID of the current product.
	 * @param  array      $args          Arguments passed to the related product query.
	 * @return array<int> Filtered array of related product IDs.
	 */
	public function exclude_related_products( $related_posts, $product_id, $args ) {
		return array_diff($related_posts, $this->exclude_ids);
	}

	/**
	 * Secondary pre_get_posts handler to set exclusions from the internal `$excluded` property.
	 *
	 * Note: This property is not populated in the provided code, which may indicate missing logic
	 * or a legacy feature, but the hook is documented based on its intention.
	 *
	 * @hooked pre_get_posts 10
	 * @param  WP_Query $q The WordPress query object (passed by reference).
	 * @return void
	 */
	public function visibility_pre_get_posts( $q ) {
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return;
		}

		if ( ! $this->is_product_listing_query( $q ) ) {
			return;
		}

		if ($q->is_front_page() || ( isset($q->query['post_type']) && 'wc-quote-rules' == @$q->query['post_type'] ) ) {
			return;
		} 

		if (! is_user_logged_in() ) {
			return;
		}

		$user = wp_get_current_user();
		if (in_array('customer', (array) $user->roles, true) ) {
			return;
		}

		if ( empty( $this->excluded ) ) {
			return;
		}

		$post__not_in = (array) $q->get( 'post__not_in' );
		$q->set( 'post__not_in', array_merge( $post__not_in, $this->excluded ) );
	}

	/**
	 * When the WooCommerce Shop page is in the trash, WordPress may 404 the /shop/ URL.
	 * Re-route that request to the product archive so WooCommerce titles and templates work.
	 *
	 * @hooked pre_get_posts 1
	 * @param  \WP_Query $q The WordPress query object.
	 * @return void
	 */
	public function restore_shop_archive_when_page_trashed( $q ) {
		if ( is_admin() || ! $q->is_main_query() || ! function_exists( 'wc_get_page_id' ) ) {
			return;
		}

		$shop_page_id = wc_get_page_id( 'shop' );
		if ( $shop_page_id <= 0 ) {
			return;
		}

		$shop_page = get_post( $shop_page_id );
		if ( ! $shop_page instanceof \WP_Post || 'trash' !== $shop_page->post_status ) {
			return;
		}

		$requested_page_id = absint( $q->get( 'page_id' ) );
		$pagename            = $q->get( 'pagename' );
		if ( empty( $pagename ) ) {
			$pagename = $q->get( 'name' );
		}

		$matches_shop_slug = ( ! empty( $pagename ) && $shop_page->post_name === $pagename );
		$matches_shop_id   = ( $requested_page_id > 0 && $requested_page_id === $shop_page_id );

		if ( ! $matches_shop_slug && ! $matches_shop_id ) {
			return;
		}

		$q->set( 'post_type', 'product' );
		$q->set( 'page_id', '' );
		$q->set( 'pagename', '' );
		$q->set( 'name', '' );
		$q->set( 'page', '' );

		$q->is_page              = false;
		$q->is_singular          = false;
		$q->is_post_type_archive = true;
		$q->is_archive           = true;
		$q->is_404               = false;
	}

	/**
	 * Limit visibility query changes to WooCommerce product listings.
	 *
	 * @param  \WP_Query $q The WordPress query object.
	 * @return bool
	 */
	private function is_product_listing_query( $q ) {
		$post_type = $q->get( 'post_type' );

		if ( is_array( $post_type ) ) {
			return in_array( 'product', $post_type, true );
		}

		if ( 'product' === $post_type ) {
			return true;
		}

		return ! empty( $q->get( 'wc_query' ) );
	}

	/**
	 * Redirects users attempting to access a single product page that should be hidden.
	 *
	 * @hooked template_redirect
	 * @global \WP_Post $post The global post object.
	 * @return void
	 */
	public function wwp_redirect_products() {
		global $post;
		if (wc_get_product($post) ) {
			$product = wc_get_product($post);
		}
		if (is_singular('product') && ! empty($post) && ! empty($this->excluded) && in_array($product->get_id(), $this->excluded) ) {
			wp_safe_redirect(home_url());
			exit;
		}
	}

	/**
	 * Filters WooCommerce purchasability to prevent excluded products from being bought.
	 *
	 * @hooked woocommerce_is_purchasable 20
	 * @param  bool        $purchasable Current purchasable status.
	 * @param  \WC_Product $product     The product object.
	 * @return bool Modified purchasable status.
	 */
	public function wwp_is_purchasable( $purchasable, $product ) {
		if (! empty($this->excluded) && in_array($product->get_id(), $this->excluded) ) {
			return false;
		}
		return $purchasable;
	}

	/**
	 * Modifies the shortcode query arguments by adding products from the internal `$excluded` list.
	 *
	 * @hooked woocommerce_shortcode_products_query 10
	 * @param  array $query_args The product query arguments.
	 * @return array Modified query arguments.
	 */
	public function wwp_modiffy_shortcode_query( $query_args ) {
		$excluded_products = $this->excluded;
		if (! empty($excluded_products) ) {
			$post__not_in               = isset($query_args['post__not_in']) ? (array) $query_args['post__not_in'] : array();
			$query_args['post__not_in'] = array_merge($post__not_in, $excluded_products);
		}
		return $query_args;
	}

	/**
	 * Modifies the internal WooCommerce product query (e.g., used by widgets/filters).
	 *
	 * @hooked woocommerce_product_query 10
	 * @param  WP_Query $query The WooCommerce product query object (passed by reference).
	 * @return void
	 */
	public function wwp_modiffy_query( $query ) {
		
		if (is_woocommerce() && $query->is_main_query() && isset($query->query_vars['wc_query']) ) {
			$excluded_products = $this->excluded;
			
			if (! empty($excluded_products) ) {
				$post__not_in = (array) $query->get('post__not_in');
				$query->set('post__not_in', array_merge($post__not_in, $excluded_products));
			}
		}
	}

	/**
	 * Placeholder function hooked to `woocommerce_archive_description`.
	 * This function is empty and likely serves as a potential hook target for future features.
	 *
	 * @hooked woocommerce_archive_description 10
	 * @return void
	 */
	public function wc_no_products_found() {
	}

	public function get_cached_categories() {

		$cached_ids = get_transient( 'wwp_exc_cats' );

		if ( false !== $cached_ids ) {
			return (array) $cached_ids;
		}

		$hidden_product_ids = get_products_by_meta( '_wwp_hide_for_visitor', 'yes' );

		if ( empty( $hidden_product_ids ) ) {
			return null;
		}

		// Get related categories
		$excluded_categories = array();
		foreach ( $hidden_product_ids as $product_id ) {
			$terms = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );
			if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
				$excluded_categories = array_merge( $excluded_categories, $terms );
			}
		}
		$excluded_categories = array_unique( $excluded_categories );

		// Only exclude categories where ALL products are hidden for visitors.
		if ( ! empty( $excluded_categories ) ) {
			$filtered = array();
			foreach ( $excluded_categories as $cat_id ) {
				// Look for at least one product in this category that is NOT hidden.
				$non_hidden_args = array(
					'post_type'      => 'product',
					'posts_per_page' => 1,
					'fields'         => 'ids',
					'tax_query'      => array(
						array(
							'taxonomy' => 'product_cat',
							'field'    => 'term_id',
							'terms'    => $cat_id,
						),
					),
					'meta_query'     => array(
						'relation' => 'OR',
						array(
							'key'     => '_wwp_hide_for_visitor',
							'value'   => 'yes',
							'compare' => '!=',
						),
						array(
							'key'     => '_wwp_hide_for_visitor',
							'compare' => 'NOT EXISTS',
						),
					),
				);

				$non_hidden = get_posts( $non_hidden_args );

				// If no non-hidden product found, it means ALL products are hidden -> keep for exclusion
				if ( empty( $non_hidden ) ) {
					$filtered[] = $cat_id;
				}
			}
			$excluded_categories = $filtered;
		}

		set_transient( 'wwp_exc_cats', $excluded_categories, 12 * HOUR_IN_SECONDS );
		return $excluded_categories;
	}

	/**
	 * Determines if the service dependencies are met.
	 *
	 * This service is designed to run on the frontend.
	 *
	 * @return bool True if the service should be initialized (i.e., when not in admin).
	 */
	public static function resolveDependency() {
		return ! is_admin();
	}
}
