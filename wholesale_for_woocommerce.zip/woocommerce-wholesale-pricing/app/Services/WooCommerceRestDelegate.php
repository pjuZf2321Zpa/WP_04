<?php
/**
 * Delegates CRUD operations to WooCommerce REST API controllers.
 *
 * @package WooCommerceWholesalePricing\App\Services
 */

namespace WooCommerceWholesalePricing\App\Services;

/**
 * Executes WooCommerce REST operations via rest_do_request().
 */
class WooCommerceRestDelegate {

	/**
	 * Valid operations.
	 *
	 * @var list<string>
	 */
	const OPERATIONS = array( 'list', 'get', 'create', 'update', 'delete' );

	/**
	 * Execute a products REST operation.
	 *
	 * @param string               $operation Operation name.
	 * @param array<string, mixed> $input     Request payload (may include id).
	 * @return array<string, mixed>|\WP_Error
	 */
	public function execute_products( $operation, $input ) {
		return $this->execute( $operation, $input, '/wc/v3/products' );
	}

	/**
	 * Execute a product categories REST operation.
	 *
	 * @param string               $operation Operation name.
	 * @param array<string, mixed> $input     Request payload (may include id).
	 * @return array<string, mixed>|\WP_Error
	 */
	public function execute_categories( $operation, $input ) {
		return $this->execute( $operation, $input, '/wc/v3/products/categories' );
	}

	/**
	 * Check whether the current user may perform a product operation.
	 *
	 * @param string $operation Operation name.
	 * @return bool|\WP_Error
	 */
	public function check_product_permission( $operation ) {
		return $this->check_permission( $operation, 'product' );
	}

	/**
	 * Check whether the current user may perform a category operation.
	 *
	 * @param string $operation Operation name.
	 * @return bool|\WP_Error
	 */
	public function check_category_permission( $operation ) {
		return $this->check_permission( $operation, 'category' );
	}

	/**
	 * Execute a WooCommerce REST operation.
	 * 
	 * @param string               $operation Operation name.
	 * @param array<string, mixed> $input     Request payload.
	 * @param string               $route     REST route.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function execute( $operation, $input, $route ) {
		if ( ! in_array( $operation, self::OPERATIONS, true ) ) {
			return new \WP_Error(
				'wwp_wc_rest_invalid_operation',
				__( 'Invalid REST operation.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( ! function_exists( 'rest_do_request' ) ) {
			return new \WP_Error(
				'wwp_wc_rest_unavailable',
				__( 'WordPress REST API is not available.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		$payload = $input;
		unset( $payload['wholesale'], $payload['action'], $payload['identifier'], $payload['product'], $payload['category'] );

		if ( isset( $input['identifier'] ) && in_array( $operation, array( 'get', 'update', 'delete' ), true ) ) {
			$payload['id'] = (int) $input['identifier'];
		}

		if ( isset( $input['product'] ) && is_array( $input['product'] ) ) {
			$payload = array_merge( $payload, $input['product'] );
		} elseif ( isset( $input['category'] ) && is_array( $input['category'] ) ) {
			$payload = array_merge( $payload, $input['category'] );
		}

		$method        = $this->get_http_method( $operation );
		$request_route = $route;

		if ( isset( $payload['id'] ) && in_array( $operation, array( 'get', 'update', 'delete' ), true ) ) {
			$request_route .= '/' . (int) $payload['id'];
			unset( $payload['id'] );
		}

		// Taxonomy resources (e.g. product categories) cannot be trashed via REST.
		if ( 'delete' === $operation && str_starts_with( $route, '/wc/v3/products/categories' ) ) {
			$payload['force'] = true;
		}

		$request = new \WP_REST_Request( $method, $request_route );
		foreach ( $payload as $key => $value ) {
			$request->set_param( $key, $value );
		}

		$response = rest_do_request( $request );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		if ( $response instanceof \WP_REST_Response && $response->is_error() ) {
			$error = $response->as_error();
			return $error ? $error : new \WP_Error(
				'wwp_wc_rest_error',
				__( 'WooCommerce REST request failed.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		$data = $response instanceof \WP_REST_Response ? $response->get_data() : $response;

		if ( 'list' === $operation ) {
			$headers = $response instanceof \WP_REST_Response ? $response->get_headers() : array();
			$total   = isset( $headers['X-WP-Total'] ) ? (int) $headers['X-WP-Total'] : count( (array) $data );

			return array(
				'data'  => is_array( $data ) ? $data : array(),
				'total' => $total,
			);
		}

		if ( 'delete' === $operation && is_array( $data ) ) {
			return $data;
		}

		return is_array( $data ) ? $data : array( 'data' => $data );
	}

	/**
	 * Create one or more product variations via WooCommerce REST API.
	 *
	 * @param int                       $product_id Parent variable product ID.
	 * @param list<array<string,mixed>> $variations Variation payloads.
	 * @return list<array<string,mixed>>|\WP_Error
	 */
	public function create_product_variations( $product_id, array $variations ) {
		if ( $product_id <= 0 ) {
			return new \WP_Error(
				'wwp_wc_rest_invalid_product',
				__( 'A valid product ID is required to create variations.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( ! function_exists( 'rest_do_request' ) ) {
			return new \WP_Error(
				'wwp_wc_rest_unavailable',
				__( 'WordPress REST API is not available.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		$created = array();

		foreach ( $variations as $variation_data ) {
			if ( ! is_array( $variation_data ) ) {
				continue;
			}

			$request = new \WP_REST_Request( 'POST', '/wc/v3/products/' . $product_id . '/variations' );
			foreach ( $variation_data as $key => $value ) {
				$request->set_param( $key, $value );
			}

			$response = rest_do_request( $request );
			if ( is_wp_error( $response ) ) {
				return $response;
			}

			if ( $response instanceof \WP_REST_Response && $response->is_error() ) {
				$error = $response->as_error();
				return $error ? $error : new \WP_Error(
					'wwp_wc_rest_error',
					__( 'Failed to create product variation.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 500 )
				);
			}

			$data = $response instanceof \WP_REST_Response ? $response->get_data() : $response;
			if ( is_array( $data ) ) {
				$created[] = $data;
			}
		}

		return $created;
	}

	/**
	 * Get the HTTP method for a given operation.
	 * 
	 * @param string $operation Operation name.
	 * @return string
	 */
	private function get_http_method( $operation ) {
		$map = array(
			'list'   => 'GET',
			'get'    => 'GET',
			'create' => 'POST',
			'update' => 'PUT',
			'delete' => 'DELETE',
		);

		return isset($map[ $operation ]) ? $map[ $operation ] : 'GET';
	}

	/**
	 * Check whether the current user may perform a WooCommerce REST operation.
	 * 
	 * @param string $operation Operation name.
	 * @param string $resource  product|category.
	 * @return bool|\WP_Error
	 */
	private function check_permission( $operation, $resource ) {
		if ( 'category' === $resource ) {
			switch ( $operation ) {
				case 'list':
				case 'get':
					return current_user_can( 'manage_product_terms' ) || current_user_can( 'edit_products' );
				case 'create':
				case 'update':
					return current_user_can( 'manage_product_terms' );
				case 'delete':
					return current_user_can( 'manage_product_terms' );
			}
		}

		switch ( $operation ) {
			case 'list':
			case 'get':
				return current_user_can( 'read' ) && ( current_user_can( 'edit_products' ) || current_user_can( 'manage_woocommerce' ) );
			case 'create':
				return current_user_can( 'publish_products' );
			case 'update':
				return current_user_can( 'edit_products' );
			case 'delete':
				return current_user_can( 'delete_products' );
		}

		return new \WP_Error(
			'wwp_wc_rest_forbidden',
			__( 'You do not have permission for this WooCommerce operation.', 'woocommerce-wholesale-pricing' ),
			array( 'status' => 403 )
		);
	}
}
