<?php
/**
 * ProductCatTaxonomyService class.
 *
 * Manages custom fields and settings on the WooCommerce Product Category
 * taxonomy pages, allowing wholesale pricing rules and visibility settings
 * to be configured per category.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Service to integrate wholesale rules into the Product Category taxonomy UI.
 * 
 * @implements ServiceInterface
 */
class ProductCatTaxonomyService implements ServiceInterface {

	/**
	 * Constructor.
	 *
	 * Hooks methods to display and save custom fields on product category screens.
	 *
	 * @return void
	 */
	public function __construct() {
		// Add fields to the 'Add New Category' screen.
		add_action('product_cat_add_form_fields', array( $this, 'add_fields' ), 10);

		// Add fields to the 'Edit Category' screen.
		add_action('product_cat_edit_form_fields', array( $this, 'edit_fields' ), 10, 1);

		// Save fields when an existing category is updated.
		add_action('edited_product_cat', array( $this, 'update_fields' ), 10, 2);

		// Save fields when a new category is created.
		add_action('create_product_cat', array( $this, 'update_fields' ), 10, 2);
	}

	/**
	 * Outputs fields for the 'Add New Category' screen.
	 *
	 * Assumes a global helper function `wwp_view()` exists to render the corresponding view file.
	 *
	 * @hooked product_cat_add_form_fields
	 * @return string The rendered HTML content.
	 */
	public function add_fields() {
		return wwp_view('admin.product-category.add');
	}

	/**
	 * Outputs fields for the 'Edit Category' screen.
	 *
	 * Assumes a global helper function `wwp_view()` exists to render the corresponding view file.
	 *
	 * @hooked product_cat_edit_form_fields
	 * @param  \WP_Term $term The current term object being edited.
	 * @return string The rendered HTML content.
	 */
	public function edit_fields( $term ) {
		return wwp_view('admin.product-category.edit', compact('term'));
	}

	/**
	 * Updates the custom wholesale fields when a product category is created or edited.
	 *
	 * Gathers pricing rules, quantity rules, and visibility settings for all
	 * available wholesale roles and saves them as term meta.
	 *
	 * @hooked edited_product_cat
	 * @hooked create_product_cat
	 * @param  int $term_id The ID of the term being updated/created.
	 * @param  int $tt_id   The term taxonomy ID (unused, but included by hook signature).
	 * @return void
	 */
	public function update_fields( $term_id, $term ) {
		if (! isset($_POST['wwp_wholeset_ruleset_nonce']) || ! wp_verify_nonce(wc_clean($_POST['wwp_wholeset_ruleset_nonce']), 'wwp_wholeset_ruleset_nonce') ) {
			return;
		}
		$roles = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
		$data  = array();

		if (! empty($roles) ) {
			foreach ( $roles as $key => $role ) {
				if (! isset($_POST[ 'role_' . $role->term_id ]) ) {
					continue;
				}
				if (isset($_POST[ 'role_' . $role->term_id ]) ) {
					$data[ $role->term_id ]['slug'] = $role->slug;
				}
				if (isset($_POST[ 'discount_type_' . $role->term_id ]) ) {
					$data[ $role->term_id ]['discount_type'] = wc_clean($_POST[ 'discount_type_' . $role->term_id ]);
				}
				if (isset($_POST[ 'wholesale_price_' . $role->term_id ]) ) {
					$category_wholesale_price = sanitize_text_field( wp_unslash( $_POST[ 'wholesale_price_' . $role->term_id ] ) );
					$data[ $role->term_id ]['wholesale_price'] = wwp_sanitize_price( $category_wholesale_price );
				}
				if (isset($_POST[ 'min_quatity_' . $role->term_id ]) ) {
					$data[ $role->term_id ]['min_quatity'] = is_numeric(wc_clean($_POST[ 'min_quatity_' . $role->term_id ])) ? wc_clean($_POST[ 'min_quatity_' . $role->term_id ]) : 1;
				}
				if (isset($_POST[ 'step_quantity_' . $role->term_id ]) ) {
					$data[ $role->term_id ]['step_quantity'] = is_numeric(wc_clean($_POST[ 'step_quantity_' . $role->term_id ])) ? wc_clean($_POST[ 'step_quantity_' . $role->term_id ]) : '';
				}
			}
		}

		update_term_meta($term_id, 'wholesale_multi_user_pricing', $data);
		if (isset($_POST['wholesale_product_visibility_multi']) ) {
			update_term_meta($term_id, 'wholesale_product_visibility_multi', (array) wc_clean($_POST['wholesale_product_visibility_multi']));
		} else {
			update_term_meta($term_id, 'wholesale_product_visibility_multi', '');
		}
		if (isset($_POST['wholesale_product_visibility_multi_customer']) ) {
			update_term_meta($term_id, 'wholesale_product_visibility_multi_customer', (array) wc_clean($_POST['wholesale_product_visibility_multi_customer']));
		} else {
			update_term_meta($term_id, 'wholesale_product_visibility_multi_customer', '');
		}
		if (isset($_POST['category_tier_pricing']) ) {
			update_term_meta($term_id, 'category_tier_pricing', wwp_sanitize_tier_prices( (array) wc_clean($_POST['category_tier_pricing']) ) );
		} else {
			update_term_meta($term_id, 'category_tier_pricing', '');
		}
	}

	/**
	 * Determines if the service dependencies are met.
	 *
	 * This service is only needed in the WordPress Admin area.
	 *
	 * @return bool True if the service should be initialized (i.e., when in admin).
	 */
	public static function resolveDependency() {
		return is_admin();
	}
}
