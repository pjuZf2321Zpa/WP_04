<?php

namespace WooCommerceWholesalePricing\App\Services\SalesAgent;

use WooCommerceWholesalePricing\App\Strategies\Init;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Service class for managing the custom 'Commission Category' taxonomy.
 *
 * This class extends the base Init strategy and hooks into taxonomy-related actions
 * to manage the creation, deletion, editing, and custom field saving for commission categories.
 */
class TaxonomyService extends Init implements ServiceInterface {

	public $slug;

	public function __construct() {
		$this->slug = wwp_env()->get('commission_tax_slug');

		parent::__construct();
		
		add_action( $this->slug . '_edit_form_fields', array( $this, 'edit' ), 10, 2 );
		add_action( $this->slug . '_add_form_fields', array( $this, 'add' ), 10, 2 );

		add_filter( 'pre_insert_term', array( $this, 'validation' ), 10, 3 );

		// save custom field to commission_cat taxonomy in edit and create.
		add_action( 'edited_' . $this->slug, array( $this, 'save' ), 10, 2 );
		add_action( 'create_' . $this->slug, array( $this, 'save' ), 10, 2 );

		// To show the column header
		add_filter( 'manage_edit-' . $this->slug . '_columns', array( $this, 'columns' ), 10 );

		// To show the column value
		add_action( 'manage_' . $this->slug . '_custom_column', array( $this, 'column_values' ), 10, 3 );
	}

	public function register() {
		register_taxonomy(
			wwp_env()->get('commission_tax_slug'), // The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces).
			wwp_env()->get('sales_agent_pt_slug'), // post type name
			array(
				'label'              => 'Commission Category', // display name
				'labels'             => array(
					'add_new_item' => 'Add new category',
					'edit_item' => 'Edit Commission Category',
					'back_to_items' => 'Back to Commission Category',
				),
				'query_var'          => true,
				'rewrite'            => array(
					'slug'       => wwp_env()->get('sales_agent_pt_slug'), // This controls the base slug that will display before each term
					'with_front' => false,  // Don't display the category base before
				),
				'show_admin_column'  => false,
				'show_in_quick_edit' => false,
				'meta_box_cb'        => false,
				'show_in_menu'       => false,
			)
		);
	}

	public function edit( $term ) {
		return wwp_view('admin.sales-agent.commission-category.edit', compact('term'));
	}

	public function add() {
		return wwp_view('admin.sales-agent.commission-category.add');
	}

	public function columns( $columns ) {

		$inserted = array(
			'commission_type' => __('Type'),
			'commission_value' => __('Value'),
			'commission_products' => __('No. of Products'),
		);
		array_splice( $columns, 2, 2, $inserted );
		return $columns;
	}

	public function column_values( $value, $column_name, $tax_id ) {
		$term_meta = get_option( "taxonomy_term_$tax_id" );
	
		// Show commission type
		if (0 == $column_name) {
			$comm_type = '';
			if ( ! empty( $term_meta ) && $term_meta['commission_type'] ) {
				$comm_type = ucfirst($term_meta['commission_type']);
				return $comm_type;
			}
			return $comm_type;
		}

		// Show commission value
		if (1 === $column_name) {
			$comm_val = 0;
			if ( ! empty( $term_meta ) && $term_meta['commission_value'] ) {
				$comm_val = $term_meta['commission_value'];
				return $comm_val;
				
			}
			return $comm_val;
		}
		if (2 === $column_name) {
			$comm_products = 0;
			if ( isset( $term_meta['commission_prod_cat'] ) && !empty( $term_meta['commission_prod_cat'] ) ) {
				if ( 'commission_on_cat' === $term_meta['commission_prod_cat'] ) {
					$comm_category = isset( $term_meta['commission_category'] ) ? $term_meta['commission_category'] : array();
					if ( count($comm_category) == 0 ) {
						return 'All Categories';
					} else {
						$total_count   = 0;
				
						// Iterate through all categories and sum up the counts
						foreach ($comm_category as $category_slug) {
							$term = get_term_by('slug', $category_slug, 'product_cat');
							if ($term && !is_wp_error($term)) {
								$total_count += $term->count;
							}
						}
						
						return $total_count;
					}
				} else if ('commission_on_prod' === $term_meta['commission_prod_cat']) {
					$comm_products = isset( $term_meta['commission_products'] ) ? $term_meta['commission_products'] : array();
					return ( count($comm_products) == 0 ) ? 'All Products' : count($comm_products);
				}
			}
			return $comm_products;
		}
	}

	public function validation( $term, $taxonomy, $args ) {
			
		if ( $taxonomy && 'commission_cat' !== $taxonomy) {
			return $term;
		}
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return $term;
		}
		if ( '' === trim( $term ) ) {
			return new \WP_Error( 'empty_term_name', __( 'A name is required for this term.' ) );
		} elseif ( ! isset( $args['term_meta']['commission_value'] ) || empty( $args['term_meta']['commission_value'] ) ) {
			return new \WP_Error( 'empty_commission_value', __( 'A commission value is required for this term.' ) );
		} else {
			return $term;
		}
	}

	public function save( $term_id ) {

		if ( isset( $_POST['action'] ) && 'inline-save-tax' === $_POST['action'] ) {
			return;
		}
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return $term_id;
		}
		if ( ! isset( $_POST['commission_cat_nonce'] ) || ( isset( $_POST['commission_cat_nonce'] ) && ! wp_verify_nonce( sanitize_text_field( $_POST['commission_cat_nonce'] ), '_nonce_commission_cat' ) ) ) {
			return;
		}

		if ( isset( $_POST['term_meta'] ) ) {
			
			$saved_term_meta = get_option( "taxonomy_term_$term_id", array() );

			$post = $_POST;
							
			$post_cat_terms = $post['term_meta'] ;

			$keys_to_check = array( 'per_quantity', 'indi_prod_comm', 'commission_prod_cat', 'product_selection', 'category_selection', 'commission_products', 'commission_category' );

			foreach ( $keys_to_check as $key ) {
				
				if ( 'commission_system' === $key && isset( $post_cat_terms[ $key ] ) && 'earning-basis' === $post_cat_terms[ $key ] ) {
					unset( $post_cat_terms['commission_products'] );
					unset( $post_cat_terms['commission_category'] );
					unset( $saved_term_meta['commission_products'] );
					unset( $saved_term_meta['commission_category'] );
					$post_cat_terms['commission_prod_cat'] = 'commission_on_prod';
				}   
				
				if ( 'commission_prod_cat' === $key && 'commission_on_cat' === $post_cat_terms[ $key ] ) {
					unset( $post_cat_terms['commission_products'] );
					unset( $saved_term_meta['commission_products'] );
					// Keep categories
				} 
				
				if ( 'commission_prod_cat' === $key && 'commission_on_prod' === $post_cat_terms[ $key ] ) {
					unset( $post_cat_terms['commission_category'] );
					unset( $saved_term_meta['commission_category'] );
					// Keep products
				} 

				if ( ! isset( $post_cat_terms[ $key ] ) ) {
					unset( $saved_term_meta[ $key ] );
				}
			}

			foreach ( $post_cat_terms as $key => $cat ) {           
				$saved_term_meta[ $key ] = $cat;
			}
			
			
			// Save the option array.
			update_option( "taxonomy_term_$term_id", $saved_term_meta );
		}
	}

	public static function resolveDependency() {
		return is_sales_agent_enabled();
	}
}
