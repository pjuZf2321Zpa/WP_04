<?php

namespace WooCommerceWholesalePricing\App\Services\SalesAgent;

use WooCommerceWholesalePricing\App\Modules\SalesAgent\Actions;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

use WooCommerceWholesalePricing\App\Models\SalesAgent\Commission;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class AjaxService implements ServiceInterface {

	public function __construct() {
		add_action( 'wp_ajax_user_search_ajax', array( $this, 'user_search_ajax_callback' ) );

		// search for agent
		add_action( 'wp_ajax_wc_agent_search_agent', array( $this, 'wc_agent_search_agent_callback' ) );

		// select search agent
		add_action( 'wp_ajax_select_search_agent', array( $this, 'select_search_agent_callback' ) );

		add_action( 'wp_ajax_mark_commissions_paid', array( $this, 'mark_commissions_paid_callback' ) );

		add_action( 'wp_ajax_delete_commissions', array( $this, 'delete_commissions_callback' ) );
		// get commission of specific agent
		add_action( 'wp_ajax_get_commission_of_agent', array( $this, 'get_commission_of_agent_callback' ) );

		add_action( 'wp_ajax_check_user_agent_assign', array( $this, 'check_user_agent_assign_callback' ) );

		add_action( 'wp_ajax_search_agents_by_group_callback', array( $this, 'search_agents_by_group_callback' ) );

		add_action( 'wp_ajax_search_agent_ajax', array( $this, 'search_agent_ajax_callback' ) );

		add_action( 'wp_ajax_manager_assign_ajax', array( $this, 'manager_assign_ajax_callback' ) );

		add_action( 'wp_ajax_search_customer_ajax', array( $this, 'search_customer_ajax_callback' ) );
		
		add_action( 'wp_ajax_sales_agent_form_builder_save', array( $this, 'sales_agent_form_builder_save' ) );

		add_action( 'wp_ajax_sales_agent_requested_user', array( $this, 'sales_agent_requested_user' ) );

		add_action( 'wp_ajax_get_agent_data', array( $this, 'get_agent_data' ) );

		add_action( 'wp_ajax_agent_payment_details', array( $this, 'agent_payment_details' ) );

		add_action('wp_ajax_save_customer_commission', array( $this, 'save_customer_commission_handler' ));
	}

	public function search_customer_ajax_callback() {
		check_ajax_referer( 'wc_sales_agent_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'Permission denied' );
		}

		$search = isset( $_GET['term'] ) ? sanitize_text_field( wp_unslash( $_GET['term'] ) ) : '';

		// Step 1: Get user IDs already assigned in posts of type 'agent'
		$assigned_users = get_posts(
			array(
				'post_type'      => 'agent',
				'posts_per_page' => -1,
				'post_status'    => 'publish',
				'fields'         => 'ids',
				'meta_query'     => array(
					array(
						'key'     => 'assign_user',
						'compare' => 'EXISTS',
					),
				),
			)
		);

		// Collect assigned user IDs
		$assigned_user_ids = array();
		foreach ( $assigned_users as $agent_id ) {
			$user_id = get_post_meta( $agent_id, 'assign_user', true );
			if ( ! empty( $user_id ) ) {
				$assigned_user_ids[] = (int) $user_id;
			}
		}
		// Step 2: Search for unassigned users
		$args   = array(
			'search'         => "*$search*",
			'search_columns' => array( 'user_login', 'user_email', 'display_name' ),
			'number'         => 20,
			'orderby'        => 'display_name',
			'order'          => 'ASC',
			'exclude'        => $assigned_user_ids, // <-- exclude already assigned users
			'meta_query'     => array(
				'relation' => 'OR',
				array(
					'key'     => 'sales_agent',
					'value'   => '0',
					'compare' => '=',
				),
				array(
					'key'     => 'sales_agent',
					'value'   => '',
					'compare' => '=',
				),
				array(
					'key'     => 'sales_agent',
					'compare' => 'NOT EXISTS',
				),
			),
		);
		$users  = get_users( $args );
		$return = array();

		foreach ( $users as $user ) {
			$return[] = array(
				$user->ID,
				$user->display_name . ' (' . $user->user_email . ')',
			);
		}

		wp_send_json( $return );
	}

	public function delete_commissions_callback() {
		// Check if nonce is set and verify it
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'delete_commissions_nonce' ) ) {
			wp_send_json_error( array( 'message' => 'Invalid nonce' ) );
		}

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}

		// Check if commission_ids is set and is an array
		if ( ! isset( $_POST['commission_ids'] ) || ! is_array( $_POST['commission_ids'] ) ) {
			wp_send_json_error( array( 'message' => 'Invalid commission IDs' ) );
		}

		// Sanitize the commission IDs
		$commission_ids = array_map( 'intval', wp_unslash( $_POST['commission_ids'] ) );

		// Perform the database deletion
		global $wpdb;
		foreach ( $commission_ids as $commission_id ) {
			$deleted = $wpdb->delete(
				"{$wpdb->prefix}wc_agents_commissions",
				array( 'id' => $commission_id ),
				array( '%d' )
			);

			if ( false === $deleted ) {
				wp_send_json_error( array( 'message' => 'Failed to delete commission ID: ' . $commission_id ) );
			}
		}

		wp_send_json_success( array( 'message' => 'Commissions deleted successfully' ) );
	}
	public function mark_commissions_paid_callback() {
		// Verify nonce
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'mark_commissions_paid_nonce' ) ) {
			wp_send_json_error( 'Nonce verification failed' );
		}

		// Check permissions
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'You do not have sufficient permissions to access this page.' );
		}

		// Process form
		if ( isset( $_POST['commission_ids'] ) && is_array( $_POST['commission_ids'] ) ) {
			global $wpdb;

			$commission_ids     = array_map( 'intval', wp_unslash( $_POST['commission_ids'] ) );
			$updated_count      = 0;
			$already_paid_count = 0;

			foreach ( $commission_ids as $commission_id ) {
				// Check if the commission is already paid
				$current_status = $wpdb->get_var(
					$wpdb->prepare(
						"SELECT commission_status FROM {$wpdb->prefix}wc_agents_commissions WHERE id = %d",
						$commission_id
					)
				);

				if ( 'paid' === $current_status ) {
					++$already_paid_count;
					continue; // Skip this commission
				}

				if ( ! $commission_id ) {
					wp_send_json_error( 'Failed to' );
				}

				// Update only if the commission is pending
				$result = $wpdb->update(
					$wpdb->prefix . 'wc_agents_commissions',
					array( 'commission_status' => 'paid' ),
					array(
						'id'                => $commission_id,
						'commission_status' => 'pending',
					),
					array( '%s' ),
					array( '%d', '%s' )
				);

				if ( false !== $result ) {
					++$updated_count;
				} else {
					wp_send_json_error( array( 'message' => 'Failed to update commission ID: ' . $commission_id ) );
				}
			}

			if ( $updated_count > 0 ) {
				$response_message = 'Commissions marked as paid.';
				if ( $already_paid_count > 0 ) {
					$response_message .= ' ' . $already_paid_count . ' commissions were already paid and excluded.';
				}
				wp_send_json_success( array( 'message' => $response_message ) );
			} else {
				wp_send_json_error( array( 'message' => 'No commissions were updated.' ) );
			}
		} else {
			wp_send_json_error( array( 'message' => 'Invalid request' ) );
		}
	}


	public function manager_assign_ajax_callback() {
		check_ajax_referer( 'wc_sales_agent_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'Permission denied' );
		}

		$all_agents = get_posts(
			array(
				'post_type'   => 'agent',
				'numberposts' => -1,
			)
		);

		$excluded_post = array();

		if ( isset( $_GET['post_id'] ) ) {
			$excluded_post[] = intval( wp_unslash( $_GET['post_id'] ) );
		}

		// Your existing code to exclude posts from meta
		if ( ! empty( $all_agents ) && count( $all_agents ) > 0 ) {
			foreach ( $all_agents as $agent ) {
				$agent_type = get_post_meta( $agent->ID, 'agent_type', true );

				if ( 'sales_manager_type' != $agent_type ) {
					$excluded_post[] = $agent->ID;
				}
			}
		}

		$args = array(
			'post_type'      => 'agent', // Set the post type to query
			'post_status'    => 'publish', // Fetch only published posts
			'posts_per_page' => -1, // Fetch all posts
			'post__not_in'   => $excluded_post, // Exclude certain posts
		);

		/**
		 *
		 * FIlter.
		 *
		 * @since 1.0.0
		 */
		$args   = apply_filters( 'sales_agent_subagent_search_args', $args );
		$query  = new \WP_Query( $args );
		$return = array();
		foreach ( $query->posts as $post ) {
			$agent_name = $post->post_title;
			$id         = $post->ID;
			$return[]   = array( $id, $agent_name );
		}

		wp_send_json( $return );
	}

	public function search_agent_ajax_callback() {
		check_ajax_referer( 'wc_sales_agent_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'Permission denied' );
		}

		$args = array(
			'post_type'      => 'agent',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'post__not_in'   => isset( $_GET['post_id'] ) ? array( sanitize_text_field( wp_unslash( $_GET['post_id'] ) ) ) : array(),
			'meta_query'     => array(
				'relation' => 'AND',
				array(
					'key'     => 'select_agent',
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'     => 'select_manager',
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'     => 'agent_type',
					'value'   => 'sales_agent_type',
					'compare' => '=',
				),
			),
		);

		/**
		 *
		 * FIlter.
		 *
		 * @since 1.6
		 */
		$args   = apply_filters( 'sales_agent_subagent_search_args', $args );
		$query  = new \WP_Query( $args );
		$return = array();
		foreach ( $query->posts as $post ) {
			$agent_name = $post->post_title;
			$id         = $post->ID;
			$return[]   = array( $id, $agent_name );
		}

		wp_send_json( $return );
	}

	public function search_agents_by_group_callback() {
		check_ajax_referer( 'wc_sales_agent_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'Permission denied' );
		}

		// we will pass post IDs and titles to this array.
		$return = array();
		$term   = isset( $_GET['user_filter'] ) ? sanitize_text_field( wp_unslash( $_GET['user_filter'] ) ) : '';

		$all_agents = get_posts(
			array(
				'post_type'   => 'agent', // Agent post type
				'numberposts' => -1,
				'meta_query'  => array(
					'relation' => 'OR',
					array(
						'key'     => 'agent_type',
						'value'   => 'sales_agent_type',
						'compare' => '=',
					),
					array(
						'key'     => 'agent_type',
						'compare' => 'NOT EXISTS',
					),
					array(
						'key'     => 'agent_type',
						'value'   => '',
						'compare' => '=',
					),
				),
			)
		);

		$excluded_post = array();



		if ( ! empty( $all_agents ) && count( $all_agents ) > 0 ) {
			foreach ( $all_agents as $agent ) {

				// Fetch associated agent groups for each agent
				$associated_groups = get_posts(
					array(
						'post_type'      => 'agent_groups', // Agent group post type
						'meta_query'     => array(
							array(
								'key'     => 'agents_in_group', // Meta key where agents are stored in agent groups
								'value'   => $agent->ID, // Value is stored as serialized array, so searching agent ID within quotes
								'compare' => 'LIKE',
							),
						),
						'fields'         => 'ids', // Only fetch post IDs to optimize performance
						'posts_per_page' => -1,
					)
				);

			
				// If agent is associated with any agent group, exclude their ID
				if ( ! empty( $associated_groups ) ) {
					foreach ( $associated_groups as $group ) {
						$agents_in_group = get_post_meta( $group, 'agents_in_group', true );
						if ( is_array( $agents_in_group ) && in_array( $agent->ID, $agents_in_group ) ) {
							$excluded_post[] = $agent->ID;
						}
					}
				}
			}
		}
		$excluded_post = array_unique( array_map( 'absint', $excluded_post ) );

		$args = array(
			'post_type'      => 'agent', // Set the post type to query
			'post_status'    => 'publish', // Fetch only published posts
			'posts_per_page' => -1, // Fetch all posts
			'post__not_in'   => $excluded_post, // Exclude certain posts
			'meta_query'     => array(
				'relation' => 'OR',
				array(
					'key'     => 'agent_type',
					'value'   => 'sales_agent_type',
					'compare' => '=',
				),
				array(
					'key'     => 'agent_type',
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'     => 'agent_type',
					'value'   => '',
					'compare' => '=',
				),
			),
		);

		if ( ! empty( $term ) ) {
			$args['s'] = $term;
		}

		/**
		 *
		 * FIlter.
		 *
		 * @since 1.6
		 */
		$args  = apply_filters( 'sales_agent_group_search_args', $args );
		$query = new \WP_Query( $args );

		foreach ( $query->posts as $post ) {
			$agent_name = $post->post_title;
			$id         = $post->ID;
			$return[]   = array( $id, $agent_name );
		}

		$already_assigned_message = '';
		if ( ! empty( $term ) && ! empty( $excluded_post ) ) {
			foreach ( $excluded_post as $excluded_agent_id ) {
				$excluded_agent_title = get_the_title( $excluded_agent_id );
				if ( is_string( $excluded_agent_title ) && '' !== $excluded_agent_title && false !== stripos( $excluded_agent_title, $term ) ) {
					$matched_group_name = '';
					$matched_groups     = get_posts(
						array(
							'post_type'      => 'agent_groups',
							'post_status'    => 'publish',
							'meta_query'     => array(
								array(
									'key'     => 'agents_in_group',
									'value'   => $excluded_agent_id,
									'compare' => 'LIKE',
								),
							),
							'posts_per_page' => 1,
						)
					);

					if ( ! empty( $matched_groups ) ) {
						$group_post        = $matched_groups[0];
						$group_title_meta  = get_post_meta( $group_post->ID, 'group_name', true );
						$matched_group_name = ! empty( $group_title_meta ) ? $group_title_meta : $group_post->post_title;
					}

					$already_assigned_message = sprintf(
						/* translators: 1: Agent name, 2: Group name */
						__( '<strong>%1$s</strong> is already assigned in <strong>%2$s</strong> group.', 'woocommerce-wholesale-pricing' ),
						esc_html( $excluded_agent_title ),
						esc_html( $matched_group_name ? $matched_group_name : __( 'another', 'woocommerce-wholesale-pricing' ) )
					);
					break;
				}
			}
		}

		wp_send_json(
			array(
				'results' => $return,
				'message' => $already_assigned_message,
			)
		);
	}


	public function user_search_ajax_callback() {
		check_ajax_referer( 'wc_sales_agent_nonce', 'nonce' );

		global $wpdb;
		// we will pass post IDs and titles to this array.
		$return = array();

		$term = isset( $_GET['user_filter'] ) ? sanitize_text_field( wp_unslash( $_GET['user_filter'] ) ) : '';

		// if an agent.
		$agent_id       = Actions::is_agent( get_current_user_id() );

		if ( ! current_user_can( 'manage_woocommerce' ) && ! $agent_id ) {
			wp_send_json_error( 'Permission denied' );
		}

		if ( isset( $_GET['type'] ) && 'commission' == $_GET['type'] ) {
			$arg   = array(
				'search'         => '*' . esc_attr( $term ) . '*',
				'search_columns' => array( 'user_login', 'user_url', 'user_email', 'user_nicename', 'display_name' ),
				'fields'         => 'ID',
				'meta_key'       => 'sales_agent',
				'meta_value'     => $agent_id,
			);
			$query = new \WP_User_Query(
				$arg
			);

			$ids = wp_parse_id_list( (array) $query->get_results() );

			foreach ( $ids as $id ) {
				$user       = get_userdata( $id );
				$last_name  = get_user_meta( $id, 'last_name', true );
				$first_name = get_user_meta( $id, 'first_name', true );
				/* translators: %1$s is name, %2$s is id, %3$s is email */
				$name = sprintf( esc_html__( '%1$s (#%2$s %3$s)', 'sales-agent' ), $first_name . ' ' . $last_name, $id, $user->user_email );

				$return[] = array( $id, $name );
			}

			wp_send_json( $return );
		}

		if ( isset( $_GET['type'] ) && 'agent_customer_search' == $_GET['type'] ) {
			$arg = array(
				'search'         => '*' . esc_attr( $term ) . '*',
				'search_columns' => array( 'user_login', 'user_url', 'user_email', 'user_nicename', 'display_name' ),
				'fields'         => 'ID',
				'meta_key'       => 'sales_agent',
				'meta_value'     => $agent_id,
			);

			$query = new \WP_User_Query(
				$arg
			);

			$ids = wp_parse_id_list( (array) $query->get_results() );

			if ( count( $ids ) <= 0 ) {
				$arg = array(
					'fields'     => 'ID',
					'orderby'    => 'display_name',
					'meta_key'   => 'sales_agent',
					'meta_value' => $agent_id,
					'meta_query' => array(
						'relation' => 'AND',
						array(
							'relation' => 'OR',
							array(
								'key'     => 'wwlc_cf_nif_cif',
								'value'   => esc_attr( $term ),
								'compare' => 'LIKE',
							),
							array(
								'key'     => 'last_name',
								'value'   => esc_attr( $term ),
								'compare' => 'LIKE',
							),
							array(
								'key'     => 'wwlc_phone',
								'value'   => esc_attr( $term ),
								'compare' => 'LIKE',
							),
							array(
								'key'     => 'wwlc_company_name',
								'value'   => esc_attr( $term ),
								'compare' => 'LIKE',
							),
						),
					),
				);

				/**
				 *
				 * FIlter.
				 *
				 * @since 1.0.0
				 */
				$arg = apply_filters( 'sales_agent_agent_customer_search_args', $arg );

				$query = new \WP_User_Query( $arg ); // nosemgrep: audit.php.wp.security.wp-user-query-email-leak

				$ids = wp_parse_id_list( (array) $query->get_results() );
			}

			if ( is_array( $ids ) && count( $ids ) > 0 ) {

				foreach ( $ids as $id ) {
					$user       = get_userdata( $id );
					$last_name  = get_user_meta( $id, 'last_name', true );
					$first_name = get_user_meta( $id, 'first_name', true );
					/* translators: %1$s is name, %2$s is id, %3$s is email */
					$name = sprintf( esc_html__( '%1$s (#%2$s %3$s)', 'sales-agent' ), $first_name . ' ' . $last_name, $id, $user->user_email );

					$return[] = array( $id, $name );
				}
			}

			wp_send_json( $return );
		}


		$all_agents = get_posts(
			array(
				'post_type'   => 'agent',
				'numberposts' => -1,
			)
		);

		$excluded_users = array();

		if ( ! empty( $all_agents ) && count( $all_agents ) > 0 ) {
			foreach ( $all_agents as $agent ) {
				$user_id = get_post_meta( $agent->ID, 'assign_user', true );
				if ( $user_id ) {
					$excluded_users[] = $user_id;
				}
			}
		}

		$arg = array(
			'search'         => '*' . esc_attr( $term ) . '*',
			'search_columns' => array( 'user_login', 'user_url', 'user_email', 'user_nicename', 'display_name' ),
			'fields'         => 'ID',
			'role__not_in'   => 'administrator',
			'exclude'        => $excluded_users,
		);

		/**
		 *
		 * FIlter.
		 *
		 * @since 1.0.0
		 */
		$arg = apply_filters( 'sales_agent_user_search_args', $arg );

		$query = new \WP_User_Query(
			$arg
		);

		$ids = wp_parse_id_list( (array) $query->get_results() );

		foreach ( $ids as $id ) {
			$user       = get_userdata( $id );
			$last_name  = get_user_meta( $id, 'last_name', true );
			$first_name = get_user_meta( $id, 'first_name', true );
			/* translators: %1$s is name, %2$s is id, %3$s is email */
			$name = sprintf( esc_html__( '%1$s (#%2$s %3$s)', 'woocommerce-wholesale-pricing' ), $first_name . ' ' . $last_name, $id, $user->user_email );

			$return[] = array( $id, $name );
		}

		wp_send_json( $return );
	}


	public function select_search_agent_callback() {

		check_ajax_referer( 'wc_sales_agent_nonce', 'nonce' );

		global $wpdb;
		// we will pass post IDs and titles to this array.
		$return       = array();
		$agent_filter = isset( $_GET['agent_filter'] ) ? sanitize_text_field( wp_unslash( $_GET['agent_filter'] ) ) : '';
		// you can use WP_Query, query_posts() or get_posts() here - it doesn't matter.
		$search_results = get_posts(
			array(
				's'              => $agent_filter,
				'post_type'      => 'agent',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
			)
		);
		if ( $search_results ) {
			foreach ( $search_results as $key => $search_result ) {
				// shorten the title a little
				$return[] = array( $search_result->ID, $search_result->post_title ); // array( Post ID, Post Title ).
			}
		}
		echo wp_json_encode( $return );
		die;
	}

	/**
	 * Search by agents
	 */
	public function wc_agent_search_agent_callback() {
		check_ajax_referer( 'wc_sales_agent_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'Permission denied' );
		}

		$found_agents = array();
		if ( isset( $_GET['search'] ) && sanitize_text_field( wp_unslash( $_GET['search'] ) ) ) {
			$term   = sanitize_text_field( wp_unslash( $_GET['search'] ) );
			$agents = get_posts(
				array(
					's'              => $term,
					'post_type'      => 'agent',
					'post_status'    => 'publish',
					'posts_per_page' => -1,
				)
			);

			foreach ( $agents as $agent ) {
					$found_agents[ $agent->ID ] = $agent->post_title;
			}
		}
		wp_send_json( $found_agents );
	}

	/**
	 * Get commission of agent
	 */
	public function get_commission_of_agent_callback() {
		check_ajax_referer( 'wc_sales_agent_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'Permission denied' );
		}

		$commission = 0;
		if ( isset( $_REQUEST['agent_id'] ) && sanitize_text_field( wp_unslash( $_REQUEST['agent_id'] ) ) ) {
			$agent_id            = sanitize_text_field( wp_unslash( $_REQUEST['agent_id'] ) );
			$commission_category = get_post_meta( $agent_id, 'commission_category', true );
			if ( $commission_category && ! empty( $commission_category ) ) {
				$commission    = new Commission();
				$commission_amount = $commission->get_commission_percentage( $commission_category );
				if ( $commission_amount ) {
					$commission = $commission_amount;
				}
			}
		}
		wp_send_json( $commission );
	}

	public function check_user_agent_assign_callback() {

		$status = 'success';
		$msg    = '';

		check_ajax_referer( 'wc_sales_agent_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'Permission denied' );
		}

		if ( isset( $_POST['user_id'] ) && sanitize_text_field( wp_unslash( $_POST['user_id'] ) ) ) {

			$args = array(
				'post_type'      => 'agent',
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'meta_key'       => 'assign_user',
				'meta_value'     => sanitize_text_field( wp_unslash( $_POST['user_id'] ) ),
			);
			if ( isset( $_POST['post_id'] ) && sanitize_text_field( wp_unslash( $_POST['post_id'] ) ) ) {
				$args['exclude'] = array( sanitize_text_field( wp_unslash( $_POST['post_id'] ) ) );
			}

			$agents = get_posts( $args );

			if ( ! empty( $agents ) ) {
				$status = 'fail';
				$msg    = __( 'This user is already agent.', 'woocommerce-wholesale-pricing' );
			}
		}

		wp_send_json(
			array(
				'status' => $status,
				'msg'    => $msg,
			)
		);
	}

	public function sales_agent_form_builder_save() {
		check_ajax_referer( 'sales-agent-ajax-nonce', 'nonce' );

		$raw_schema = isset( $_POST['builder_schema'] )
			? sanitize_textarea_field( wp_unslash( $_POST['builder_schema'] ) )
			: '';

		$decoded = '' !== $raw_schema ? json_decode( $raw_schema, true ) : array();

		if ( '' !== $raw_schema && ( ! is_array( $decoded ) || JSON_ERROR_NONE !== json_last_error() ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid form schema.', 'woocommerce-wholesale-pricing' ) ) );
		}

		$builder_schema = '' !== $raw_schema ? wp_json_encode( $decoded ) : '';
		update_option( 'sales_agent_form_builder_data', $builder_schema );

		wp_send_json(
			array(
				'success' => true,
				'message' => __( 'Setting Saved.', 'woocommerce-wholesale-pricing' ),
			)
		);

		wp_die();
	}

	/**
	 * Return submitted registration fields HTML for an agent approval request.
	 *
	 * @return void
	 */
	public function get_agent_data() {
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'agent_view_details_nonce' ) ) {
			wp_send_json_error( __( 'Invalid security token.', 'woocommerce-wholesale-pricing' ) );
		}

		if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'edit_agents' ) ) {
			wp_send_json_error( __( 'Permission denied.', 'woocommerce-wholesale-pricing' ) );
		}

		$post_id = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0;

		if ( ! $post_id || 'agent_approval' !== get_post_type( $post_id ) ) {
			wp_send_json_error( __( 'Invalid request.', 'woocommerce-wholesale-pricing' ) );
		}

		$post = get_post( $post_id );

		ob_start();
		wwp_view( 'admin.sales-agent.requests.meta-box.fields', compact( 'post' ), true );
		$html = ob_get_clean();

		wp_send_json_success( array( 'html' => $html ) );
	}

	public function sales_agent_requested_user() {

		if ( isset( $_POST['nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'agent_approve_reject_nonce' ) && isset( $_POST['action'] ) && 'sales_agent_requested_user' == $_POST['action'] ) {
			
			if ( isset( $_POST['user_id'] ) && isset( $_POST['commission_cat'] ) ) {

				$user_id = absint( wp_unslash( $_POST['user_id'] ) );
				update_user_meta( $user_id, 'wc_agent_approve', 'Approved' );
				$commission_cat = sanitize_text_field( wp_unslash( $_POST['commission_cat'] ) );
				$user_data      = new \WP_User( $user_id );
				if ( in_array( 'subscriber', (array) $user_data->roles ) || in_array( 'customer', (array) $user_data->roles ) || empty( $user_data->roles ) ) {
					$user_data->set_role( 'sales_agent' );
				} elseif ( ! in_array( 'sales_agent', (array) $user_data->roles ) ) {
					$user_data->add_role( 'sales_agent' );
				}
				$first_name = get_user_meta( $user_id, 'first_name', true );
				$last_name  = get_user_meta( $user_id, 'last_name', true );

				if ( ! post_exists( $first_name . ' ' . $last_name ) ) {

					$post_id = wp_insert_post(
						array(
							'post_title'  => $first_name . ' ' . $last_name,
							'post_type'   => 'agent',
							'post_status' => 'publish',
						)
					);

					if ( $post_id ) {
						update_post_meta( $post_id, 'first_name', $first_name );
						update_post_meta( $post_id, 'last_name', $last_name );
						update_post_meta( $post_id, 'commission_category', $commission_cat );
						update_post_meta( $post_id, 'assign_user', $user_id );
						update_post_meta( $post_id, 'customer_registration', 'yes' );
						update_post_meta( $post_id, 'agent_type', 'sales_agent_type' );

						// Assign the commission category taxonomy term to the agent post
						wp_set_object_terms( $post_id, intval( $commission_cat ), 'commission_cat' );
	
					}
					new \WooCommerceWholesalePricing\App\Modules\SalesAgent\Emails\AssigningAgent();
					/**
					*  Action to register email for assigning agent
					*
					*  @since 1.4
					*/
					do_action( 'safw_email_assign_agent', $user_id, $post_id );

				} else {
					wp_send_json(
						array(
							'error'   => true,
							'message' => __( 'Agent already exists.', 'woocommerce-wholesale-pricing' ),
						)
					);
				}
			} elseif ( isset( $_POST['rejected'] ) && isset( $_POST['user_id'] ) ) {
				$user_id   = absint( wp_unslash( $_POST['user_id'] ) );
					$user_data = new \WP_User( $user_id );
					update_user_meta( $user_id, 'wc_agent_rejected', 'Rejected' );
					wp_send_json(
						array(
							'error'   => true,
							'message' => __( 'Agent Rejected.', 'woocommerce-wholesale-pricing' ),
						)
					);
			}
		}
		wp_send_json(
			array(
				'success' => true,
				'message' => __( 'Agent added.', 'woocommerce-wholesale-pricing' ),
			)
		);

		die();
	}

	public function agent_payment_details() {
		$data = $_REQUEST;

		check_ajax_referer( 'wc_sales_agent_nonce', 'nonce' );

		if ( isset( $data['agent_payout_detail'] ) && ! empty( sanitize_text_field( $data['agent_payout_detail'] ) ) ) {

			$agent_payout_data = array();
			parse_str( $data['agent_payout_detail'], $agent_payout_data );
			$post_id = sanitize_text_field( $agent_payout_data['payment_agent_id'] );

			update_post_meta( $post_id, 'agent_payout_detail', $agent_payout_data );
			wp_send_json_success();

		} else {
			wp_send_json_error();
		}
		die();
	}

	public function save_customer_commission_handler() {
		// Sanitize nonce before verifying
		$nonce = isset($_POST['security']) ? sanitize_text_field($_POST['security']) : '';

		// Verify nonce
		if (!wp_verify_nonce($nonce, 'wc_sales_agent_nonce')) {
			wp_send_json_error(array( 'message' => __('Nonce verification failed.', 'woocommerce-wholesale-pricing') ));
		}

		// Validate and sanitize input
		if (
			!isset($_POST['user_id'], $_POST['post_id'], $_POST['commission_percentage']) ||
			!is_numeric($_POST['commission_percentage']) || 
			!is_numeric($_POST['user_id']) || 
			!is_numeric($_POST['post_id'])
		) {
			wp_send_json_error(array( 'message' => __('Invalid data provided.', 'woocommerce-wholesale-pricing') ));
		}

		$user_id               = intval($_POST['user_id']);
		$commission_percentage = floatval($_POST['commission_percentage']);
		$post_id               = intval($_POST['post_id']);

		// Retrieve existing commission list from options table
		$commission_list = get_option('customer_commission_list', array());

		// If no data exists for the given post_id, initialize it
		if (!isset($commission_list[$post_id])) {
			$commission_list[$post_id] = array();
		}

		// Update the commission percentage for the customer in the given post_id
		$commission_list[$post_id][$user_id] = $commission_percentage;

		// Save the updated commission list back to the options table
		update_option('customer_commission_list', $commission_list);

		// Respond with success
		wp_send_json_success(array( 'message' => __('Commission saved successfully.', 'woocommerce-wholesale-pricing') ));
	}


	public static function resolveDependency() {
		return is_sales_agent_enabled();
	}
}
