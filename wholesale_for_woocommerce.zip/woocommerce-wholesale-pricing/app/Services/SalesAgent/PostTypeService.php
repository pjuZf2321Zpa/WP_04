<?php

namespace WooCommerceWholesalePricing\App\Services\SalesAgent;

use WooCommerceWholesalePricing\App\Models\SalesAgent\Agent;
use WooCommerceWholesalePricing\App\Models\SalesAgent\Stats;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\Init;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Service for registering wholesale-related custom post types.
 * 
 * @extends Init
 */
class PostTypeService extends Init implements ServiceInterface {
	use WholesaleSettings;

	public $slug;

	public $requests_slug;

	public function __construct() {

		$this->slug = wwp_env()->get('sales_agent_pt_slug');
		$this->requests_slug = 'agent_approval';

		add_action('add_meta_boxes', array( $this, 'meta_boxes' ));
		add_action('save_post_' . $this->slug, array( $this, 'save' ), 10, 2);

		add_filter('manage_' . $this->slug . '_posts_columns', array( $this, 'columns' ));
		add_action('manage_' . $this->slug . '_posts_custom_column', array( $this, 'column_values' ), 10, 2);

		add_filter('manage_' . $this->requests_slug . '_posts_columns', array( $this, 'requests_columns' ));
		add_action('manage_' . $this->requests_slug . '_posts_custom_column', array( $this, 'requests_column_values' ), 10, 2);

		add_filter('post_row_actions', array( $this, 'request_row_actions' ), 10, 2);
		add_filter( 'bulk_actions-edit-' . $this->requests_slug, array( $this, 'request_bulk_actions' ) );


		parent::__construct();
	}

	public function register() {
		
		$settings = self::get_pricing_settings();

		if ( ! isset( $settings['sales_agent'] ) || 'no' === $settings['sales_agent'] ) {
			return;
		}

		$shop_manager  = get_role( 'shop_manager' );
		$administrator = get_role( 'administrator' );

		if ( ! wp_roles() ) {
			wp_roles();
		}
		if ( ! get_role( 'sales_agent' ) ) {
			add_role( 'sales_agent', __( 'Sales Agent', 'woocommerce-wholesale-pricing' ), array(
				'read' => true,
			) );
		}

		$agents_caps = array(
			'edit_agent',
			'read_agent',
			'delete_agent',
			'edit_agents',
			'edit_others_agents',
			'publish_agents',
			'read_private_agents',
			'delete_agents',
			'delete_private_agents',
			'delete_published_agents',
			'delete_others_agents',
			'edit_private_agents',
			'edit_published_agents',
			'create_agents',
		);

		foreach ( $agents_caps as $agent_cap ) {
			$shop_manager->add_cap( $agent_cap );
			$administrator->add_cap( $agent_cap );
		}

		/**
		 * Filter product table menu title
		 * 
		 * @since 3.3.0
		**/
		$post_type_title = apply_filters( 'wc_agent_plugin_name', esc_html__( 'Agents', 'woocommerce-wholesale-pricing' ) );
		
		$args   = array(
			'labels'             => array(
				'name'                  => $post_type_title,
				'singular_name'         => $post_type_title,
				'all_items'             => $post_type_title,
				'menu_name'             => $post_type_title,
				'add_new'               => esc_html__( 'Add New', 'woocommerce-wholesale-pricing' ),
				'add_new_item'          => esc_html__( 'Add New Agent', 'woocommerce-wholesale-pricing' ),
				'edit'                  => esc_html__( 'Edit', 'woocommerce-wholesale-pricing' ),
				'edit_item'             => esc_html__( 'Edit Agent', 'woocommerce-wholesale-pricing' ),
				'new_item'              => esc_html__( 'New Agent', 'woocommerce-wholesale-pricing' ),
				'view_item'             => esc_html__( 'View Agent', 'woocommerce-wholesale-pricing' ),
				'view_items'            => esc_html__( 'View Agents', 'woocommerce-wholesale-pricing' ),
				'search_items'          => esc_html__( 'Search Agents', 'woocommerce-wholesale-pricing' ),
				'not_found'             => esc_html__( 'No Agents found.', 'woocommerce-wholesale-pricing' ),
				'not_found_in_trash'    => esc_html__( 'No Agents found in Trash.', 'woocommerce-wholesale-pricing' ),
				'featured_image'        => esc_html__( 'Agent Image', 'woocommerce-wholesale-pricing' ),
				'set_featured_image'    => esc_html__( 'Set Agent image', 'woocommerce-wholesale-pricing' ),
				'remove_featured_image' => esc_html__( 'Remove Agent image', 'woocommerce-wholesale-pricing' ),
				'use_featured_image'    => esc_html__( 'Use as Agent image', 'woocommerce-wholesale-pricing' ),
				'insert_into_item'      => esc_html__( 'Insert into Agent', 'woocommerce-wholesale-pricing' ),
				'uploaded_to_this_item' => esc_html__( 'Uploaded to this Agent', 'woocommerce-wholesale-pricing' ),
				'filter_items_list'     => esc_html__( 'Filter Agent list', 'woocommerce-wholesale-pricing' ),
				'items_list_navigation' => esc_html__( 'Agents list navigation', 'woocommerce-wholesale-pricing' ),
				'items_list'            => esc_html__( 'Agents list', 'woocommerce-wholesale-pricing' ),
			),
			'description'        => esc_html__( 'Agent custom post type.', 'woocommerce-wholesale-pricing' ),
			'public'             => true,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'show_in_menu'       => false,
			'capability_type'    => 'post',
			'capabilities'       => array(
				'edit_post'          => 'edit_agent',
				'read_post'          => 'read_agent',
				'delete_post'        => 'delete_agent',
				'edit_posts'         => 'edit_agents',
				'edit_others_posts'  => 'edit_others_agents',
				'publish_posts'      => 'publish_agents',
				'read_private_posts' => 'read_private_agents',
				'delete_posts'       => 'delete_agents',
				'read'               => 'read',
				'delete_private_posts'  => 'delete_private_agents',
				'delete_published_posts' => 'delete_published_agents',
				'delete_others_posts'   => 'delete_others_agents',
				'edit_private_posts'    => 'edit_private_agents',
				'edit_published_posts'  => 'edit_published_agents',
				'create_posts'  => 'create_agents',
			),
			'map_meta_cap'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'agent' ),
			'has_archive'        => true,
			'hierarchical'       => false,

			/**
			* Filter.
			* 
			* @since 1.0.4
			*/
			'menu_position'      => apply_filters( 'wc_agent_menu_position', 10 ),
			'supports'           => array( '' ),
			'show_in_rest'       => true,
			'menu_icon'          => 'dashicons-businessman',
		);

		register_post_type( $this->slug, $args );

		$plg_name = esc_html__( 'Agents Request', 'woocommerce-wholesale-pricing' );

			$labels = array(
				'name'          => $plg_name,
				'singular_name' => $plg_name,
				'all_items'     => $plg_name,
				'menu_name'     => $plg_name,
				'edit_item'     => esc_html__( 'Edit Agent Request', 'woocommerce-wholesale-pricing' ),
				'new_item'      => esc_html__( 'New Agent Request', 'woocommerce-wholesale-pricing' ),
				'view_item'     => esc_html__( 'View Agent Request', 'woocommerce-wholesale-pricing' ),
				'view_items'    => esc_html__( 'View Agent Requests', 'woocommerce-wholesale-pricing' ),
				'search_items'  => esc_html__( 'Search Agent Requests', 'woocommerce-wholesale-pricing' ),
				'not_found'     => esc_html__( 'No Agent Requests found.', 'woocommerce-wholesale-pricing' ),
				'not_found_in_trash' => esc_html__( 'No Agent Requests found in Trash.', 'woocommerce-wholesale-pricing' ),
			);
			$args   = array(
				'labels'             => $labels,
				'description'        => esc_html__( 'Agent custom post type.', 'woocommerce-wholesale-pricing' ),
				'public'             => true,
				'publicly_queryable' => false,
				'show_ui'            => true,
				'show_in_menu'       => 'dashboard_static_list',
				'capabilities' => array(
					'create_posts' => 'do_not_allow', // Prevents adding new posts
				),
				'capability_type'    => 'post',
				'map_meta_cap'       => true,
				'query_var'          => true,
				'has_archive'        => false,
				'hierarchical'       => false,
				'supports'           => array( 'title' ),
			);

			register_post_type( $this->requests_slug, $args );
	}

	public function meta_boxes() {
		add_meta_box($this->slug . '-custom-fields', __('Agent Custom Fields', 'woocommerce-wholeasle-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'agent-fields' ));
		add_meta_box($this->slug . '-customer-list', __('Customer List', 'woocommerce-wholeasle-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'assigned-customers' ));
		add_meta_box($this->slug . '-performance', __('Performance', 'woocommerce-wholeasle-pricing'), array( $this, 'callback' ), $this->slug, 'side', 'default', array( 'file' => 'performance' ));
	}

	public function callback( $post, $args ) {
		$post_id = $post->ID;
		return wwp_view('admin.sales-agent.meta-box.' . $args['args']['file'], compact('post_id', 'post'));
	}

	public function columns( $columns ) {
		$new_columns['cb']    = $columns['cb'];
		$new_columns['title'] = $columns['title'];

		unset( $columns['cb'] );
		unset( $columns['author'] );
		
		$new_columns['commission_category']   = esc_html__( 'Commission Category', 'woocommerce-wholesale-pricing' );
		$new_columns['customer_registration'] = esc_html__( 'Customer Registration', 'woocommerce-wholesale-pricing' );
		$new_columns['assign_user']           = esc_html__( 'Assign User', 'woocommerce-wholesale-pricing' );
		$new_columns['safw_no_of_orders']     = esc_html__( 'No. Of Orders', 'woocommerce-wholesale-pricing' );
		$new_columns['no_of_customers']       = esc_html__( 'No. Of Customers', 'woocommerce-wholesale-pricing' );
		foreach ( $columns as $key => $column ) {
			$new_columns[ $key ] = $column;
		}

		return $new_columns;
	}

	public function column_values( $column, $post_id ) {
		$assign_user                   = '';
		$terms                         = array();
		$customer_registration         = get_post_meta( $post_id, 'customer_registration', true );
		$user_IDs                      = get_post_meta( $post_id, 'assign_user', true );
		$assign_user                   = '-';
		$stats                         = new Stats();
		$total_order_count             = $stats->total_count_order_by_agent( $post_id );

		$customer_ids = Agent::get_agent_customers( $post_id );
		$total_customer = count( array_unique( array_map( 'intval', $customer_ids ) ) );

		if ( $user_IDs ) {
			$user = get_user_by( 'id', $user_IDs );
			if (isset($user) && !empty($user)) {
				$assign_user = "<a href='" . get_edit_user_link( $user_IDs ) . "'>" . $user->display_name . '</a>';
			}
		}

		$commission_category_id = get_post_meta( $post_id, 'commission_category', true );
		if ( $commission_category_id ) {
			$terms = get_term( $commission_category_id, 'commission_cat' );
		}

		switch ( $column ) {
			case 'safw_no_of_orders':
				echo $total_order_count ? esc_attr( $total_order_count ) : '0';
				break;

			case 'no_of_customers':
				echo $total_customer ? esc_attr( $total_customer ) : '0';
				break;

			case 'customer_registration':
				echo $customer_registration && 'yes' == $customer_registration ? 'Yes' : 'No';
				break;

			case 'assign_user':
				echo $assign_user ? wp_kses_post( $assign_user ) : '';
				break;
				
			case 'commission_category':
				echo ( ! empty( $terms ) ) ? "<a href='edit.php?post_type=agent&commission_cat=" . esc_attr( $terms->term_id ) . "'>" . esc_html( $terms->name ) . '</a>' : '__';
				break;
		}
	}

	public function requests_columns( $columns ) {
		$temp = $columns['date'];
		unset( $columns['date'] );
		unset( $columns['title'] );
		$columns['existing_title'] = esc_html__( 'Title', 'woocommerce-wholesale-pricing' );
		$columns['name']   = esc_html__( 'Full Name', 'woocommerce-wholesale-pricing' );
		$columns['email']     = esc_html__( 'Email', 'woocommerce-wholesale-pricing' );
		$columns['commission_category'] = esc_html__( 'Commission Category', 'woocommerce-wholesale-pricing' );
		$columns['status']       = esc_html__( 'Status', 'woocommerce-wholesale-pricing' );
		$columns['actions']       = esc_html__( 'Actions', 'woocommerce-wholesale-pricing' );
		$columns['date']       = $temp;
	  
		return $columns;
	}

	public function requests_column_values( $column, $post_id ) {
		$agent_id        = get_post_meta( $post_id, 'wc_sales_agent_user_id', true );
		$approve_agent      = get_user_meta( $agent_id, 'wc_agent_approve', true );
		$reject_agent       = get_user_meta( $agent_id, 'wc_agent_rejected', true );
		$nonce           = wp_create_nonce( 'agent_approve_reject_nonce' );
		$commission_category_id = get_post_meta($post_id, 'wc_sales_agent_cat', true);
		$disabled_button = ! empty( $approve_agent ) || ! empty( $reject_agent ) ? 'disabled=true' : '';

		switch ( $column ) {
			case 'existing_title':
				echo esc_html( get_the_title($post_id) );
				break;
			
			case 'name':
				echo esc_attr( get_post_meta($post_id, 'wc_sales_agent_first_name', true) ) . ' ' . esc_attr( get_post_meta($post_id, 'wc_sales_agent_last_name', true) );
				break;

			case 'commission_category':
				$terms = '';
				if ( $commission_category_id ) {
					$terms = get_term( $commission_category_id, 'commission_cat' );
				}
				echo ( ! empty( $terms ) ) ? "<a href='edit.php?post_type=agent&commission_cat=" . esc_attr( $terms->term_id ) . "'>" . esc_html( $terms->name ) . '</a>' : '__';
				break;

			case 'email':
				echo esc_attr( get_post_meta($post_id, 'wc_sales_agent_email', true) );
				break;

			case 'status':
				$agent_approve_type = ! empty( $approve_agent ) ? $approve_agent : $reject_agent;
				echo ! empty( $agent_approve_type ) ? esc_html( $agent_approve_type ) : '-';
				break;

			case 'actions':
				$view_nonce = wp_create_nonce( 'agent_view_details_nonce' );
				echo '<button type="button" class="button button-secondary wc-view-details" data-id="' . esc_attr( $post_id ) . '" data-nonce="' . esc_attr( $view_nonce ) . '">' . esc_html__( 'View', 'woocommerce-wholesale-pricing' ) . '</button> ';
				echo '<button ' . esc_attr( $disabled_button ) . ' type="button" data-commission="' . esc_attr( $commission_category_id ) . '" data-nonce="' . esc_attr( $nonce ) . '" data-id="' . esc_attr( $agent_id ) . '" class="agent-requested-data button button-primary agent-request" value="approve">' . esc_html__( 'Approve', 'woocommerce-wholesale-pricing' ) . '</button> <button ' . esc_attr( $disabled_button ) . ' type="button" class="button button-primary agent-request-rejected agent-request" data-id="' . esc_attr( $agent_id ) . '" data-nonce="' . esc_attr( $nonce ) . '" data-reject="rejected">' . esc_html__( 'Reject', 'woocommerce-wholesale-pricing' ) . '</button>';
				break;
		}
	}


	/**
	 * Table Save
	 *
	 * @param int $post_id sales agent id.
	 * @param int $post             post id.
	 */
	public function save( $post_id, $post ) {
		if ( ! isset( $_POST['agent_nonce'] ) || ( isset( $_POST['agent_nonce'] ) && ! wp_verify_nonce( sanitize_text_field( $_POST['agent_nonce'] ), '_agent_nonce' ) ) ) {
			return;
		}

		if ( 'trash' == get_post_status( $post_id ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( empty( $_POST['last_name'] ) || empty( $_POST['first_name'] ) ) {
			return;
		}

		$title = array();
		if ( isset( $_POST['first_name'] ) && ! empty( $_POST['first_name'] ) ) {
			$title[] = sanitize_text_field( $_POST['first_name'] );
			update_post_meta( $post_id, 'first_name', sanitize_text_field( $_POST['first_name'] ) );
		}
		if ( isset( $_POST['last_name'] ) && ! empty( $_POST['last_name'] ) ) {
			$title[] = sanitize_text_field( $_POST['last_name'] );
			update_post_meta( $post_id, 'last_name', sanitize_text_field( $_POST['last_name'] ) );
		}
		if ( isset( $_POST['agent_bio'] ) ) {
			update_post_meta( $post_id, 'agent_bio', wp_kses_post( $_POST['agent_bio'] ) );
		}
		if ( isset( $_POST['customer_registration'] ) && ! empty( $_POST['customer_registration'] ) ) {
			update_post_meta( $post_id, 'customer_registration', sanitize_text_field( $_POST['customer_registration'] ) );
		}
		if ( isset( $_POST['assign_user'] ) ) {
			update_post_meta( $post_id, 'assign_user', sanitize_text_field( $_POST['assign_user'] ) );
			$user_id   = (int) sanitize_text_field( $_POST['assign_user'] );
			$user_data = new \WP_User( $user_id );
			if ( in_array( 'subscriber', (array) $user_data->roles ) || in_array( 'customer', (array) $user_data->roles ) || empty( $user_data->roles ) ) {
				$user_data->set_role( 'sales_agent' );
			} elseif ( ! in_array( 'sales_agent', (array) $user_data->roles ) ) {
				$user_data->add_role( 'sales_agent' );
			}
		}
		
		
		if ( isset( $_POST['commission_category'] ) ) {
			update_post_meta( $post_id, 'commission_category', sanitize_text_field( $_POST['commission_category'] ) );
			$current_commisson_category = get_post_meta( $post_id, 'commission_category', true ); 
			
			$old_commisson_category = get_post_meta( $post_id, 'old_commission_category', true ); 
			update_post_meta( $post_id, 'old_commission_category', sanitize_text_field( $_POST['commission_category'] ) );
			wp_set_object_terms( $post_id, intval( $_POST['commission_category'] ), 'commission_cat' );

			if ( empty( $old_commisson_category ) || ( ! empty( $old_commisson_category ) && $old_commisson_category != $current_commisson_category ) ) {

				/**
				 * ACtion Hook.
				 * 
				 * @since 1.3
				 */
				do_action( 'safw_email_assign_comm_cat', $post_id, sanitize_text_field( $_POST['commission_category'] ) );
			}
		}

		if ( ! empty( $title ) ) {
			remove_action( 'save_post_' . $this->slug, array( $this, 'save' ), 10, 2 );

			wp_update_post(
				array(
					'ID'         => $post_id,
					'post_title' => implode( ' ', $title ),
				)
			);

			add_action( 'save_post_' . $this->slug, array( $this, 'save' ), 10, 2 );
		}
	}

	public function request_row_actions( $actions, $post ) {
		if ( $post->post_type == $this->requests_slug ) {
			unset( $actions['edit'], $actions['inline hide-if-no-js'] );
		}
		return $actions;
	}

	/**
	 * Remove bulk Edit (quick edit) from agent approval list table bulk actions.
	 *
	 * @param array $actions Bulk actions.
	 * @return array
	 */
	public function request_bulk_actions( $actions ) {
		unset( $actions['edit'] );
		return $actions;
	}

	public static function resolveDependency() {
		return is_sales_agent_enabled();
	}
}
