<?php
/**
 * Programmatic read/write of wholesale product meta.
 *
 * @package WooCommerceWholesalePricing\App\Services
 */

namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\RoleDiscountPatchNormalizer;

/**
 * Manages wholesale-specific product metadata for the AI abilities API.
 */
class WholesaleProductMetaService {

	/**
	 * Product meta keys managed by the wholesale tab.
	 *
	 * @var list<string>
	 */
	const TAB_META_KEYS = array(
		'_wwp_hide_for_customer',
		'_wwp_hide_for_visitor',
		'wholesale_product_visibility_multi',
		'wwp_icon_url',
		'wwp_image_url',
		'wwp_attachment_title',
		'wwp_attachment_text_link',
		'wwp_variation_explode_eneble',
		'wwp_variation_attribute_with_qty',
		'sample_product_id',
		'sample_product_id_hidden',
		'request_for_sample_enable',
	);

	/**
	 * Get the role taxonomy slug, with compatibility for plugins that may change it.
	 * 
	 * @return string
	 */
	private function get_role_taxonomy() {
		if ( function_exists( 'wwp_env' ) ) {
			$slug = (string) wwp_env()->get( 'role_taxonomy' );
			if ( '' !== $slug ) {
				return $slug;
			}
		}

		return 'wholesale_user_roles';
	}

	/**
	 * Get formatted wholesale settings for a product.
	 *
	 * @param int $product_id Product ID.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function get_wholesale_settings( $product_id ) {
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return new \WP_Error(
				'wwp_product_not_found',
				__( 'Product not found.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		return $this->format_settings( $product_id, $product );
	}

	/**
	 * Update wholesale settings (partial merge).
	 *
	 * @param int                  $product_id Product ID.
	 * @param array<string, mixed> $wholesale  Wholesale patch.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function update_wholesale_settings( $product_id, array $wholesale ) {
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return new \WP_Error(
				'wwp_product_not_found',
				__( 'Product not found.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		if ( empty( $wholesale ) ) {
			return $this->get_wholesale_settings( $product_id );
		}

		if ( array_key_exists( 'hide_for_customer', $wholesale ) ) {
			$product->update_meta_data( '_wwp_hide_for_customer', $this->bool_to_yes( $wholesale['hide_for_customer'] ) );
		}
		if ( array_key_exists( 'hide_for_visitor', $wholesale ) ) {
			$product->update_meta_data( '_wwp_hide_for_visitor', $this->bool_to_yes( $wholesale['hide_for_visitor'] ) );
		}
		if ( array_key_exists( 'hide_for_roles', $wholesale ) ) {
			$roles = is_array( $wholesale['hide_for_roles'] ) ? array_map( 'sanitize_key', $wholesale['hide_for_roles'] ) : array();
			$product->update_meta_data( 'wholesale_product_visibility_multi', $roles );
		}
		if ( array_key_exists( 'icon_url', $wholesale ) ) {
			$product->update_meta_data( 'wwp_icon_url', esc_url_raw( (string) $wholesale['icon_url'] ) );
		}
		if ( array_key_exists( 'attachment_url', $wholesale ) ) {
			$product->update_meta_data( 'wwp_image_url', esc_url_raw( (string) $wholesale['attachment_url'] ) );
		}
		if ( array_key_exists( 'attachment_title', $wholesale ) ) {
			$product->update_meta_data( 'wwp_attachment_title', sanitize_text_field( (string) $wholesale['attachment_title'] ) );
		}
		if ( array_key_exists( 'attachment_link', $wholesale ) ) {
			$product->update_meta_data( 'wwp_attachment_text_link', sanitize_text_field( (string) $wholesale['attachment_link'] ) );
		}
		if ( array_key_exists( 'variation_explode_enable', $wholesale ) ) {
			$product->update_meta_data( 'wwp_variation_explode_eneble', $this->bool_to_yes( $wholesale['variation_explode_enable'] ) );
		}
		if ( array_key_exists( 'variation_attribute_with_qty', $wholesale ) ) {
			$product->update_meta_data( 'wwp_variation_attribute_with_qty', sanitize_text_field( (string) $wholesale['variation_attribute_with_qty'] ) );
		}
		if ( array_key_exists( 'sample_product_id', $wholesale ) ) {
			$product->update_meta_data( 'sample_product_id', absint( $wholesale['sample_product_id'] ) );
		}
		if ( array_key_exists( 'sample_product_id_hidden', $wholesale ) ) {
			$product->update_meta_data( 'sample_product_id_hidden', absint( $wholesale['sample_product_id_hidden'] ) );
		}
		if ( array_key_exists( 'request_for_sample_enable', $wholesale ) ) {
			$product->update_meta_data( 'request_for_sample_enable', $this->bool_to_yes( $wholesale['request_for_sample_enable'] ) );
		}
		if ( array_key_exists( 'tier_pricing', $wholesale ) ) {
			$product->update_meta_data( 'product_tier_pricing', is_array( $wholesale['tier_pricing'] ) ? wwp_sanitize_tier_prices( $wholesale['tier_pricing'] ) : array() );
		}

		if ( isset( $wholesale['role_pricing'] ) && is_array( $wholesale['role_pricing'] ) ) {
			$result = $this->apply_role_pricing( $product, $wholesale['role_pricing'] );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		$product->save();

		return $this->get_wholesale_settings( $product_id );
	}

	/**
	 * Snapshot raw wholesale meta for undo.
	 *
	 * @param int $product_id Product ID.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function snapshot_wholesale_settings( $product_id ) {
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return new \WP_Error(
				'wwp_product_not_found',
				__( 'Product not found.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		$raw = array();
		foreach ( self::TAB_META_KEYS as $key ) {
			$raw[ $key ] = $product->get_meta( $key, true );
		}
		$raw['wholesale_multi_user_pricing'] = get_post_meta( $product_id, 'wholesale_multi_user_pricing', true );
		$raw['product_tier_pricing']         = get_post_meta( $product_id, 'product_tier_pricing', true );

		if ( $product->is_type( 'variable' ) ) {
			$raw['variation_meta'] = array();
			foreach ( $product->get_children() as $variation_id ) {
				$variation = wc_get_product( $variation_id );
				if ( $variation ) {
					$raw['variation_meta'][ $variation_id ] = array(
						'wholesale_multi_user_pricing' => $variation->get_meta( 'wholesale_multi_user_pricing', true ),
						'product_tier_pricing'         => $variation->get_meta( 'product_tier_pricing', true ),
					);
				}
			}
		}

		return array(
			'product_id' => $product_id,
			'raw'        => $raw,
		);
	}

	/**
	 * Restore wholesale meta from snapshot.
	 *
	 * @param array<string, mixed> $snapshot Snapshot data.
	 * @return true|\WP_Error
	 */
	public function restore_wholesale_settings( array $snapshot ) {
		$product_id = (int) ( isset( $snapshot['product_id'] ) ? $snapshot['product_id'] : 0 );
		$raw        = is_array( isset( $snapshot['raw'] ) ? $snapshot['raw'] : null ) ? $snapshot['raw'] : array();

		if ( $product_id <= 0 ) {
			return new \WP_Error(
				'wwp_product_restore_invalid',
				__( 'Cannot restore product wholesale settings: invalid snapshot.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return new \WP_Error(
				'wwp_product_not_found',
				__( 'Product not found.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		foreach ( self::TAB_META_KEYS as $key ) {
			if ( array_key_exists( $key, $raw ) ) {
				$product->update_meta_data( $key, $raw[ $key ] );
			}
		}
		if ( array_key_exists( 'wholesale_multi_user_pricing', $raw ) ) {
			$product->update_meta_data( 'wholesale_multi_user_pricing', $raw['wholesale_multi_user_pricing'] );
		}
		if ( array_key_exists( 'product_tier_pricing', $raw ) ) {
			$product->update_meta_data( 'product_tier_pricing', $raw['product_tier_pricing'] );
		}

		$product->save();

		if ( ! empty( $raw['variation_meta'] ) && is_array( $raw['variation_meta'] ) ) {
			foreach ( $raw['variation_meta'] as $variation_id => $meta ) {
				$variation = wc_get_product( (int) $variation_id );
				if ( ! $variation || ! is_array( $meta ) ) {
					continue;
				}
				if ( array_key_exists( 'wholesale_multi_user_pricing', $meta ) ) {
					$variation->update_meta_data( 'wholesale_multi_user_pricing', $meta['wholesale_multi_user_pricing'] );
				}
				if ( array_key_exists( 'product_tier_pricing', $meta ) ) {
					$variation->update_meta_data( 'product_tier_pricing', $meta['product_tier_pricing'] );
				}
				$variation->save();
			}
		}

		return true;
	}

	/**
	 * Format wholesale settings for API output.
	 * 
	 * @param int           $product_id Product ID.
	 * @param \WC_Product   $product    Product object.
	 * @return array<string, mixed>
	 */
	private function format_settings( $product_id, \WC_Product $product ) {
		$hide_roles = $product->get_meta( 'wholesale_product_visibility_multi', true );
		if ( ! is_array( $hide_roles ) ) {
			$hide_roles = '' === $hide_roles || empty( $hide_roles ) ? array() : array( (string) $hide_roles );
		}

		$formatted = array(
			'hide_for_customer'             => $this->yes_to_bool( $product->get_meta( '_wwp_hide_for_customer', true ) ),
			'hide_for_visitor'              => $this->yes_to_bool( $product->get_meta( '_wwp_hide_for_visitor', true ) ),
			'hide_for_roles'                => array_values( array_map( 'strval', $hide_roles ) ),
			'icon_url'                      => (string) $product->get_meta( 'wwp_icon_url', true ),
			'attachment_url'                => (string) $product->get_meta( 'wwp_image_url', true ),
			'attachment_title'              => (string) $product->get_meta( 'wwp_attachment_title', true ),
			'attachment_link'               => (string) $product->get_meta( 'wwp_attachment_text_link', true ),
			'variation_explode_enable'      => $this->yes_to_bool( $product->get_meta( 'wwp_variation_explode_eneble', true ) ),
			'variation_attribute_with_qty'  => (string) $product->get_meta( 'wwp_variation_attribute_with_qty', true ),
			'sample_product_id'             => (int) $product->get_meta( 'sample_product_id', true ),
			'sample_product_id_hidden'      => (int) $product->get_meta( 'sample_product_id_hidden', true ),
			'request_for_sample_enable'     => $this->yes_to_bool( $product->get_meta( 'request_for_sample_enable', true ) ),
			'tier_pricing'                  => get_post_meta( $product_id, 'product_tier_pricing', true ),
			'role_pricing'                  => $this->format_role_pricing( $product_id, $product ),
		);

		if ( ! is_array( $formatted['tier_pricing'] ) ) {
			$formatted['tier_pricing'] = array();
		}

		return $formatted;
	}

	/**
	 * Format role_pricing for API output, including defaults for missing fields to mirror the behavior of the admin product save. This ensures that if a stored entry is missing some fields, the missing fields will be filled with the same defaults as the admin product save, to prevent unintended consequences from missing fields. For example, if discount_type is stored but wholesale_price is not, wholesale_price will be defaulted to '' rather than left as null or undefined, to mirror the admin product save behavior where wholesale_price would be set to '' if discount_type is set but wholesale_price is left empty.
	 * 
	 * @param int         $product_id Product ID.
	 * @param \WC_Product $product    Product object.
	 * @return list<array<string, mixed>>
	 */
	private function format_role_pricing( $product_id, \WC_Product $product ) {
		$stored = get_post_meta( $product_id, 'wholesale_multi_user_pricing', true );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		$roles    = get_terms( array( 'taxonomy' => $this->get_role_taxonomy(), 'hide_empty' => false ) );
		$formatted = array();

		if ( is_wp_error( $roles ) || empty( $roles ) ) {
			return $formatted;
		}

		foreach ( $roles as $role_term ) {
			$term_id = (int) $role_term->term_id;
			$entry   = array(
				'role_slug' => (string) $role_term->slug,
				'enabled'   => isset( $stored[ $term_id ] ),
			);

			if ( ! isset( $stored[ $term_id ] ) || ! is_array( $stored[ $term_id ] ) ) {
				$formatted[] = $entry;
				continue;
			}

			$row = $stored[ $term_id ];
			$entry['discount_type']  = (string) ( isset( $row['discount_type'] ) ? $row['discount_type'] : 'percent' );
			$entry['wholesale_price'] = isset( $row['wholesale_price'] ) ? (string) $row['wholesale_price'] : '';
			$entry['min_quantity']   = isset( $row['min_quatity'] ) ? (int) $row['min_quatity'] : 1;
			$entry['step_quantity']  = isset( $row['step_quantity'] ) ? (string) $row['step_quantity'] : '';

			if ( $product->is_type( 'variable' ) ) {
				$variations = array();
				foreach ( $product->get_children() as $variation_id ) {
					if ( isset( $row[ $variation_id ] ) && is_array( $row[ $variation_id ] ) ) {
						$var_row = $row[ $variation_id ];
						$variations[] = array(
							'variation_id'    => (int) $variation_id,
							'wholesale_price' => (string) ( isset( $var_row['wholesaleprice'] ) ? $var_row['wholesaleprice'] : '' ),
							'qty'             => isset( $var_row['qty'] ) ? (int) $var_row['qty'] : 1,
							'step'            => (string) ( isset( $var_row['step'] ) ? $var_row['step'] : '' ),
						);
					}
				}
				if ( ! empty( $variations ) ) {
					$entry['variations'] = $variations;
				}
			}

			$formatted[] = $entry;
		}

		return $formatted;
	}

	/**
	 * Apply role_pricing patch to a product, merging with existing data and applying defaults for missing fields to mirror the behavior of the admin product save. This ensures that if a patch includes some but not all fields for an entry, the missing fields will be filled with the same defaults as the admin product save, to prevent unintended consequences from missing fields. For example, if discount_type is included but wholesale_price is not, wholesale_price will be defaulted to '' rather than left as null or unchanged from previous value, to mirror the admin product save behavior where wholesale_price would be set to '' if discount_type is set but wholesale_price is left empty.
	 * 
	 * @param \WC_Product          $product      Product.
	 * @param list<array<string,mixed>> $role_pricing Role pricing patch.
	 * @return true|\WP_Error
	 */
	private function apply_role_pricing( \WC_Product $product, array $role_pricing ) {
		$stored     = get_post_meta( $product->get_id(), 'wholesale_multi_user_pricing', true );
		$stored     = is_array( $stored ) ? $stored : array();
		$is_variable = $product->is_type( 'variable' );

		foreach ( $role_pricing as $item ) {
			if ( ! is_array( $item ) || empty( $item ) ) {
				continue;
			}

			$resolved = $this->resolve_role_term( $item );
			if ( is_wp_error( $resolved ) ) {
				return $resolved;
			}

			$term_id = (int) $resolved['term_id'];
			$slug    = (string) $resolved['slug'];

			$row = isset( $stored[ $term_id ] ) && is_array( $stored[ $term_id ] ) ? $stored[ $term_id ] : array();
			$item = RoleDiscountPatchNormalizer::prune_role_discount_item( $item, $row );

			if ( array_key_exists( 'enabled', $item ) && ! $this->is_enabled_value( $item['enabled'] ) ) {
				unset( $stored[ $term_id ] );
				continue;
			}

			$explicit_enable = array_key_exists( 'enabled', $item ) && $this->is_enabled_value( $item['enabled'] );
			$has_fields      = $explicit_enable
				|| isset( $item['discount_type'] )
				|| array_key_exists( 'wholesale_price', $item )
				|| isset( $item['min_quantity'] )
				|| array_key_exists( 'step_quantity', $item )
				|| ( ! empty( $item['variations'] ) && is_array( $item['variations'] ) );

			if ( ! $has_fields ) {
				continue;
			}

			$row = isset( $stored[ $term_id ] ) && is_array( $stored[ $term_id ] ) ? $stored[ $term_id ] : array();
			$is_new_row = empty( $row );

			if ( $is_new_row ) {
				$row = $this->apply_role_entry_defaults( $row, $item, $is_variable );
			}

			if ( isset( $item['discount_type'] ) ) {
				$type = sanitize_key( (string) $item['discount_type'] );
				if ( ! in_array( $type, array( 'percent', 'fixed' ), true ) ) {
					return new \WP_Error(
						'wwp_product_invalid_discount_type',
						__( 'discount_type must be percent or fixed.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$row['discount_type'] = $type;
			}

			if ( ! $is_variable && array_key_exists( 'wholesale_price', $item ) ) {
				$raw_price = $item['wholesale_price'];
				$price     = wwp_sanitize_price( $raw_price );
				if ( '' !== $raw_price && null !== $raw_price && '' === $price ) {
					return new \WP_Error(
						'wwp_product_invalid_wholesale_price',
						__( 'wholesale_price must be numeric.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$row['wholesale_price'] = $price;
			}

			if ( ! $is_variable && isset( $item['min_quantity'] ) ) {
				$row['min_quatity'] = (string) max( 1, (int) $item['min_quantity'] );
			}

			if ( ! $is_variable && array_key_exists( 'step_quantity', $item ) ) {
				$step = $item['step_quantity'];
				$row['step_quantity'] = is_numeric( $step ) ? (string) $step : '';
			}

			if ( $is_variable && ! empty( $item['variations'] ) && is_array( $item['variations'] ) ) {
				foreach ( $item['variations'] as $var_item ) {
					if ( ! is_array( $var_item ) || empty( $var_item['variation_id'] ) ) {
						continue;
					}

					$variation_id = (int) $var_item['variation_id'];
					if ( ! in_array( $variation_id, $product->get_children(), true ) ) {
						return new \WP_Error(
							'wwp_product_invalid_variation',
							sprintf(
								/* translators: %d: variation ID */
								__( 'Variation #%d does not belong to this product.', 'woocommerce-wholesale-pricing' ),
								$variation_id
							),
							array( 'status' => 400 )
						);
					}

					$raw_price = isset( $var_item['wholesale_price'] ) ? $var_item['wholesale_price'] : '';
					$price     = wwp_sanitize_price( $raw_price );
					if ( '' !== $raw_price && null !== $raw_price && '' === $price ) {
						return new \WP_Error(
							'wwp_product_invalid_wholesale_price',
							__( 'Variation wholesale_price must be numeric.', 'woocommerce-wholesale-pricing' ),
							array( 'status' => 400 )
						);
					}

					$qty = isset( $var_item['qty'] ) ? max( 1, (int) $var_item['qty'] ) : 1;
					$step = isset( $var_item['step'] ) ? $var_item['step'] : '';

					$row[ $variation_id ] = array(
						'wholesaleprice' => $price,
						'qty'            => (string) $qty,
						'step'           => is_numeric( $step ) ? (string) $step : (string) $step,
					);
				}
			}

			$stored[ $term_id ] = $is_variable
				? $this->format_variable_role_row_for_storage( $row, $slug )
				: $this->format_simple_role_row_for_storage( $row, $slug );
		}

		$stored = $this->normalize_role_keyed_array( $stored );
		$product->update_meta_data( 'wholesale_multi_user_pricing', $stored );

		if ( $is_variable ) {
			$this->sync_variable_wholesale_meta( $product, $stored );
		}

		return true;
	}

	/**
	 * Mirror admin variable-product save: each variation stores enabled roles for that variation.
	 *
	 * @param \WC_Product            $product Variable product.
	 * @param array<int|string,mixed> $stored  Parent wholesale_multi_user_pricing rows.
	 * @return void
	 */
	private function sync_variable_wholesale_meta( \WC_Product $product, array $stored ) {
		foreach ( $product->get_children() as $variation_id ) {
			$variation = wc_get_product( $variation_id );
			if ( ! $variation ) {
				continue;
			}

			$vary = array();
			foreach ( $stored as $role_id => $role_row ) {
				if ( ! is_array( $role_row ) || empty( $role_row['slug'] ) ) {
					continue;
				}

				$term_id     = (int) $role_id;
				$role_entry  = array(
					'slug' => (string) $role_row['slug'],
				);

				if ( isset( $role_row['discount_type'] ) ) {
					$role_entry['discount_type'] = (string) $role_row['discount_type'];
				}

				if ( isset( $role_row[ $variation_id ] ) && is_array( $role_row[ $variation_id ] ) ) {
					$role_entry[ $variation_id ] = $role_row[ $variation_id ];
				}

				$vary[ $term_id ] = $role_entry;
			}

			$variation->update_meta_data( 'wholesale_multi_user_pricing', $vary );
			$variation->save();
		}
	}

	/**
	 * Apply defaults to a role_pricing entry for missing fields, to mirror the behavior of the admin product save which fills in missing fields with defaults. This ensures that if a patch includes some but not all fields for an entry, the missing fields will be filled with the same defaults as the admin product save, to prevent unintended consequences from missing fields. For example, if discount_type is included but wholesale_price is not, wholesale_price will be defaulted to '' rather than left as null or unchanged from previous value, to mirror the admin product save behavior where wholesale_price would be set to '' if discount_type is set but wholesale_price is left empty.
	 * 
	 * @param array<string, mixed> $entry       Existing role row.
	 * @param array<string, mixed> $item        Incoming patch.
	 * @param bool                 $is_variable Whether the product is variable.
	 * @return array<string, mixed>
	 */
	private function apply_role_entry_defaults( $entry, $item, $is_variable ) {
		if ( ! isset( $entry['discount_type'] ) && ! isset( $item['discount_type'] ) ) {
			$entry['discount_type'] = 'percent';
		}

		if ( ! $is_variable ) {
			if ( ! isset( $entry['min_quatity'] ) && ! isset( $item['min_quantity'] ) ) {
				$entry['min_quatity'] = '1';
			}
			if ( ! array_key_exists( 'wholesale_price', $entry ) && ! array_key_exists( 'wholesale_price', $item ) ) {
				$entry['wholesale_price'] = '';
			}
			if ( ! array_key_exists( 'step_quantity', $entry ) && ! array_key_exists( 'step_quantity', $item ) ) {
				$entry['step_quantity'] = '';
			}
		}

		return $entry;
	}

	/**
	 * Match AdminProductService simple product save shape.
	 *
	 * @param array<string, mixed> $row  Role row.
	 * @param string               $slug Role slug.
	 * @return array<string, mixed>
	 */
	private function format_simple_role_row_for_storage( $row, $slug ) {
		$discount_type = isset( $row['discount_type'] ) ? sanitize_key( (string) $row['discount_type'] ) : 'percent';
		if ( ! in_array( $discount_type, array( 'percent', 'fixed' ), true ) ) {
			$discount_type = 'percent';
		}

		$wholesale_price = array_key_exists( 'wholesale_price', $row ) ? $row['wholesale_price'] : '';
		$wholesale_price = wwp_sanitize_price( $wholesale_price );

		$min_quatity = isset( $row['min_quatity'] ) ? $row['min_quatity'] : '1';
		$min_quatity = is_numeric( $min_quatity ) ? (string) max( 1, (int) $min_quatity ) : '1';

		$stored = array(
			'slug'            => $slug,
			'discount_type'   => $discount_type,
			'wholesale_price' => $wholesale_price,
			'min_quatity'     => $min_quatity,
		);

		if ( array_key_exists( 'step_quantity', $row ) ) {
			$step = $row['step_quantity'];
			$stored['step_quantity'] = is_numeric( $step ) ? (string) $step : (string) $step;
		}

		return $stored;
	}

	/**
	 * Match AdminProductService variable product parent save shape.
	 *
	 * @param array<string, mixed> $row  Role row.
	 * @param string               $slug Role slug.
	 * @return array<string, mixed>
	 */
	private function format_variable_role_row_for_storage( $row, $slug ) {
		$discount_type = isset( $row['discount_type'] ) ? sanitize_key( (string) $row['discount_type'] ) : 'percent';
		if ( ! in_array( $discount_type, array( 'percent', 'fixed' ), true ) ) {
			$discount_type = 'percent';
		}

		$stored = array(
			'slug'          => $slug,
			'discount_type' => $discount_type,
		);

		foreach ( $row as $key => $value ) {
			if ( is_numeric( $key ) && is_array( $value ) ) {
				$price = isset( $value['wholesaleprice'] ) ? $value['wholesaleprice'] : '';
				$qty   = isset( $value['qty'] ) ? $value['qty'] : '1';
				$step  = isset( $value['step'] ) ? $value['step'] : '';

				$stored[ (int) $key ] = array(
					'wholesaleprice' => wwp_sanitize_price( $price ),
					'qty'            => is_numeric( $qty ) ? (string) max( 1, (int) $qty ) : (string) $qty,
					'step'           => is_numeric( $step ) ? (string) $step : (string) $step,
				);
			}
		}

		return $stored;
	}

	/**
	 * Resolve a role term from a role_pricing patch item using multiple matching strategies, with a user-friendly error if resolution fails. Matching strategies include exact slug match, sanitized key match, case-insensitive name match, and suffix match (allowing role_slug to be specified as the suffix of the actual slug, to allow for prefixes like "wholesale_" on the actual role slugs). Also includes a special case to allow "wholesaler" and "default-wholesaler" to match the default wholesale role slug, for user convenience and to allow for legacy input that may have used those values before more robust lookup was implemented.
	 * 
	 * @param array<string, mixed> $item Role pricing patch item.
	 * @return array{term_id: int, slug: string}|\WP_Error
	 */
	private function resolve_role_term( $item ) {
		foreach ( array( 'role_slug', 'slug', 'role' ) as $key ) {
			if ( empty( $item[ $key ] ) ) {
				continue;
			}

			$resolved = $this->lookup_role_by_slug( (string) $item[ $key ] );
			if ( null !== $resolved ) {
				return $resolved;
			}
		}

		if ( ! empty( $item['role_name'] ) ) {
			$resolved = $this->lookup_role_by_name( (string) $item['role_name'] );
			if ( null !== $resolved ) {
				return $resolved;
			}
		}

		if ( ! empty( $item['role_id'] ) && is_numeric( $item['role_id'] ) ) {
			$term = get_term( (int) $item['role_id'], $this->get_role_taxonomy() );
			if ( $term && ! is_wp_error( $term ) ) {
				return array(
					'term_id' => (int) $term->term_id,
					'slug'    => (string) $term->slug,
				);
			}
		}

		$identifier = '';
		foreach ( array( 'role_slug', 'slug', 'role', 'role_name', 'role_id' ) as $key ) {
			if ( ! empty( $item[ $key ] ) ) {
				$identifier = (string) $item[ $key ];
				break;
			}
		}

		if ( '' === $identifier ) {
			return new \WP_Error(
				'wwp_product_missing_role',
				__( 'Each role_pricing entry must include role_slug, slug, role_id, or role_name.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		return new \WP_Error(
			'wwp_product_invalid_role',
			sprintf(
				/* translators: %s: role identifier */
				__( 'Unknown wholesale role: %s', 'woocommerce-wholesale-pricing' ),
				$identifier
			),
			array( 'status' => 400 )
		);
	}

	/**
	 * Lookup role by slug with multiple matching strategies: exact match, sanitized key match, case-insensitive name match, and suffix match (allowing role_slug to be specified as the suffix of the actual slug, to allow for prefixes like "wholesale_" on the actual role slugs). Also includes a special case to allow "wholesaler" and "default-wholesaler" to match the default wholesale role slug, for user convenience and to allow for legacy input that may have used those values before more robust lookup was implemented.
	 * 
	 * @param string $candidate Role slug candidate.
	 * @return array{term_id: int, slug: string}|null
	 */
	private function lookup_role_by_slug( $candidate ) {
		$candidate = trim( $candidate );
		if ( '' === $candidate ) {
			return null;
		}

		$candidate_key = sanitize_key( $candidate );
		$terms         = get_terms( array( 'taxonomy' => $this->get_role_taxonomy(), 'hide_empty' => false ) );

		if ( is_wp_error( $terms ) ) {
			return null;
		}

		foreach ( $terms as $term ) {
			if ( $term->slug === $candidate || sanitize_key( (string) $term->slug ) === $candidate_key ) {
				return array(
					'term_id' => (int) $term->term_id,
					'slug'    => (string) $term->slug,
				);
			}
		}

		foreach ( $terms as $term ) {
			if ( 0 === strcasecmp( (string) $term->name, $candidate ) ) {
				return array(
					'term_id' => (int) $term->term_id,
					'slug'    => (string) $term->slug,
				);
			}
		}

		if ( in_array( $candidate_key, array( 'wholesaler', 'default-wholesaler' ), true ) ) {
			foreach ( $terms as $term ) {
				if ( WholesaleUserRoleService::DEFAULT_ROLE_SLUG === $term->slug ) {
					return array(
						'term_id' => (int) $term->term_id,
						'slug'    => (string) $term->slug,
					);
				}
			}
		}

		if ( '' !== $candidate_key ) {
			$suffix_matches = array();

			foreach ( $terms as $term ) {
				$slug = (string) $term->slug;

				if ( str_ends_with( $slug, '_' . $candidate_key ) ) {
					$suffix_matches[] = $term;
				}
			}

			if ( 1 === count( $suffix_matches ) ) {
				return array(
					'term_id' => (int) $suffix_matches[0]->term_id,
					'slug'    => (string) $suffix_matches[0]->slug,
				);
			}
		}

		return null;
	}

	/**
	 * Lookup role by display name, case-insensitive. This is a fallback after slug and ID lookups fail, to allow role_name to be used with display names as well as slugs. Not ideal but allows more flexibility in input.
	 * 
	 * @param string $name Role display name.
	 * @return array{term_id: int, slug: string}|null
	 */
	private function lookup_role_by_name( $name ) {
		$name = trim( $name );
		if ( '' === $name ) {
			return null;
		}

		$terms = get_terms( array( 'taxonomy' => $this->get_role_taxonomy(), 'hide_empty' => false ) );
		if ( is_wp_error( $terms ) ) {
			return null;
		}

		foreach ( $terms as $term ) {
			if ( 0 === strcasecmp( (string) $term->name, $name ) ) {
				return array(
					'term_id' => (int) $term->term_id,
					'slug'    => (string) $term->slug,
				);
			}
		}

		return null;
	}

	/**
	 * Is the given value an enabled flag (treating true, 'true', '1', 'yes', and 'on' as truthy, anything else as falsy).
	 * 
	 * @param mixed $value Enabled flag.
	 * @return bool
	 */
	private function is_enabled_value( $value ) {
		if ( is_bool( $value ) ) {
			return $value;
		}

		if ( is_numeric( $value ) ) {
			return (int) 1 === $value;
		}

		if ( is_string( $value ) ) {
			return in_array( strtolower( trim( $value ) ), array( '1', 'true', 'yes', 'on' ), true );
		}

		return false;
	}

	/**
	 * Normalize array keys to int or string as appropriate for role IDs, to prevent issues with numeric string keys being treated as strings instead of ints in some contexts.
	 * 
	 * @param array<int|string, mixed> $rows Role-keyed rows.
	 * @return array<int|string, mixed>
	 */
	private function normalize_role_keyed_array( array $rows ) {
		$normalized = array();

		foreach ( $rows as $role_id => $row ) {
			$key                = is_numeric( $role_id ) ? (int) $role_id : $role_id;
			$normalized[ $key ] = $row;
		}

		return $normalized;
	}

	/**
	 * Get map of role slug to term ID for the role taxonomy.
	 * 
	 * @return array<string, int> slug => term_id
	 */
	private function get_role_slug_map() {
		$terms = get_terms( array( 'taxonomy' => $this->get_role_taxonomy(), 'hide_empty' => false ) );
		$map   = array();

		if ( is_wp_error( $terms ) ) {
			return $map;
		}

		foreach ( $terms as $term ) {
			$map[ $term->slug ] = (int) $term->term_id;
		}

		return $map;
	}

	/**
	 * Yes/no value to boolean, treating 'yes', '1', 1, and true as truthy, anything else as falsy.
	 * 
	 * @param mixed $value Stored yes/no value.
	 * @return bool
	 */
	private function yes_to_bool( $value ) {
		return 'yes' === $value || true === $value || 1 === $value || '1' === $value;
	}

	/**
	 * Boolean input to 'yes' for storage, anything else is treated as falsy and stored as empty string.
	 * 
	 * @param mixed $value Boolean input.
	 * @return string
	 */
	private function bool_to_yes( $value ) {
		if ( is_bool( $value ) ) {
			return $value ? 'yes' : '';
		}

		return in_array( $value, array( 'yes', '1', 1, true ), true ) ? 'yes' : '';
	}
}
