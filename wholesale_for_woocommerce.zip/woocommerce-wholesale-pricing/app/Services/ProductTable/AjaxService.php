<?php
/**
 * WooCommerce Product Table setup
 *
 * @package Woocommerce Product Table/Includes
 */
namespace WooCommerceWholesalePricing\App\Services\ProductTable;

use WooCommerceWholesalePricing\App\Modules\ProductTable\Traits\Fields;
use WooCommerceWholesalePricing\App\Strategies\DataTableCollection;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

if (! defined('ABSPATH') ) {
	exit; // Exit if accessed directly.
}

/**
 * WC_Product_Table Class.
 */
class AjaxService implements ServiceInterface {

	use Fields;

	/**
	 * Define woocommerce product table ajax
	 */
	public function __construct() {

		// load woocommerce products.
		add_action('wp_ajax_wcpt_load_products', array( $this, 'wcpt_load_products' ));
		add_action('wp_ajax_nopriv_wcpt_load_products', array( $this, 'wcpt_load_products' ));

		add_action('wp_ajax_wcpt_export_product_table', array( $this, 'wcpt_export_product_table' ));
		add_action('wp_ajax_wcpt_import_product_table', array( $this, 'wcpt_import_product_table' ));
		add_action('wp_ajax_wcpt_toggle_onepage_checkout', array( $this, 'wcpt_toggle_onepage_checkout' ));
		add_action('wp_ajax_wcpt_toggle_post_status', array( $this, 'wcpt_toggle_post_status' ));

		// Hook for the AJAX action
		add_action('wp_ajax_get_product_image', array( $this, 'get_product_image' ));
		add_action('wp_ajax_nopriv_get_product_image', array( $this, 'get_product_image' ));

		// add woocommerce product to cart.
		add_action('wp_ajax_wcpt_add_to_cart', array( $this, 'wcpt_add_to_cart' ));
		add_action('wp_ajax_nopriv_wcpt_add_to_cart', array( $this, 'wcpt_add_to_cart' ));
		// add woocommerce multiple products to cart.
		add_action('wp_ajax_wcpt_add_selected_products_cart', array( $this, 'wcpt_add_selected_products_cart' ));
		add_action('wp_ajax_nopriv_wcpt_add_selected_products_cart', array( $this, 'wcpt_add_selected_products_cart' ));
		// Quick view for a product.
		add_action('wp_ajax_wcpt_popup_content', array( $this, 'wcpt_popup_content' ));
		add_action('wp_ajax_nopriv_wcpt_popup_content', array( $this, 'wcpt_popup_content' ));
		// expandable image 
		// Set names of the products that added to cart.
		add_filter('woocommerce_add_to_cart_fragments', array( $this, 'wcpt_set_title_products_added_cart' ));
		// Used for stop redirecting to single product page from popup
		add_filter('woocommerce_add_to_cart_form_action', array( $this, 'redirect_to_same_page_after_add_to_cart' ));
		add_action('wp_ajax_load_mini_cart_checkout', array( $this, 'load_mini_cart_checkout_ajax' ));
		add_action('wp_ajax_nopriv_load_mini_cart_checkout', array( $this, 'load_mini_cart_checkout_ajax' ));
		add_action('wp_ajax_load_mini_cart_content', array( $this, 'load_mini_cart_content_ajax' ));
		add_action('wp_ajax_nopriv_load_mini_cart_content', array( $this, 'load_mini_cart_content_ajax' ));
		add_action('wp_ajax_clear_wc_notices', array( $this, 'clear_wc_notices' ));
		add_action('wp_ajax_nopriv_clear_wc_notices', array( $this, 'clear_wc_notices' ));

		add_action('wp_ajax_add_to_cart', array( $this, 'custom_grouped_ajax_add_to_cart' ));
		add_action('wp_ajax_nopriv_add_to_cart', array( $this, 'custom_grouped_ajax_add_to_cart' ));

		// Add this to functions.php or a custom plugin
		add_filter('wcpt_cache_key', array( $this, 'custom_cache_key_filter' ), 10, 5);

		add_action('wp_ajax_wcpt_get_wholesale_price', array( $this, 'wcpt_get_wholesale_price' ));
		add_action('wp_ajax_nopriv_wcpt_get_wholesale_price', array( $this, 'wcpt_get_wholesale_price' ));
	}

	public function wcpt_get_wholesale_price() {
		if (! isset($_REQUEST['nonce']) ) {
			return;
		}

		if ( is_user_logged_in() && function_exists('is_wholesaler_user') && is_wholesaler_user( get_current_user_id() ) ) {
			// Check if necessary params are set
			if (isset($_REQUEST['variation_id'], $_REQUEST['price'])) {
				$variation_id = sanitize_text_field($_REQUEST['variation_id']);
				$price = sanitize_text_field($_REQUEST['price']);

				// Get the product object
				$variation_product = wc_get_product($variation_id);

				// Call the wholesale pricing function
				if ( class_exists( 'WWP_Easy_Wholesale_Multiuser' ) ) {
					$Wholesale_Price_class = new \WWP_Easy_Wholesale_Multiuser();
					$wholesale_price = $Wholesale_Price_class->wwp_regular_price_change($price, $variation_product);


					// Send back the new price
					wp_send_json_success(array( 'wwp_price' => wc_price($wholesale_price) ));
				}
			}
		} else {
			// Send back the new price
			wp_send_json_success(array( 'wwp_price' => wc_price(sanitize_text_field($_REQUEST['price'])) ));
		}

		wp_send_json_error();
	}

	public function custom_cache_key_filter( $cache_key, $table_id, $current_page_offset, $chunk_size, $filters ) {
		// Modify the cache key based on the filters
		return $cache_key . '_' . md5($filters); // Use md5 to reduce the size of the filter string
	}


	public function custom_grouped_ajax_add_to_cart() {
		$data = $_REQUEST;
		if (
		!isset($data['add-to-cart']) ||
		!isset($data['quantity']) ||
		!wp_verify_nonce($data['add-to-cart-nonce'], 'woocommerce-add-to-cart')
		) {
			wp_send_json_error(array( 'message' => 'Invalid request' ));
		}

		$quantities = $data['quantity'];
		$added = false;

		foreach ($quantities as $product_id => $qty) {
			$product_id = absint($product_id);
			$qty = (int) $qty;

			if ($qty > 0) {
				$added_to_cart = WC()->cart->add_to_cart($product_id, $qty);
				if ($added_to_cart) {
					$added = true;
				}
			}
		}

		if ($added) {
			WC()->cart->calculate_totals();
			WC()->cart->set_session();
			\WC_AJAX::get_refreshed_fragments();
		} else {
			wp_send_json_error(array( 'message' => 'No products were added' ));
		}
	}


	public function clear_wc_notices() {
		if (function_exists('wc_clear_notices')) {
			wc_clear_notices();
		}
		wp_die();
	}

	public function load_mini_cart_content_ajax() {
		ob_start();
		woocommerce_mini_cart(); // Load mini cart HTML
		$mini_cart_html = ob_get_clean();

		wp_send_json_success($mini_cart_html);
	}

	public function load_mini_cart_checkout_ajax() {
		if (null === WC()->session) {
			WC()->session = new \WC_Session_Handler();
			WC()->session->init();
		}
		if (null === WC()->checkout) {
			WC()->checkout = new \WC_Checkout();
		}
		ob_start();
		wc_get_template('checkout/form-checkout.php', array( 'checkout' => WC()->checkout ));
		wp_send_json_success(ob_get_clean());
	}
	
	public function wcpt_import_product_table() {
		if (! isset($_POST['nonce']) ) {
			return;
		}
		if (! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ajax-nonce') ) {
			return;
		}

		$data = $_FILES;
		if ( 'application/json' !== $data['import_file']['type'] ) {
			wp_safe_redirect(wp_get_referer() ? wp_get_referer() . '&product-table-import=failed' : admin_url('edit.php?postype=wcpt&product-table-import=failed') );
			exit;
		}
		
		$fileContent = file_get_contents($data['import_file']['tmp_name']);
		$table_data = (array) json_decode( $fileContent );
		$post_data = (array) $table_data['post_data'];
		$args = array(
			'post_author'  => $post_data['post_author'],
			'post_title'   => $post_data['post_title'],
			'post_status'  => $post_data['post_status'],
			'post_type'    => 'wcpt',
		);
		$post_id = wp_insert_post($args);

		$fields = $table_data['product_table_fields'] ;
		$table_fields = array();
		foreach ($fields as $field) {
			$table_fields[] = (array) $field;
		}
		foreach ( $table_data as $key => $meta_value ) {    
			update_post_meta($post_id, $key, $meta_value);
		}
		update_post_meta($post_id, 'product_table_fields', $table_fields );
		wp_safe_redirect( admin_url('edit.php?post_type=wcpt') );
		exit;
	}

	/**
	 * Verify list-table AJAX request and return post ID.
	 *
	 * @return int
	 */
	private function verify_list_table_ajax_request() {
		check_ajax_referer('wcpt_list_table', 'nonce');

		$post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
		if ( ! $post_id || 'wcpt' !== get_post_type($post_id) ) {
			wp_send_json_error(array( 'message' => __('Invalid product table.', 'woocommerce-wholesale-pricing') ), 400);
		}

		if ( ! current_user_can('edit_post', $post_id) ) {
			wp_send_json_error(array( 'message' => __('Permission denied.', 'woocommerce-wholesale-pricing') ), 403);
		}

		return $post_id;
	}

	/**
	 * Toggle one-page checkout meta from the list table.
	 *
	 * @return void
	 */
	public function wcpt_toggle_onepage_checkout() {
		$post_id = $this->verify_list_table_ajax_request();
		$enabled = filter_input( INPUT_POST, 'enabled', FILTER_SANITIZE_SPECIAL_CHARS );

		$enabled = ! empty($enabled) && '1' === $enabled;

		if ( $enabled ) {
			update_post_meta($post_id, 'display_onepage_checkout', 'yes');
		} else {
			delete_post_meta($post_id, 'display_onepage_checkout');
		}

		wp_send_json_success(array( 'enabled' => $enabled ));
	}

	/**
	 * Toggle product table post status from the list table.
	 *
	 * @return void
	 */
	public function wcpt_toggle_post_status() {
		$post_id = $this->verify_list_table_ajax_request();

		$status  = filter_input( INPUT_POST, 'status', FILTER_SANITIZE_SPECIAL_CHARS );
		$status = $status ? $status : '';

		if ( ! in_array($status, array( 'publish', 'draft' ), true) ) {
			wp_send_json_error(array( 'message' => __('Invalid status.', 'woocommerce-wholesale-pricing') ), 400);
		}

		$result = wp_update_post(
			array(
				'ID'          => $post_id,
				'post_status' => $status,
			),
			true
		);

		if ( is_wp_error($result) ) {
			wp_send_json_error(array( 'message' => $result->get_error_message() ), 500);
		}

		wp_send_json_success(array( 'status' => $status ));
	}

	public function wcpt_export_product_table() {

		$data = $_REQUEST;
		$post_id = ! empty( $data['post'] ) ? $data['post'] : '' ;
		$post = get_post($post_id); 

		$product_table_fields      = get_post_meta($post->ID, 'product_table_fields', true);
		$wcpt_meta_settings = array(
			'display_wholesale_only',
			'display_table_header',
			'display_table_footer',
			'display_reset',
			'display_page_length',
			'display_product_totals',
			'display_pagination',
			'variable_list_view',
			'wcpt_custom_products_msg',
			'default_sorted_col',
			'default_sorted_dir',
			'wcpt_rows_page',
			'wcpt_product_limit',
			'enable_sort_cols',
			'show_search',
			'show_filter',
			'wcpt_inc_product_cats',
			'wcpt_wholesale_selected_roles',
			'wcpt_addon_display',
			'display_table_design',
			'external_bdcolor',
			'external_bdsize',
			'header_bdcolor',
			'header_bdsize',
			'border_cells_color',
			'border_cells_size',
			'table_header_bg',
			'table_cell_bg',
			'table_header_font_clr',
			'table_header_font_size',
			'table_cell_font',
			'table_cell_size',
			'wcpt_inc_product_tags',
			'wcpt_product_status',
			'wcpt_ex_product_cats',
			'display_responsive',
			'columns_show',
			'wcpt_date_opt',
			'wcpt_date',
			'wcpt_filters_col',
			'wcpt_filters_obj',
			'filter_product_based_term',
			'shortocode_html_formatting',
			'guest_users',
			'wcpt_add_to_cart_label',
			'wcpt_price_text',
			'guest_users_redirection',
			'mini_cart_enable',
			'mini_cart_position',
			'mini_cart_placement',
			'mini_cart_icons',
			'wcpt_wrap',
			'wcpt_scroll',
			'wcpt_checked',
			'sorted_cols',
			'mobile_icon_chck',
			'columns_mobile_show',
			'tablet_icon_chck',
			'columns_tablet_show',
			'pagingType',
			'display_onepage_checkout',
		);

		  // Fetch all settings data
		$table_data = array();
		foreach ($wcpt_meta_settings as $wcpt_meta_setting) {
			$meta_value = get_post_meta($post->ID, $wcpt_meta_setting, true);
		// Ensure the meta value is not empty before adding it to the data array
			if ( '' !== $meta_value ) {
				$table_data[$wcpt_meta_setting] = $meta_value;
			}
		}

	// Add additional data
		$table_data['product_table_fields'] = $product_table_fields;
		$table_data['post_data'] = $post;

	// Check if any data is present
		if (empty($table_data)) {
			// No data to export, handle error or exit
			return __('No data to export.', 'woocommerce-wholesale-pricing');
		}

	// Encode data to JSON
		$json = json_encode($table_data);

	// Check if JSON encoding was successful
		if (false === $json) {
		// JSON encoding failed, handle error
		return __('JSON encoding failed.', 'woocommerce-wholesale-pricing');
			
		}

	// Define folder path
		$folder_path = WWP_PLUGIN_PATH . 'public/product-table-json/';

	// Create the folder if it doesn't exist
		if (!file_exists($folder_path)) {
			if (!mkdir($folder_path, 0755, true)) {
			// Handle folder creation failure
		
				return __('Failed to create folder.', 'woocommerce-wholesale-pricing');
			}
		}

	// Define file path
		$file_name = 'product_table_settings_' . $post->ID . '.json';
		$output_file = $folder_path . $file_name;

		$result = file_put_contents($output_file, $json); // nosemgrep: audit.php.lang.security.file.read-write-delete
		if (file_exists($output_file) && filesize($output_file) > 0) {
			header('Content-Description: File Transfer');
			header('Content-Type: application/json');
			header('Content-Disposition: attachment; filename="' . $file_name . '"');
			header('Expires: 0');
			header('Cache-Control: must-revalidate');
			header('Pragma: public');
			header('Content-Length: ' . filesize($output_file));

			readfile($output_file); // nosemgrep: audit.php.lang.security.file.read-write-delete
			exit;
		}
	}

		// AJAX handler function to get the product image URL
	public function get_product_image() {
		$image_data = $_REQUEST;
		$product_id = !empty( absint($image_data['product_id']) ) ? absint($image_data['product_id']) : '';
		$product = wc_get_product($product_id);
		$image_id = $product->get_image_id();

		
		if ( $image_id ) {
			$image_url = wp_get_attachment_image_url($image_id, 'full');
		} else {
			$image_url = wc_placeholder_img_src('full');
		}

		if ( false == $image_url ) {
			return;
		}
		echo esc_url( $image_url );
		wp_die();
	}



	/**
	 * Get woocommerce product table headings.
	 *
	 * @param  int $product_table_id table id.
	 * @return array $product_table_headings
	 */
	public function products_table_heading( $product_table_id ) {
		// Check if display table heading or not.
		$product_table_headings = array();
		// get product table fields.
		$product_table_fields = self::get_product_table_fields($product_table_id);
		if ($product_table_fields ) {
			foreach ( $product_table_fields as $product_table_field ) {
				$product_table_headings[] = array(
					'label' => $product_table_field['woo_label'],
					'type'  => $product_table_field['woo_ids'],
					'width' => $product_table_field['woo_width'],
				);
			}
		}
		/**
		 * Filter product table headings
		 * 
		 * @since 1.1.5
		**/
		return apply_filters('wcpt_product_table_headings', $product_table_headings, $product_table_fields, $product_table_id);
	}

	/**
	 * Get product table selected product to cart position.
	 *
	 * @param  int $product_table_id product table id.
	 * @return string $selected_cart_position
	 */
	public function product_table_add_selected_cart( $product_table_id ) {
		$selected_cart_position = '';
		// get product table fields.
		$product_table_fields = self::get_product_table_fields($product_table_id);
		if ($product_table_fields ) {
			foreach ( $product_table_fields as $product_table_field ) {
				if ('cart_button' === $product_table_field['woo_ids'] && 'add_button' !== $product_table_field['woo_add_types'] && 'add_quick_view_button' !== $product_table_field['woo_add_types']  ) {
					$selected_cart_position = $product_table_field['woo_add_selected_cart'];
				}

			}
		}
		/**
		 * Filter wcpt selected cart position
		 * 
		 * @since 1.1.5
		**/
		return apply_filters('wcpt_selected_cart_position', $selected_cart_position, $product_table_fields, $product_table_id);
	}

	/**
	 * Load woocommerce products
	 */
	public function wcpt_load_products() {
		// get request data.
		if (! isset($_POST['nonce']) ) {
			return;
		}
		if (! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ajax-nonce') ) {
			return;
		}

		$table_id = isset($_POST['table_id']) ? intval($_POST['table_id']) : 0; 
		$total_products = (int) get_post_meta($table_id, 'wcpt_product_limit', true);

		$per_page_product = isset($_POST['length']) ? intval($_POST['length']) : 10; 

		$total_draws = ceil($total_products / $per_page_product);
		$current_page_offset = isset($_POST['start']) ? intval($_POST['start']) : 0;
		$draw = isset($_POST['draw']) ? intval($_POST['draw']) : 0;

		if ( $draw == $total_draws ) {
			$_POST['length'] = $total_products - $current_page_offset;
		}

		// Fetch chunked products
		$wcpt_collection = new DataTableCollection($_POST);

		// Initialize products data array
		$products_data = array(
			'wc_products' => array(),
			'records_total' => 0,
			'records_filtered' => 0,
		);

		$total_length = isset($_POST['length']) ? intval($_POST['length']) : 10; // Total number of items to fetch
		$chunk_size = $total_length; // Number of items per chunk (e.g., 5)
		$current_page_offset = isset($_POST['start']) ? intval($_POST['start']) : 0; // Start index for pagination
		$user_id = is_user_logged_in() ? get_current_user_id() : 0;

		// Loop through in chunks based on the total length
		for ($i = 1; $i <= ceil($total_length / $chunk_size); $i++) {

			// Check cache for the current chunk
			$cache_key = 'wc_products_' . $table_id . '_' . $user_id . '_' . $current_page_offset . '_' . $chunk_size;

			// If filters are provided as an array, serialize them
			$filters = isset($_POST['filters']) ? json_encode(sanitize_text_field($_POST['filters'])) : '';

			// Apply a filter to modify the cache key, if needed
			 /**
			 * Filter wcpt_cache_key
			 * 
			 * @since 1.1.5
			**/
			$cache_key = apply_filters('wcpt_cache_key', $cache_key, $table_id, $current_page_offset, $chunk_size, $filters);

			// Check if the cache already contains the product data
			$cached_products = wp_cache_get($cache_key);


			if ( true ) {  //false === $cached_products

				// Cache miss, fetch the product data
				$products_chunk = $this->get_wc_product_data($wcpt_collection, $chunk_size, $current_page_offset);
				
				// Store fetched data in cache for 1 hour (3600 seconds)
				wp_cache_set($cache_key, $products_chunk, '', 3600);
			} else {
				// Cache hit, use the cached data
				$products_chunk = $cached_products;
			}

			// Append the chunk of products to the products_data array
			$products_data['wc_products'] = array_merge($products_data['wc_products'], $products_chunk['wc_products']);
			if ( 1 == $i ) {
				$products_data['records_total'] = $products_chunk['records_total'];
				$products_data['records_filtered'] = $products_chunk['records_filtered'];
			}

			// Update the offset for the next chunk
			$current_page_offset += $chunk_size;
		}

		echo wp_json_encode(array(
			'draw' => $draw,
			'recordsTotal' => $products_data['records_total'],
			'recordsFiltered' => $products_data['records_filtered'],
			'data' => $products_data['wc_products'],
		));

		wp_die();
	}

	/**
	 * Get woocommerce product table.
	 *
	 * @param  array $wcpt_collection array of wcpt_collection.
	 * @return array $products_data
	 */
	public function get_wc_product_data( $wcpt_collection, $chunk_size, $offset ) {

		// query to get woocommerce products.
		$box_office = null;
		$wc_products          = array();
		$products_data        = array();
		$records_total        = 0;
		$records_filtered     = 0;
		$product_table_id     = $wcpt_collection->get('table_id');
		$list_variations_type = get_post_meta($product_table_id, 'variable_list_view', true);
		$list_group_type = get_post_meta($product_table_id, 'group_list_view', true);

		$wcpt_price_text = !empty( get_post_meta($product_table_id, 'wcpt_price_text', true) ) ? get_post_meta($product_table_id, 'wcpt_price_text', true) : __('Login to see price', 'woocommerce-wholesale-pricing');
		$enable = !empty( get_post_meta($product_table_id, 'guest_users', true) ) ? get_post_meta($product_table_id, 'guest_users', true) : 0 ;
		$wcpt_add_to_cart_label = !empty( get_post_meta($product_table_id, 'wcpt_add_to_cart_label', true) ) ? get_post_meta($product_table_id, 'wcpt_add_to_cart_label', true) : __('Sign up', 'woocommerce-wholesale-pricing');
		$guest_users_redirection =  !empty ( get_post_meta($product_table_id, 'guest_users_redirection', true) ) ?  get_post_meta($product_table_id, 'guest_users_redirection', true) : '' ;
		
		$display_onepage_checkout = get_post_meta($product_table_id, 'display_onepage_checkout', true);

		$group_list_view = get_post_meta($product_table_id, 'group_list_view', true);

		$products_query = $this->wc_products_query($wcpt_collection, $product_table_id, $list_variations_type, $offset, $chunk_size);
		
		// loop and popuplate products array with data.
		if ( isset( $products_query->posts ) && is_array( $products_query->posts ) && count( $products_query->posts ) > 0 ) {
			// get product table fields.
			$product_table_fields = self::get_product_table_fields($product_table_id);
			foreach ( $products_query->posts as $product_id ) {

				global $product;
				$product        = wc_get_product($product_id);

				$product_record = array();
				$stock_status       = get_post_meta($product_table_id, 'wcpt_product_status', true);

				if ($stock_status ) {
					if ('instock' === $stock_status && $stock_status === $product->get_stock_status() ) {
						$check_status = true;
					} elseif ('outofstock' === $stock_status && $stock_status === $product->get_stock_status() ) {
						$check_status = true;
					} else {
						$check_status = false;
					}
				} else {
					$check_status = true;
				}

				// 🚫 Skip if product is of type "grouped"
				if ( $product && $product->is_type('grouped') && 'separate_row' == $group_list_view ) {
					continue;
				}

				if ($product && $check_status) {
					foreach ( $product_table_fields as $product_table_field ) {
						$args = array();
						ob_start();
						$args['shortocode_html_formatting'] = get_post_meta($product_table_id, 'shortocode_html_formatting', true);
						switch ( $product_table_field['woo_ids'] ) {
							case 'id':
							$args['product_id'] = $product_id;
							wwp_wc_product_table_get_template('fields/product-table-id.php', $args);
							$product_record[] = ob_get_clean();
								break;
							case 'title':
							$args['product_title'] = $product->get_name();
								if ('variation' === $product->get_type() ) {
									$args['product_title'] .= wc_get_formatted_variation($product, false, true, true);
								}
							$args['product_linkable'] = $product_table_field['woo_linkable'];
								if ($args['product_linkable'] ) {
									$args['product_url'] = get_permalink($product_id);
								}

							$formatted_variation_list = wc_get_formatted_variation($product, true, true, true);
							wwp_wc_product_table_get_template('fields/product-table-title.php', $args);
							$product_record[] = ob_get_clean();
								break;

							case 'quick_view':
							$args['product_id'] = $product_id;
							wwp_wc_product_table_get_template('fields/product-table-quick-view.php', $args);
							$product_record[] = ob_get_clean();
								break;

							
							case 'sku':
							$args['product_sku'] = $product->get_sku();
							wwp_wc_product_table_get_template('fields/product-table-sku.php', $args);
							$product_record[] = ob_get_clean();
								break;

							
							case 'short_desc':
							$args['product_short_description'] = $product->get_short_description();
							wwp_wc_product_table_get_template('fields/product-table-short-description.php', $args);
							$product_record[] = ob_get_clean();
								break;
							case 'descr':
							$descrption_length           = $product_table_field['woo_descr'];
							$args['product_description'] = $product->get_description();
								if ($descrption_length ) {
									$args['product_description'] = substr($args['product_description'], 0, $descrption_length);
								}
							wwp_wc_product_table_get_template('fields/product-table-description.php', $args);
							$product_record[] = ob_get_clean();
								break;
							case 'date':
							$args['product_date'] = $product->get_date_created();
								// product date fotmat.
								if ($product_table_field['woo_date_format'] ) {
									$args['product_date_format'] = $product_table_field['woo_date_format'];
								} else {
									$args['product_date_format'] = get_option('date_format', true);
								}
							wwp_wc_product_table_get_template('fields/product-table-date.php', $args);
							$product_record[] = ob_get_clean();
								break;
							case 'cat':
							$product_category_ids = $product->get_category_ids();
							$product_categories   = '';
								if ($product_category_ids ) {
									$product_categories = implode(
									',',
									get_terms(
										array(
											'taxonomy' => 'product_cat',
											'include'  => $product_category_ids,
											'fields'   => 'names',
										)
									)
									);
								}

							$args['product_categories'] = $product_categories;
							wwp_wc_product_table_get_template('fields/product-table-categories.php', $args);
							$product_record[] = ob_get_clean();
								break;
							case 'featured_img':
							$args['product_image']    = $product->get_image();
							$args['product_linkable']         = $product_table_field['woo_linkable'];
							$args['product_image_expandable'] = $product_table_field['woo_expandable'];

								if ($args['product_linkable'] ) {
									$args['product_url'] = get_permalink($product_id);
								} 
								if ( $args['product_image_expandable']  ) {
									$args['product_id'] = $product->get_id();
								}

							wwp_wc_product_table_get_template('fields/product-table-image.php', $args);
							$product_record[] = ob_get_clean();
								break;
							case 'reviews':
							$args['product_reviews'] = $product->get_average_rating();
							wwp_wc_product_table_get_template('fields/product-table-reviews.php', $args);
							$product_record[] = ob_get_clean();
								break;
							case 'stock':
							$args['product_stock_status'] = $product->get_stock_status();
							$args['product']              = $product;
							$args['woo_show_stock']        = $product_table_field['woo_show_stock'];


							wwp_wc_product_table_get_template('fields/product-table-stock-status.php', $args);
							$product_record[] = ob_get_clean();
								break;
							case 'weight':
							$args['product_weight'] = $product->get_weight();
							wwp_wc_product_table_get_template('fields/product-table-weight.php', $args);
							$product_record[] = ob_get_clean();
								break;
							case 'dimensions':
							$args['product_dimensions'] = $product->get_dimensions();
							wwp_wc_product_table_get_template('fields/product-table-dimensions.php', $args);
							$product_record[] = ob_get_clean();
								break;
							case 'price':
							$args['product_price'] = $product->get_price_html();
							$args['product_id'] = $product_id;
							$args['enable'] = $enable;
							$args['wcpt_price_text'] = $wcpt_price_text;
							wwp_wc_product_table_get_template('fields/product-table-price.php', $args);
							$product_record[] = ob_get_clean();
								break;
							case 'attributes':
							$attribute_key              = $product_table_field['woo_attrs'];
							$args['product_attributes'] = $product->get_attribute($attribute_key);
							wwp_wc_product_table_get_template('fields/product-table-attributes.php', $args);
							$product_record[] = ob_get_clean();
								break;
							case 'custom_fields':
							$custom_key                   = $product_table_field['woo_custom_keys'];
							$args['product_custom_field'] = $product->get_meta($custom_key, true);
							wwp_wc_product_table_get_template('fields/product-table-custom-field.php', $args);
							$product_record[] = ob_get_clean();
								break;
							case 'tags':
							$product_tag_ids = $product->get_tag_ids();
							$product_tags    = '';
								if ($product_tag_ids ) {
									$product_tags = implode(
									',',
									get_terms(
										array(
											'taxonomy' => 'product_tag',
											'include'  => $product_tag_ids,
											'fields'   => 'names',
										)
									)
									);
								}

							$args['product_tags'] = $product_tags;
							wwp_wc_product_table_get_template('fields/product-table-tags.php', $args);
							$product_record[] = ob_get_clean();
								break;
							case 'taxonomy':
							$custom_taxonomy          = $product_table_field['woo_taxonomy'];
							$product_custom_tax_terms = '';
								if (taxonomy_exists($custom_taxonomy) ) {
									$product_custom_tax_terms = implode(
									',',
									get_terms(
										array(
											'taxonomy' => $custom_taxonomy,
											'object_ids' => $product_id,
											'fields'   => 'names',
										)
									)
									);
								}

							$args['product_custom_tax_terms'] = $product_custom_tax_terms;
							wwp_wc_product_table_get_template('fields/product-table-custom-taxonomy.php', $args);
							$product_record[] = ob_get_clean();
								break;

							case 'cart_button':
									$args['product']          = $product;
									$args['classes']          = '';
									$args['cart_button_type'] = $product_table_field['woo_add_types'];
									$args['enable'] = $enable;
									$args['wcpt_add_to_cart_label'] = $wcpt_add_to_cart_label;
									$args['wcpt_price_text'] = $wcpt_price_text;
									$args['guest_users_redirection'] = $guest_users_redirection;
								
								if ('add_checkbox' === $product_table_field['woo_add_types'] || 'add_quick_view_button' === $product_table_field['woo_add_types'] ) {
									$args['classes'] = 'hide-submit-btn';
								}
									$args['show_quantity'] = $product_table_field['woo_quantity'];
								if ('true' !== $product_table_field['woo_quantity'] ) {
									$args['classes'] = 'hide-quantity';
								}
									$args['cart_button_position'] = $product_table_field['woo_add_selected_cart'];
								
								if ('variable' === $product->get_type() || 'variable-subscription' === $product->get_type() ) {
									$args['list_variations_type'] = $list_variations_type;
								}

								if ('variable' === $product->get_type() || 'variable-subscription' === $product->get_type() ) {
									// Check if variations are cached, mufaddal
									$cached_variations = get_transient('product_variations_' . $product_id);
									if (false !== $cached_variations) {
										// Variations found in cache, use them
										$variation_args = array(
											'available_variations' => $cached_variations['available_variations'],
											'attributes' => $cached_variations['attributes'],
											'selected_attributes' => $cached_variations['selected_attributes'],
										);
									} else {
									   /**
									 * Filter woocommerce ajax variation threshold
									 * 
									 * @since 1.1.5
									   **/
									   $get_variations = count($product->get_children()) <= apply_filters('woocommerce_ajax_variation_threshold', 30, $product);

									   $variation_args = array(
										'available_variations' => $get_variations ? $product->get_available_variations() : false,
										'attributes' => $product->get_variation_attributes(),
										'selected_attributes' => $product->get_default_attributes(),
									   );
									}

									   $args = array_merge($args, $variation_args);
								}

								if ( class_exists('WC_Box_Office') ) {
									$box_office = wc_box_office_is_product_ticket($product);
								} 
								if ('add_quick_view_button' === $product_table_field['woo_add_types'] ||
												( 'bundle_product' === $product->get_type() ) || $box_office ||
												( 'bundle' === $product->get_type() )
											) {

									wwp_wc_product_table_get_template('fields/product-table-quick-view.php', $args);

								} elseif ('variable-subscription' === $product->get_type() ) {
									wwp_wc_product_table_get_template('fields/variable-product-add-to-cart.php', $args);
								} else {
									$args['list_group_type'] = $list_group_type;
									wwp_wc_product_table_get_template('fields/' . $product->get_type() . '-product-add-to-cart.php', $args);
								}
										$product_record[] = ob_get_clean();

								break;

							default:
							$product_record[] = '';
						}
						/**
						 * Filter after product table field
						 * 
						 * @since 1.1.5
						**/
						$product_record = apply_filters('product_table_field_after', $product_record, $product_table_field['woo_ids'], $args, $product_id);

					}
					$wc_products[] = $product_record;
				}
			}
			$records_filtered = $products_query->found_posts;
			$records_total    = $products_query->found_posts;
		}

		// get posts.
		$products_limit = get_post_meta($product_table_id, 'wcpt_product_limit', true);
		if ($products_limit ) {
			if ($products_limit < $records_total ) {
				$records_total = $products_limit;
			}
			if ($products_limit < $records_filtered ) {
				$records_filtered = $products_limit;
			}
		}
		$products_data['wc_products']      = $wc_products;
		$products_data['records_filtered'] = $records_filtered;
		$products_data['records_total']    = $records_total;
		/**
		 * Filter product table products data
		 * 
		 * @since 1.1.5
		**/
		return apply_filters('wcpt_products_data', $products_data, $product_table_id);
	}

	/**
	 * Get woocommerce product table query.
	 *
	 * @param  array $wcpt_collection      array of wcpt_collection.
	 * @param  int   $product_table_id     product table ID.
	 * @param  array $list_variations_type array of variation type.
	 * @return array $products_query
	 */
	public function wc_products_query( $wcpt_collection, $product_table_id, $list_variations_type, $offset, $chunk_size ) {
		$products_query     = false;
		$parent_variations  = array();
		$product_variations = array();

		if ($wcpt_collection && $product_table_id ) {
			// prepare products args.
			$products_limit = get_post_meta($product_table_id, 'wcpt_product_limit', true);
			$posts_per_page = $chunk_size;

			$filter_terms = $wcpt_collection->get('filters');

			$product_inc_ids = get_post_meta($product_table_id, 'wcpt_inc_product_ids', true);

			$product_exc_ids = get_post_meta($product_table_id, 'wcpt_ex_product_ids', true);
			$tax_query       = $this->wc_get_tax_query($product_table_id, $filter_terms);

			$meta_query_attrs = $this->wc_get_meta_attr_query($filter_terms);

			$meta_product_query = $this->wc_get_meta_query($product_table_id, $filter_terms);

			$date_query = $this->wc_get_date_query($product_table_id);

			$search_filter_term = $this->wc_get_search_query($product_table_id);

			// display each variable in seperated row.
			if ('separate_row' === $list_variations_type ) {
				// get variations parent ids to exculde.
				$tax_query_variation = array( 'relation' => 'AND' );

				$tax_query_variation[] = array(
					'relation' => 'OR',
					array(
						'taxonomy' => 'product_type',
						'field'    => 'slug',
						'terms'    => 'variable',
					),
					array(
						'taxonomy' => 'product_type',
						'field'    => 'slug',
						'terms'    => 'variable-subscription',
					),
				);

				$parent_variations_args = array(
					'post_type'      => 'product',
					'fields'         => 'ids',
					'post_status'      => 'publish',
					'posts_per_page' => -1,
					'_meta_or_title' => $search_filter_term,
					'meta_value'      => $search_filter_term,
					'meta_compare'      => 'LIKE',
				);

				// set tax query.
				if ($tax_query ) {
					$parent_variations_args['tax_query'] = array_merge($tax_query_variation, $tax_query);
				} else {
					$parent_variations_args['tax_query'] = $tax_query_variation;
				}
				// set date query.
				if ($date_query ) {
					$parent_variations_args['date_query'] = $date_query;
				}       
				// set meta query.
				if ($meta_product_query ) {
					$parent_variations_args['meta_query'] = $meta_product_query;
				}

				/**
				 * Filter product table parent variation args
				 * 
				 * @since 1.1.5
				**/
				$parent_variations_args = apply_filters('wcpt_parent_variations_args', $parent_variations_args);

				$parent_variations = new \WP_Query($parent_variations_args);
				// get product variations.
				if ($parent_variations->posts ) {
					$product_variations_args = array(
						'fields'          => 'ids',
						'post_type'       => 'product_variation',
						'posts_per_page'  => -1,
						'post_parent__in' => $parent_variations->posts,
					);

					if ($meta_query_attrs || $meta_product_query ) {
						$product_variations_args['meta_query'] = array_merge( $meta_query_attrs, $meta_product_query);
					}
					/**
					 * Filter product table variation args
					 * 
					 * @since 1.1.5
					**/
					$product_variations_args = apply_filters('wcpt_product_variations_args', $product_variations_args);
					$product_variations      = new \WP_Query($product_variations_args);
				}
			}

			// get all products except variations.
			if (( 'separate_row' === $list_variations_type ) && $product_variations && $product_variations->have_posts() ) {
				$products_per_page = -1;
			} else {
				$posts_per_page = isset($posts_per_page) && $posts_per_page > 0 ? $posts_per_page : -1;
				$products_per_page = $posts_per_page;
			}

			// get order query.
			$order_query = $this->prepare_wcpt_order_query($wcpt_collection, $product_table_id);

			$is_sku = wc_get_product_id_by_sku($search_filter_term);
			
			if ( $is_sku ) {
				$search_value = 'meta_value';
			} else {
				$search_value = 's';
			}
			$product_args = array(
				'post_type'      => 'product',
				'fields'         => 'ids',
				'post_status'    => 'publish',
				'posts_per_page' => $wcpt_collection->get('length'),
				$search_value     => $search_filter_term,
			);
			// set tax query.
			if (is_array($tax_query) && count($tax_query) > 0 ) {
				$product_args['tax_query'] = $tax_query;
			}
			// set date query.
			if (is_array($date_query) && count($date_query) > 0 ) {
				$product_args['date_query'] = $date_query;
			}
			// set meta query.
			if ( is_array($meta_product_query) && count($meta_product_query) > 0 ) {
				$product_args['meta_query'] = $meta_product_query;
			}
			
			if ( 'separate_row' === $list_variations_type && $parent_variations ) {
				$product_args['post__not_in'] = $product_exc_ids ? array_merge($parent_variations->posts, $product_exc_ids) : $parent_variations->posts;
				$product_args['fields']       = 'ids';
			} else {
				if (is_array($product_exc_ids) && count($product_exc_ids) > 0 ) {
					$product_args['post__not_in'] = $product_exc_ids;
				}
				if (is_array($product_inc_ids) && count($product_inc_ids) > 0 ) {
					$product_args['post__in'] = $product_inc_ids;
				}
				if (is_array($order_query) && count($order_query) > 0 ) {
					$product_args = array_merge($product_args, $order_query);
				}
				$product_args['offset'] = $offset;
			}
			/**
			 * Filter product table args
			 * 
			 * @since 1.1.5
			**/
			$product_args = apply_filters('wcpt_product_table_args', $product_args);
			// Products Query.
			$products_query = new \WP_Query($product_args);

			// query to get all types of products.
			if ('separate_row' === $list_variations_type && $product_variations && $product_variations->have_posts() ) {
				$product_ids      = array_merge($products_query->posts, $product_variations->posts);
				$all_product_args = array(
					'post_type'      => array( 'product', 'product_variation' ),
					'post__in'       => $product_inc_ids ? $product_inc_ids : $product_ids,
					'posts_per_page' => $wcpt_collection->get('length') - 2,
					'post_status'    => 'publish',
					'offset'         => $offset,
					'_meta_or_title' => $search_filter_term,
					'meta_value'     => $search_filter_term,
					'meta_compare'   => 'LIKE',
					'fields'         => 'ids',
				);
				if ($order_query ) {
					$all_product_args = array_merge($all_product_args, $order_query);
				}
				/**
				 * Filter all products args
				 * 
				 * @since 1.1.5
				**/
				$all_product_args = apply_filters('wcpt_all_product_args', $all_product_args);

				$products_query = new \WP_Query($all_product_args);
			}
		}

		return $products_query;
	}

	/**
	 * Get woocommerce product table taxonomy query.
	 *
	 * @param  int    $product_table_id product table ID.
	 * @param  string $filter_terms     terms.
	 * @return array $tax_query
	 */
	public function wc_get_tax_query( $product_table_id, $filter_terms = '' ) {
		$cat_ids     = get_post_meta($product_table_id, 'wcpt_inc_product_cats', true);
		$tag_ids     = get_post_meta($product_table_id, 'wcpt_inc_product_tags', true);
		$cat_exc_ids = get_post_meta($product_table_id, 'wcpt_ex_product_cats', true);
		$search_filter_term = $this->wc_get_search_query($product_table_id);
		$tax_query   = array();
		if ($cat_ids ) {
			$tax_query[] = array(
				'taxonomy' => 'product_cat',
				'terms'    => $cat_ids,
			);
		}

		if ($tag_ids ) {
			$tax_query[] = array(
				'taxonomy' => 'product_tag',
				'terms'    => $tag_ids,
			);
		}
		if ($cat_exc_ids ) {
			$tax_query[] = array(
				'taxonomy' => 'product_cat',
				'terms'    => $cat_exc_ids,
				'operator' => 'NOT IN',
			);
		}

		if ($filter_terms ) {
			$filters_col  = get_post_meta($product_table_id, 'wcpt_filters_col', true);
			$filter_terms = json_decode(stripslashes($filter_terms));
			$tax_query[]  = array(
				'relation' => 'AND',
			);
			foreach ( $filter_terms as $filter_term ) {
				if ( ! empty( $filter_term->value ) ) {
					if ( 'wcpt_filter_height' == $filter_term->key || 'wcpt_filter_width' == $filter_term->key || 'wcpt_filter_length' == $filter_term->key || 'wcpt_filter_weight' == $filter_term->key || 'from_min' == $filter_term->key || 'to_max' == $filter_term->key || 'sort_by' == $filter_term->key || ( 'load_archive' === $filters_col && ! taxonomy_is_product_attribute($filter_term->key) ) ) {
						continue;
					}
					$tax_query[] = array(
						'taxonomy' => $filter_term->key,
						'terms'    => $filter_term->value,
					);
				}
			}
		}
		return $tax_query;
	}
	/**
	 * Get meta attribute query
	 *
	 * @param string $filter_terms terms.
	 */
	public function wc_get_meta_attr_query( $filter_terms = '' ) {
		$meta_attr_product_query = array();
		if ($filter_terms ) {
			$filter_terms = json_decode(stripslashes($filter_terms));
			foreach ( $filter_terms as $filter_term ) {
				if ( !empty( $filter_term->value ) ) {
					if (taxonomy_is_product_attribute($filter_term->key) ) {
						$term                    = get_term_by('id', $filter_term->value, $filter_term->key);
						$meta_attr_product_query = array(
							'relation' => 'AND',
							array(
								'key'     => wc_variation_attribute_name($filter_term->key),
								'value'   => $term->slug,
								'compare' => '=',
							),
						);
					}
				}
			}
		}
		return $meta_attr_product_query;
	}

	/**
	 * Get meta query
	 *
	 * @param int $product_table_id product table ID.
	 */
	public function wc_get_meta_query( $product_table_id, $filter_terms ) { 

		$stock_status       = get_post_meta($product_table_id, 'wcpt_product_status', true);
		$meta_product_query = array();
		
		if ( ! empty( $filter_terms ) ) {
			$filter_terms = json_decode( stripslashes( $filter_terms ) );
		} else {
			$filter_terms = array();
		}

		$min = 0;
		$max = 0;
		$weight_filter = '';

		if ( is_array( $filter_terms ) && ! empty( $filter_terms ) ) {
			foreach ( $filter_terms as $filter_term ) {
				if ( is_object( $filter_term ) ) {

					// Price Range
					if ( 'from_min' == $filter_term->key ) {
						$min = ! empty( $filter_term->value ) ? (int) $filter_term->value : 0;
					} elseif ( 'to_max' == $filter_term->key ) {
						$max = ! empty( $filter_term->value ) ? (int) $filter_term->value : 100;
					} elseif ( 'wcpt_filter_weight' === $filter_term->key && ! empty( $filter_term->value ) ) {
						$weight_filter = floatval( $filter_term->value );
					} elseif ( 'wcpt_filter_length' === $filter_term->key && ! empty( $filter_term->value ) ) {
						$length_filter = floatval( $filter_term->value );
					} elseif ( 'wcpt_filter_width' === $filter_term->key && ! empty( $filter_term->value ) ) {
						$width_filter = floatval( $filter_term->value );
					} elseif ( 'wcpt_filter_height' === $filter_term->key && ! empty( $filter_term->value ) ) {
						$height_filter = floatval( $filter_term->value );
					}

				}
			}
		}

		// Stock Status
		if ( $stock_status ) {
			$meta_product_query[] = array(
				'key'   => '_stock_status',
				'value' => $stock_status,
			);
		}

		// Price Range Filter
		if ( $min > 0 || $max > 0 ) {
			$meta_product_query[] = array(
				'relation' => 'AND',
				array(
					'key'     => '_price',
					'value'   => array( $min, $max ),
					'compare' => 'BETWEEN',
					'type'    => 'NUMERIC',
				),
			);
		}

		// Weight Filter
		if ( ! empty( $weight_filter ) ) {
			$meta_product_query[] = array(
				'key'     => '_weight',
				'value'   => $weight_filter,
				'compare' => '=',
				'type'    => 'CHAR',
			);
			
		}

		// Length Filter
		if ( ! empty( $length_filter ) ) {
			$meta_product_query[] = array(
				'key'     => '_length',
				'value'   => $length_filter,
				'compare' => '=',
				'type'    => 'CHAR',
			);
			
		}

		// Width Filter
		if ( ! empty( $width_filter ) ) {
			$meta_product_query[] = array(
				'key'     => '_width',
				'value'   => $width_filter,
				'compare' => '=',
				'type'    => 'CHAR',
			);
			
		}

		// Height Filter
		if ( ! empty( $height_filter ) ) {
			$meta_product_query[] = array(
				'key'     => '_height',
				'value'   => $height_filter,
				'compare' => '=',
				'type'    => 'CHAR',
			);
			
		}


		return $meta_product_query;
	}

	/**
	 * Get date query
	 *
	 * @param int $product_table_id table id.
	 */
	public function wc_get_date_query( $product_table_id ) {
		$date_option = get_post_meta($product_table_id, 'wcpt_date_opt', true);
		$date        = get_post_meta($product_table_id, 'wcpt_date', true);
		$date_query  = array();
		if ($date_option && $date ) {
			$date_query[ $date_option ] = $date;
		}
		return $date_query;
	}

	/**
	 * Get search query
	 *
	 * @param int $product_table_id table id.
	 */
	public function wc_get_search_query( $product_table_id ) {
		$search_filter_term = '';
		$search             = get_post_meta($product_table_id, 'show_search', true);
		if ($search ) {
			$search_filter_term = get_post_meta($product_table_id, 'filter_product_based_term', true);
			if (! isset($_POST['nonce']) ) {
				return;
			}
			if (! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ajax-nonce') ) {
				return;
			}

			// Respect DataTables search input exactly, including an intentional clear ("").
			if (isset($_POST['search']) && is_array($_POST['search']) && array_key_exists('value', $_POST['search']) ) {
				$search_filter_term = sanitize_text_field(wp_unslash($_POST['search']['value']));
			}
			// for search by ID
			if (is_numeric($search_filter_term) ) {
				$product = wc_get_product($search_filter_term);
				
				if ($product ) {
					// If a valid product is found with the provided ID, update the search term
					$search_filter_term = $product->get_title();
				}
			}
		}
		return $search_filter_term;
	}

	/**
	 * Prepare woocommerce product table order
	 *
	 * @param array $wcpt_collection  array of wcpt collection.
	 * @param int   $product_table_id table id.
	 */
	public function prepare_wcpt_order_query( $wcpt_collection, $product_table_id ) {
		$order_query = array();
		if ($wcpt_collection && $product_table_id ) {
			// get order column.
			$order_columns = $wcpt_collection->get('order');
			$filter_terms = $wcpt_collection->get('filters');

			$filter_terms = !empty($filter_terms) ? json_decode(stripslashes($filter_terms)) : array();
			
			if ($order_columns ) {
				// get order column and order direction.
				$order_column = $order_columns[0]['column'];
				// check if column is orderable.
				$columns         = $wcpt_collection->get('columns');
				$column_name     = $columns[ $order_column ]['name'];
				$order_direction = $order_columns[0]['dir'];
				switch ( $column_name ) {
					case 'id':
					$order_query['orderby'] = 'ID';
					$order_query['order']   = $order_direction;
						break;
					case 'title':
					$order_query['orderby'] = 'title';
					$order_query['order']   = $order_direction;
						break;
					case 'sku':
					$order_query['meta_key'] = '_sku';
					$order_query['orderby']  = 'meta_value';
					$order_query['order']    = $order_direction;
						break;
					case 'date':
					$order_query['orderby'] = 'date';
					$order_query['order']   = $order_direction;
						break;
					case 'reviews':
					$order_query['orderby']  = 'meta_value_num';
					$order_query['meta_key'] = '_wc_average_rating';
					$order_query['order']    = $order_direction;
						break;
					case 'price':
					$order_query['orderby']  = 'meta_value_num';
					$order_query['meta_key'] = '_price';
					$order_query['order']    = $order_direction;
						break;
				}
				// }
			}
			foreach ( $filter_terms as $filter_term ) {
				if ( 'sort_by' == $filter_term->key && !empty($filter_term->value) ) {
					if ( 'asc' ==  $filter_term->value  ||  'desc' ==  $filter_term->value) {
						$order_query['orderby']  = 'meta_value_num';
						$order_query['meta_key'] = '_price';
						$order_query['order']    = $filter_term->value;
						break;
					} elseif ('date' == $filter_term->value) {
						$order_query['meta_key'] = $filter_term->value;
						$order_query['order']    = 'desc';
					} else {
						$order_query['orderby']  = 'meta_value_num';
						$order_query['meta_key'] = $filter_term->value;
						$order_query['order']    = 'desc';
					}
				}

			}
		}
		/**
		 * Filter products order query
		 * 
		 * @since 1.1.5
		**/
		return apply_filters('wcpt_products_order_query', $order_query, $wcpt_collection, $product_table_id);
	}

	/**
	 * Get product table saved fields
	 *
	 * @param  int $product_table_id product table id.
	 * @return array $product_table_fields
	 */
	public function get_product_table_fields( $product_table_id ) {
		$product_table_fields = array();
		if ($product_table_id ) {
			// get product table fields.
			$product_table_fields = get_post_meta($product_table_id, 'product_table_fields', true);
		}
		/**
		 * Filter product table fields
		 * 
		 * @since 1.1.5
		**/
		$product_table_fields = apply_filters('wcpt_product_table_fields', $product_table_fields, $product_table_id);
		return $product_table_fields;
	}

	/**
	 * Ajax to add woocommerce product to cart
	 */
	public function wcpt_add_to_cart() {
		if (! isset($_POST['nonce']) ) {
			return;
		}
		if (! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ajax-nonce') ) {
			return;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		if (! isset($_POST['product_id']) ) {
			return;
		}
		/**
		 * Filter woocommerce_add_to_cart_product_id
		 * 
		 * @since 1.1.6
		**/
		$product_id        = apply_filters('woocommerce_add_to_cart_product_id', absint($_POST['product_id']));
		$product           = wc_get_product($product_id);
		$quantity          = empty($_POST['quantity']) ? 1 : wc_stock_amount(wp_unslash($_POST['quantity']));

		/**
		 * Filter woocommerce_add_to_cart_validation
		 * 
		 * @since 1.1.6
		**/
		$passed_validation = apply_filters('woocommerce_add_to_cart_validation', true, $product_id, $quantity);
		$product_status    = get_post_status($product_id);
		$variation_id      = 0;
		$variation         = array();

		if ($product && 'variation' === $product->get_type() ) {
			$variation_id = $product_id;
			$product_id   = $product->get_parent_id();
			$variation    = $product->get_variation_attributes();
			
			$attribute_names = array_keys($variation);
			if (is_array($attribute_names) ) {
				foreach ( $attribute_names as $attribute_name ) {
					if (isset($_POST[$attribute_name])) {
						$sanitized_value = sanitize_text_field($_POST[$attribute_name]);
						$variation[$attribute_name] = $sanitized_value;
					}
				}
				
			}
		}
		
		if ($passed_validation && false !== WC()->cart->add_to_cart($product_id, $quantity, $variation_id, $variation) && 'publish' === $product_status ) {
			
			/**
			 * Action woocommerce_ajax_added_to_cart
			 * 
			 * @since 1.1.6
			**/
			do_action('woocommerce_ajax_added_to_cart', $product_id);
			
			if ('yes' === get_option('woocommerce_cart_redirect_after_add') ) {
				wc_add_to_cart_message(array( $product_id => $quantity ), true);
			}

			WC()->cart->calculate_totals();
			WC()->cart->set_session();
			\WC_AJAX::get_refreshed_fragments();

		} else {

			// If there was an error adding to the cart, redirect to the product page to show any errors.
			$data = array(
				'error'       => true,
			/**
			 * Filter woocommerce_cart_redirect_after_error
			 * 
			 * @since 1.1.6
			**/
			'product_url' => apply_filters('woocommerce_cart_redirect_after_error', get_permalink($product_id), $product_id),
		);

			wp_send_json($data);
		}
	}


	/**
	 * Ajax to view product on popup
	 */

	public function wcpt_popup_content() {
		if (! isset($_POST['nonce']) ) {
			return;
		}
		if (! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ajax-nonce') ) {
			return;
		}
		$productId = isset($_REQUEST['productId']) ? absint($_REQUEST['productId']) : 0;

		ob_start();
		global $product;
		$product = wc_get_product($productId);
		$product_type = $product->get_type();


		wwp_view('product-table.fields.quick-view-popup', compact('product'));

		$bundle_product = ob_get_clean();

		$response = array(
			'fragments' => $bundle_product,
			'productType' => $product_type,
		);
		
		if ('bundle_product' == $product_type  ) {
			$response['wcbp_url'] = ( WC_UBP_URL . '/assets/js/frontend-script.js' );
			$response['wcbp_bundle'] = $data;
		} 
		wp_send_json($response);
	}

	
	// Stop redirecting to single page when added product from popup
	public function redirect_to_same_page_after_add_to_cart( $url ) {
		// Get the current page URL.
		$current_url = get_permalink(get_the_ID());
		return $current_url;
	}


	
	public function wcpt_add_selected_products_cart() {
		

		if (! isset($_POST['nonce']) ) {
			return;
		}
		
		if (! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'ajax-nonce') ) {
			return;
		}

		$formData = array();
		
		$post_data = $_POST;

		foreach ( $post_data['formdata'] as $key => $value ) {
			if (isset($value) && !empty($value)) {
				$dataArray = array();
				if ( is_string($value) ) {
			parse_str($value, $dataArray);
				} elseif ( is_array($value) ) {
					$dataArray = $value; // Already parsed
				}
				$formData[ $key ] = $dataArray;

			}
		}
		$cart_message      = '';

		$added_products    = array();
		if (isset($_POST['product_ids']) ) {
			$product_ids = $post_data['product_ids'];
			$product_quantites = $post_data['product_quantites'];
		} else {
			$product_ids = array();
			$product_quantites = array();
		}
		if ($product_ids && $product_quantites ) {

			// compatible with product quantity
			/**
			 * Filter wc_bulk_validation
			 * 
			 * @since 1.5.1
			**/
			$passed_validation = apply_filters('wc_bulk_validation', true, $product_ids, $formData);

			if (!$passed_validation ) {
				wp_send_json( array( 'fail' => 'failed' ) );
			}

			foreach ( $formData as $product_id => $data ) {
				 // ✅ Check if this is grouped product data
				if ( 'grouped' === $product_id ) {
					foreach ( $data as $grouped_id => $grouped_qty_string ) {
						// Extract quantity from string like "quantity=1"
						parse_str( $grouped_qty_string, $parsed_grouped );

						$grouped_qty = isset($parsed_grouped['quantity']) ? (int) $parsed_grouped['quantity'] : 0;

						if ( $grouped_qty > 0 ) {
							WC()->cart->add_to_cart( $grouped_id, $grouped_qty );
							$added_products[] = '"' . get_the_title($grouped_id) . '"';
						}
					}
					continue; // Skip rest of the loop for 'grouped'
				}
				$cart_item_data = array(); 
				$variations_data = array();

				foreach ($data as $key => $value) {


					if ($product && 'variation' === $product->get_type() ) {
						if (isset($post_data['nyp_data'][$variation_id]) ) {
							$cart_item_data = $this->cart_item_data_generate($variation_id, $post_data);
							if (empty($cart_item_data) ) {
								continue;
							}
						}
					} elseif (isset($post_data['nyp_data'][$product_id])) {

						$cart_item_data = $this->cart_item_data_generate($product_id, $post_data);
						if (empty($cart_item_data) ) {
							continue;
						}

					}

					// Check if $key is a valid non-empty string before using strpos
					if (is_string($key) && !empty($key) && strpos($key, 'attribute_') === 0) {
						$attribute_name = $key; // or substr($key, 10) to remove 'attribute_' prefix
						$variations_data[$attribute_name] = $value;
					}
				}
				$data['attributes'] = $variations_data;

				// compatible with inventory plugin
				if ( isset( $data['product_inventory'] ) && ! empty( $data['product_inventory'] ) ) {
					$product = wc_get_product( $product_id );
					$inventories= $product->get_meta( '_ifw_multi_inventory' );
					$cart_item_data['inventory_index'] = $data['product_inventory'];
				}
				if (WC()->cart->add_to_cart($product_id, $data['quantity'], $data['variation_id'], $data['attributes'], $cart_item_data)) {
					$added_products[] = '"' . get_the_title($product_id) . '"';

				}

			}
		}

		if ($added_products ) {

			$added_products = implode(' And ', $added_products);
			// translators: Added Product.
			$added_products = '<p class="wcpt-added-products">' . sprintf(__('%s Added to cart', 'woocommerce-wholesale-pricing'), $added_products) . '</p>';

		}
			WC()->session->set('wcpt_added_products', $added_products);


		// Return fragments.
			WC()->cart->calculate_totals();
			WC()->cart->set_session();
			\WC_AJAX::get_refreshed_fragments();
			wp_die();
	}


	public function cart_item_data_generate( $product_id, $post_data ) {

		if (isset($post_data['nyp_data'][$product_id])) {

			$nyp_price = $post_data['nyp_data'][$product_id];
			$min_price = get_post_meta($product_id, '_min_price', true);
			$maximum_price = get_post_meta($product_id, '_maximum_price', true);                        

			if (!empty($min_price) && !empty($maximum_price) ) {
				if ($nyp_price >= $min_price &&  $nyp_price <= $maximum_price  ) {
					return array( 'nyp' =>  $nyp_price );
				}
			} elseif (!empty($min_price)) {
				if ($nyp_price >= $min_price ) {
					return array( 'nyp' =>  $nyp_price );
				}  
			} elseif (!empty($maximum_price)) {
				if ($nyp_price <= $maximum_price  ) {
					return array( 'nyp' =>  $nyp_price );
				}
			} else {
				return array( 'nyp' => $nyp_price );
			}
		}
	}

	/**
	 * Set names of the products that added to cart
	 *
	 * @param  array $fragments array of fragments.
	 * @return array $fragments
	 */
	public function wcpt_set_title_products_added_cart( $fragments ) {
		if (WC()->session && WC()->session->get('wcpt_added_products') ) {
			$fragments['wcpt_added_products'] = WC()->session->get('wcpt_added_products');
			WC()->session->__unset('wcpt_added_products');
		}
		return $fragments;
	}

	public static function resolveDependency() {
		return is_product_table_enabled();
	}
}
