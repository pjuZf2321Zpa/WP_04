<?php

namespace WooCommerceWholesalePricing\App\Services\ProductTable;

use Automattic\WooCommerce\Blocks\Package;
use WooCommerceWholesalePricing\App\Strategies\Init;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

class GutenbergBlockService extends Init implements ServiceInterface {

	/**
	/**
	 * Constructor.
	 *
	 * Initializes the service by calling the parent constructor.
	 *
	 * @return void
	 */
	public function __construct() {
		parent::__construct();
	}

	public function register() {
		$wcpt_tables = $this->wcpt_all_tables();
		$tables = array();
		$count = 1;
		$tables[0]['value'] = '';
		$tables[0]['label'] = esc_html__('--Select Product Table--', 'wcpt');
		foreach ($wcpt_tables as $table) {
			$tables[$count]['value'] = $table->ID;
			$tables[$count]['label'] = $table->post_title;
			$count++;
		}
	
		$post_tables = array(
			'product_tables' => $tables,
		);
	
	
		wp_register_script('wcpt_product_table_block_register_script', WWP_PLUGIN_URL . 'build/product-table/product-table.js', array( 'wp-blocks', 'wp-element', 'wp-editor', 'wp-components' ), WWP_VERSION );
	
		wp_localize_script('wcpt_product_table_block_register_script', 'wcpt_gutenberg', $post_tables);
	
	
		$args = array(
			'editor_script' => 'wcpt_product_table_block_register_script',
			'render_callback' => array( $this, 'wcpt_product_table_callback' ),
		);
		
		if ( ! \WP_Block_Type_Registry::get_instance()->is_registered( 'product-table/wcpt-product-table' ) ) {
			register_block_type( 'product-table/wcpt-product-table', $args );
		}
	}

	public function wcpt_product_table_callback( $atts ) {
		return ProductTableService::wc_products_table( $atts );
	}


	public function wcpt_all_tables() {
		$args = array(
		   'post_type' => 'wcpt',
		   'numberposts' => -1,
		   'orderby' => 'title',
		   'order' => 'ASC',
		);
	
		$wcpt_tables = get_posts($args);
	return $wcpt_tables;
	}

	public function loaded() {
	}

	public static function resolveDependency() {
		return is_product_table_enabled();
	}
}
