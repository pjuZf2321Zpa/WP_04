<?php

namespace WooCommerceWholesalePricing\App\Services\ProductTable;

use Exception;
use WC_Data_Store;

/**
 * Session-backed form cart for Quick Order Form.
 */
class QuickOrderProcess {

	/**
	 * Contains an array of form items.
	 *
	 * @var array
	 */
	public $form_contents = array();

	/**
	 * Constructor. Loads form contents from session when needed.
	 *
	 * @param array $form_contents_arr Existing form contents.
	 * @param int   $form_id           Quick order form post ID.
	 */
	public function __construct( $form_contents_arr = array(), $form_id = 0 ) {
		$this->form_contents = $form_contents_arr;

		if ( empty( $this->form_contents ) && isset( WC()->session ) && 0 !== $form_id ) {
			$this->form_contents = (array) WC()->session->get( 'wc_quick_order_' . $form_id );
		}
	}

	/**
	 * Whether a variation may be ordered for this form.
	 *
	 * @param int $variation_id Variation ID.
	 * @param int $form_id      Form post ID.
	 * @return bool
	 */
	public function check_product_availability_for_variation( $variation_id, $form_id ) {
		if ( empty( $variation_id ) ) {
			return true;
		}

		$variation    = wc_get_product( $variation_id );
		$stock_status = get_post_meta( $form_id, 'wcpt_product_status', true );

		if ( $variation && ! $variation->is_in_stock() && 'instock' === $stock_status ) {
			return false;
		}

		return true;
	}

	/**
	 * Add a product to the form session.
	 *
	 * @param array $form_data       Posted form data.
	 * @param int   $form_id         Form post ID.
	 * @param int   $product_id      Product ID.
	 * @param int   $quantity        Quantity.
	 * @param int   $variation_id    Variation ID.
	 * @param array $variation       Variation attributes.
	 * @param array $form_item_data  Extra item data.
	 * @param bool  $return_contents Whether to return contents instead of saving session.
	 * @return string|bool|array
	 */
	public function add_to_form( $form_data = array(), $form_id = 0, $product_id = 0, $quantity = 1, $variation_id = 0, $variation = array(), $form_item_data = array(), $return_contents = false ) {
		try {
			$product_id   = absint( $product_id );
			$variation_id = absint( $product_id );

			$product_data = wc_get_product( $variation_id ? $variation_id : $product_id );
			$quantity     = apply_filters( 'wc_quick_order_quantity', $quantity, $product_id );

			if ( $quantity <= 0 || ! $product_data || 'trash' === $product_data->get_status() ) {
				return false;
			}

			if ( $product_data->is_type( 'variation' ) ) {
				$missing_attributes = array();
				$parent_data        = wc_get_product( $product_data->get_parent_id() );

				$variation_attributes = array_filter( $product_data->get_variation_attributes() );

				$posted_attributes = array();
				foreach ( $parent_data->get_attributes() as $attribute ) {
					if ( ! $attribute['is_variation'] ) {
						continue;
					}
					$attribute_key = 'attribute_' . sanitize_title( $attribute['name'] );

					if ( isset( $variation[ $attribute_key ] ) ) {
						if ( $attribute['is_taxonomy'] ) {
							$value = sanitize_title( wp_unslash( $variation[ $attribute_key ] ) );
						} else {
							$value = html_entity_decode( wc_clean( wp_unslash( $variation[ $attribute_key ] ) ), ENT_QUOTES, get_bloginfo( 'charset' ) );
						}

						if ( ! empty( $value ) || '0' === $value ) {
							$posted_attributes[ $attribute_key ] = $value;
						}
					}
				}

				$posted_and_variation_attributes = array_merge( $variation_attributes, $posted_attributes );

				if ( empty( $variation_id ) ) {
					$data_store   = WC_Data_Store::load( 'product' );
					$variation_id = $data_store->find_matching_product_variation( $parent_data, $posted_attributes );
				}

				if ( empty( $variation_id ) ) {
					throw new Exception( __( 'Please choose product options&hellip;', 'woocommerce-wholesale-pricing' ) );
				}

				if ( ! $this->check_product_availability_for_variation( $variation_id, $form_id ) ) {
					throw new Exception( __( 'Order is not permitted for selected variation &hellip;', 'woocommerce-wholesale-pricing' ) );
				}

				$variation_data = wc_get_product_variation_attributes( $variation_id );
				$attributes     = array();

				foreach ( $parent_data->get_attributes() as $attribute ) {
					if ( ! $attribute['is_variation'] ) {
						continue;
					}

					$attribute_key = 'attribute_' . sanitize_title( $attribute['name'] );
					$valid_value   = isset( $variation_data[ $attribute_key ] ) ? $variation_data[ $attribute_key ] : '';

					if ( isset( $posted_and_variation_attributes[ $attribute_key ] ) ) {
						$value = $posted_and_variation_attributes[ $attribute_key ];

						if ( $valid_value === $value ) {
							$attributes[ $attribute_key ] = $value;
						} elseif ( '' === $valid_value && in_array( $value, $attribute->get_slugs(), true ) ) {
							$attributes[ $attribute_key ] = $value;
						} else {
							/* translators: %s: Attribute name. */
							throw new Exception( sprintf( __( 'Invalid value posted for %s', 'woocommerce-wholesale-pricing' ), wc_attribute_label( $attribute['name'] ) ) );
						}
					} elseif ( '' === $valid_value ) {
						$missing_attributes[] = wc_attribute_label( $attribute['name'] );
					}

					$variation = $attributes;
				}

				if ( ! empty( $missing_attributes ) && ! is_admin() ) {
					/* translators: %s: Attribute name. */
					throw new Exception( sprintf( _n( '%s is a required field', '%s are required fields', count( $missing_attributes ), 'woocommerce-wholesale-pricing' ), wc_format_list_of_items( $missing_attributes ) ) );
				}
			}

			$form_item_data = (array) apply_filters( 'wc_quick_order_add_item_data', $form_item_data, $product_id, $variation_id, $quantity, $form_data );
			$row_id         = $this->generate_row_id( $product_id, $variation_id, $variation, $form_item_data );
			$form_item_key  = $this->find_product_in_form( $row_id );

			if ( $product_data->is_sold_individually() ) {
				$quantity      = apply_filters( 'wc_quick_order_sold_individually_quantity', 1, $quantity, $product_id, $variation_id, $form_item_data );
				$found_in_form = apply_filters( 'wc_quick_order_sold_individually_found_in_form', $form_item_key && $this->form_contents[ $form_item_key ]['quantity'] > 0, $product_id, $variation_id, $form_item_data, $row_id );

				if ( $found_in_form ) {
					/* translators: %s: product name */
					$message = sprintf( __( 'You cannot add another "%s" to your form.', 'woocommerce-wholesale-pricing' ), $product_data->get_name() );
					$message = apply_filters( 'wc_quick_order_cannot_add_another_message', $message, $product_data );
					throw new Exception( $message );
				}
			}

			if ( ! $product_data->is_purchasable() ) {
				$message = __( 'Sorry, this product cannot be purchased.', 'woocommerce-wholesale-pricing' );
				$message = apply_filters( 'wc_quick_order_cannot_be_purchased_message', $message, $product_data );
				throw new Exception( $message );
			}

			if ( ! empty( $form_item_key ) ) {
				$this->form_contents[ $form_item_key ]['quantity'] += intval( $quantity );
			} else {
				$form_item_key = $row_id;

				$this->form_contents[ $form_item_key ] = apply_filters(
					'wc_quick_order_add_item',
					array_merge(
						$form_item_data,
						array(
							'key'          => $form_item_key,
							'product_id'   => $product_id,
							'variation_id' => $variation_id,
							'variation'    => $variation,
							'quantity'     => $quantity,
							'data'         => $product_data,
							'data_hash'    => wc_get_cart_item_data_hash( $product_data ),
						)
					),
					$form_item_key
				);
			}

			$this->form_contents = apply_filters( 'wc_quick_order_form_contents_changed', $this->form_contents );

			if ( $return_contents ) {
				return $this->form_contents;
			}

			if ( ! WC()->session->has_session() ) {
				WC()->session->set_customer_session_cookie( true );
			}

			WC()->session->set( 'wc_quick_order_' . $form_id, $this->form_contents );
			do_action( 'wc_quick_order_session_changed' );
			do_action( 'wc_quick_order_add_to_form', $form_item_key, $product_id, $quantity, $variation_id, $variation, $form_item_data );

			return $form_item_key;
		} catch ( Exception $e ) {
			if ( $e->getMessage() && ! is_admin() ) {
				wc_add_notice( $e->getMessage(), 'error' );
			}
			return false;
		}
	}

	/**
	 * Generate a unique ID for the form item being added.
	 *
	 * @param int   $product_id    Product ID.
	 * @param int   $variation_id  Variation ID.
	 * @param array $variation     Variation attributes.
	 * @param array $form_item_data Extra item data.
	 * @return string
	 */
	public function generate_row_id( $product_id, $variation_id = 0, $variation = array(), $form_item_data = array() ) {
		$id_parts = array( $product_id );

		if ( $variation_id && 0 !== $variation_id ) {
			$id_parts[] = $variation_id;
		}

		if ( is_array( $variation ) && ! empty( $variation ) ) {
			$variation_key = '';
			foreach ( $variation as $key => $value ) {
				$variation_key .= trim( $key ) . trim( $value );
			}
			$id_parts[] = $variation_key;
		}

		if ( is_array( $form_item_data ) && ! empty( $form_item_data ) ) {
			$form_item_data_key = '';
			foreach ( $form_item_data as $key => $value ) {
				if ( is_array( $value ) || is_object( $value ) ) {
					$value = http_build_query( $value );
				}
				$form_item_data_key .= trim( $key ) . trim( $value );
			}
			$id_parts[] = $form_item_data_key;
		}

		return apply_filters( 'wc_quick_order_row_id', md5( implode( '_', $id_parts ) ), $product_id, $variation_id, $variation, $form_item_data );
	}

	/**
	 * Find product in form by row ID.
	 *
	 * @param mixed $row_id Row ID.
	 * @return string
	 */
	public function find_product_in_form( $row_id = false ) {
		if ( false !== $row_id && is_array( $this->form_contents ) && isset( $this->form_contents[ $row_id ] ) ) {
			return $row_id;
		}
		return '';
	}

	/**
	 * Remove an item from the form contents array.
	 *
	 * @param string $form_item_key Item key.
	 * @return bool
	 */
	public function remove_form_item( $form_item_key ) {
		if ( isset( $this->form_contents[ $form_item_key ] ) ) {
			do_action( 'wc_quick_order_remove_form_item', $form_item_key, $this );
			unset( $this->form_contents[ $form_item_key ] );
			do_action( 'wc_quick_order_item_removed', $form_item_key, $this );
			return true;
		}
		return false;
	}
}
