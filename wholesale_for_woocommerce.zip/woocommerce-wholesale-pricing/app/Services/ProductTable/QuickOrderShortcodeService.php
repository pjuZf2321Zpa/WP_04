<?php

namespace WooCommerceWholesalePricing\App\Services\ProductTable;

use WooCommerceWholesalePricing\App\Modules\ProductTable\Traits\Fields;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;
use WC_Data_Store;

/**
 * Frontend shortcode and AJAX for Quick Order Form.
 */
class QuickOrderShortcodeService implements ServiceInterface {

	use Fields;

	public function __construct() {
		add_shortcode( 'wc_quick_order', array( $this, 'render_shortcode' ) );

		add_action( 'wp_ajax_wc_quick_order_add', array( $this, 'wc_quick_order_add' ) );
		add_action( 'wp_ajax_nopriv_wc_quick_order_add', array( $this, 'wc_quick_order_add' ) );

		add_action( 'wp_ajax_wc_quick_order_update', array( $this, 'wc_quick_order_update' ) );
		add_action( 'wp_ajax_nopriv_wc_quick_order_update', array( $this, 'wc_quick_order_update' ) );

		add_action( 'wp_ajax_wc_quick_order_update_items', array( $this, 'wc_quick_order_update_items' ) );
		add_action( 'wp_ajax_nopriv_wc_quick_order_update_items', array( $this, 'wc_quick_order_update_items' ) );

		add_action( 'wp_ajax_wc_quick_order_remove_item', array( $this, 'wc_quick_order_remove_item' ) );
		add_action( 'wp_ajax_nopriv_wc_quick_order_remove_item', array( $this, 'wc_quick_order_remove_item' ) );

		add_action( 'wp_ajax_wc_quick_order_add_to_cart', array( $this, 'wc_quick_order_add_to_cart' ) );
		add_action( 'wp_ajax_nopriv_wc_quick_order_add_to_cart', array( $this, 'wc_quick_order_add_to_cart' ) );

		add_action( 'wp_ajax_woocommerce_json_search_products_and_variations', array( $this, 'wc_quick_order_search_nopriv' ), 99 );
		add_action( 'wp_ajax_nopriv_woocommerce_json_search_products_and_variations', array( $this, 'wc_quick_order_search_nopriv' ), 99 );
	}

	/**
	 * Locate and include a quick order template (theme override supported).
	 *
	 * @param string $template_name Template filename.
	 * @param array  $args          Template vars.
	 * @return void
	 */
	public static function get_template( $template_name, $args = array() ) {
		if ( ! empty( $args ) && is_array( $args ) ) {
			extract( $args, EXTR_SKIP ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract
		}

		$template_name = basename( (string) $template_name );
		$theme_path    = get_stylesheet_directory() . '/woocommerce/bulkorder/templates/' . $template_name;
		$plugin_path   = WWP_PLUGIN_PATH . 'resources/views/product-table/' . $template_name;

		if ( file_exists( $theme_path ) ) {
			include $theme_path; // nosemgrep: audit.php.lang.security.file.inclusion-arg
			return;
		}

		if ( file_exists( $plugin_path ) ) {
			include $plugin_path; // nosemgrep: audit.php.lang.security.file.inclusion-arg
		}
	}

	/**
	 * Render table HTML for AJAX responses.
	 *
	 * @param int $quick_order_id Form post ID.
	 * @return string
	 */
	private function render_form_table( $quick_order_id ) {
		$quick_order_fields = self::get_product_table_fields( $quick_order_id );
		$product_ids        = $this->get_product_ids_csv( $quick_order_id );

		ob_start();
		self::get_template(
			'quick-order-table.php',
			compact( 'quick_order_id', 'quick_order_fields', 'product_ids' )
		);
		return ob_get_clean();
	}

	/**
	 * Build include product ID CSV for Select2.
	 *
	 * @param int $quick_order_id Form post ID.
	 * @return string
	 */
	private function get_product_ids_csv( $quick_order_id ) {
		$cat_ids            = get_post_meta( $quick_order_id, 'wcpt_inc_product_cats', true );
		$stock_status       = get_post_meta( $quick_order_id, 'wcpt_product_status', true );
		$meta_product_query = array();
		$tax_product_query  = array();
		$product_ids        = array();

		if ( $stock_status ) {
			$meta_product_query = array(
				array(
					'key'   => '_stock_status',
					'value' => $stock_status,
				),
			);
		}
		if ( $cat_ids ) {
			$tax_product_query = array(
				array(
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => $cat_ids,
					'operator' => 'IN',
				),
			);
		}

		$all_ids = get_posts(
			array(
				'post_type'      => array( 'product' ),
				'posts_per_page' => -1,
				'post_status'    => 'publish',
				'fields'         => 'ids',
				'tax_query'      => $tax_product_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				'meta_query'     => $meta_product_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
			)
		);

		foreach ( $all_ids as $product_id ) {
			$product = wc_get_product( $product_id );
			if ( ! $product ) {
				continue;
			}
			if ( 'variable' === $product->get_type() ) {
				$variations    = $product->get_available_variations();
				$variations_id = wp_list_pluck( $variations, 'variation_id' );
				$product_ids   = array_merge( $product_ids, $variations_id );
			} else {
				$product_ids[] = $product_id;
			}
		}

		$csv = implode( ',', $product_ids );
		return empty( $csv ) ? '0' : $csv;
	}

	/**
	 * Guest / logged-in product search override.
	 *
	 * @return void
	 */
	public function wc_quick_order_search_nopriv() {
		$this->json_search_products( '', true );
	}

	/**
	 * JSON product search (supports guests).
	 *
	 * @param string $term               Search term.
	 * @param bool   $include_variations Include variations.
	 * @return void
	 */
	public function json_search_products( $term = '', $include_variations = false ) {
		check_ajax_referer( 'search-products', 'security' );

		if ( empty( $term ) && isset( $_GET['term'] ) ) {
			$term = (string) wc_clean( wp_unslash( $_GET['term'] ) );
		}

		if ( empty( $term ) ) {
			wp_die();
		}

		$limit = ! empty( $_GET['limit'] ) ? absint( $_GET['limit'] ) : absint( apply_filters( 'woocommerce_json_search_limit', 30 ) );

		$include_ids = ! empty( $_GET['include'] ) ? array_map( 'absint', (array) wp_unslash( $_GET['include'] ) ) : array();
		$exclude_ids = ! empty( $_GET['exclude'] ) ? array_map( 'absint', (array) wp_unslash( $_GET['exclude'] ) ) : array();

		$exclude_types = array();
		if ( ! empty( $_GET['exclude_type'] ) ) {
			$exclude_types = wp_unslash( $_GET['exclude_type'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			if ( ! is_array( $exclude_types ) ) {
				$exclude_types = explode( ',', $exclude_types );
			}
			foreach ( $exclude_types as &$exclude_type ) {
				$exclude_type = strtolower( trim( $exclude_type ) );
			}
			$exclude_types = array_intersect(
				array_merge( array( 'variation' ), array_keys( wc_get_product_types() ) ),
				$exclude_types
			);
		}

		$data_store = WC_Data_Store::load( 'product' );
		$ids        = $data_store->search_products( $term, '', (bool) $include_variations, false, $limit, $include_ids, $exclude_ids );

		$products = array();
		foreach ( $ids as $id ) {
			$product_object = wc_get_product( $id );
			if ( ! is_a( $product_object, 'WC_Product' ) ) {
				continue;
			}
			if ( in_array( $product_object->get_type(), $exclude_types, true ) ) {
				continue;
			}

			$formatted_name = $product_object->get_formatted_name();
			if ( $product_object->managing_stock() && ! empty( $_GET['display_stock'] ) ) {
				$stock_amount    = $product_object->get_stock_quantity();
				$formatted_name .= ' &ndash; ' . sprintf(
					/* translators: %d stock amount */
					__( 'Stock: %d', 'woocommerce' ),
					wc_format_stock_quantity_for_display( $stock_amount, $product_object )
				);
			}

			$products[ $product_object->get_id() ] = rawurldecode( wp_strip_all_tags( $formatted_name ) );
		}

		wp_send_json( apply_filters( 'woocommerce_json_search_found_products', $products ) );
	}

	/**
	 * Rename array key helper.
	 *
	 * @param array  $array   Source array.
	 * @param string $old_key Old key.
	 * @param string $new_key New key.
	 * @return array
	 */
	private function change_key( $array, $old_key, $new_key ) {
		if ( ! array_key_exists( $old_key, $array ) ) {
			return $array;
		}

		$keys                                 = array_keys( $array );
		$keys[ array_search( $old_key, $keys, true ) ] = $new_key;

		return array_combine( $keys, $array );
	}

	/**
	 * Verify AJAX nonce or die.
	 *
	 * @return void
	 */
	private function verify_ajax_nonce() {
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'search-products' ) ) {
			die( 'Failed ajax security check!' );
		}
	}

	/**
	 * AJAX: add product to form.
	 *
	 * @return void
	 */
	public function wc_quick_order_add() {
		$this->verify_ajax_nonce();

		$form_data      = isset( $_POST ) ? map_deep( wp_unslash( $_POST ), 'sanitize_text_field' ) : array();
		$product_id     = isset( $form_data['product_id'] ) ? intval( $form_data['product_id'] ) : 0;
		$quantity       = isset( $form_data['quantity'] ) ? intval( $form_data['quantity'] ) : 1;
		$quick_order_id = isset( $form_data['form_id'] ) ? intval( $form_data['form_id'] ) : 0;

		$wc_quick_order    = new QuickOrderProcess( array(), $quick_order_id );
		$passed_validation = apply_filters( 'wc_quick_order_form_validation', true, $product_id, $quantity, $form_data );

		if ( ! $passed_validation ) {
			echo 'failed';
			die();
		}

		$form_item_key = $wc_quick_order->add_to_form( $form_data, $quick_order_id, $product_id, $quantity );
		$form_contents = WC()->session->get( 'wc_quick_order_' . $quick_order_id );
		$product_name  = __( 'Product', 'woocommerce-wholesale-pricing' );

		if ( isset( $form_contents[ $form_item_key ]['data'] ) && is_object( $form_contents[ $form_item_key ]['data'] ) ) {
			$product_name = $form_contents[ $form_item_key ]['data']->get_name();
		}

		$form_table = $this->render_form_table( $quick_order_id );

		if ( false === $form_item_key ) {
			/* translators: %s: Product name */
			wc_add_notice( sprintf( __( '“%s” cannot be added.', 'woocommerce-wholesale-pricing' ), $product_name ), 'error' );
			echo 'success';
		} else {
			wp_send_json(
				array(
					'form_empty' => empty( WC()->session->get( 'wc_quick_order_' . $quick_order_id ) ),
					'form-table' => $form_table,
				)
			);
		}
		die();
	}

	/**
	 * AJAX: update product on a row.
	 *
	 * @return void
	 */
	public function wc_quick_order_update() {
		$this->verify_ajax_nonce();

		$form_data      = isset( $_POST ) ? map_deep( wp_unslash( $_POST ), 'sanitize_text_field' ) : array();
		$product_id     = isset( $form_data['product_id'] ) ? intval( $form_data['product_id'] ) : 0;
		$quantity       = isset( $form_data['quantity'] ) ? intval( $form_data['quantity'] ) : 1;
		$quick_order_id = isset( $form_data['form_id'] ) ? intval( $form_data['form_id'] ) : 0;
		$item_key       = isset( $_POST['form_key'] ) ? sanitize_text_field( wp_unslash( $_POST['form_key'] ) ) : '';

		$wc_quick_order    = new QuickOrderProcess( array(), $quick_order_id );
		$passed_validation = apply_filters( 'wc_quick_order_form_validation', true, $product_id, $quantity, $form_data );

		if ( ! $passed_validation ) {
			echo 'failed';
			die();
		}

		$form_item_key = $wc_quick_order->add_to_form( $form_data, $quick_order_id, $product_id, $quantity );
		$form_contents = WC()->session->get( 'wc_quick_order_' . $quick_order_id );

		if ( isset( $form_contents[ $form_item_key ] ) && $item_key ) {
			$form_contents[ $item_key ] = $form_contents[ $form_item_key ];
			$form_contents              = $this->change_key( $form_contents, $item_key, $form_item_key );
			WC()->session->set(
				'wc_quick_order_' . $quick_order_id,
				array_filter(
					$form_contents,
					function ( $value ) {
						return ! empty( $value );
					}
				)
			);
		}

		$form_table = $this->render_form_table( $quick_order_id );

		if ( false === $form_item_key ) {
			echo 'success';
		} else {
			wp_send_json(
				array(
					'form_empty' => empty( WC()->session->get( 'wc_quick_order_' . $quick_order_id ) ),
					'form-table' => $form_table,
				)
			);
		}
		die();
	}

	/**
	 * AJAX: update row quantity.
	 *
	 * @return void
	 */
	public function wc_quick_order_update_items() {
		$this->verify_ajax_nonce();

		$form_data      = isset( $_POST ) ? map_deep( wp_unslash( $_POST ), 'sanitize_text_field' ) : array();
		$quantity       = isset( $form_data['quantity'] ) ? intval( $form_data['quantity'] ) : 1;
		$quick_order_id = isset( $form_data['form_id'] ) ? intval( $form_data['form_id'] ) : 0;
		$item_key       = isset( $form_data['form_key'] ) ? sanitize_text_field( $form_data['form_key'] ) : '';
		$contents       = WC()->session->get( 'wc_quick_order_' . $quick_order_id );

		if ( ! is_array( $contents ) ) {
			$contents = array();
		}

		if ( 0 === $quantity || empty( $quantity ) ) {
			unset( $contents[ $item_key ] );
		} else {
			$contents[ $item_key ]['quantity'] = intval( $quantity );
		}

		WC()->session->set(
			'wc_quick_order_' . $quick_order_id,
			array_filter(
				$contents,
				function ( $value ) {
					return ! empty( $value );
				}
			)
		);

		do_action( 'wc_quick_order_session_changed' );

		wp_send_json(
			array(
				'form_empty' => empty( WC()->session->get( 'wc_quick_order_' . $quick_order_id ) ),
			)
		);
		die();
	}

	/**
	 * AJAX: remove item from form.
	 *
	 * @return void
	 */
	public function wc_quick_order_remove_item() {
		$this->verify_ajax_nonce();

		$form_key       = isset( $_POST['form_key'] ) ? sanitize_text_field( wp_unslash( $_POST['form_key'] ) ) : '';
		$quick_order_id = isset( $_POST['form_id'] ) ? intval( $_POST['form_id'] ) : 0;

		if ( empty( $form_key ) ) {
			die( 'Form key is empty' );
		}

		$contents = WC()->session->get( 'wc_quick_order_' . $quick_order_id );
		if ( ! is_array( $contents ) ) {
			$contents = array();
		}

		$product = isset( $contents[ $form_key ]['data'] ) ? $contents[ $form_key ]['data'] : null;
		unset( $contents[ $form_key ] );

		WC()->session->set( 'wc_quick_order_' . $quick_order_id, $contents );
		do_action( 'wc_quick_order_session_changed' );
		do_action( 'wc_quick_order_item_removed', $form_key, $product );

		wp_send_json(
			array(
				'form_empty' => empty( WC()->session->get( 'wc_quick_order_' . $quick_order_id ) ),
				'form-table' => $this->render_form_table( $quick_order_id ),
			)
		);
		die();
	}

	/**
	 * AJAX: push form session items into WooCommerce cart.
	 *
	 * @return void
	 */
	public function wc_quick_order_add_to_cart() {
		$this->verify_ajax_nonce();

		$quick_order_id = isset( $_POST['form_id'] ) ? intval( $_POST['form_id'] ) : 0;
		$items          = WC()->session->get( 'wc_quick_order_' . $quick_order_id );

		if ( ! is_array( $items ) ) {
			$items = array();
		}

		foreach ( $items as $item => $form_data ) {
			$product_id   = isset( $form_data['product_id'] ) ? intval( $form_data['product_id'] ) : 0;
			$quantity     = isset( $form_data['quantity'] ) ? intval( $form_data['quantity'] ) : 1;
			$variation_id = isset( $form_data['variation_id'] ) && $product_id !== (int) $form_data['variation_id'] ? intval( $form_data['variation_id'] ) : 0;
			$variation    = isset( $form_data['variation'] ) ? $form_data['variation'] : array();

			$passed_validation = apply_filters( 'wc_quick_order_add_to_cart_validation', true, $product_id, $quantity, $form_data );
			if ( ! $passed_validation ) {
				echo 'failed';
				die();
			}

			$product_cart_id = WC()->cart->generate_cart_id( $product_id, $variation_id, $variation );
			$cart_item_key   = WC()->cart->find_product_in_cart( $product_cart_id );
			if ( $cart_item_key ) {
				WC()->cart->remove_cart_item( $cart_item_key );
			}

			$cart_item_key = WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variation );
			$product_name  = __( 'Product', 'woocommerce-wholesale-pricing' );
			$cart_contents = WC()->cart->get_cart();

			if ( isset( $cart_contents[ $cart_item_key ]['data'] ) && is_object( $cart_contents[ $cart_item_key ]['data'] ) ) {
				$product_name = $cart_contents[ $cart_item_key ]['data']->get_name();
			}

			if ( false === $cart_item_key ) {
				/* translators: %s: Product name */
				wc_add_notice( sprintf( __( '“%s” has not been added to your cart.', 'woocommerce-wholesale-pricing' ), $product_name ), 'error' );
			} else {
				unset( $items[ $item ] );
				WC()->session->set( 'wc_quick_order_' . $quick_order_id, $items );
				/* translators: %s: Product name */
				wc_add_notice( sprintf( __( '“%s” has been added to your cart.', 'woocommerce-wholesale-pricing' ), $product_name ), 'success' );
			}
		}

		echo 'success';
		die();
	}

	/**
	 * Shortcode callback: [wc_quick_order id=X]
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function render_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'id' => '',
			),
			$atts,
			'wc_quick_order'
		);

		$post_id = absint( $atts['id'] );
		if ( ! $post_id ) {
			return '';
		}

		if ( ! TableTypeHelper::is_quick_order_form( $post_id ) ) {
			return '';
		}

		$post_status    = get_post_status( $post_id );
		$selected_roles = get_post_meta( $post_id, '_wcpt_table_user_role_restriction', true );
		$selected_users = get_post_meta( $post_id, '_wcpt_table_user_restriction', true );

		if ( ! is_array( $selected_roles ) ) {
			$selected_roles = array();
		}
		if ( ! is_array( $selected_users ) ) {
			$selected_users = array();
		}

		$show_table = false;

		if ( in_array( 'Guest', $selected_roles, true ) && ! is_user_logged_in() ) {
			$show_table = true;
		}

		if ( empty( array_filter( $selected_roles ) ) && empty( array_filter( $selected_users ) ) ) {
			$show_table = true;
		}

		if ( is_user_logged_in() ) {
			$current_user       = wp_get_current_user();
			$current_user_role  = isset( $current_user->roles[0] ) ? $current_user->roles[0] : '';
			$current_user_id    = $current_user->ID;

			if ( in_array( $current_user_role, $selected_roles, true ) || in_array( $current_user_id, $selected_users, false ) ) {
				$show_table = true;
			}

			if ( in_array( 'all', $selected_roles, true ) || in_array( 'all', $selected_users, true ) ) {
				$show_table = true;
			}
		}

		if ( false === $show_table || 'publish' !== $post_status ) {
			return '';
		}

		if ( in_array( get_post_status( $post_id ), array( 'trash', false ), true ) ) {
			return '';
		}

		$this->enqueue_assets();

		$quick_order_id     = $post_id;
		$quick_order_fields = self::get_product_table_fields( $quick_order_id );

		ob_start();
		self::get_template( 'quick-order-page.php', compact( 'quick_order_id', 'quick_order_fields' ) );
		return ob_get_clean();
	}

	/**
	 * Enqueue frontend assets for product search.
	 *
	 * @return void
	 */
	private function enqueue_assets() {
		wp_enqueue_script( 'selectWoo' );
		wp_enqueue_style( 'wcpt_single_product' );

		wp_register_script(
			'wc-enhanced-select',
			WC()->plugin_url() . '/assets/js/admin/wc-enhanced-select.js',
			array( 'jquery', 'selectWoo' ),
			WWP_VERSION,
			true
		);

		wp_localize_script(
			'wc-enhanced-select',
			'wc_enhanced_select_params',
			array(
				'i18n_no_matches'           => _x( 'No matches found', 'enhanced select', 'woocommerce' ),
				'i18n_ajax_error'           => _x( 'Loading failed', 'enhanced select', 'woocommerce' ),
				'i18n_input_too_short_1'    => _x( 'Please enter 1 or more characters', 'enhanced select', 'woocommerce' ),
				'i18n_input_too_short_n'    => _x( 'Please enter %qty% or more characters', 'enhanced select', 'woocommerce' ),
				'i18n_input_too_long_1'     => _x( 'Please delete 1 character', 'enhanced select', 'woocommerce' ),
				'i18n_input_too_long_n'     => _x( 'Please delete %qty% characters', 'enhanced select', 'woocommerce' ),
				'i18n_selection_too_long_1' => _x( 'You can only select 1 item', 'enhanced select', 'woocommerce' ),
				'i18n_selection_too_long_n' => _x( 'You can only select %qty% items', 'enhanced select', 'woocommerce' ),
				'i18n_load_more'            => _x( 'Loading more results&hellip;', 'enhanced select', 'woocommerce' ),
				'i18n_searching'            => _x( 'Searching&hellip;', 'enhanced select', 'woocommerce' ),
				'ajax_url'                  => admin_url( 'admin-ajax.php' ),
				'search_products_nonce'     => wp_create_nonce( 'search-products' ),
				'search_customers_nonce'    => wp_create_nonce( 'search-customers' ),
				'search_categories_nonce'   => wp_create_nonce( 'search-categories' ),
				'search_pages_nonce'        => wp_create_nonce( 'search-pages' ),
			)
		);

		wp_register_style( 'woocommerce_admin_styles', WC()->plugin_url() . '/assets/css/admin.css', array(), WC_VERSION );
		wp_enqueue_script( 'wc-enhanced-select' );
		wp_enqueue_style( 'woocommerce_admin_styles' );

		$extra_css = '.select2-container .select2-search__field{min-width:auto !important;}td.product-name {position: relative;}table.wc-quick-order__contents tr .product-name{width:200px;}table.wc-quick-order__contents tr .product-remove{width:30px;}#order_actions a.wc_quick_order_add_to_cart{float:right;}#order_actions a.wc_quick_order_add_row{float:left;}table.wc-quick-order__contents td, table.wc-quick-order__contents th{vertical-align:middle;}table.wc-quick-order__contents td.product-quantity {padding:0px; }';
		wp_add_inline_style( 'woocommerce_admin_styles', $extra_css );
	}

	public static function resolveDependency() {
		return is_product_table_enabled() && is_quick_order_form_enabled();
	}
}
