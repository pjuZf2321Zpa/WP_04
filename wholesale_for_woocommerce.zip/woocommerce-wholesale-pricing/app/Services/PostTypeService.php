<?php
/**
 * PostTypeService class.
 *
 * Manages the registration of custom post types (CPTs) required for the
 * wholesale functionality, such as 'Requests' for user registration/access
 * and conditionally 'Group' for group-based wholesale settings.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @extends    Init
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\Init;

/**
 * Service for registering wholesale-related custom post types.
 * 
 * @extends Init
 */
class PostTypeService extends Init {


	/**
	 * Includes methods for retrieving general wholesale settings.
	 */
	use WholesaleSettings;

	/**
	 * Constructor.
	 *
	 * Calls the parent constructor to initialize the registration hooks.
	 *
	 * @return void
	 */
	public function __construct() {
		parent::__construct();        
	}

	/**
	 * Registers the custom post types.
	 *
	 * Registers the 'Request' CPT unconditionally.
	 * Conditionally registers the 'Group' CPT if 'enable_groups' is set to 'yes'
	 * in the global wholesale settings.
	 *
	 * @action init
	 * @return void
	 */
	public function register() {
		$settings = self::get_pricing_settings();
		$labels = array(
			'name'               => esc_html_x('Requests', 'Post Type Name', 'woocommerce-wholesale-pricing'),
			'singular_name'      => esc_html_x('Request', 'Post Type Singular Name', 'woocommerce-wholesale-pricing'),
			'menu_name'          => esc_html__('Request', 'woocommerce-wholesale-pricing'),
			'name_admin_bar'     => esc_html__('Request', 'woocommerce-wholesale-pricing'),
			'add_new'            => esc_html__('Add New Request', 'woocommerce-wholesale-pricing'),
			'add_new_item'       => esc_html__('Add New Request', 'woocommerce-wholesale-pricing'),
			'new_item'           => esc_html__('New Request', 'woocommerce-wholesale-pricing'),
			'edit_item'          => esc_html__('Edit Request', 'woocommerce-wholesale-pricing'),
			'view_item'          => esc_html__('View Request', 'woocommerce-wholesale-pricing'),
			'all_items'          => esc_html__('Requests', 'woocommerce-wholesale-pricing'),
			'search_items'       => esc_html__('Search Request', 'woocommerce-wholesale-pricing'),
			'not_found'          => esc_html__('No Request found.', 'woocommerce-wholesale-pricing'),
			'not_found_in_trash' => esc_html__('No Request found in Trash.', 'woocommerce-wholesale-pricing'),
		);
		$args   = array(
			'labels'          => $labels,
			'description'     => esc_html__('Description.', 'woocommerce-wholesale-pricing'),
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => '',
			'query_var'       => false,
			'rewrite'         => false,
			'capability_type' => 'post',
			'has_archive'     => false,
			'hierarchical'    => false,
			'menu_position'   => 58.3,
			'supports'        => array( 'thumbnail', 'title' ),
		);
		register_post_type(wwp_env()->get('request_slug'), $args);

		if (isset($settings['enable_groups']) && 'yes' == $settings['enable_groups'] ) {

			$labels = array(
				'name'               => esc_html_x('Group', 'Post Type Name', 'woocommerce-wholesale-pricing'),
				'singular_name'      => esc_html_x('Group', 'Post Type Singular Name', 'woocommerce-wholesale-pricing'),
				'menu_name'          => esc_html__('Groups', 'woocommerce-wholesale-pricing'),
				'name_admin_bar'     => esc_html__('Groups', 'woocommerce-wholesale-pricing'),
				'add_new'            => esc_html__('Add New Group', 'woocommerce-wholesale-pricing'),
				'add_new_item'       => esc_html__('Add New Group', 'woocommerce-wholesale-pricing'),
				'new_item'           => esc_html__('New Group', 'woocommerce-wholesale-pricing'),
				'edit_item'          => esc_html__('Edit Group', 'woocommerce-wholesale-pricing'),
				'view_item'          => esc_html__('View Groups', 'woocommerce-wholesale-pricing'),
				'all_items'          => esc_html__('Groups', 'woocommerce-wholesale-pricing'),
				'search_items'       => esc_html__('Search Group', 'woocommerce-wholesale-pricing'),
				'not_found'          => esc_html__('No Group found.', 'woocommerce-wholesale-pricing'),
				'not_found_in_trash' => esc_html__('No Group found in Trash.', 'woocommerce-wholesale-pricing'),
			);
			$args   = array(
				'labels'          => $labels,
				'description'     => esc_html__('Description.', 'woocommerce-wholesale-pricing'),
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => '',
				'query_var'       => false,
				'rewrite'         => false,
				'capability_type' => 'post',
				'has_archive'     => false,
				'hierarchical'    => false,
				'menu_position'   => 58.3,
				'supports'        => array( 'title' ),
			);
			register_post_type(wwp_env()->get('group_slug'), $args);
		}
	}
}
