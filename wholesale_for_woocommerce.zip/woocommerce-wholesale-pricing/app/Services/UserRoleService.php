<?php
/**
 * UserRoleService
 *
 * This service class is responsible for initializing the core user roles and
 * capabilities required by the wholesale pricing plugin during startup. It ensures
 * a default 'default_wholesaler' role exists and assigns administrative capabilities
 * to built-in WordPress management roles.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @extends    Init
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Strategies\Init;

/**
 * UserRoleService
 *
 * Handles the creation of the default wholesale user role and the assignment
 * of custom wholesale capabilities to administrative roles.
 *
 * @extends Init
 */
class UserRoleService extends Init {


	/**
	 * UserRoleService constructor.
	 *
	 * Initializes the service by calling the parent constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Registers the default wholesaler role and assigns wholesale capabilities
	 * to the 'shop_manager' and 'administrator' roles.
	 *
	 * The capabilities allow these administrative users to manage various
	 * aspects of the wholesale pricing system.
	 *
	 * @global \WP_Roles $wp_roles WordPress Roles object, used to manipulate roles and capabilities.
	 * @return void
	 */
	public function register() {
		add_role(
			'default_wholesaler',
			esc_html__('Wholesaler - Wholesaler Role', 'woocommerce-wholesale-pricing'),
			array(
				'read'    => true,
				'level_0' => true,
			)
		);

		$wp_roles = wp_roles();
		if (! class_exists('WP_Roles') ) {
			return;
		}

		if (! isset($wp_roles) ) {
			$wp_roles = new \WP_Roles();
		}

		$capabilities = array(
			'manage_wholesale',
			'manage_wholesale_settings',
			'manage_wholesale_user_role',
			'manage_wholesale_notifications',
			'manage_wholesale_bulk_ricing',
			'manage_wholesale_registration_page',
			'manage_wholesale_quotes',
			'manage_wholesale_product_table',
			'manage_wholesale_user_requests',
			'manage_wholesale_group',
			'manage_wholesale_reports',
			'manage_wholesale_sales_agent',
			'manage_wholesale_company_credits',
			'manage_wholesale_credit_logs',
		);
		
		/**
		* Hooks
		*
		* @since 3.0
		*/
		$capabilities = apply_filters('wholesale_user_capabilities', $capabilities);
		foreach ( $capabilities as $cap ) {
			$wp_roles->add_cap('shop_manager', $cap);
			$wp_roles->add_cap('administrator', $cap);
		}
	}
}
