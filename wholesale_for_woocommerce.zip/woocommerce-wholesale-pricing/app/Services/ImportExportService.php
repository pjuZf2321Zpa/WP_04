<?php
/**
 * ImportExportService class.
 *
 * Integrates wholesale pricing fields into the standard WooCommerce product
 * CSV importer and exporter tools. It dynamically generates import/export
 * columns based on the defined 'wholesale_user_roles' taxonomy terms.
 *
 * @package    WooCommerceWholesalePricing\Services
 */
namespace WooCommerceWholesalePricing\App\Services;

/**
 * Service class for handling import and export of wholesale pricing data.
 */
class ImportExportService {

	/**
	 * Constructor.
	 *
	 * Registers all necessary filters for the WooCommerce importer and exporter.
	 *
	 * @return void
	 */
	public function __construct() {
		// Importer hooks
		add_filter('woocommerce_csv_product_import_mapping_options', array( $this, 'add_column_to_importer' ));
		add_filter('woocommerce_csv_product_import_mapping_default_columns', array( $this, 'add_column_to_mapping_screen' ));
		add_filter('woocommerce_product_import_pre_insert_product_object', array( $this, 'process_import' ), 10, 2);

		// Exporter hooks
		add_filter('woocommerce_product_export_product_default_columns', array( $this, 'add_export_column' ));
		add_filter('woocommerce_product_export_column_names', array( $this, 'add_export_column' ));
	}

	/**
	 * Adds custom wholesale pricing columns to the CSV importer's mapping options.
	 *
	 * Creates three columns for each wholesale user role:
	 * - `[role_slug]_type`: Discount type (percent or fixed).
	 * - `[role_slug]`: Discount amount or price.
	 * - `[role_slug]_quantity`: Minimum quantity.
	 *
	 * @filter woocommerce_csv_product_import_mapping_options
	 * @param  array $options Existing mapping options (internal slug => label).
	 * @return array Modified mapping options.
	 */
	public function add_column_to_importer( $options ) {

		$allterms = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
		foreach ( $allterms as $wholesale_user_roles ) {
			$options[ $wholesale_user_roles->slug . '_type' ]     = $wholesale_user_roles->slug . ':wholesale_type';
			$options[ $wholesale_user_roles->slug ]               = $wholesale_user_roles->slug . ':wholesale_price';
			$options[ $wholesale_user_roles->slug . '_quantity' ] = $wholesale_user_roles->slug . ':wholesale_quantity';
			$options[ $wholesale_user_roles->slug . '_step_quantity' ] = $wholesale_user_roles->slug . ':wholesale_step_quantity';
		}
		return $options;
	}

	/**
	 * Maps the human-readable column names from the CSV to the internal slugs
	 * used by the importer.
	 *
	 * @filter woocommerce_csv_product_import_mapping_default_columns
	 * @param  array $columns Existing default column mappings (label => internal slug).
	 * @return array Modified column mappings.
	 */
	public function add_column_to_mapping_screen( $columns ) {

		$allterms = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
		foreach ( $allterms as $wholesale_user_roles ) {
			$columns[ $wholesale_user_roles->slug . ':wholesale_type' ]     = $wholesale_user_roles->slug . '_type';
			$columns[ $wholesale_user_roles->slug . ':wholesale_price' ]    = $wholesale_user_roles->slug;
			$columns[ $wholesale_user_roles->slug . ':wholesale_step_quantity' ] = $wholesale_user_roles->slug . '_step_quantity';

		}

		return $columns;
	}

	/**
	 * Processes the imported data and saves the wholesale pricing rules to product metadata.
	 *
	 * Handles pricing for both simple/bundle products and variations of variable products.
	 * The wholesale pricing data is stored in the `wholesale_multi_user_pricing` meta key.
	 *
	 * @filter woocommerce_product_import_pre_insert_product_object
	 * @param  WC_Product $product The product object about to be saved.
	 * @param  array      $data    The imported CSV data for this product/variation.
	 * @return WC_Product The modified product object.
	 */
	public function process_import( $product, $data ) {
		$vary     = array();
		$p_data   = array();
		$amount   = '';
		$qty      = '';
		$step_qty = '';
		$allterms = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
		foreach ( $allterms as $wholesale_user_roles ) {
			$variation_id = $product->get_id();
			$slug         = $wholesale_user_roles->slug;
			$role_id      = $wholesale_user_roles->term_id;

			if (isset($data[ $wholesale_user_roles->slug ]) && ! empty($data[ $wholesale_user_roles->slug ]) ) {

				$amount = wwp_sanitize_price( $data[ $wholesale_user_roles->slug ] );
				$type   = $data[ $wholesale_user_roles->slug . '_type' ];
				$qty    = $data[ $wholesale_user_roles->slug . '_quantity' ];
				$step_qty    = $data[ $wholesale_user_roles->slug . '_step_quantity' ];

				if (empty($data[ $wholesale_user_roles->slug . '_type' ]) ) {
					$type = 'percent';
				}
				if (empty($data[ $wholesale_user_roles->slug . '_quantity' ]) ) {
					$qty = 1;
				}

				if (empty($data[ $wholesale_user_roles->slug . '_step_quantity' ]) ) {
					$step_qty = 1;
				}

				if ('simple' == $product->get_type() || 'bundle' == $product->get_type() ) {
					$p_data[ $role_id ] = array(
						'slug'            => $wholesale_user_roles->slug,
						'discount_type'   => $type,
						'wholesale_price' => $amount,
						'min_quatity'     => $qty,
						'step_quantity'   => $step_qty,
					);

					if (! empty(get_post_meta($product->get_parent_id(), 'wholesale_multi_user_pricing', true)) ) {
						$previous = get_post_meta($product->get_parent_id(), 'wholesale_multi_user_pricing', true);
						$p_data   = array_merge($p_data, $previous);
						$product->update_meta_data('wholesale_multi_user_pricing', $p_data);
					} else {
						$product->update_meta_data('wholesale_multi_user_pricing', $p_data);
					}
				} else {

					if (! empty(get_post_meta($product->get_parent_id(), 'wholesale_multi_user_pricing', true)) ) {
						$p_data = get_post_meta($product->get_parent_id(), 'wholesale_multi_user_pricing', true);
					}

					$vary[ $role_id ]['slug']                            = $wholesale_user_roles->slug;
					$vary[ $role_id ]['discount_type']                   = $type;
					$vary[ $role_id ][ $variation_id ]['wholesaleprice'] = $amount;
					$vary[ $role_id ][ $variation_id ]['qty']            = $qty;
					$vary[ $role_id ][ $variation_id ]['step']           = $step_qty;
					$p_data[ $role_id ]['slug']                            = $wholesale_user_roles->slug;
					$p_data[ $role_id ]['discount_type']                   = $type;
					$p_data[ $role_id ][ $variation_id ]['wholesaleprice'] = $amount;
					$p_data[ $role_id ][ $variation_id ]['qty']            = $qty;
					$p_data[ $role_id ][ $variation_id ]['step']           = $step_qty;

					$product->update_meta_data('wholesale_multi_user_pricing', $vary);
					update_post_meta($product->get_parent_id(), 'wholesale_multi_user_pricing', $p_data);
				}
				$product->save();
			}
		}
		return $product;
	}

	/**
	 * Adds custom wholesale pricing columns to the product exporter and hooks up
	 * the functions to populate the data for those columns.
	 *
	 * @filter woocommerce_product_export_product_default_columns
	 * @filter woocommerce_product_export_column_names
	 * @param  array $columns Existing export columns (slug => label).
	 * @return array Modified export columns.
	 */
	public function add_export_column( $columns ) {

		// column slug => column name
		$allterms = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
		foreach ( $allterms as $wholesale_user_roles ) {
			$columns[ $wholesale_user_roles->slug . '_type' ]     = $wholesale_user_roles->slug . ':wholesale_type';
			$columns[ $wholesale_user_roles->slug ]               = $wholesale_user_roles->slug . ':wholesale_price';
			$columns[ $wholesale_user_roles->slug . '_quantity' ] = $wholesale_user_roles->slug . ':wholesale_quantity';
			$columns[ $wholesale_user_roles->slug . '_step_quantity' ] = $wholesale_user_roles->slug . ':wholesale_step_quantity';

			$slug = $wholesale_user_roles->slug;
			$role = $wholesale_user_roles->term_id;

			// wholesale type
			add_filter(
				'woocommerce_product_export_product_column_' . $wholesale_user_roles->slug . '_type',
				function ( $value, $product ) use ( $slug, $role ) {

					$data = $product->get_meta('wholesale_multi_user_pricing', true, 'edit');
					if (isset($data[ $role ]['discount_type']) ) {
							return $data[ $role ]['discount_type'];
					}
				},
				10,
				2
			);

			// wholesale price
			add_filter(
				'woocommerce_product_export_product_column_' . $wholesale_user_roles->slug,
				function ( $value, $product ) use ( $slug, $role ) {

					$data = $product->get_meta('wholesale_multi_user_pricing', true, 'edit');

					if ('simple' == $product->get_type() || 'bundle' == $product->get_type() ) {
						if (isset($data[ $role ]) ) {
							$my = $data[ $role ];
							return $my['wholesale_price'];
						}
					} elseif (isset($data[ $role ][ $product->post->ID ]['wholesaleprice']) ) {
						return $data[ $role ][ $product->post->ID ]['wholesaleprice'];
					}
				},
				10,
				2
			);

			// wholesale quantity
			add_filter(
				'woocommerce_product_export_product_column_' . $wholesale_user_roles->slug . '_quantity',
				function ( $value, $product ) use ( $slug, $role ) {

					$data = $product->get_meta('wholesale_multi_user_pricing', true, 'edit');

					if ('simple' == $product->get_type() || 'bundle' == $product->get_type() ) {
						if (isset($data[ $role ]) ) {
							return $data[ $role ]['min_quatity'];
						}
					} elseif (isset($data[ $role ][ $product->post->ID ]['qty']) ) {
						return $data[ $role ][ $product->post->ID ]['qty'];
					}
				},
				10,
				2
			);

			// wholesale step quantity
			add_filter(
				'woocommerce_product_export_product_column_' . $wholesale_user_roles->slug . '_step_quantity',
				function ( $value, $product ) use ( $slug, $role ) {

					$data = $product->get_meta('wholesale_multi_user_pricing', true, 'edit');

					if ('simple' == $product->get_type() || 'bundle' == $product->get_type() ) {
						if (isset($data[ $role ]) ) {
							return $data[ $role ]['step_quantity'];
						}
					} elseif (isset($data[ $role ][ $product->post->ID ]['step']) ) {
						return $data[ $role ][ $product->post->ID ]['step'];
					}
				},
				10,
				2
			);
		}
		return $columns;
	}
}
