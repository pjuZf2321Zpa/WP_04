<?php
/**
 * RoleTaxonomyService
 *
 * This service manages the custom taxonomy for 'Wholesale User Roles' and ensures
 * synchronization between the taxonomy terms and actual WordPress user roles.
 * It handles the creation, updating, and deletion of roles, registers custom
 * fields for role-specific settings (like tax exemption), and customizes the
 * WordPress admin list table for roles.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @extends    Init
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Strategies\Init;

/**
 * Service class for managing the custom 'Wholesale User Roles' taxonomy.
 *
 * This class extends the base Init strategy and hooks into taxonomy-related actions
 * to manage the creation, deletion, editing, and custom field saving for wholesale roles.
 * It ensures that every taxonomy term corresponds to a distinct WordPress user role.
 *
 * @extends Init
 */
class RoleTaxonomyService extends Init {

	/**
	 * Wholesale user role service.
	 *
	 * @var WholesaleUserRoleService
	 */
	private $role_service;

	/**
	 * RoleTaxonomyService constructor.
	 *
	 * Hooks into various WordPress actions and filters related to the custom
	 * wholesale role taxonomy to manage CRUD operations, custom fields, and
	 * admin list display.
	 */
	public function __construct() {
		$this->role_service = new WholesaleUserRoleService();
		parent::__construct();

		// Dynamically get the role taxonomy slug from the environment helper.
		$slug = wwp_env()->get('role_taxonomy');

		// CRUD Hooks (Create, Remove, Edit) for the taxonomy term.
		add_action('created_' . $slug, array( $this, 'create_role' ), 10, 2);
		add_action('delete_' . $slug, array( $this, 'remove_role' ), 10, 3);
		add_action('edit_' . $slug, array( $this, 'edit_role' ), 10, 2);

		// Custom Fields for Add/Edit Term screens.
		add_action($slug . '_add_form_fields', array( $this, 'add_fields' ), 10);
		add_action($slug . '_edit_form_fields', array( $this, 'edit_fields' ), 10, 1);

		// Save Custom Fields/Meta data.
		add_action('edited_' . $slug, array( $this, 'save_fields' ), 10, 2);
		add_action('create_' . $slug, array( $this, 'save_fields' ), 10, 2);

		// Admin List Table Customization.
		add_filter($slug . '_row_actions', array( $this, 'row_actions' ), 10, 2);
		add_filter('manage_edit-' . $slug . '_columns', array( $this, 'columns' ));
		add_filter('manage_' . $slug . '_custom_column', array( $this, 'column_values' ), 10, 3);
		add_filter('manage_edit-' . $slug . '_sortable_columns', array( $this, 'sortable_columns' ));

		// Custom sorting for the admin list table.
		add_action('pre_get_posts', array( $this, 'roles_sorting_query' ));
	}

	/**
	 * Registers the custom 'Wholesale User Roles' taxonomy.
	 *
	 * This method defines the labels, capabilities, and arguments for the
	 * `wholesale_user_roles` taxonomy and registers it against the 'wwp_requests'
	 * object type (though it primarily functions as a standalone user role system).
	 * It also ensures a mandatory 'default_wholesaler' term is created.
	 *
	 * @return void
	 */
	public function register() {

		$capabilities = array();
		$labels = array(
			'label'                      => esc_html__('Wholesale Roles', 'woocommerce-wholesale-pricing'),
			'name'                       => esc_html__('Wholesale User Roles', 'woocommerce-wholesale-pricing'),
			'singular_name'              => esc_html__('Wholesale Role', 'woocommerce-wholesale-pricing'),
			'search_items'               => esc_html__('Search User Roles', 'woocommerce-wholesale-pricing'),
			'popular_items'              => esc_html__('Popular User Roles', 'woocommerce-wholesale-pricing'),
			'all_items'                  => esc_html__('All User Roles', 'woocommerce-wholesale-pricing'),
			'parent_item'                => null,
			'parent_item_colon'          => null,
			'edit_item'                  => esc_html__('Edit User Role', 'woocommerce-wholesale-pricing'),
			'update_item'                => esc_html__('Update User Role', 'woocommerce-wholesale-pricing'),
			'add_new_item'               => esc_html__('Add New User Role', 'woocommerce-wholesale-pricing'),
			'new_item_name'              => esc_html__('New User Role Name', 'woocommerce-wholesale-pricing'),
			'separate_items_with_commas' => esc_html__('Separate topics with commas', 'woocommerce-wholesale-pricing'),
			'add_or_remove_items'        => esc_html__('Add or remove topics', 'woocommerce-wholesale-pricing'),
			'choose_from_most_used'      => esc_html__('Choose from the most used topics', 'woocommerce-wholesale-pricing'),
			'menu_name'                  => esc_html__('Wholesale Roles', 'woocommerce-wholesale-pricing'),
		);
		$args   = array(
			'hierarchical'          => false,
			'labels'                => $labels,
			'show_ui'               => true,
			'show_admin_column'     => true,
			'update_count_callback' => '_update_post_term_count',
			'query_var'             => true,
		);
		register_taxonomy(wwp_env()->get('role_taxonomy'), array( 'wwp_requests' ), $args);

		$term = term_exists('default_wholesaler', wwp_env()->get('role_taxonomy'));
		if (null === $term ) {
			wp_insert_term('Wholesaler', wwp_env()->get('role_taxonomy'), array( 'slug' => 'default_wholesaler' ));
		}
	}

	/**
	 * Synchronizes a newly created taxonomy term into a WordPress user role.
	 *
	 * This method is hooked to `created_{$taxonomy}` and adds a corresponding
	 * WordPress role with basic 'read' and 'level_0' capabilities.
	 *
	 * @param  int $term_id The term ID.
	 * @param  int $tt_id   The term taxonomy ID.
	 * @return void
	 */
	public function create_role( $term_id, $tt_id ) {
		$term = get_term($term_id, 'wholesale_user_roles');
		if (! wp_roles()->is_role($term->slug) ) {
			add_role(
				$term->slug,
				$term->name . esc_html__(' - Wholesaler role', 'woocommerce-wholesale-pricing'),
				array(
					'read'    => true,
					'level_0' => true,
				)
			);
		}
	}

	/**
	 * Removes the corresponding WordPress user role when a taxonomy term is deleted.
	 *
	 * This method is hooked to `delete_{$taxonomy}`.
	 *
	 * @since 1.0.0
	 *
	 * @param  int   $term         The term ID
	 *                              being
 deleted.
	 * @param  int   $tt_id        The term
	 *                              taxonomy
 ID.
	 * @param  object $deleted_term The WP_Term object of the term being deleted.
	 * @return void
	 */
	public function remove_role( $term, $tt_id, $deleted_term ) {
		$termObj = get_term($deleted_term, 'wholesale_user_roles');
		if (wp_roles()->is_role($termObj->slug) ) {
			remove_role($termObj->slug);
		}
	}

	/**
	 * Synchronizes name and slug changes from the taxonomy term to the WordPress user role.
	 *
	 * If the slug changes, it removes the old role, creates the new role, and
	 * reassigns all users from the old role to the new one.
	 * This method is hooked to `edit_{$taxonomy}`.
	 *
	 * @param  int $term_id The term ID.
	 * @param  int $tt_id   The term taxonomy ID.
	 * @return void
	 */
	public function edit_role( $term_id, $tt_id ) {
		
		if (isset($_GET['taxonomy']) && 'wholesale_user_roles' == sanitize_text_field($_GET['taxonomy']) && isset($_GET['tag_ID']) ) {
			if (! isset($_POST['wwp_tax_exempt_nonce']) || ( isset($_POST['wwp_tax_exempt_nonce']) && ! wp_verify_nonce(wc_clean(@$_POST['wwp_tax_exempt_nonce']), 'wwp_tax_exempt_nonce') ) ) {
				return;
			}
		}
		$termObj  = get_term($term_id, 'wholesale_user_roles');
		$new_name = isset($_POST['name']) ? wc_clean($_POST['name']) : '';
		$new_slug = isset($_POST['slug']) ? wc_clean($_POST['slug']) : '';
		if ($new_slug != $termObj->slug || $new_name != $termObj->name ) {
			if (empty($new_slug) ) {
				$new_slug = sanitize_title($new_name);
			}
			if (wp_roles()->is_role($termObj->slug) ) {
				remove_role($termObj->slug);
			}
			if (! wp_roles()->is_role($new_slug) ) {
				add_role(
					$new_slug,
					$new_name . esc_html__(' - Wholesaler role', 'woocommerce-wholesale-pricing'),
					array(
						'read'    => true,
						'level_0' => true,
					)
				);
			}
			$args  = array(
				'role' => $termObj->slug,
			);
			$users = get_users($args);
			if (! empty($users) ) {
				foreach ( $users as $user ) {
					$user = new \WP_User($user->ID);
					// Remove current subscriber role
					$user->remove_role($termObj->slug);
					$user->remove_cap($termObj->slug);
					// Upgrade to editor role
					$user->add_role($new_slug);
					$user->add_cap($new_slug);
					wp_cache_delete($user->ID, 'users');
				}
			}
		}
	}

	/**
	 * Outputs custom fields on the 'Add New Wholesale Role' admin screen.
	 *
	 * @return string HTML output from the view template.
	 */
	public function add_fields() {
		return wwp_view('admin.user-role.add'); 
	}

	/**
	 * Outputs custom fields on the 'Edit Wholesale Role' admin screen.
	 *
	 * @param  \WP_Term $term The current term object being edited.
	 * @return string HTML output from the view template.
	 */
	public function edit_fields( $term ) {
		return wwp_view('admin.user-role.edit', compact('term')); 
	}

	/**
	 * Saves the custom term meta fields for the wholesale role.
	 *
	 * This method handles settings like tax exemption, tax classes, coupon disabling,
	 * subscription control, and payment/shipping method restrictions.
	 * Hooked to `edited_{$taxonomy}` and `create_{$taxonomy}`.
	 *
	 * @param  int     $term_id The term
	 * @param  int     $tt_id     The term
	 *                            taxonomy
	 * @return void
	 */
	public function save_fields( $term_id, $term ) {

		if ( ! isset( $_POST['wwp_tax_exempt_nonce'] ) || ! wp_verify_nonce( wc_clean( wp_unslash( $_POST['wwp_tax_exempt_nonce'] ) ), 'wwp_tax_exempt_nonce' ) ) {
			return;
		}

		$this->role_service->save_role_meta( (int) $term_id, $this->role_service->map_post_to_role_meta() );
	}

	/**
	 * Removes the 'View' action link from the row actions in the admin list table.
	 *
	 * Hooked to `{$taxonomy}_row_actions`.
	 *
	 * @param  array   $actions An array of action links.
	 * @param  \WP_Term $tag        The term
	 *                           object.
	 * @return array Modified array of action links.
	 */
	public function row_actions( $actions, $tag ) {
		unset($actions['view']);
		return $actions;
	}

	/**
	 * Defines the columns for the Wholesale Roles admin list table.
	 *
	 * This removes the default 'posts' column and adds a custom 'count' column.
	 * Hooked to `manage_edit-{$taxonomy}_columns`.
	 *
	 * @param  array $columns Existing columns in the list table.
	 * @return array Modified columns array.
	 */
	public function columns( $columns ) {
		if (isset($columns['posts']) ) {
			unset($columns['posts']);
		}
		$columns['count'] = 'Count';
		return $columns;
	}

	/**
	 * Renders the content for the custom columns in the admin list table.
	 *
	 * Specifically populates the 'count' column with a link to the user list.
	 * Hooked to `manage_{$taxonomy}_custom_column`.
	 *
	 * @param  string    $content         Current
	 *                                column
 content.
	 * @param  string    $column_name Name of the column being rendered.
	 * @param  int     $term_id         The
	 *                                term
 ID.
	 * @return string Column content.
	 */
	public function column_values( $content, $column_name, $term_id ) {
		if ('count' == $column_name ) {
			// Get the term object for the specific term
			$term = get_term($term_id, 'wholesale_user_roles');
			
			if ($term && isset($term->name) ) {
				// Construct the URL to show users with this term (role)
				$url = admin_url('users.php?role=' . urlencode($term->slug));
				$args = array(
					'role'    => $term->name,
				);

				$users = get_users(array( 'role__in' => $term->slug ));
				
				$content = '<a href="' . esc_url($url) . '">' . esc_html(count($users)) . '</a>';
			}
		}

		return $content;
	}

	/**
	 * Makes the custom 'count' column sortable in the admin list table.
	 *
	 * Hooked to `manage_edit-{$taxonomy}_sortable_columns`.
	 *
	 * @param  array $columns Existing sortable columns.
	 * @return array Modified sortable columns array.
	 */
	public function sortable_columns( $columns ) {
		$columns['count'] = 'count';
		return $columns;
	}

	/**
	 * Modifies the query to enable sorting by 'count' (number of users).
	 *
	 * Hooked to `pre_get_posts` but is specifically targeting the role taxonomy
	 * administration screen based on URL parameters.
	 *
	 * @param  \WP_Query $query The current WP_Query object.
	 * @return void
	 */
	public function roles_sorting_query( $query ) {
		if (is_admin() && isset($_GET['taxonomy']) && 'wholesale_user_roles' == $_GET['taxonomy'] ) {
			if (isset($_GET['orderby']) && 'count' == $_GET['orderby'] ) {
				$query->set('orderby', 'count');
				$query->set('order', 'ASC');
			}
		}
	}
}
