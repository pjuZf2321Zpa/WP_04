<?php

/**
 * RequisitionListService.php
 *
 * This service handles all functionality related to the "Requisition List" feature,
 * which allows users (typically wholesale customers) to create, manage, and
 * convert product lists into orders. It sets up frontend endpoints in 'My Account'
 * and registers necessary AJAX handlers for list operations.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Service class for integrating and managing the Requisition List feature.
 *
 * This class hooks into various WooCommerce and WordPress actions to create a
 * dedicated 'Requisition List' section in the My Account area, enable saving
 * the current cart as a list, and provide the backend logic for list CRUD operations.
 *
 * @implements ServiceInterface
 */
class RequisitionListService implements ServiceInterface {


   
	/**
	 * Includes methods for retrieving general wholesale settings.
	 */
	use WholesaleSettings;

	/**
	 * The URL endpoint slug for the requisition list in the WooCommerce My Account area.
	 *
	 * @var string
	 */
	public $requisition_list_url;

	/**
	 * Constructor: Initializes all action and filter hooks required for the Requisition List.
	 */
	public function __construct() {
		
		$settings = self::get_pricing_settings();
		if (isset($settings['requisition_list_cart_page']) && 'yes' == $settings['requisition_list_cart_page'] ) {
			add_action('woocommerce_cart_actions', array( $this, 'add_requisition_list_button_cart' ), 10, 0); 
		}

		// Set the dynamic requisition list URL/endpoint.
		/**
		 * Filter 
		 * 
		 * @var string value
		 * 
		 * @since 2.0.0
		 */
		$this->requisition_list_url = apply_filters('wholesale_requisition_list_url', wwp_env()->get('requisition_endpoint'));

		// My Account integration.
		add_action('init', array( $this, 'requisition_list_rewrite' ));
		add_filter('query_vars', array( $this, 'requisition_list_query_var' ), 10);
		add_filter('woocommerce_account_menu_items', array( $this, 'requisition_list_add_menu_item' ));
		add_action("woocommerce_account_{$this->requisition_list_url}_endpoint", array( $this, 'requisition_list_tab_content' ));

		// AJAX handlers for CRUD and data retrieval.
		add_action('wp_ajax_wwp_get_datatable', array( $this, 'get_user_lists' ));
		add_action('wp_ajax_nopriv_wwp_get_datatable', array( $this, 'get_user_lists' ));

		add_action('wp_ajax_select2_get_ajax_callback', array( $this, 'search_products' ));  
		add_action('wp_ajax_nopriv_select2_get_ajax_callback', array( $this, 'search_products' ));  

		add_action('wp_ajax_requisition_open_list_edit', array( $this, 'edit_list' ));  
		add_action('wp_ajax_nopriv_requisition_open_list_edit', array( $this, 'edit_list' ));  

		add_action('wp_ajax_wwp_load_requisition_modal', array( $this, 'load_template_new' ));
		add_action('wp_ajax_nopriv_wwp_load_requisition_modal', array( $this, 'load_template_new' ));

		add_action('wp_ajax_WWP_requisition_list_template_new', array( $this, 'template_new' ));
		add_action('wp_ajax_nopriv_WWP_requisition_list_template_new', array( $this, 'template_new' ));

		add_action('wp_ajax_WWP_requisition_list_template_edit', array( $this, 'template_edit' ));  
		add_action('wp_ajax_nopriv_WWP_requisition_list_template_edit', array( $this, 'template_edit' ));
		
		add_action('wp_ajax_requisition_list_add_to_cart', array( $this, 'list_add_to_cart' ));  
		add_action('wp_ajax_nopriv_requisition_list_add_to_cart', array( $this, 'list_add_to_cart' ));
			
		add_action('wp_ajax_requisition_list_delete', array( $this, 'delete_list' ));  
		
		add_action('wp_ajax_requisition_list_add_cart_page', array( $this, 'list_cart_page' ));  
		add_action('wp_ajax_nopriv_requisition_list_add_cart_page', array( $this, 'list_cart_page' ));
	}

	/**
	 * Adds the "Save as Requisition List" button to the WooCommerce Cart actions section.
	 *
	 * @action woocommerce_cart_actions
	 * @return void Outputs HTML button.
	 */
	public function add_requisition_list_button_cart() {
		?>
		  <button type="button" id="requisition_add_to_list" class="button requisition_add_to_list" name="requisition_add_to_list"><?php esc_html_e('Save as Requisition List', 'woocommerce-wholesale-pricing'); ?></button>
		<?php
	}

	/**
	 * Registers the custom rewrite endpoint for the Requisition List in My Account.
	 *
	 * @action init
	 * @global \WP_Rewrite $wp_rewrite
	 * @return void
	 */
	public function requisition_list_rewrite() {
		add_rewrite_endpoint( $this->requisition_list_url, EP_ROOT | EP_PAGES );

		$flushed_for = get_option( 'wwp_requisition_list_endpoint_rewrite_flushed', '' );
		if ( $flushed_for !== $this->requisition_list_url ) {
			flush_rewrite_rules( false );
			update_option( 'wwp_requisition_list_endpoint_rewrite_flushed', $this->requisition_list_url, false );
		}
	}

	/**
	 * Adds the custom query variable for the Requisition List endpoint.
	 *
	 * @filter query_vars
	 * @param  array $vars Existing query variables.
	 * @return array Updated array of query variables.
	 */
	public function requisition_list_query_var( $vars ) {
		$vars[] = $this->requisition_list_url;
		return $vars;
	}

	/**
	 * Adds the Requisition List link to the WooCommerce My Account menu.
	 *
	 * Uses the custom text configured in settings, or a default string.
	 *
	 * @filter woocommerce_account_menu_items
	 * @param  array $items Existing menu items.
	 * @return array Updated menu items.
	 */
	public function requisition_list_add_menu_item( $items ) {
		$settings = self::get_pricing_settings();

		if (isset($settings['requisition_list_text']) && ! empty($settings['requisition_list_text']) ) {
			$items[$this->requisition_list_url] = $settings['requisition_list_text'];
		} else {
			$items[$this->requisition_list_url] = esc_html__('Requisition List', 'woocommerce-wholesale-pricing');
		}

		return $items;
	}

	/**
	 * Renders the content for the Requisition List tab in the My Account area.
	 *
	 * This function manages script and style dependencies and loads the main view.
	 *
	 * @action woocommerce_account_{$this->requisition_list_url}_endpoint
	 * @return void Outputs the HTML content via the `wwp_view()` helper.
	 */
	public function requisition_list_tab_content() {
		wp_dequeue_script('selectWoo');
		wp_enqueue_style('dashicons');
		wp_enqueue_style('select2css');
		wp_enqueue_script('select2');
		wp_enqueue_style('wwp_dataTables');
		wp_enqueue_script('wwp_dataTables');
		
		return wwp_view('requisition-list.index');
	}

	/**
	 * AJAX handler to fetch and format the current user's requisition lists for a DataTable.
	 *
	 * Queries the 'wp_requisition_list' CPT authored by the current user.
	 *
	 * @action wp_ajax_wwp_get_datatable
	 * @action wp_ajax_nopriv_wwp_get_datatable
	 * @global \wpdb $wpdb WordPress database access object (though not strictly used in the current version).
	 * @return void Outputs JSON array containing list data and terminates script execution with `wp_die()`.
	 */
	public function get_user_lists() {
		global $wpdb;
		$args        = array(
			'post_type'             => 'wp_requisition_list',
			'posts_per_page'        => -1,
			'meta_query'=> array(
			array(
				'key' => 'user_id',
				'value' => get_current_user_id(),
				),
			),
		);
		$postsQ      = new \WP_Query($args);
		$return_json = array();
		
		
		while ( $postsQ->have_posts() ) { 
			$postsQ->the_post();
			$i           =0;
			$count_lists = get_post_meta(get_the_ID(), 'requisition', true);
			foreach ( $count_lists as $key => $count_list ) {
				
				if (isset($count_list['wwp_product_id'])) {
					$i++;
				}
			}
			$row           = array(
				'title' => get_the_title(),
				'count_list' => $i . ' items',
				'id' => get_the_ID(),
			);
			$return_json[] = $row;
		}
		echo json_encode(array( 'data' => $return_json ));
		wp_die();
	}

	/**
	 * AJAX handler for searching products by title or SKU for use in Select2 fields.
	 *
	 * This allows users to search for products to add to a requisition list.
	 *
	 * @action wp_ajax_select2_get_ajax_callback
	 * @action wp_ajax_nopriv_select2_get_ajax_callback
	 * @return void Outputs JSON array of product IDs, titles, and prices, and terminates script execution with `wp_die()`.
	 */
	public function search_products() {

		$return =array();
		$args   = array( 
			'post_type' =>  array( 'product', 'product_variation' ),
			'post_status' => array( 'publish' ),
			'posts_per_page' => '-1',
		);
		
		if ('productname' == wwp_get_get_data('bytype') ) { 
			$args['s'] = wwp_get_get_data('q');
		} else {
			$args['meta_query'] = 
					array(
						array(
						'key'     => '_sku',
						'value'   =>  wwp_get_get_data('q'),
						'compare' => '=',
						),
					);
		}   
		$search_results = get_posts($args);
		if ($search_results ) :
			foreach ( $search_results as $post ) : 
				$product  = wc_get_product($post->ID);
				$title    = ( mb_strlen($post->post_title) > 50 ) ? mb_substr($post->post_title, 0, 49) . '...' : $post->post_title;
				$return[] = array( $post->ID, $title, wwp_get_price_including_tax_for_requisition($product, array( 'price' => $product->get_price() )) ); 
			endforeach;
		endif;
		echo json_encode($return);
		wp_die();
	}

	/**
	 * AJAX handler to display the edit form/modal for an existing requisition list.
	 *
	 * @action wp_ajax_requisition_open_list_edit
	 * @action wp_ajax_nopriv_requisition_open_list_edit
	 * @return void Outputs the edit list view and terminates script execution with `wp_die()`.
	 */
	public function edit_list() {
		wwp_view('requisition-list.edit');
		wp_die();
	}

	/**
	 * AJAX handler to update an existing requisition list custom post type (CPT) and its metadata.
	 *
	 * @action wp_ajax_WWP_requisition_list_template_edit
	 * @action wp_ajax_nopriv_WWP_requisition_list_template_edit
	 * @return void Outputs 'updated' on success or an error message, then terminates script execution with `wp_die()`.
	 */
	public function template_edit() {
		$postdata        = wwp_get_post_data();
		$wwp_requisition = array(
			'ID' => $postdata['post_id'],
			'post_title'   => esc_html($postdata['wwp_list_name']),
			'post_type' => 'wp_requisition_list',
			'post_author'   => 1,
			'meta_input'   => array(
				'requisition' => $postdata['requisition'],
				'user_id' => get_current_user_id(),
			),
		);
		
		$id = wp_update_post($wwp_requisition);
		if (!is_wp_error($id) ) {
			echo 'updated';
		} else {
			echo wp_kses_post($id->get_error_message());
		}
	
		wp_die();
	}

	public function load_template_new() {
		check_ajax_referer('wwp_wholesale_pricing', 'security');

		ob_start();
		wwp_view('requisition-list.new');
		$html = ob_get_clean();

		wp_send_json_success(
			array(
				'html' => $html,
			)
		);
	}

	/**
	 * AJAX handler to create a new requisition list custom post type (CPT).
	 *
	 * @action wp_ajax_WWP_requisition_list_template_new
	 * @action wp_ajax_nopriv_WWP_requisition_list_template_new
	 * @return void Outputs 'updated' on success or an error message, then terminates script execution with `wp_die()`.
	 */
	public function template_new() {
		$psotdata        = wwp_get_post_data();
		$wwp_requisition = array(
			'post_title'   => esc_html($psotdata['wwp_list_name']),
			'post_type' => 'wp_requisition_list',
			'post_author'   => 1,
			'meta_input'   => array(
				'requisition' => $psotdata['requisition'],
				'user_id' => get_current_user_id(),
			),
		);
		
		$id = wp_insert_post($wwp_requisition);
		if (!is_wp_error($id) ) {
			echo 'updated';
		} else {
			echo wp_kses_post($id->get_error_message());
		}
		wp_die();
	}

	/**
	 * AJAX handler to add all products from a requisition list to the current WooCommerce cart.
	 *
	 * @action wp_ajax_requisition_list_add_to_cart
	 * @action wp_ajax_nopriv_requisition_list_add_to_cart
	 * @return void Outputs 'done' and terminates script execution with `wp_die()`.
	 */
	public function list_add_to_cart() {
		$data = wwp_get_post_data();
		$hasItems = count(array_filter($data['requisition'], function ( $item ) {
			return isset($item['wwp_product_id']);
		}));
		if ( $hasItems ) {
			foreach ( $data['requisition'] as $list ) {
				if (isset($list['wwp_product_id']) && !empty($list['wwp_product_id']) ) {
					WC()->cart->add_to_cart($list['wwp_product_id'], $list['wwp_product_qty']);
				}
			}
			wp_send_json_success(array( 'message' => __('Products added to cart successfully.', 'woocommerce-wholesale-pricing') ));
		} else {
			wp_send_json_error(array( 'message' => __('The requisition list is empty.', 'woocommerce-wholesale-pricing') ));
		}
	}

	/**
	 * AJAX handler to permanently delete a requisition list custom post type (CPT).
	 *
	 * @action wp_ajax_requisition_list_delete
	 * @return void Outputs 'deleted' and terminates script execution with `wp_die()`.
	 */
	public function delete_list() {
		if (! is_user_logged_in() ) {
			return;
		}
		wp_delete_post(wwp_get_post_data('post_id'), true); 
		wp_die('deleted');
	}

	/**
	 * AJAX handler to save the current WooCommerce cart contents as a new requisition list.
	 *
	 * @action wp_ajax_requisition_list_add_cart_page
	 * @action wp_ajax_nopriv_requisition_list_add_cart_page
	 * @return void Outputs success or failure message, then terminates script execution with `wp_die()`.
	 */
	public function list_cart_page() {
		// $post_cart = wwp_get_post_data( 'cart' );
		$arraydata = array();
		if (!empty(WC()->cart->get_cart()) ) { 
			foreach ( WC()->cart->get_cart() as $key => $cart ) { 
				$data = WC()->cart->get_cart_item($key);
				$rand = rand(120, 11100333);
				if (0 == $data['variation_id'] ) {
					$arraydata[$rand]['wwp_product_id'] = $data['product_id'];
				} else {
					$arraydata[$rand]['wwp_product_id'] = $data['variation_id'];
				}
				$arraydata[$rand]['wwp_product_qty']   = $cart['quantity'];
				$arraydata[$rand]['wwp_product_price'] = $data['data']->get_price();
			}

			$wwp_requisition = array(
				'post_title'   => esc_html(wwp_get_post_data('list_name')),
				'post_type' => 'wp_requisition_list',
				'post_author'   => 1,
				'meta_input'   => array(
					'requisition' => $arraydata,
					'user_id' => get_current_user_id(),
				),
			);
			
			$id = wp_insert_post($wwp_requisition);
			if (!is_wp_error($id) ) { 
				echo 'Successfully Added';
			} else {
				echo wp_kses_post($id->get_error_message());
			}
		} else {
			echo 'Failed';
		}
		wp_die();
	}

	/**
	 * Determines whether the Requisition List feature should be initialized.
	 *
	 * Required by the ServiceInterface. Checks the plugin settings for activation status.
	 *
	 * @static
	 * @return bool True if the requisition list is enabled in settings, false otherwise.
	 */
	public static function resolveDependency() {
		$settings = self::get_pricing_settings();
		return isset($settings['requisition_list']) && 'yes' === $settings['requisition_list'];
	}
}
