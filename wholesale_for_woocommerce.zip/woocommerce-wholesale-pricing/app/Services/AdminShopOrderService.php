<?php
/**
 * AdminShopOrderService Class
 *
 * This service handles various administrative functions related to WooCommerce Shop Orders,
 * specifically implementing features for wholesale users, such as order filtering,
 * displaying wholesale pricing details, and handling special checkout fields.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\ProductPriceHTML;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\VariablePriceHTML;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\RegularPriceChange;

/**
 * Handles admin shop order list filtering and order item display/saving logic.
 * 
 * @implements ServiceInterface
 */
class AdminShopOrderService implements ServiceInterface {

	// Use utility traits to handle specific aspects of the admin shop order.
	use WholesaleSettings;
	use VariablePriceHTML;
	use ProductPriceHTML;
	use RegularPriceChange;

	/**
	 * Constructor. Registers all necessary WordPress and WooCommerce hooks.
	 * Hooks cover order list filtering, order saving, and adding custom order item fields/logic.
	 */
	public function __construct() {
		// Order list filtering for legacy (pre-HPOS) and HPOS list tables
		add_action('woocommerce_order_list_table_restrict_manage_orders', array( $this, 'shop_order_user_role_filter' ));
		add_action('restrict_manage_posts', array( $this, 'shop_order_user_role_filter' ));
		
		// Filtering orders for legacy list table based on user role
		add_filter('pre_get_posts', array( $this, 'shop_order_user_role_posts_where' ));

		// Filtering orders for the modern HPOS list table based on user role
		add_filter('woocommerce_order_list_table_prepare_items_query_args', array( $this, 'wwp_woocommerce_order_query_filter' ), 10);

		// Displaying wholesaler tax ID on the order details screen
		add_action('woocommerce_order_details_after_customer_details', array( $this, 'display_tax_admin_order' ), 10, 1);
		add_action('woocommerce_admin_order_data_after_billing_address', array( $this, 'display_tax_admin_order' ), 10, 1);

		// Custom checkout fields meta box
		add_action('add_meta_boxes', array( $this, 'wwp_register_meta_box' ));

		// Saving custom checkout form data to the order
		add_action('save_post_shop_order', array( $this, 'update_order_wwp_form_data_json_value' ));

		$settings = self::get_pricing_settings();
		$order_id = $this->get_order_id();

		// Add wholesale item logic only if enabled and on an order edit screen
		if (isset($settings['enable_admin_new_order_item']) && 'yes' == $settings['enable_admin_new_order_item'] && ( in_array(get_post_type($order_id), array( 'shop_order', 'shop_order_placehold' ) ) || filter_input( INPUT_GET, 'page', FILTER_SANITIZE_SPECIAL_CHARS ) ) ) { 
			add_action('admin_head', array( $this, 'admin_head' ));

			// Custom columns in the order items table
			add_action('woocommerce_admin_order_item_headers', array( $this, 'woocommerce_admin_order_item_headers' ), 10, 1);
			add_action('woocommerce_admin_order_item_values', array( $this, 'woocommerce_admin_order_item_values' ), 10, 3);

			// Logic to apply wholesale price and tax class when a new item is added in admin
			add_action('woocommerce_new_order_item', array( $this, 'action_woocommerce_new_order_item' ), 10, 3);
		}
	}

	/**
	 * Retrieves the current order ID from various global request variables or current post ID.
	 *
	 * @return int The sanitized order ID, or an empty string if not found.
	 */
	public function get_order_id() {
		$order_id ='';
		$request = $_REQUEST;

		if (isset($request['post']) ) {
			$order_id = sanitize_text_field($request['post']);
		} elseif (isset($request['order_id']) ) {
			$order_id = sanitize_text_field($request['order_id']);
		} elseif (get_the_ID() ) {
			$order_id = get_the_ID();
		} elseif (isset($request['page'], $request['id']) && 'wc-orders' == sanitize_text_field($request['page']) ) {
			$order_id =sanitize_text_field($request['id']);
		}

		return $order_id;
	}

	/**
	 * Displays a dropdown filter on the WooCommerce Shop Orders list table
	 * to filter orders by 'Wholesaler' or 'non-Wholesaler' user roles.
	 *
	 * @return void
	 */
	public function shop_order_user_role_filter() {
		if ( 
			( isset($_GET['post_type']) && 'shop_order' === wc_clean($_GET['post_type']) ) 
			|| 
			( isset($_GET['page']) && 'wc-orders' === wc_clean($_GET['page']) ) 
		) {
		
			if (! empty($_GET['_user_role']) ) {
				$user_role = sanitize_text_field($_GET['_user_role']);
			} else {
				$user_role = '';
			}
			?>
			<select name="_user_role" class="">
				<option value=""><?php esc_html_e('All', 'woocommerce-wholesale-pricing'); ?></option>
				<option <?php selected($user_role, 'Wholesaler'); ?> value="Wholesaler"><?php esc_html_e('Wholesaler', 'woocommerce-wholesale-pricing'); ?></option>
				<option <?php selected($user_role, 'non-Wholesaler'); ?> value="non-Wholesaler"><?php esc_html_e('Non - Wholesaler', 'woocommerce-wholesale-pricing'); ?></option>
			</select>
			<?php
		}
	}

	/**
	 * Modifies the WordPress query to filter `shop_order` posts based on the
	 * selected 'Wholesaler' or 'non-Wholesaler' filter in the admin list.
	 * This logic is primarily for the legacy post-based order list.
	 *
	 * @param  \WP_Query $query The current WP_Query object.
	 * @return \WP_Query The modified query object.
	 */
	public function shop_order_user_role_posts_where( $query ) {

		if (! $query->is_main_query() || ! isset($_GET['_user_role']) || ( isset($_GET['_user_role']) && empty($_GET['_user_role']) ) ) {
			return $query;
		}
		

		$wholesale_user_ids = array();
		$all_wholesale_role = array();
		$allterms           = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
		foreach ( $allterms as $allterm_key => $allterm_value ) {
			array_push($all_wholesale_role, $allterm_value->slug);
		}

		$wholesale_user_ids = get_users(
			array(
				'role__in' => $all_wholesale_role,
				'fields'   => 'ID',
			)
		);

		switch ( $_GET['_user_role'] ) {
			case 'Wholesaler':
				$query->set(
				'meta_query',
				array(
					array(
						'key'     => '_customer_user',
						'compare' => 'IN',
						'value'   => $wholesale_user_ids,
					),
				)
				);
				break;
			case 'non-Wholesaler':
				$query->set(
				'meta_query',
				array(
					array(
						'key'     => '_customer_user',
						'compare' => 'NOT IN',
						'value'   => $wholesale_user_ids,
					),
				)
				);
				break;
		}
		if (empty($wholesale_user_ids) ) {
			$query->set('posts_per_page', 0);
		}

		return $query;
	}

	/**
	 * Filters the order query arguments for the HPOS order list table
	 * based on the selected 'Wholesaler' or 'non-Wholesaler' filter.
	 *
	 * @param  array $query_args The array of query arguments for the WC_Order_Query.
	 * @return array The modified query arguments.
	 */
	public function wwp_woocommerce_order_query_filter( $query_args ) {
		$type = filter_input(INPUT_GET, '_user_role', FILTER_SANITIZE_SPECIAL_CHARS);

		if (! empty($type) ) {
			$wholesale_user_ids = array();
			$all_wholesale_role = array();

			$allterms = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
			foreach ( $allterms as $allterm_value ) {
				$all_wholesale_role[] = $allterm_value->slug;
			}

			$user_args = array(
				'role__in' => $all_wholesale_role,
				'fields'   => 'ID',
			);

			if ('non-Wholesaler' === $type ) {
				$user_args['role__not_in'] = $all_wholesale_role;
				unset($user_args['role__in']);

				$wholesale_user_ids = get_users($user_args);
				if (! empty($wholesale_user_ids) ) {
					$query_args['customer_id'] = $wholesale_user_ids;
					$query_args['customer_id'][] = 0; // Add guest orders
				} else {
					$query_args['customer_id'] = array( 0 );
				}
			} else {
				$wholesale_user_ids = get_users($user_args);

				if (! empty($wholesale_user_ids) ) {
					$query_args['customer_id'] = $wholesale_user_ids;
				} else {
					$query_args['customer_id'] = array( -1 );
				}
			}
		}

		return $query_args;
	}

	/**
	 * Displays the Wholesaler Tax ID on the admin order details page if the
	 * registration setting 'tax_id_display' is enabled.
	 *
	 * @param  \WC_Order $order The WooCommerce Order object.
	 * @return void
	 */
	public function display_tax_admin_order( $order ) {
		$registrations = self::get_registration_settings();
		if ( isset( $registrations['tax_id_display'] ) && 'yes' == $registrations['tax_id_display'] ) {
			$tax_id = $order->get_meta( 'wwp_wholesaler_tax_id', true );
			if ( '' === (string) $tax_id && $order->get_user_id() ) {
				$tax_id = get_user_meta( $order->get_user_id(), 'wwp_wholesaler_tax_id', true );
			}
			$wholesaler_tax_id = esc_html__( 'Wholesaler Tax ID ', 'woocommerce-wholesale-pricing' );
			echo wp_kses( '<p><strong> ' . $wholesaler_tax_id . ':</strong> <br/>' . esc_html( (string) $tax_id ) . '</p>', shapeSpace_allowed_html() );
		}
	}

	/**
	 * Registers the 'Checkout Extra Fields Data' meta box on the shop order edit screen.
	 * This is only registered if the 'display_fields_checkout' setting is enabled.
	 *
	 * @return void
	 */
	public function wwp_register_meta_box() {
		$registrations = self::get_registration_settings();
		if (isset($registrations['display_fields_checkout']) && 'yes' == $registrations['display_fields_checkout'] ) {
			add_meta_box(
				'wwp_form_builder',
				esc_html__('Checkout Extra Fields Data', 'woocommerce-wholesale-pricing'),
				array( $this, 'wwp_meta_box_callback' ),
				'shop_order',
				'advanced',
				'high'
			);
		}
	}

	/**
	 * Renders the content of the 'Checkout Extra Fields Data' meta box.
	 * Assumes a global function `render_form_builder` exists to handle rendering.
	 *
	 * @param  \WP_Post $order_post The current post object for the order.
	 * @return void
	 */
	public function wwp_meta_box_callback( $order_id ) {
		echo wp_kses_post(render_form_builder('get_post_meta', $order_id->ID));
	}

	/**
	 * Saves the JSON data from the extra checkout fields into the order post meta.
	 *
	 * @param  int $post_id The ID of the post (order) being saved.
	 * @return void
	 */
	public function update_order_wwp_form_data_json_value( $post_id ) {
		$form_data = wwp_get_form_builder_posted_data();
		if ( ! empty( $form_data ) ) {
			update_post_meta( $post_id, 'wwp_form_data_json', $form_data );
		}
	}

	/**
	 * Adds custom headers ('Cost' and 'Wholesale Prices') to the order items table
	 * in the admin edit order screen, but only for wholesaler users.
	 *
	 * @param  \WC_Order $order The WooCommerce Order object.
	 * @return void
	 */
	public function woocommerce_admin_order_item_headers( $order ) {
		if (! is_wholesaler_user($order->get_user_id()) ) {
			return;
		}
		echo '<th class="wholesale_th">' . esc_html__('Cost', 'woocommerce-wholesale-pricing') . '</th>';
		echo '<th class="wholesale_th">' . esc_html__('Wholesale Prices', 'woocommerce-wholesale-pricing') . '</th>';
	}

	/**
	 * Displays the 'Cost' (Subtotal) and the wholesale price information for an
	 * individual line item in the admin order items table.
	 *
	 * @param  \WC_Product            $product The product object for the line item.
	 * @param  \WC_Order_Item_Product $item    The order item object.
	 * @param  int|null               $item_id The order item ID (optional).
	 * @return void
	 */
	public function woocommerce_admin_order_item_values( $product, $item, $item_id = null ) {
		$order_id = $this->get_order_id();
		$order = wc_get_order($order_id);

		if ( ! $order instanceof \WC_Abstract_Order ) {
			return;
		}

		if ( ! method_exists( $order, 'get_user_id' ) ) {
			return;
		}

		$user_id = $order->get_user_id();

		if ( ! $user_id || ! is_wholesaler_user( $user_id ) ) {
			return;
		}
		
		/**
		 * Filter
		 * 
		 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
		 * 
		 * @since 3.1.0
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );

		if ('shop_order_refund' == $item->get_type() ) {
			echo wp_kses_post('<td></td><td></td>');
			return;
		}
		$settings               = self::get_pricing_settings();
		$variation_id           =  $item['variation_id'];
		if (0 != $variation_id ) {
			$r_price = get_post_meta($variation_id, $price_key, true);
			$data    = $this->wwp_variable_price_format($r_price, wc_get_product($product->get_parent_id()));
		} else {
			$r_price = get_post_meta($item['product_id'], $price_key, true);
			$data    = $this->wwp_change_product_price_display($r_price, $product);
		}

		$lable     = !empty($settings['retailer_label']) ? $settings['retailer_label'] : 'Actual';
		$wholesale = strpos($data, $lable);
		$note      = '<div class="edit note_wholesale">' . __('The wholesale pricing will not be applied to the manually changed quantity and price. In order to apply the wholesale price, delete the product from the order and re-add it.', 'woocommerce-wholesale-pricing') . '</div>';
		$data      =  $data . $note;

		$order = wc_get_order($order_id);
		echo wp_kses_post('<td class="wholesale_td_cost"> ' . wc_price($order->get_item_subtotal($item, false, true), array( 'currency' => $order->get_currency() )) . ' </td>');
		echo wp_kses_post('<td class="wholesale_td replace_wholesale">' . $data . '</td>');
	}

	/**
	 * Action triggered when a new line item is added to an order in the admin area.
	 * It applies the wholesale price and tax class if the order customer is a wholesaler.
	 *
	 * @param  int                    $item_id  The new order item ID.
	 * @param  \WC_Order_Item_Product $item     The order item product object.
	 * @param  int                    $order_id The order ID.
	 * @return void
	 */
	public function action_woocommerce_new_order_item( $item_id, $item, $order_id ) {
		
		if (0 == $order_id ) {
			return;
		}
		
		if (! is_wholesaler_user(wc_get_order($item->get_order_id())->get_user_id()) ) {
			return;
		} 
		if ('line_item' != $item->get_type() ) {
			return;
		}
		
		$variation_id = $item->get_variation_id();
		
		if (0 != $variation_id ) {
			$product = wc_get_product($variation_id);
		} else {
			$product = wc_get_product($item->get_product_id());
		}
		if (! $product ) {
			return;
		} 

		/**
		 * 
		 * Apply wholesale price on
		 * 
		 * @since 3.0.0
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );
		$Wprice                = $this->wwp_regular_price_change(get_post_meta($product->get_id(), $price_key, true), $product);
		
		$role                       = get_current_user_role_id();
		$wwp_wholesaler_tax_classes = get_term_meta($role, 'wwp_wholesaler_tax_classes', true);
		if (!empty($wwp_wholesaler_tax_classes) ) {
			$item->set_tax_class($wwp_wholesaler_tax_classes);
		}
		
		if (!empty($Wprice) ) {
			$item->set_total($Wprice * $item->get_quantity());
			$item->set_subtotal($Wprice * $item->get_quantity());
			$item->save();
		}
	}

	/**
	 * Outputs inline JavaScript and CSS in the admin head of the order edit screen.
	 * JS forces a form submission/save when the customer is changed, to re-apply
	 * wholesale pricing logic based on the new customer's role.
	 * CSS hides the default WooCommerce 'Cost' column, which is replaced by a custom column.
	 *
	 * @return void
	 */
	public function admin_head() {
		$order_id = '';
		$settings = self::get_pricing_settings();
		if (isset($settings['enable_admin_new_order_item']) && 'yes' == $settings['enable_admin_new_order_item'] ) { 
			$get = wwp_get_get_data('post_type');
			if (is_admin() && ( ( 'shop_order' == get_post_type(get_the_ID()) || 'shop_order' == $get ) || ( isset($get['page']) && 'wc-orders' == $get['page'] ) ) ) {
				?>
				<script type="text/javascript">
					jQuery(document).ready(function() {
						jQuery('#customer_user').on('change', function() {
							setTimeout( function () { 
								//this.form.submit();
								var postElement = document.getElementById('post');
								if (postElement) {
									postElement.submit();
								} else {
									jQuery(".save_order").click();
								}
							}, 3000);
						});
					});
				</script>
				<?php 
				if (isset($_REQUEST['post']) ) {
					$order_id = sanitize_text_field($_REQUEST['post']);
				} elseif (isset($_REQUEST['order_id']) ) {
					$order_id = sanitize_text_field($_REQUEST['order_id']);
				} elseif (isset($_REQUEST['page'], $_REQUEST['id']) && 'wc-orders' == sanitize_text_field($_REQUEST['page']) ) {
					$order_id =sanitize_text_field($_REQUEST['id']);
				}

				$order = wc_get_order($order_id);
				if (! $order ) {
					return;
				}
					
				if (! is_wholesaler_user($order->get_user_id()) ) {
					return;
				}
				?>
				<style>
					.woocommerce_order_items td.item_cost, .woocommerce_order_items th.item_cost.sortable {
						display: none;
					}
				</style>
				<?php 
			}
		}
	}

	/**
	 * Determines if the dependency for this service is met.
	 * This service should only run in the WordPress administration area.
	 *
	 * @return bool True if the service should be registered, false otherwise.
	 */
	public static function resolveDependency() {
		return is_admin();
	}
}
