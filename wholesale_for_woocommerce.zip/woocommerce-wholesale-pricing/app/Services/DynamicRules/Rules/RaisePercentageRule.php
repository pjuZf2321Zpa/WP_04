<?php
/**
 * Raise Price (Percentage) dynamic rule runtime.
 *
 * Applies compounded percentage raises on top of already-discounted
 * wholesale prices via existing plugin price filters.
 *
 * Group pricing builds its own price HTML (tire_*) and skips wwp_change_price,
 * so this class also adjusts woocommerce_get_price_html after WWP's display.
 *
 * @package WooCommerceWholesalePricing\App\Services\DynamicRules\Rules
 */

namespace WooCommerceWholesalePricing\App\Services\DynamicRules\Rules;

use WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMatcher;

/**
 * Class RaisePercentageRule
 */
class RaisePercentageRule {

	const RULE_TYPE = 'raise-percentage';

	/**
	 * Product IDs already raised via wwp_change_price this request.
	 *
	 * @var array<int, bool>
	 */
	private static $raised_via_change_price = array();

	/**
	 * Product IDs already raised via get_price this request.
	 *
	 * @var array<int, bool>
	 */
	private static $raised_via_get_price = array();

	/**
	 * Temporarily skip raise (e.g. when reading pre-raise wholesale price for HTML).
	 *
	 * @var bool
	 */
	private static $suppress_raise = false;

	/**
	 * Constructor — register hooks only.
	 */
	public function __construct() {
		add_filter( 'wwp_change_price', array( $this, 'filter_change_price' ), 20, 2 );
		add_filter( 'wwp_override_product_price_cart_price', array( $this, 'filter_cart_price' ), 20, 2 );
		add_filter( 'woocommerce_product_get_price', array( $this, 'filter_get_price' ), 250, 2 );
		add_filter( 'woocommerce_product_variation_get_price', array( $this, 'filter_get_price' ), 250, 2 );
		add_filter( 'wwp_wholesale_price_on_product_page', array( $this, 'filter_display_price' ), 20, 2 );
		// After CartService wwp_change_product_price_display @ 200 (group/tier HTML bypasses get_price).
		add_filter( 'woocommerce_get_price_html', array( $this, 'filter_price_html' ), 210, 2 );
		add_filter( 'woocommerce_cart_item_price', array( $this, 'filter_cart_item_price_html' ), 210, 2 );

		add_action( 'wwp_dynamic_rule_save', array( RuleMatcher::class, 'clear_cache' ) );
	}

	/**
	 * After simple wholesale change_price().
	 *
	 * @param float             $price   Wholesale price.
	 * @param \WC_Product|false $product Product (may be false if variation_id was 0).
	 * @return float
	 */
	public function filter_change_price( $price, $product ) {
		if ( ! $product instanceof \WC_Product ) {
			return $price;
		}

		$new_price = $this->apply_raise( $price, $product );
		if ( (float) $new_price !== (float) $price ) {
			self::$raised_via_change_price[ (int) $product->get_id() ] = true;
		}

		return $new_price;
	}

	/**
	 * After cart wholesale price is computed.
	 *
	 * @param float $price Cart item price.
	 * @param array $item  Cart item.
	 * @return float
	 */
	public function filter_cart_price( $price, $item ) {
		$product = null;

		if ( is_array( $item ) && isset( $item['data'] ) && $item['data'] instanceof \WC_Product ) {
			$product = $item['data'];
		}

		if ( ! $product instanceof \WC_Product ) {
			return $price;
		}

		return $this->apply_raise( $price, $product );
	}

	/**
	 * Catch-all for tier/group/variable paths that bypass wwp_change_price.
	 *
	 * @param float       $price   Product price.
	 * @param \WC_Product $product Product.
	 * @return float
	 */
	public function filter_get_price( $price, $product ) {
		if ( self::$suppress_raise ) {
			return $price;
		}

		if ( ! $product instanceof \WC_Product ) {
			return $price;
		}

		$product_id = (int) $product->get_id();

		// Already raised on the simple change_price path — avoid double raise.
		if ( ! empty( self::$raised_via_change_price[ $product_id ] ) ) {
			return $price;
		}

		// Already raised via get_price this request.
		if ( ! empty( self::$raised_via_get_price[ $product_id ] ) ) {
			return $price;
		}

		$new_price = $this->apply_raise( $price, $product );

		if ( (float) $new_price !== (float) $price ) {
			self::$raised_via_get_price[ $product_id ] = true;
		}

		return $new_price;
	}

	/**
	 * Wholesale price HTML display parity (role-based simple_wholesale_product_price_html).
	 *
	 * @param float       $price   Display wholesale price.
	 * @param \WC_Product $product Product.
	 * @return float
	 */
	public function filter_display_price( $price, $product ) {
		if ( ! $product instanceof \WC_Product ) {
			return $price;
		}

		$product_id = (int) $product->get_id();

		if ( ! empty( self::$raised_via_change_price[ $product_id ] ) || ! empty( self::$raised_via_get_price[ $product_id ] ) ) {
			return $price;
		}

		return $this->apply_raise( $price, $product );
	}

	/**
	 * Fix shop/product HTML when WWP group/tier display bypasses get_price raise.
	 *
	 * @param string      $html    Price HTML.
	 * @param \WC_Product $product Product.
	 * @return string
	 */
	public function filter_price_html( $html, $product ) {
		return $this->maybe_raise_wholesale_html( $html, $product );
	}

	/**
	 * Fix cart line price HTML for the same group/tier bypass.
	 *
	 * @param string $html Price HTML.
	 * @param array  $item Cart item.
	 * @return string
	 */
	public function filter_cart_item_price_html( $html, $item ) {
		$product = null;
		if ( is_array( $item ) && isset( $item['data'] ) && $item['data'] instanceof \WC_Product ) {
			$product = $item['data'];
		}
		return $this->maybe_raise_wholesale_html( $html, $product );
	}

	/**
	 * If HTML is a WWP wholesale block and a raise applies, swap the displayed New price.
	 *
	 * @param string           $html    Price HTML.
	 * @param \WC_Product|null $product Product.
	 * @return string
	 */
	private function maybe_raise_wholesale_html( $html, $product ) {
		if ( ! $product instanceof \WC_Product || ! is_string( $html ) || '' === $html ) {
			return $html;
		}

		if ( false === strpos( $html, 'wwp-wholesale-pricing-details' ) ) {
			return $html;
		}

		$matched = RuleMatcher::get_matching_rules( self::RULE_TYPE, $product );
		if ( empty( $matched ) ) {
			return $html;
		}

		// Read wholesale/group price without our raise.
		self::$suppress_raise = true;
		$wholesale            = $product->get_price();
		self::$suppress_raise = false;

		if ( ! is_numeric( $wholesale ) || (float) $wholesale <= 0 ) {
			return $html;
		}

		if ( ! RuleMatcher::has_wholesale_discount( $wholesale, $product ) ) {
			return $html;
		}

		$raised = $this->compound_raise( (float) $wholesale, $matched );
		if ( abs( $raised - (float) $wholesale ) < 0.0001 ) {
			return $html;
		}

		$display_old = $this->price_for_display( $product, (float) $wholesale );
		$display_new = $this->price_for_display( $product, $raised );

		$old_html = wc_price( $display_old );
		$new_html = wc_price( $display_new );

		if ( $old_html === $new_html || false === strpos( $html, $old_html ) ) {
			return $html;
		}

		// Replace the wholesale ("New") amount once; leave struck retail alone.
		return preg_replace( '/' . preg_quote( $old_html, '/' ) . '/', $new_html, $html, 1 );
	}

	/**
	 * Match tax display context used by WWP tire HTML.
	 *
	 * @param \WC_Product $product Product.
	 * @param float       $price   Ex-tax style price.
	 * @return float
	 */
	private function price_for_display( $product, $price ) {
		$incl = ( ( is_shop() || is_product() || is_product_category() ) && 'incl' === get_option( 'woocommerce_tax_display_shop' ) )
			|| ( ( is_cart() || is_checkout() ) && 'incl' === get_option( 'woocommerce_tax_display_cart' ) );

		if ( $incl && function_exists( 'wwp_get_price_including_tax' ) ) {
			return (float) wwp_get_price_including_tax( $product, array( 'price' => $price ) );
		}

		if ( function_exists( 'wc_get_price_excluding_tax' ) ) {
			return (float) wc_get_price_excluding_tax( $product, array( 'price' => $price ) );
		}

		return (float) $price;
	}

	/**
	 * Match raise-percentage rules and compound the raise onto $price.
	 *
	 * @param float       $price   Discounted wholesale price.
	 * @param \WC_Product $product Product.
	 * @return float
	 */
	private function apply_raise( $price, $product ) {
		if ( self::$suppress_raise ) {
			return $price;
		}

		if ( ! is_numeric( $price ) || (float) $price <= 0 ) {
			return $price;
		}

		if ( ! RuleMatcher::has_wholesale_discount( $price, $product ) ) {
			return $price;
		}

		$matched = RuleMatcher::get_matching_rules( self::RULE_TYPE, $product );

		if ( empty( $matched ) ) {
			return $price;
		}

		$raised = $this->compound_raise( (float) $price, $matched );

		/**
		 * Filter final price after Raise Price (Percentage) rules.
		 *
		 * @since 3.2.0
		 * @param float       $raised  Raised price.
		 * @param float       $price   Original discounted price.
		 * @param \WC_Product $product Product.
		 * @param array[]     $matched Matched rules.
		 */
		return apply_filters( 'wwp_dynamic_rule_raise_percentage_price', $raised, $price, $product, $matched );
	}

	/**
	 * Compound percentage increases from matched rules.
	 *
	 * @param float   $price   Base discounted price.
	 * @param array[] $matched Matched rules.
	 * @return float
	 */
	private function compound_raise( $price, array $matched ) {
		$raised = (float) $price;
		foreach ( $matched as $rule ) {
			$increase = isset( $rule['price_increase'] ) ? absint( $rule['price_increase'] ) : 0;
			if ( $increase < 1 ) {
				continue;
			}
			$raised = $raised * ( 1 + ( $increase / 100 ) );
		}
		return $raised;
	}
}
