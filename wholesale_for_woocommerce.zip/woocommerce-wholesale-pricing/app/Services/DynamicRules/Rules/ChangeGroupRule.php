<?php
/**
 * Change Group dynamic rule runtime.
 *
 * Moves a customer from selected source groups into a destination group when
 * a spending, order-count, or registration-age condition is met. Optionally
 * emails the customer with hardcoded copy (subject/body are filterable).
 *
 * @package WooCommerceWholesalePricing\App\Services\DynamicRules\Rules
 */

namespace WooCommerceWholesalePricing\App\Services\DynamicRules\Rules;

use WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMatcher;
use WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMetaHelper;

/**
 * Class ChangeGroupRule
 */
class ChangeGroupRule {

	const RULE_TYPE = 'change-group';

	const CRON_HOOK = 'wwp_dr_change_group_daily';

	/**
	 * Users already evaluated in this request (prevents double-move).
	 *
	 * @var array<int, bool>
	 */
	private static $evaluated_users = array();

	/**
	 * Constructor — register hooks only.
	 */
	public function __construct() {
		add_action( 'woocommerce_thankyou', array( $this, 'handle_order' ), 30, 1 );
		add_action( 'woocommerce_order_status_processing', array( $this, 'handle_order' ), 30, 1 );
		add_action( 'woocommerce_order_status_completed', array( $this, 'handle_order' ), 30, 1 );

		add_action( 'init', array( $this, 'register_cron' ) );
		add_action( self::CRON_HOOK, array( $this, 'run_registration_rules' ) );

		add_action( 'wwp_dynamic_rule_save', array( RuleMatcher::class, 'clear_cache' ) );
	}

	/**
	 * Evaluate order-based change-group rules for the order customer.
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public function handle_order( $order_id ) {
		if ( ! $order_id || ! function_exists( 'wc_get_order' ) ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		$user_id = (int) $order->get_user_id();
		if ( $user_id < 1 ) {
			return;
		}

		$this->evaluate_user( $user_id, false );
	}

	/**
	 * Schedule the daily registration-age check.
	 *
	 * @return void
	 */
	public function register_cron() {
		if ( ! function_exists( 'wp_next_scheduled' ) ) {
			return;
		}

		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time(), 'daily', self::CRON_HOOK );
		}
	}

	/**
	 * Daily cron: evaluate days_since_registration rules.
	 *
	 * @return void
	 */
	public function run_registration_rules() {
		if ( ! RuleMetaHelper::is_groups_enabled() ) {
			return;
		}

		$rules = $this->get_registration_rules();
		if ( empty( $rules ) ) {
			return;
		}

		$user_ids = array();
		foreach ( $rules as $rule ) {
			$source_ids = $this->get_source_group_ids( $rule );
			foreach ( $source_ids as $group_id ) {
				foreach ( $this->get_group_members( $group_id ) as $member_id ) {
					$user_ids[ $member_id ] = true;
				}
			}
		}

		foreach ( array_keys( $user_ids ) as $user_id ) {
			$this->evaluate_user( (int) $user_id, true );
		}
	}

	/**
	 * Evaluate published change-group rules for a customer.
	 *
	 * @param int  $user_id            User ID.
	 * @param bool $registration_only Whether to run only days_since_registration rules.
	 * @return void
	 */
	private function evaluate_user( $user_id, $registration_only ) {
		$user_id = absint( $user_id );
		if ( $user_id < 1 ) {
			return;
		}

		if ( ! empty( self::$evaluated_users[ $user_id ] ) ) {
			return;
		}
		self::$evaluated_users[ $user_id ] = true;

		if ( ! RuleMetaHelper::is_groups_enabled() ) {
			return;
		}

		foreach ( RuleMatcher::get_published_rules( self::RULE_TYPE ) as $rule ) {
			$condition = isset( $rule['condition'] ) ? $rule['condition'] : '';
			$is_reg    = ( 'days_since_registration' === $condition );

			if ( $registration_only && ! $is_reg ) {
				continue;
			}
			if ( ! $registration_only && $is_reg ) {
				continue;
			}

			$this->maybe_apply_rule( $user_id, $rule );
		}
	}

	/**
	 * Apply a single rule if the customer matches source group + threshold.
	 *
	 * @param int   $user_id User ID.
	 * @param array $rule    Rule meta.
	 * @return void
	 */
	private function maybe_apply_rule( $user_id, array $rule ) {
		
		$rule_id = isset( $rule['_post_id'] ) ? absint( $rule['_post_id'] ) : 0;
		if ( $rule_id && get_user_meta( $user_id, $this->applied_meta_key( $rule_id ), true ) ) {
			return;
		}

		$to_group = isset( $rule['move_to_group'] ) ? absint( $rule['move_to_group'] ) : 0;
		if ( $to_group < 1 ) {
			return;
		}

		$source_ids = $this->get_source_group_ids( $rule );
		if ( empty( $source_ids ) ) {
			return;
		}

		$from_group = $this->get_user_source_group( $user_id, $source_ids );
		if ( ! $from_group ) {
			return;
		}

		if ( $from_group === $to_group ) {
			return;
		}

		if ( ! $this->condition_met( $user_id, $rule ) ) {
			return;
		}

		$moved = $this->move_user( $user_id, $source_ids, $to_group, $rule_id );
		if ( ! $moved ) {
			return;
		}

		if ( isset( $rule['notify_customer'] ) && 'yes' === $rule['notify_customer'] ) {
			$this->send_notification( $user_id, $rule, $from_group, $to_group );
		}
	}

	/**
	 * Whether the rule condition meets the threshold.
	 *
	 * @param int   $user_id User ID.
	 * @param array $rule    Rule meta.
	 * @return bool
	 */
	private function condition_met( $user_id, array $rule ) {
		$condition = isset( $rule['condition'] ) ? $rule['condition'] : 'total_spent';
		$threshold = isset( $rule['threshold'] ) ? (float) $rule['threshold'] : 0;
		if ( $threshold <= 0 ) {
			return false;
		}

		$value = 0;

		switch ( $condition ) {
			case 'total_spent':
				$value = function_exists( 'wc_get_customer_total_spent' ) ? (float) wc_get_customer_total_spent( $user_id ) : 0;
				break;
			case 'yearly_order_value':
				$value = $this->get_paid_order_total( $user_id, strtotime( gmdate( 'Y-01-01 00:00:00' ) ) );
				break;
			case 'monthly_order_value':
				$value = $this->get_paid_order_total( $user_id, strtotime( gmdate( 'Y-m-01 00:00:00' ) ) );
				break;
			case 'no_of_orders':
				$value = function_exists( 'wc_get_customer_order_count' ) ? (float) wc_get_customer_order_count( $user_id ) : 0;
				break;
			case 'days_since_registration':
				$user = get_userdata( $user_id );
				if ( $user && ! empty( $user->user_registered ) ) {
					$registered = strtotime( $user->user_registered . ' GMT' );
					if ( $registered ) {
						$value = (int) floor( ( time() - $registered ) / DAY_IN_SECONDS );
					}
				}
				break;
			default:
				return false;
		}

		return $value >= $threshold;
	}

	/**
	 * Sum paid order totals for a customer on or after a timestamp.
	 *
	 * @param int $user_id User ID.
	 * @param int $after   Unix timestamp (inclusive).
	 * @return float
	 */
	private function get_paid_order_total( $user_id, $after ) {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return 0;
		}

		$statuses = function_exists( 'wc_get_is_paid_statuses' ) ? wc_get_is_paid_statuses() : array( 'processing', 'completed' );
		if ( ! in_array( 'processing', $statuses, true ) ) {
			$statuses[] = 'processing';
		}
		if ( ! in_array( 'completed', $statuses, true ) ) {
			$statuses[] = 'completed';
		}

		$orders = wc_get_orders(
			array(
				'customer_id' => $user_id,
				'status'      => $statuses,
				'date_created'=> '>=' . gmdate( 'Y-m-d H:i:s', (int) $after ),
				'limit'       => -1,
				'return'      => 'objects',
			)
		);

		$total = 0;
		foreach ( (array) $orders as $order ) {
			if ( $order instanceof \WC_Order ) {
				$total += (float) $order->get_total();
			}
		}

		return $total;
	}

	/**
	 * Move the user from source groups into the destination group.
	 *
	 * @param int   $user_id     User ID.
	 * @param int[] $source_ids  Source group IDs.
	 * @param int   $to_group    Destination group ID.
	 * @param int   $rule_id     Rule post ID.
	 * @return bool Whether the user was moved.
	 */
	private function move_user( $user_id, array $source_ids, $to_group, $rule_id ) {
		$user_id  = absint( $user_id );
		$to_group = absint( $to_group );

		foreach ( $source_ids as $group_id ) {
			$this->remove_user_from_group( $user_id, (int) $group_id );
		}

		$this->add_user_to_group( $user_id, $to_group );

		update_user_meta( $user_id, 'user_wwp_groupname', $to_group );
		update_user_meta( $user_id, 'add_in_wwp_group', 'true' );

		if ( $rule_id ) {
			update_user_meta( $user_id, $this->applied_meta_key( $rule_id ), time() );
		}

		/**
		 * Fires after a customer is moved by a Change Group dynamic rule.
		 *
		 * @since 3.2.0
		 * @param int   $user_id    User ID.
		 * @param int   $to_group   Destination group ID.
		 * @param int[] $source_ids Source group IDs.
		 * @param int   $rule_id    Rule post ID.
		 */
		do_action( 'wwp_dynamic_rule_change_group_moved', $user_id, $to_group, $source_ids, $rule_id );

		return true;
	}

	/**
	 * Remove a user from a group's `_add_users` list.
	 *
	 * @param int $user_id  User ID.
	 * @param int $group_id Group post ID.
	 * @return void
	 */
	private function remove_user_from_group( $user_id, $group_id ) {
		$members = $this->get_group_members( $group_id );
		$updated = array_values( array_diff( $members, array( absint( $user_id ) ) ) );
		if ( $updated === $members ) {
			return;
		}
		update_post_meta( $group_id, '_add_users', $updated );
		update_post_meta( $group_id, '_group_members_count', count( $updated ) );
	}

	/**
	 * Add a user to a group's `_add_users` list.
	 *
	 * @param int $user_id  User ID.
	 * @param int $group_id Group post ID.
	 * @return void
	 */
	private function add_user_to_group( $user_id, $group_id ) {
		$members = $this->get_group_members( $group_id );
		if ( in_array( absint( $user_id ), $members, true ) ) {
			return;
		}
		$members[] = absint( $user_id );
		update_post_meta( $group_id, '_add_users', $members );
		update_post_meta( $group_id, '_group_members_count', count( $members ) );
	}

	/**
	 * Source group IDs from the rule.
	 *
	 * @param array $rule Rule meta.
	 * @return int[]
	 */
	private function get_source_group_ids( array $rule ) {
		$ids = isset( $rule['applies_to_groups'] ) && is_array( $rule['applies_to_groups'] )
			? $rule['applies_to_groups']
			: array();

		return array_values( array_filter( array_map( 'absint', $ids ) ) );
	}

	/**
	 * Group IDs that currently include the user, limited to source groups.
	 *
	 * @param int   $user_id    User ID.
	 * @param int[] $source_ids Source group IDs.
	 * @return int Matching source group ID, or 0.
	 */
	private function get_user_source_group( $user_id, array $source_ids ) {
		$user_id = absint( $user_id );

		$current = absint( get_user_meta( $user_id, 'user_wwp_groupname', true ) );
		if ( $current && in_array( $current, $source_ids, true ) ) {
			return $current;
		}

		foreach ( $source_ids as $group_id ) {
			if ( in_array( $user_id, $this->get_group_members( $group_id ), true ) ) {
				return (int) $group_id;
			}
		}

		return 0;
	}

	/**
	 * Member user IDs stored on a group.
	 *
	 * @param int $group_id Group post ID.
	 * @return int[]
	 */
	private function get_group_members( $group_id ) {
		$members = get_post_meta( $group_id, '_add_users', true );
		if ( ! is_array( $members ) ) {
			return array();
		}

		return array_values( array_filter( array_map( 'absint', $members ) ) );
	}

	/**
	 * Published change-group rules that use days_since_registration.
	 *
	 * @return array[]
	 */
	private function get_registration_rules() {
		$out = array();
		foreach ( RuleMatcher::get_published_rules( self::RULE_TYPE ) as $rule ) {
			if ( isset( $rule['condition'] ) && 'days_since_registration' === $rule['condition'] ) {
				$out[] = $rule;
			}
		}
		return $out;
	}

	/**
	 * User meta key marking a rule as already applied.
	 *
	 * @param int $rule_id Rule post ID.
	 * @return string
	 */
	private function applied_meta_key( $rule_id ) {
		return '_wwp_dr_changed_group_' . absint( $rule_id );
	}

	/**
	 * Email the customer after a group move.
	 *
	 * @param int   $user_id     User ID.
	 * @param array $rule        Rule meta.
	 * @param int   $from_group  Previous group ID.
	 * @param int   $to_group    Destination group ID.
	 * @return void
	 */
	private function send_notification( $user_id, array $rule, $from_group, $to_group ) {
		$user = get_userdata( $user_id );
		if ( ! $user || empty( $user->user_email ) ) {
			return;
		}

		$old_group = get_the_title( $from_group );
		$new_group = get_the_title( $to_group );
		$site_name = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$first     = $user->first_name ? $user->first_name : $user->display_name;

		$subject = __( 'Your wholesale group has been updated', 'woocommerce-wholesale-pricing' );

		/**
		 * Filter Change Group notification subject.
		 *
		 * @since 3.2.0
		 * @param string   $subject     Email subject.
		 * @param \WP_User $user        User.
		 * @param array    $rule        Rule meta.
		 * @param int      $from_group Previous group ID.
		 * @param int      $to_group    Destination group ID.
		 */
		$subject = apply_filters( 'wwp_dynamic_rule_change_group_email_subject', $subject, $user, $rule, $from_group, $to_group );

		$body  = '<p>' . sprintf(
			/* translators: %s: first name */
			esc_html__( 'Hello %s,', 'woocommerce-wholesale-pricing' ),
			esc_html( $first )
		) . '</p>';
		$body .= '<p>' . sprintf(
			/* translators: 1: previous group name, 2: new group name, 3: site name */
			esc_html__( 'Your wholesale group has been updated from %1$s to %2$s on %3$s.', 'woocommerce-wholesale-pricing' ),
			esc_html( $old_group ? $old_group : (string) $from_group ),
			esc_html( $new_group ? $new_group : (string) $to_group ),
			esc_html( $site_name )
		) . '</p>';

		/**
		 * Filter Change Group notification body (HTML).
		 *
		 * @since 3.2.0
		 * @param string   $body        Email HTML body.
		 * @param \WP_User $user        User.
		 * @param array    $rule        Rule meta.
		 * @param int      $from_group Previous group ID.
		 * @param int      $to_group    Destination group ID.
		 */
		$body = apply_filters( 'wwp_dynamic_rule_change_group_email_body', $body, $user, $rule, $from_group, $to_group );

		$from_email = get_option( 'woocommerce_email_from_address' );
		$from_name  = get_option( 'woocommerce_email_from_name' );
		if ( ! $from_email ) {
			$from_email = get_option( 'admin_email' );
		}
		if ( ! $from_name ) {
			$from_name = $site_name;
		}

		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . $from_name . ' <' . $from_email . '>',
		);

		wp_mail( $user->user_email, $subject, $body, $headers );
	}
}
