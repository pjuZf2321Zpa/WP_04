<?php
/**
 * Add Tax Fee dynamic rule runtime (percentage and fixed).
 *
 * WooCommerce still calculates cart tax. Matching rules add extra tax on top
 * as a non-taxable cart fee for applicable products and audiences.
 *
 * @package WooCommerceWholesalePricing\App\Services\DynamicRules\Rules
 */

namespace WooCommerceWholesalePricing\App\Services\DynamicRules\Rules;

use WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMatcher;

/**
 * Class AddTaxFeeRule
 */
class AddTaxFeeRule {

	const TYPE_PERCENTAGE = 'add-tax-fee-percentage';

	const TYPE_FIXED = 'add-tax-fee-fixed';

	/**
	 * Constructor — register hooks only.
	 */
	public function __construct() {
		add_action( 'woocommerce_cart_calculate_fees', array( $this, 'add_fees' ), 20, 1 );
		add_action( 'wwp_dynamic_rule_save', array( RuleMatcher::class, 'clear_cache' ) );
	}

	/**
	 * Add extra tax as a cart fee after WooCommerce item taxes exist.
	 *
	 * @param \WC_Cart $cart Cart.
	 * @return void
	 */
	public function add_fees( $cart ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return;
		}

		if ( ! $cart instanceof \WC_Cart ) {
			return;
		}

		$extra = $this->calculate_extra_tax( $cart );
		if ( $extra <= 0 ) {
			return;
		}

		$label = $this->resolve_tax_fee_label( $cart );

		/**
		 * Filter Additional tax fee label.
		 *
		 * @since 3.2.0
		 * @param string   $label Fee label.
		 * @param float    $extra Extra tax amount.
		 * @param \WC_Cart $cart  Cart.
		 */
		$label = apply_filters( 'wwp_dynamic_rule_add_tax_fee_label', $label, $extra, $cart );

		$cart->add_fee( $label, $extra, false );
	}

	/**
	 * Resolve fee label from first matching Add Tax Fee rule.
	 *
	 * Falls back to "Additional Tax" when rule label is empty.
	 *
	 * @param \WC_Cart $cart Cart.
	 * @return string
	 */
	private function resolve_tax_fee_label( $cart ) {
		$default = __( 'Additional Tax', 'woocommerce-wholesale-pricing' );

		foreach ( $cart->get_cart() as $item ) {
			if ( empty( $item['data'] ) || ! $item['data'] instanceof \WC_Product ) {
				continue;
			}

			$product = $item['data'];
			$rules   = array_merge(
				RuleMatcher::get_matching_rules( self::TYPE_PERCENTAGE, $product ),
				RuleMatcher::get_matching_rules( self::TYPE_FIXED, $product )
			);

			foreach ( $rules as $rule ) {
				$label = isset( $rule['tax_label'] ) ? sanitize_text_field( (string) $rule['tax_label'] ) : '';
				if ( '' !== $label ) {
					return $label;
				}
			}
		}

		return $default;
	}

	/**
	 * Sum extra tax from matching percentage and fixed rules.
	 *
	 * @param \WC_Cart $cart Cart.
	 * @return float
	 */
	private function calculate_extra_tax( $cart ) {
		$percentage_extra = 0.0;
		$fixed_extra      = 0.0;
		$fixed_applied    = array();

		foreach ( $cart->get_cart() as $item ) {
			if ( empty( $item['data'] ) || ! $item['data'] instanceof \WC_Product ) {
				continue;
			}

			$product  = $item['data'];
			$line_tax = isset( $item['line_tax'] ) ? (float) $item['line_tax'] : 0.0;

			foreach ( RuleMatcher::get_matching_rules( self::TYPE_PERCENTAGE, $product ) as $rule ) {
				$percent = isset( $rule['tax_fee'] ) ? absint( $rule['tax_fee'] ) : 0;
				if ( $percent < 1 || $line_tax <= 0 ) {
					continue;
				}
				$percentage_extra += $line_tax * ( $percent / 100 );
			}

			foreach ( RuleMatcher::get_matching_rules( self::TYPE_FIXED, $product ) as $rule ) {
				$rule_id = isset( $rule['_post_id'] ) ? absint( $rule['_post_id'] ) : 0;
				if ( $rule_id && isset( $fixed_applied[ $rule_id ] ) ) {
					continue;
				}

				$amount = isset( $rule['tax_fee'] ) ? (float) $rule['tax_fee'] : 0;
				if ( $amount <= 0 ) {
					continue;
				}

				if ( $rule_id ) {
					$fixed_applied[ $rule_id ] = true;
				}

				$fixed_extra += $amount;
			}
		}

		$extra = $percentage_extra + $fixed_extra;

		/**
		 * Filter extra tax amount before it is added as a fee.
		 *
		 * @since 3.2.0
		 * @param float    $extra Extra tax amount.
		 * @param \WC_Cart $cart  Cart.
		 */
		return (float) apply_filters( 'wwp_dynamic_rule_add_tax_fee_amount', $extra, $cart );
	}
}
