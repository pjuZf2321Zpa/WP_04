<?php
/**
 * GroupAnnouncementService class.
 *
 * This service handles all backend logic for creating, deleting, and managing
 * announcements targeted at specific wholesale user groups using WordPress AJAX.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Service class for managing wholesale group announcements via AJAX.
 *
 * Implements the ServiceInterface contract.
 */
class GroupAnnouncementService implements ServiceInterface {

	/**
     * Constructor: Registers the necessary AJAX action hooks.
	 *
	 * @return void
     
	 */
	public function __construct() {
		// Hook for adding a new wholesale group announcement.
		add_action('wp_ajax_add_wholesale_announcement', array( $this, 'add' ));

		// Hook for deleting a wholesale group announcement.
		add_action('wp_ajax_delete_wholesale_announcement_data', array( $this, 'delete' ));

		// Hook for updating the read status of an announcement for the current user.
		add_action('wp_ajax_update_announcement_status', array( $this, 'update_status' ));

		// Hook for retrieving the content of a specific announcement.
		add_action('wp_ajax_wwp_get_announcement_content', array( $this, 'get_content' ));
	}

	/**
	 * Handles the AJAX request to add a new announcement to a wholesale group.
	 *
	 * Validates nonce and user capability. If successful, saves the announcement
	 * data to the group's post meta and flags all users in that group with a 'new announcement' meta.
	 *
	 * @action wp_ajax_add_wholesale_announcement
	 * @return void Sends a JSON response and terminates script execution via wp_die().
	 */
	public function add() {
		if (isset($_POST['announcement_nonce']) && wp_verify_nonce(sanitize_text_field($_POST['announcement_nonce']), 'wwp_announcement') ) {

			if (! current_user_can('manage_options') ) {
				wp_send_json_error(array( 'message' => __('Unauthorized', 'woocommerce-wholesale-pricing') ));
			}

			if (! empty($_POST['announcement_content']) && ! empty($_POST['announcement_subject']) && ! empty($_POST['post_id']) ) {
				$announcement_content = sanitize_text_field($_POST['announcement_content']);
				$announcement_subject = sanitize_text_field($_POST['announcement_subject']);
				$post_id = intval($_POST['post_id']);
				
				$announcement_date = current_time('mysql');
				
				$announcements = get_post_meta($post_id, '_wholesale_group_announcements', true);

				if (! is_array($announcements) ) {
					$announcements = array();
				}

				$announcement_key = count($announcements) + 1;

				$announcements[$announcement_key] = array(
					'content' => $announcement_content,
					'subject' => $announcement_subject,
					'date'    => $announcement_date,
					'key'     => $announcement_key,
				);

				update_post_meta($post_id, '_wholesale_group_announcements', $announcements);

				$users = get_post_meta($post_id, '_add_users', true);
				if (! empty($users) ) {
					foreach ( $users as $user_id ) {
						update_user_meta($user_id, 'wwp_new_announce', 'true');
					}
				}

				wp_send_json_success(
					array(
					'message'              => __('Announcement added successfully!', 'woocommerce-wholesale-pricing'),
					'announcement_content' => $announcement_content,
					'announcement_subject' => $announcement_subject,
					'announcement_date'    => date_i18n(get_option('date_format'), strtotime($announcement_date)),
					'announcement_author'  => get_option('admin_email'),
					'announcement_key'     => $announcement_key,
					) 
				);
			} else {
				wp_send_json_error(array( 'message' => __('Missing fields', 'woocommerce-wholesale-pricing') ));
			}
		} else {
			wp_send_json_error(array( 'message' => __('Invalid nonce', 'woocommerce-wholesale-pricing') ));
		}

		wp_die();
	}

	/**
	 * Handles the AJAX request to delete a specific announcement from a wholesale group.
	 *
	 * Validates nonce, post ID, and user permission to edit the group post.
	 *
	 * @action wp_ajax_delete_wholesale_announcement_data
	 * @return void Sends a JSON response and terminates script execution via wp_die().
	 */
	public function delete() {

		if (isset($_POST['announcement_nonce']) && wp_verify_nonce(sanitize_text_field($_POST['announcement_nonce']), 'wwp_announcement') ) {

			if (isset($_POST['post_id']) && is_numeric($_POST['post_id']) && isset($_POST['announcement_index']) ) {
				$post_id = intval($_POST['post_id']);
				$announcement_index = intval($_POST['announcement_index']);

				if (! current_user_can('edit_post', $post_id) ) {
					wp_send_json_error(array( 'message' => __('You do not have permission to delete this announcement.', 'woocommerce-wholesale-pricing') ));
				}

				$announcements = get_post_meta($post_id, '_wholesale_group_announcements', true);

				if (is_array($announcements) && isset($announcements[$announcement_index]) ) {

					unset($announcements[$announcement_index]);

					update_post_meta($post_id, '_wholesale_group_announcements', $announcements);

					wp_send_json_success(array( 'message' => __('Announcement deleted successfully.', 'woocommerce-wholesale-pricing') ));
				} else {
					wp_send_json_error(array( 'message' => __('Invalid announcement data.', 'woocommerce-wholesale-pricing') ));
				}
			} else {
				wp_send_json_error(array( 'message' => __('Invalid announcement ID or index.', 'woocommerce-wholesale-pricing') ));
			}
		} else {
			wp_send_json_error(array( 'message' => __('Invalid nonce.', 'woocommerce-wholesale-pricing') ));
		}

		wp_die();
	}

	/**
	 * Handles the AJAX request to mark a specific announcement as "read" for the current user.
	 *
	 * @action wp_ajax_update_announcement_status
	 * @return void Sends a JSON response and terminates script execution via wp_die().
	 */
	public function update_status() {

		if (! empty(get_current_user_id()) ) {

			if (isset($_POST['nonce']) && wp_verify_nonce(sanitize_text_field($_POST['nonce']), 'wwp_user_annoucement') ) {  

				$current_user_id = get_current_user_id();
				if (isset($_POST['announcement_index']) ) {
					
					$announcement_index = intval($_POST['announcement_index']);

					$user_group_id = get_user_meta($current_user_id, 'user_wwp_groupname', true);

					
					$users = get_post_meta($user_group_id, '_add_users', true);

					if (! empty($users) && is_array($users) ) {
					
						if (in_array($current_user_id, $users) ) {
							
							update_user_meta($current_user_id, 'wwp_read_announcement_' . $announcement_index, 'true');

							wp_send_json_success(
								array(
								'message' => __('Announcement status updated successfully.', 'woocommerce-wholesale-pricing'),
								'announcement_index' => $announcement_index,
								)
							);
						}
					} else {
						wp_send_json_error('No users found in this group.');
					}
				} else {
					wp_send_json_error('Invalid or missing Announcement.');
				}
			} else {
				wp_send_json_error('Security Error.');
			}
		} else {
			wp_send_json_error('User not logged in.');
		}
		wp_die();
	}

	/**
	 * Handles the AJAX request to retrieve the subject and content of a specific announcement.
	 *
	 * Only works for logged-in users who belong to the relevant wholesale group.
	 *
	 * @action wp_ajax_wwp_get_announcement_content
	 * @return void Sends a JSON response with announcement content or an error, then terminates script execution via wp_die().
	 */
	public function get_content() {
		if (! is_user_logged_in() ) {
			wp_send_json_error('User not logged in.');
		}

		if (isset($_POST['nonce']) && wp_verify_nonce(sanitize_text_field($_POST['nonce']), 'wwp_user_annoucement') ) {  

			$user_id = get_current_user_id();
			$user_group = get_user_meta($user_id, 'add_in_wwp_group', true);

			if (!empty($user_group) && 'true' == $user_group) {
				$group_id = get_user_meta($user_id, 'user_wwp_groupname', true);
				$group_announcements = get_post_meta($group_id, '_wholesale_group_announcements', true); 

				if (!empty($group_announcements) && is_array($group_announcements)) {
					$announcement_index = isset($_POST['announcement_index']) ? intval($_POST['announcement_index']) : 0;

					if (isset($group_announcements[$announcement_index])) {
						$announcement = $group_announcements[$announcement_index];

						wp_send_json_success(
							array(
							'subject' => $announcement['subject'],
							'content' => $announcement['content'], 
							)
						);
					} else {
						wp_send_json_error('Invalid announcement index.');
					}
				}
			}
		} else {
			wp_send_json_error('Security Error.');
		}
		wp_send_json_error('No announcements available.');
	}

	/**
	 * Determines if the service's dependencies are met.
	 *
	 * This service is only required to run within the WordPress admin context,
	 * as the AJAX handlers are primarily for managing group settings (admin)
	 * and user interactions usually require a logged-in user.
	 *
	 * @return bool True if the service should be initialized, false otherwise.
	 */
	public static function resolveDependency() {
		return is_admin();
	}
}
