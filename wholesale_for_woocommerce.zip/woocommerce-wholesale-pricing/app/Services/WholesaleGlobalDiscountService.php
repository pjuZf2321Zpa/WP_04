<?php
/**
 * Read and update global wholesale role discounts and tier pricing.
 *
 * @package WooCommerceWholesalePricing\App\Services
 */

namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\RoleDiscountPatchNormalizer;
use WooCommerceWholesalePricing\App\Providers\WholesaleOption;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;
use WooCommerceWholesalePricing\App\Services\WholesaleUserRoleService;

/**
 * Manages wholesale_multi_user_pricing and global tier_pricing in pricing options.
 */
class WholesaleGlobalDiscountService {

	/**
	 * Get formatted global discount settings exposed to the ability API.
	 *
	 * @return array<string, mixed>
	 */
	public function get_settings() {
		$multiuser = $this->get_raw_multiuser_pricing();
		$pricing   = $this->get_raw_pricing_options();
		$tier_raw  = isset( $pricing['tier_pricing'] ) && is_array( $pricing['tier_pricing'] )
			? $pricing['tier_pricing']
			: array();

		return array(
			'multiuser_option_key' => WholesaleOption::MULTIUSER_PRICING_OPTION,
			'pricing_option_key'   => WholesaleOption::PRICING_OPTION,
			'role_discounts'       => $this->format_role_discounts( $multiuser ),
			'tier_pricing'         => $this->format_tier_pricing( $tier_raw ),
		);
	}

	/**
	 * Update global discount settings (partial merge).
	 *
	 * @param array<string, mixed> $patch Settings patch.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function update_settings( array $patch ) {
		if ( empty( $patch ) ) {
			return new \WP_Error(
				'wwp_global_discounts_missing_settings',
				__( 'Settings are required for update.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$unknown = array_diff(
			array_keys( $patch ),
			array( 'role_discounts', 'tier_pricing' )
		);
		if ( ! empty( $unknown ) ) {
			return new \WP_Error(
				'wwp_global_discounts_invalid_field',
				sprintf(
					/* translators: %s: comma-separated field names */
					__( 'Unknown global discount setting(s): %s', 'woocommerce-wholesale-pricing' ),
					implode( ', ', $unknown )
				),
				array( 'status' => 400 )
			);
		}

		$multiuser = $this->get_raw_multiuser_pricing();
		$pricing   = $this->get_raw_pricing_options();

		if ( isset( $patch['role_discounts'] ) ) {
			if ( ! is_array( $patch['role_discounts'] ) ) {
				return new \WP_Error(
					'wwp_global_discounts_invalid_role_discounts',
					__( 'role_discounts must be an array.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			$result = $this->apply_role_discounts( $multiuser, $patch['role_discounts'] );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
			$multiuser = $this->normalize_role_keyed_array( $result );
		}

		$pricing_updated   = false;
		$multiuser_updated = isset( $patch['role_discounts'] );

		if ( isset( $patch['tier_pricing'] ) ) {
			if ( ! is_array( $patch['tier_pricing'] ) ) {
				return new \WP_Error(
					'wwp_global_discounts_invalid_tier_pricing',
					__( 'tier_pricing must be an array.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			$tier_pricing_patch = RoleDiscountPatchNormalizer::filter_tier_pricing_patch( $patch['tier_pricing'] );

			if ( empty( $tier_pricing_patch ) ) {
				unset( $patch['tier_pricing'] );
			} else {
				$patch['tier_pricing'] = $tier_pricing_patch;
			}
		}

		if ( isset( $patch['tier_pricing'] ) ) {
			if ( ! isset( $pricing['tier_pricing'] ) || ! is_array( $pricing['tier_pricing'] ) ) {
				$pricing['tier_pricing'] = array();
			}

			$result = $this->apply_tier_pricing( $pricing['tier_pricing'], $patch['tier_pricing'], $multiuser );
			if ( is_wp_error( $result ) ) {
				return $result;
			}

			$pricing['tier_pricing'] = $this->normalize_role_keyed_array( $result['tier_pricing'] );
			$multiuser               = $this->normalize_role_keyed_array( $result['multiuser'] );
			$pricing_updated         = true;
			$multiuser_updated       = true;
		}

		if ( $multiuser_updated ) {
			WholesaleSettingsHelper::update_multiuser_pricing_settings( $multiuser );
			wp_cache_delete( WholesaleOption::MULTIUSER_PRICING_OPTION, 'options' );
		}

		if ( $pricing_updated ) {
			WholesaleSettingsHelper::update_pricing_settings( $pricing );
			wp_cache_delete( WholesaleOption::PRICING_OPTION, 'options' );
		}

		return $this->get_settings();
	}

	/**
	 * Snapshot raw stored values for undo.
	 *
	 * @return array<string, mixed>
	 */
	public function snapshot_settings() {
		return array(
			'multiuser_pricing' => $this->get_raw_multiuser_pricing(),
			'pricing_options'   => $this->get_raw_pricing_options(),
		);
	}

	/**
	 * Restore a full global discount settings snapshot.
	 *
	 * @param array<string, mixed> $snapshot Snapshot data.
	 * @return true|\WP_Error
	 */
	public function restore_settings( array $snapshot ) {
		if ( ! array_key_exists( 'multiuser_pricing', $snapshot ) || ! array_key_exists( 'pricing_options', $snapshot ) ) {
			return new \WP_Error(
				'wwp_global_discounts_restore_invalid_snapshot',
				__( 'Cannot restore global discount settings: invalid snapshot.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$multiuser = is_array( $snapshot['multiuser_pricing'] ) ? $snapshot['multiuser_pricing'] : array();
		$pricing   = is_array( $snapshot['pricing_options'] ) ? $snapshot['pricing_options'] : array();

		WholesaleSettingsHelper::update_multiuser_pricing_settings( $multiuser );
		WholesaleSettingsHelper::update_pricing_settings( $pricing );

		return true;
	}

	/**
	 * Format raw multiuser pricing into a more usable shape, resolving role IDs to slugs and normalizing role rows.
	 * 
	 * @param array<int|string, mixed> $multiuser Raw multiuser pricing.
	 * @return list<array<string, mixed>>
	 */
	private function format_role_discounts( array $multiuser ) {
		$roles     = $this->get_role_terms();
		$formatted = array();

		if ( empty( $roles ) ) {
			return $formatted;
		}

		foreach ( $roles as $role_term ) {
			$term_id = (int) $role_term->term_id;
			$entry   = array(
				'role_id'   => $term_id,
				'role_slug' => (string) $role_term->slug,
				'role_name' => (string) $role_term->name,
				'enabled'   => isset( $multiuser[ $term_id ] ) && is_array( $multiuser[ $term_id ] ),
			);

			if ( ! $entry['enabled'] ) {
				$formatted[] = $entry;
				continue;
			}

			$row = $multiuser[ $term_id ];
			$entry['discount_type']   = (string) ( isset( $row['discount_type'] ) ? $row['discount_type'] : 'percent' );
			$entry['wholesale_price'] = isset( $row['wholesale_price'] ) ? (string) $row['wholesale_price'] : '';
			$entry['min_quantity']    = isset( $row['min_quantity'] ) ? (int) $row['min_quantity'] : 1;
			$entry['min_subtotal']    = isset( $row['min_subtotal'] ) ? (string) $row['min_subtotal'] : '';
			$entry['exclude_categories'] = $this->format_exclude_categories(
				isset( $row['exclude_categories'] ) ? (array) $row['exclude_categories'] : array()
			);

			$formatted[] = $entry;
		}

		return $formatted;
	}

	/**
	 * Format raw tier pricing into a more usable shape, resolving role IDs to slugs and normalizing tier rows.
	 * 
	 * @param array<int|string, mixed> $tier_raw Raw tier pricing keyed by role term_id.
	 * @return list<array<string, mixed>>
	 */
	private function format_tier_pricing( array $tier_raw ) {
		$id_map    = $this->get_role_id_slug_map();
		$formatted = array();

		foreach ( $tier_raw as $role_id => $tiers ) {
			if ( ! is_array( $tiers ) || empty( $tiers ) ) {
				continue;
			}

			$term_id = (int) $role_id;
			$slug    = isset( $id_map[ $term_id ] ) ? $id_map[ $term_id ] : '';
			if ( '' === $slug ) {
				continue;
			}

			$formatted[] = array(
				'role_slug' => $slug,
				'tiers'     => $this->normalize_tier_rows( $tiers ),
			);
		}

		return $formatted;
	}

	/**
	 * Apply role discount patches, ensuring existing values are preserved when not explicitly overwritten, and validating input.
	 * 
	 * @param array<int|string, mixed> $multiuser      Multiuser pricing to update.
	 * @param list<array<string,mixed>> $role_discounts Role discount patches.
	 * @return array<int|string, mixed>|\WP_Error
	 */
	private function apply_role_discounts( array $multiuser, array $role_discounts ) {
		foreach ( $role_discounts as $item ) {
			if ( ! is_array( $item ) || empty( $item ) ) {
				continue;
			}

			$item     = $this->normalize_role_discount_item( $item );
			$resolved = $this->resolve_role_term( $item );
			if ( is_wp_error( $resolved ) ) {
				return $resolved;
			}

			$term_id = (int) $resolved['term_id'];
			$slug    = (string) $resolved['slug'];
			$stored  = isset( $multiuser[ $term_id ] ) && is_array( $multiuser[ $term_id ] )
				? $multiuser[ $term_id ]
				: array();

			$item = RoleDiscountPatchNormalizer::prune_role_discount_item( $item, $stored );

			if ( array_key_exists( 'enabled', $item ) && ! $this->is_enabled_value( $item['enabled'] ) ) {
				unset( $multiuser[ $term_id ] );
				continue;
			}

			$explicit_enable = array_key_exists( 'enabled', $item ) && $this->is_enabled_value( $item['enabled'] );
			$has_fields      = $explicit_enable
				|| isset( $item['discount_type'] )
				|| array_key_exists( 'wholesale_price', $item )
				|| isset( $item['min_quantity'] )
				|| array_key_exists( 'min_subtotal', $item )
				|| array_key_exists( 'exclude_categories', $item );

			if ( ! $has_fields ) {
				continue;
			}

			$is_new_row = ! isset( $multiuser[ $term_id ] ) || ! is_array( $multiuser[ $term_id ] );

			if ( $is_new_row ) {
				$multiuser[ $term_id ] = array();
			}

			$row = $multiuser[ $term_id ];

			if ( $is_new_row ) {
				$row = $this->apply_role_entry_defaults( $row, $item );
			}

			if ( isset( $item['discount_type'] ) ) {
				$type = sanitize_key( (string) $item['discount_type'] );
				if ( ! in_array( $type, array( 'percent', 'fixed' ), true ) ) {
					return new \WP_Error(
						'wwp_global_discounts_invalid_discount_type',
						__( 'discount_type must be percent or fixed.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$row['discount_type'] = $type;
			}

			if ( array_key_exists( 'wholesale_price', $item ) ) {
				$price = $item['wholesale_price'];
				if ( '' !== $price && null !== $price && ! is_numeric( $price ) ) {
					return new \WP_Error(
						'wwp_global_discounts_invalid_wholesale_price',
						__( 'wholesale_price must be numeric.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$row['wholesale_price'] = is_numeric( $price ) ? (string) $price : '';
			}

			if ( isset( $item['min_quantity'] ) ) {
				$min = (int) $item['min_quantity'];
				if ( $min < 1 ) {
					return new \WP_Error(
						'wwp_global_discounts_invalid_min_quantity',
						__( 'min_quantity must be at least 1.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$row['min_quatity'] = (string) $min;
			}

			if ( array_key_exists( 'min_subtotal', $item ) ) {
				$subtotal = $item['min_subtotal'];
				if ( '' !== $subtotal && null !== $subtotal && ! is_numeric( $subtotal ) ) {
					return new \WP_Error(
						'wwp_global_discounts_invalid_min_subtotal',
						__( 'min_subtotal must be numeric.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$row['min_subtotal'] = is_numeric( $subtotal ) ? (string) $subtotal : '';
			}

			if ( array_key_exists( 'exclude_categories', $item ) ) {
				$resolved_categories = $this->resolve_category_ids( $item['exclude_categories'] );
				if ( is_wp_error( $resolved_categories ) ) {
					return $resolved_categories;
				}
				$row['exclude_categories'] = $resolved_categories;
			}

			$include_exclude = array_key_exists( 'exclude_categories', $item )
				|| array_key_exists( 'exclude_categories', $row );
			$multiuser[ $term_id ] = $this->format_role_row_for_storage( $row, $slug, $include_exclude );
		}

		return $multiuser;
	}

	/**
	 * Apply tier pricing patches, ensuring role entries exist in multiuser pricing when needed.
	 * 
	 * @param array<int|string, mixed>  $tier_raw   Stored tier pricing.
	 * @param list<array<string,mixed>> $patches    Tier pricing patches.
	 * @param array<int|string, mixed>  $multiuser  Multiuser pricing (updated when tiers require an active role).
	 * @return array{tier_pricing: array<int|string, mixed>, multiuser: array<int|string, mixed>}|\WP_Error
	 */
	private function apply_tier_pricing( array $tier_raw, array $patches, array $multiuser ) {
		foreach ( $patches as $item ) {
			if ( ! is_array( $item ) || empty( $item ) ) {
				continue;
			}

			$resolved = $this->resolve_role_term( $item );
			if ( is_wp_error( $resolved ) ) {
				return $resolved;
			}

			$term_id = (int) $resolved['term_id'];
			$slug    = (string) $resolved['slug'];

			if ( ! array_key_exists( 'tiers', $item ) ) {
				continue;
			}

			$tiers = $item['tiers'];
			if ( ! is_array( $tiers ) ) {
				return new \WP_Error(
					'wwp_global_discounts_invalid_tiers',
					__( 'tiers must be an array.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			if ( empty( $tiers ) ) {
				unset( $tier_raw[ $term_id ] );
				continue;
			}

			$multiuser = $this->ensure_role_entry_for_tiers( $multiuser, $term_id, $slug );

			$stored_tiers = array();
			foreach ( $tiers as $tier ) {
				if ( ! is_array( $tier ) ) {
					continue;
				}

				$min   = isset( $tier['min'] ) ? $tier['min'] : '';
				$max   = isset( $tier['max'] ) ? $tier['max'] : '';
				$price = isset( $tier['price'] ) ? $tier['price'] : '';

				if ( '' === $min && '' === $max && '' === $price ) {
					continue;
				}

				if ( '' !== $min && ! is_numeric( $min ) ) {
					return new \WP_Error(
						'wwp_global_discounts_invalid_tier_min',
						__( 'Tier min must be numeric.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				if ( '' !== $max && ! is_numeric( $max ) ) {
					return new \WP_Error(
						'wwp_global_discounts_invalid_tier_max',
						__( 'Tier max must be numeric.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				if ( '' !== $price && ! is_numeric( $price ) ) {
					return new \WP_Error(
						'wwp_global_discounts_invalid_tier_price',
						__( 'Tier price must be numeric.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}

				$key = substr( md5( (string) wp_rand() ), 0, 10 );
				$stored_tiers[ $key ] = array(
					'min'   => is_numeric( $min ) ? (string) $min : '',
					'max'   => is_numeric( $max ) ? (string) $max : '',
					'price' => is_numeric( $price ) ? (string) $price : '',
				);
			}

			if ( empty( $stored_tiers ) ) {
				unset( $tier_raw[ $term_id ] );
			} else {
				$tier_raw[ $term_id ] = $stored_tiers;
			}
		}

		return array(
			'tier_pricing' => $tier_raw,
			'multiuser'    => $multiuser,
		);
	}

	/**
	 * Ensure role rows use the same shape as the admin settings save handler.
	 *
	 * @param array<string, mixed> $entry Existing role row.
	 * @param array<string, mixed> $item   Incoming patch.
	 * @return array<string, mixed>
	 */
	private function apply_role_entry_defaults( array $entry, array $item ) {
		if ( ! isset( $entry['discount_type'] ) && ! isset( $item['discount_type'] ) ) {
			$entry['discount_type'] = 'percent';
		}

		if ( ! isset( $entry['min_quatity'] ) && ! isset( $item['min_quantity'] ) ) {
			$entry['min_quatity'] = '1';
		}

		if ( ! array_key_exists( 'wholesale_price', $entry ) && ! array_key_exists( 'wholesale_price', $item ) ) {
			$entry['wholesale_price'] = '';
		}

		if ( ! array_key_exists( 'min_subtotal', $entry ) && ! array_key_exists( 'min_subtotal', $item ) ) {
			$entry['min_subtotal'] = '';
		}

		return $entry;
	}

	/**
	 * Match the admin settings.php section3 save shape exactly.
	 *
	 * @param array<string, mixed> $row              Role row before storage.
	 * @param string               $slug             Taxonomy slug.
	 * @param bool                 $include_exclude  Whether to persist exclude_categories.
	 * @return array<string, mixed>
	 */
	private function format_role_row_for_storage( array $row, $slug, $include_exclude = false ) {
		$discount_type = isset( $row['discount_type'] ) ? sanitize_key( (string) $row['discount_type'] ) : 'percent';
		if ( ! in_array( $discount_type, array( 'percent', 'fixed' ), true ) ) {
			$discount_type = 'percent';
		}

		$wholesale_price = array_key_exists( 'wholesale_price', $row ) ? $row['wholesale_price'] : '';
		$wholesale_price = is_numeric( $wholesale_price ) ? (string) $wholesale_price : '';

		$min_quatity = isset( $row['min_quatity'] ) ? $row['min_quatity'] : '1';
		$min_quatity = is_numeric( $min_quatity ) ? (string) max( 1, (int) $min_quatity ) : '1';

		$min_subtotal = array_key_exists( 'min_subtotal', $row ) ? $row['min_subtotal'] : '';
		$min_subtotal = is_numeric( $min_subtotal ) && '' !== (string) $min_subtotal ? (string) $min_subtotal : '';

		$stored = array(
			'slug'            => $slug,
			'discount_type'   => $discount_type,
			'wholesale_price' => $wholesale_price,
			'min_quatity'     => $min_quatity,
			'min_subtotal'    => $min_subtotal,
		);

		if ( $include_exclude ) {
			$stored['exclude_categories'] = isset( $row['exclude_categories'] ) && is_array( $row['exclude_categories'] )
				? array_map( 'intval', $row['exclude_categories'] )
				: array();
		}

		return $stored;
	}

	/**
	 * Drop invented slug values (e.g. global-pricing) when they do not match a wholesale role.
	 *
	 * @param array<string, mixed> $item Role discount patch item.
	 * @return array<string, mixed>
	 */
	private function normalize_role_discount_item( array $item ) {
		foreach ( array( 'role_slug', 'slug', 'role' ) as $key ) {
			if ( empty( $item[ $key ] ) ) {
				continue;
			}

			if ( null === $this->lookup_role_by_slug( (string) $item[ $key ] ) ) {
				unset( $item[ $key ] );
			}
		}

		return $item;
	}

	/**
	 * Resolve a wholesale role from ability input fields.
	 *
	 * @param array<string, mixed> $item Role discount patch item.
	 * @return array{term_id: int, slug: string}|\WP_Error
	 */
	private function resolve_role_term( array $item ) {
		foreach ( array( 'role_slug', 'slug', 'role' ) as $key ) {
			if ( empty( $item[ $key ] ) ) {
				continue;
			}

			$resolved = $this->lookup_role_by_slug( (string) $item[ $key ] );
			if ( null !== $resolved ) {
				return $resolved;
			}
		}

		if ( ! empty( $item['role_name'] ) ) {
			$resolved = $this->lookup_role_by_name( (string) $item['role_name'] );
			if ( null !== $resolved ) {
				return $resolved;
			}
		}

		if ( ! empty( $item['role_id'] ) && is_numeric( $item['role_id'] ) ) {
			$term = get_term( (int) $item['role_id'], $this->get_role_taxonomy() );
			if ( $term && ! is_wp_error( $term ) ) {
				return array(
					'term_id' => (int) $term->term_id,
					'slug'    => (string) $term->slug,
				);
			}
		}

		$identifier = '';
		foreach ( array( 'role_slug', 'slug', 'role', 'role_name', 'role_id' ) as $key ) {
			if ( ! empty( $item[ $key ] ) ) {
				$identifier = (string) $item[ $key ];
				break;
			}
		}

		if ( '' === $identifier ) {
			return new \WP_Error(
				'wwp_global_discounts_missing_role',
				__( 'Each role discount must include role_slug, slug, role_id, or role_name.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		return new \WP_Error(
			'wwp_global_discounts_invalid_role',
			sprintf(
				/* translators: %s: role identifier */
				__( 'Unknown wholesale role: %s', 'woocommerce-wholesale-pricing' ),
				$identifier
			),
			array( 'status' => 400 )
		);
	}

	/**
	 * Lookup a wholesale role by slug with various fallbacks (case-insensitive match, sanitize_key match, suffix match).
	 * 
	 * @param string $candidate Role slug candidate.
	 * @return array{term_id: int, slug: string}|null
	 */
	private function lookup_role_by_slug( $candidate ) {
		$candidate = trim( $candidate );
		if ( '' === $candidate ) {
			return null;
		}

		$candidate_key = sanitize_key( $candidate );

		foreach ( $this->get_role_terms() as $term ) {
			if ( $term->slug === $candidate || sanitize_key( (string) $term->slug ) === $candidate_key ) {
				return array(
					'term_id' => (int) $term->term_id,
					'slug'    => (string) $term->slug,
				);
			}
		}

		foreach ( $this->get_role_terms() as $term ) {
			if ( 0 === strcasecmp( (string) $term->name, $candidate ) ) {
				return array(
					'term_id' => (int) $term->term_id,
					'slug'    => (string) $term->slug,
				);
			}
		}

		if ( in_array( $candidate_key, array( 'wholesaler', 'default-wholesaler' ), true ) ) {
			foreach ( $this->get_role_terms() as $term ) {
				if ( WholesaleUserRoleService::DEFAULT_ROLE_SLUG === $term->slug ) {
					return array(
						'term_id' => (int) $term->term_id,
						'slug'    => (string) $term->slug,
					);
				}
			}
		}

		if ( '' !== $candidate_key ) {
			$suffix_matches = array();

			foreach ( $this->get_role_terms() as $term ) {
				$slug = (string) $term->slug;

				if ( str_ends_with( $slug, '_' . $candidate_key ) ) {
					$suffix_matches[] = $term;
				}
			}

			if ( 1 === count( $suffix_matches ) ) {
				return array(
					'term_id' => (int) $suffix_matches[0]->term_id,
					'slug'    => (string) $suffix_matches[0]->slug,
				);
			}
		}

		return null;
	}

	/**
	 * Lookup a wholesale role by display name (case-insensitive).
	 * 
	 * @param string $name Role display name.
	 * @return array{term_id: int, slug: string}|null
	 */
	private function lookup_role_by_name( $name ) {
		$name = trim( $name );
		if ( '' === $name ) {
			return null;
		}

		foreach ( $this->get_role_terms() as $term ) {
			if ( 0 === strcasecmp( (string) $term->name, $name ) ) {
				return array(
					'term_id' => (int) $term->term_id,
					'slug'    => (string) $term->slug,
				);
			}
		}

		return null;
	}

	/**
	 * Is the given value an enabled flag (boolean true, 1, '1', 'true', 'yes', 'on')?
	 * 
	 * @param mixed $value Enabled flag from ability input.
	 * @return bool
	 */
	private function is_enabled_value( $value ) {
		if ( is_bool( $value ) ) {
			return $value;
		}

		if ( is_numeric( $value ) ) {
			return (int) 1 === $value;
		}

		if ( is_string( $value ) ) {
			return in_array( strtolower( trim( $value ) ), array( '1', 'true', 'yes', 'on' ), true );
		}

		return false;
	}

	/**
	 * Global tier pricing only applies when the role is active in multiuser pricing.
	 *
	 * @param array<int|string, mixed> $multiuser Multiuser pricing.
	 * @param int                      $term_id   Role term ID.
	 * @param string                   $slug      Role slug.
	 * @return array<int|string, mixed>
	 */
	private function ensure_role_entry_for_tiers( array $multiuser, $term_id, $slug ) {
		$row = isset( $multiuser[ $term_id ] ) && is_array( $multiuser[ $term_id ] )
			? $multiuser[ $term_id ]
			: array();

		$row                     = $this->apply_role_entry_defaults( $row, array() );
		$multiuser[ $term_id ]   = $this->format_role_row_for_storage( $row, $slug, false );

		return $multiuser;
	}

	/**
	 * Normalize wholesale role term IDs to integers for option storage.
	 *
	 * @param array<int|string, mixed> $rows Role-keyed rows.
	 * @return array<int|string, mixed>
	 */
	private function normalize_role_keyed_array( array $rows ) {
		$normalized = array();

		foreach ( $rows as $role_id => $row ) {
			$key = is_numeric( $role_id ) ? (int) $role_id : $role_id;
			$normalized[ $key ] = $row;
		}

		return $normalized;
	}

	/**
	 * Format category term IDs for ability output, validating existence and skipping invalid entries.
	 * 
	 * @param array<int|string> $category_ids Category term IDs.
	 * @return list<array{id:int,slug:string,name:string}>
	 */
	private function format_exclude_categories( array $category_ids ) {
		$formatted = array();

		foreach ( $category_ids as $cat_id ) {
			$term = get_term( (int) $cat_id, 'product_cat' );
			if ( ! $term || is_wp_error( $term ) ) {
				continue;
			}

			$formatted[] = array(
				'id'   => (int) $term->term_id,
				'slug' => (string) $term->slug,
				'name' => (string) $term->name,
			);
		}

		return $formatted;
	}

	/**
	 * Resolve category identifiers (IDs or slugs) to term IDs, validating existence.
	 * 
	 * @param mixed $categories Category slugs or IDs.
	 * @return list<int>|\WP_Error
	 */
	private function resolve_category_ids( $categories ) {
		if ( ! is_array( $categories ) ) {
			return array();
		}

		$ids = array();

		foreach ( $categories as $category ) {
			if ( is_numeric( $category ) ) {
				$term = get_term( (int) $category, 'product_cat' );
			} else {
				$term = get_term_by( 'slug', sanitize_title( (string) $category ), 'product_cat' );
			}

			if ( ! $term || is_wp_error( $term ) ) {
				return new \WP_Error(
					'wwp_global_discounts_invalid_category',
					sprintf(
						/* translators: %s: category identifier */
						__( 'Unknown product category: %s', 'woocommerce-wholesale-pricing' ),
						(string) $category
					),
					array( 'status' => 400 )
				);
			}

			$ids[] = (int) $term->term_id;
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Normalize tier rows to ensure consistent keys and string values for storage.
	 * 
	 * @param array<int|string, mixed> $tiers Raw tier rows.
	 * @return list<array{min:string,max:string,price:string}>
	 */
	private function normalize_tier_rows( array $tiers ) {
		$normalized = array();

		foreach ( $tiers as $tier ) {
			if ( ! is_array( $tier ) ) {
				continue;
			}

			$normalized[] = array(
				'min'   => isset( $tier['min'] ) ? (string) $tier['min'] : '',
				'max'   => isset( $tier['max'] ) ? (string) $tier['max'] : '',
				'price' => isset( $tier['price'] ) ? (string) $tier['price'] : '',
			);
		}

		return $normalized;
	}

	/**
	 * Get raw multiuser pricing settings for snapshotting and patch application.
	 * 
	 * @return array<int|string, mixed>
	 */
	private function get_raw_multiuser_pricing() {
		$stored = WholesaleSettingsHelper::get_multiuser_pricing_settings();

		return is_array( $stored ) ? $stored : array();
	}

	/**
	 * Get raw pricing settings for snapshotting and patch application.
	 * 
	 * @return array<string, mixed>
	 */
	private function get_raw_pricing_options() {
		$stored = WholesaleSettingsHelper::get_pricing_settings();

		return is_array( $stored ) ? $stored : array();
	}

	/**
	 * Get the wholesale role taxonomy, allowing for environment override.
	 * 
	 * @return string
	 */
	private function get_role_taxonomy() {
		if ( function_exists( 'wwp_env' ) ) {
			$slug = (string) wwp_env()->get( 'role_taxonomy' );
			if ( '' !== $slug ) {
				return $slug;
			}
		}

		return 'wholesale_user_roles';
	}

	/**
	 * Get all wholesale role terms for resolving and formatting global discount settings.
	 * 
	 * @return list<\WP_Term>
	 */
	private function get_role_terms() {
		$terms = get_terms(
			array(
				'taxonomy'   => $this->get_role_taxonomy(),
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return array();
		}

		return $terms;
	}

	/**
	 * Get a map of role slugs to term IDs for resolving ability input.
	 * 
	 * @return array<string, int> slug => term_id
	 */
	private function get_role_slug_map() {
		$map = array();

		foreach ( $this->get_role_terms() as $term ) {
			$map[ $term->slug ] = (int) $term->term_id;
		}

		return $map;
	}

	/**
	 * Get a map of role term IDs to slugs for formatting tier pricing.
	 * 
	 * @return array<int, string> term_id => slug
	 */
	private function get_role_id_slug_map() {
		$map = array();

		foreach ( $this->get_role_terms() as $term ) {
			$map[ (int) $term->term_id ] = (string) $term->slug;
		}

		return $map;
	}
}
