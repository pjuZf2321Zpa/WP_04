<?php
/**
 * Programmatic CRUD for wholesale account request posts (wwp_requests).
 *
 * @package WooCommerceWholesalePricing\App\Services
 */

namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

/**
 * API-oriented service for wholesale registration requests.
 */
class WholesaleAccountRequestService {

	/**
	 * Request post type.
	 *
	 * @var string
	 */
	const POST_TYPE = 'wwp_requests';

	/**
	 * Valid request statuses.
	 *
	 * @var list<string>
	 */
	const STATUSES = array( 'waiting', 'active', 'rejected' );

	/**
	 * List account requests.
	 *
	 * @param array<string, mixed> $args Query args (status, per_page, page).
	 * @return array{requests: list<array<string, mixed>>, total: int}
	 */
	public function list_requests( array $args = array() ) {
		$per_page = max( 1, min( 100, (int) ( isset( $args['per_page'] ) ? $args['per_page'] : 20 ) ) );
		$page     = max( 1, (int) ( isset( $args['page'] ) ? $args['page'] : 1 ) );
		$status   = isset( $args['status'] ) ? sanitize_key( (string) $args['status'] ) : '';

		$query_args = array(
			'post_type'      => self::POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'orderby'        => 'ID',
			'order'          => 'DESC',
		);

		if ( '' !== $status && in_array( $status, self::STATUSES, true ) ) {
			$query_args['meta_query'] = array(
				array(
					'key'   => '_user_status',
					'value' => $status,
				),
			);
		}

		$query = new \WP_Query( $query_args );
		$items = array();

		foreach ( $query->posts as $post ) {
			if ( $post instanceof \WP_Post ) {
				$items[] = $this->format_request( (int) $post->ID );
			}
		}

		return array(
			'requests' => $items,
			'total'    => (int) $query->found_posts,
		);
	}

	/**
	 * Get a single request.
	 *
	 * @param int $request_id Request post ID.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function get_request( $request_id ) {
		$post = $this->resolve_post( $request_id );
		if ( is_wp_error( $post ) ) {
			return $post;
		}

		return $this->format_request( (int) $post->ID );
	}

	/**
	 * Update request status, role assignment, or rejection note.
	 *
	 * @param int                  $request_id Request post ID.
	 * @param array<string, mixed> $data       Update payload.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function update_request( $request_id, array $data ) {
		$post = $this->resolve_post( $request_id );
		if ( is_wp_error( $post ) ) {
			return $post;
		}

		if ( empty( $data ) ) {
			return new \WP_Error(
				'wwp_request_missing_data',
				__( 'Request data is required for update.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$user_id = (int) get_post_meta( $request_id, '_user_id', true );
		if ( $user_id <= 0 ) {
			return new \WP_Error(
				'wwp_request_missing_user',
				__( 'Request is not linked to a user.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$guard = $this->guard_mutable_user( $user_id );
		if ( is_wp_error( $guard ) ) {
			return $guard;
		}

		if ( isset( $data['role_slug'] ) ) {
			$role_slug = sanitize_key( (string) $data['role_slug'] );
			if ( '' !== $role_slug ) {
				update_post_meta( $request_id, 'user_role_set', $role_slug );
			}
		}

		if ( array_key_exists( 'rejected_note', $data ) ) {
			$note = sanitize_textarea_field( (string) $data['rejected_note'] );
			update_user_meta( $user_id, 'rejected_note', $note );
		}

		if ( isset( $data['status'] ) ) {
			$status = sanitize_key( (string) $data['status'] );
			if ( ! in_array( $status, self::STATUSES, true ) ) {
				return new \WP_Error(
					'wwp_request_invalid_status',
					__( 'Status must be waiting, active, or rejected.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			$role_slug = isset( $data['role_slug'] )
				? sanitize_key( (string) $data['role_slug'] )
				: (string) get_post_meta( $request_id, 'user_role_set', true );

			$result = $this->apply_status_change( $request_id, $user_id, $status, $role_slug );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		return $this->format_request( $request_id );
	}

	/**
	 * Approve a request (status active).
	 *
	 * @param int    $request_id Request post ID.
	 * @param string $role_slug  Optional wholesale role slug.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function approve_request( $request_id, $role_slug = '' ) {
		$payload = array( 'status' => 'active' );
		if ( '' !== $role_slug ) {
			$payload['role_slug'] = $role_slug;
		}

		return $this->update_request( $request_id, $payload );
	}

	/**
	 * Reject a request (status rejected).
	 *
	 * @param int    $request_id    Request post ID.
	 * @param string $rejected_note Optional rejection note.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function reject_request( $request_id, $rejected_note = '' ) {
		$payload = array( 'status' => 'rejected' );
		if ( '' !== $rejected_note ) {
			$payload['rejected_note'] = $rejected_note;
		}

		return $this->update_request( $request_id, $payload );
	}

	/**
	 * Permanently delete a request post.
	 *
	 * @param int $request_id Request post ID.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function delete_request( $request_id ) {
		$post = $this->resolve_post( $request_id );
		if ( is_wp_error( $post ) ) {
			return $post;
		}

		$user_id = (int) get_post_meta( $request_id, '_user_id', true );
		if ( $user_id > 0 ) {
			delete_user_meta( $user_id, '_user_status' );
		}

		$deleted = wp_delete_post( $request_id, true );
		if ( ! $deleted ) {
			return new \WP_Error(
				'wwp_request_delete_failed',
				__( 'Failed to delete account request.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		return array(
			'deleted'    => true,
			'request_id' => $request_id,
		);
	}

	/**
	 * Snapshot request state for undo.
	 *
	 * @param int $request_id Request post ID.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function snapshot_request( $request_id ) {
		$post = $this->resolve_post( $request_id );
		if ( is_wp_error( $post ) ) {
			return $post;
		}

		$user_id = (int) get_post_meta( $request_id, '_user_id', true );
		$user    = $user_id > 0 ? get_userdata( $user_id ) : false;

		return array(
			'request_id'            => $request_id,
			'post_title'            => (string) $post->post_title,
			'user_id'               => $user_id,
			'user_status'           => (string) get_post_meta( $request_id, '_user_status', true ),
			'user_role_set'         => (string) get_post_meta( $request_id, 'user_role_set', true ),
			'rejected_note'         => (string) get_user_meta( $user_id, 'rejected_note', true ),
			'approval_notification' => (string) get_post_meta( $request_id, '_approval_notification', true ),
			'user_roles'            => ( $user && ! empty( $user->roles ) ) ? (array) $user->roles : array(),
			'term_slugs'            => wp_list_pluck(
				wp_get_post_terms( $request_id, $this->get_role_taxonomy(), array( 'fields' => 'all' ) ),
				'slug'
			),
		);
	}

	/**
	 * Restore request snapshot after an update (does not re-fire approval/rejection hooks).
	 *
	 * @param array<string, mixed> $snapshot Snapshot data.
	 * @return true|\WP_Error
	 */
	public function restore_request( array $snapshot ) {
		$request_id = (int) ( isset( $snapshot['request_id'] ) ? $snapshot['request_id'] : 0 );
		if ( $request_id <= 0 ) {
			return new \WP_Error(
				'wwp_request_restore_invalid_snapshot',
				__( 'Cannot restore request: invalid snapshot.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$post = $this->resolve_post( $request_id );
		if ( is_wp_error( $post ) ) {
			return $post;
		}

		$user_id = (int) ( isset( $snapshot['user_id'] ) ? $snapshot['user_id'] : get_post_meta( $request_id, '_user_id', true ) );
		if ( $user_id <= 0 ) {
			return new \WP_Error(
				'wwp_request_missing_user',
				__( 'Request is not linked to a user.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$status   = sanitize_key( (string) ( isset( $snapshot['user_status'] ) ? $snapshot['user_status'] : 'waiting' ) );
		$role_set = sanitize_key( (string) ( isset( $snapshot['user_role_set'] ) ? $snapshot['user_role_set'] : '' ) );

		update_post_meta( $request_id, '_user_status', $status );
		update_post_meta( $request_id, 'user_role_set', $role_set );
		update_user_meta( $user_id, 'rejected_note', (string) ( isset( $snapshot['rejected_note'] ) ? $snapshot['rejected_note'] : '' ) );
		update_user_meta( $user_id, '_user_status', $status );

		$wp_user = new \WP_User( $user_id );
		foreach ( (array) $wp_user->roles as $role ) {
			$wp_user->remove_role( $role );
		}
		foreach ( (array) ( isset( $snapshot['user_roles'] ) ? $snapshot['user_roles'] : array() ) as $role ) {
			$wp_user->add_role( (string) $role );
		}

		$term_slugs = array_filter( array_map( 'strval', (array) ( isset( $snapshot['term_slugs'] ) ? $snapshot['term_slugs'] : array() ) ) );
		wp_set_object_terms( $request_id, $term_slugs, $this->get_role_taxonomy(), false );

		if ( class_exists( '\WC_Customer' ) ) {
			$customer = new \WC_Customer( $user_id );
			$customer->update_meta_data( '_user_status', $status );
			$customer->save();
		}

		if ( array_key_exists( 'approval_notification', $snapshot ) ) {
			update_post_meta( $request_id, '_approval_notification', (string) $snapshot['approval_notification'] );
		}

		return true;
	}

	/**
	 * Recreate a deleted request from a snapshot (undo delete).
	 *
	 * @param array<string, mixed> $snapshot Snapshot data.
	 * @return int|\WP_Error New request post ID.
	 */
	public function restore_deleted_request( array $snapshot ) {
		$user_id = (int) ( isset( $snapshot['user_id'] ) ? $snapshot['user_id'] : 0 );
		if ( $user_id <= 0 ) {
			return new \WP_Error(
				'wwp_request_restore_invalid_snapshot',
				__( 'Cannot restore deleted request: missing user id.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$request_id = wp_insert_post(
			array(
				'post_type'   => self::POST_TYPE,
				'post_title'  => (string) ( isset( $snapshot['post_title'] ) ? $snapshot['post_title'] : 'Restored request' ),
				'post_status' => 'publish',
			),
			true
		);

		if ( is_wp_error( $request_id ) ) {
			return $request_id;
		}

		update_post_meta( $request_id, '_user_id', $user_id );

		$restore_snapshot               = $snapshot;
		$restore_snapshot['request_id'] = $request_id;

		$result = $this->restore_request( $restore_snapshot );
		if ( is_wp_error( $result ) ) {
			wp_delete_post( $request_id, true );
			return $result;
		}

		return $request_id;
	}

	/**
	 * Format a request post into an array for API responses.
	 * 
	 * @param int $request_id Request post ID.
	 * @return array<string, mixed>
	 */
	private function format_request( $request_id ) {
		$post    = get_post( $request_id );
		$user_id = (int) get_post_meta( $request_id, '_user_id', true );
		$user    = $user_id > 0 ? get_userdata( $user_id ) : false;
		$roles   = wp_get_post_terms( $request_id, $this->get_role_taxonomy(), array( 'fields' => 'all' ) );
		$role    = ( ! is_wp_error( $roles ) && ! empty( $roles ) ) ? $roles[0]->name : '';

		return array(
			'id'            => $request_id,
			'title'         => $post ? (string) $post->post_title : '',
			'date'          => $post ? (string) $post->post_date : '',
			'status'        => (string) get_post_meta( $request_id, '_user_status', true ),
			'user_id'       => $user_id,
			'user_email'    => $user ? (string) $user->user_email : '',
			'display_name'  => $user ? (string) $user->display_name : '',
			'username'      => $user ? (string) $user->user_login : '',
			'current_role'  => ( $user && ! empty( $user->roles[0] ) ) ? (string) $user->roles[0] : '',
			'role_slug'     => (string) get_post_meta( $request_id, 'user_role_set', true ),
			'assigned_role' => $role,
			'rejected_note' => (string) get_user_meta( $user_id, 'rejected_note', true ),
		);
	}

	/**
	 * Resolve a request post by ID, returning an error if not found or invalid type.
	 * 
	 * @param int $request_id Request post ID.
	 * @return \WP_Post|\WP_Error
	 */
	private function resolve_post( $request_id ) {
		$post = get_post( $request_id );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return new \WP_Error(
				'wwp_request_not_found',
				__( 'Account request not found.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		return $post;
	}

	/**
	 * Guard against modifying users with elevated permissions (administrator/editor).
	 * 
	 * @param int $user_id User ID.
	 * @return true|\WP_Error
	 */
	private function guard_mutable_user( $user_id ) {
		if ( user_can( $user_id, 'edit_others_posts' ) ) {
			return new \WP_Error(
				'wwp_request_protected_user',
				__( 'Administrator or editor accounts cannot be modified through requests.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Apply approve/reject/waiting transitions.
	 *
	 * @param int    $request_id Request post ID.
	 * @param int    $user_id    Linked user ID.
	 * @param string $status     Target status.
	 * @param string $role_slug  Wholesale role slug.
	 * @return true|\WP_Error
	 */
	private function apply_status_change( $request_id, $user_id, $status, $role_slug = '' ) {
		$user = get_user( $user_id );
		if ( ! $user ) {
			return new \WP_Error(
				'wwp_request_user_not_found',
				__( 'Linked user no longer exists.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		$settings      = WholesaleSettingsHelper::get_pricing_settings();
		$user_role_set = $this->resolve_role_slug( $request_id, $role_slug, $settings );

		update_post_meta( $request_id, '_user_status', $status );
		update_user_meta( $user_id, '_user_status', $status );

		if ( ! class_exists( '\WC_Customer' ) ) {
			return new \WP_Error(
				'wwp_request_woocommerce_missing',
				__( 'WooCommerce is required to update account requests.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		$customer = new \WC_Customer( $user_id );
		$customer->update_meta_data( '_user_status', $status );
		$customer->save();

		$wp_user   = new \WP_User( $user_id );
		$term_list = wp_get_post_terms( $request_id, $this->get_role_taxonomy(), array( 'fields' => 'all' ) );
		$all_terms = get_terms(
			array(
				'taxonomy'   => $this->get_role_taxonomy(),
				'hide_empty' => false,
			)
		);

		if ( 'active' === $status ) {
			$wp_roles = new \WP_Roles();
			foreach ( $wp_roles->get_names() as $role_key => $role_name ) {
				$wp_user->remove_role( $role_key );
			}

			$wp_user->add_role( $user_role_set );

			if ( is_array( $term_list ) ) {
				foreach ( $term_list as $term_remove ) {
					wp_remove_object_terms( $request_id, $term_remove->slug, $this->get_role_taxonomy(), true );
				}
			}

			wp_set_object_terms( $request_id, $user_role_set, $this->get_role_taxonomy(), true );

			if ( 'sent' !== get_post_meta( $request_id, '_approval_notification', true ) ) {
				/**
				 * Wholesale user approval notification hook.
				 * 
				 * @since 3.1.0
				 */
				do_action( 'wwp_wholesale_user_request_approved', $user_id );
				update_post_meta( $request_id, '_approval_notification', 'sent' );
			}
		} elseif ( 'rejected' === $status ) {
			if ( is_array( $all_terms ) ) {
				foreach ( $all_terms as $term ) {
					$wp_user->remove_role( $term->slug );
				}
			}

			$wp_user->add_role( (string) get_option( 'default_role' ) );
			/**
			 * Wholesale user rejection notification hook.
			 * 
			 * @since 3.1.0
			 */
			do_action( 'wwp_wholesale_user_rejection_notification', $user_id );
		}

		return true;
	}

	/**
	 * Resolve the wholesale role slug to use for a request, based on the request, user, and settings.
	 * 
	 * @param int                  $request_id Request post ID.
	 * @param string               $role_slug  Requested role slug.
	 * @param array<string, mixed> $settings   Pricing settings.
	 * @return string
	 */
	private function resolve_role_slug( $request_id, $role_slug, array $settings ) {
		if ( '' !== $role_slug ) {
			return $role_slug;
		}

		$stored = (string) get_post_meta( $request_id, 'user_role_set', true );
		if ( '' !== $stored ) {
			return $stored;
		}

		if ( isset( $settings['default_multipe_wholesale_roles'] ) && '' !== $settings['default_multipe_wholesale_roles'] && 'multiple' === ( isset( $settings['wholesale_role'] ) ? $settings['wholesale_role'] : '' ) ) {
			return (string) $settings['default_multipe_wholesale_roles'];
		}

		return 'default_wholesaler';
	}

	/**
	 * Get the taxonomy name for wholesale user roles.
	 * 
	 * @return string
	 */
	private function get_role_taxonomy() {
		if ( function_exists( 'wwp_env' ) ) {
			$slug = (string) wwp_env()->get( 'role_taxonomy' );
			if ( '' !== $slug ) {
				return $slug;
			}
		}

		return 'wholesale_user_roles';
	}
}
