<?php
/**
 * CouponService class.
 *
 * Handles custom WooCommerce coupon restrictions based on wholesale user roles,
 * adds a custom settings tab to the coupon edit screen, and manages coupon
 * disabling based on global wholesale settings.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Service class responsible for managing wholesale-specific coupon logic.
 *
 * This includes adding custom fields to the coupon editor for role restrictions,
 * saving those restrictions, validating coupons against user roles, and globally
 * enabling/disabling coupons based on wholesale tier settings.
 *
 * @implements ServiceInterface 
 */
class CouponService implements ServiceInterface {


  

	/**
	 * Includes methods for retrieving general wholesale settings.
	 */
	use WholesaleSettings;

	/**
	 * Flag used to prevent infinite loops/recursion when checking if coupons are enabled.
	 *
	 * @var bool
	 */
	public $coupons_disabled;

	/**
	 * Constructor: Registers all necessary WordPress and WooCommerce hooks.
	 *
	 * Hooks cover admin area (coupon data tabs/panels/save) and frontend logic
	 * (coupon validation, global enabling/disabling, and free shipping logic).
	 *
	 * @return void
	 */
	public function __construct() {
		// Admin: Coupon editor custom fields
		add_filter('woocommerce_coupon_data_tabs', array( $this, 'data_tabs' ), 10, 1);
		add_action('woocommerce_coupon_data_panels', array( $this, 'data_panels' ));
		add_action('woocommerce_coupon_options_save', array( $this, 'options_save' ));

		// Frontend/Validation: Coupon behavior
		add_filter('woocommerce_coupons_enabled', array( $this, 'wwp_coupons_enabled' ), 10, 1);
		add_filter('woocommerce_coupon_is_valid', array( $this, 'woocommerce_coupon_is_valid' ), 10, 2);

		// apply free shipping with coupon discount in cart
		add_filter('woocommerce_package_rates', array( $this, 'free_shipping_coupon' ), 100);
	}

	/**
	 * Adds the "Wholesale" tab to the WooCommerce coupon editing screen in the admin area.
	 *
	 * @param  array $tabs Existing array of coupon data tabs.
	 * @return array Modified array of tabs including the 'wwp_wholesale' tab.
	 */
	public function data_tabs( $tabs ) {
		$tabs['wwp_wholesale'] = array( 
			'label'  => __('Wholesale', 'woocommerce-wholesale-pricing'), 
			'target' => 'wwp_wholesale_data', 
			'class'  => 'wwp_wholesale_data', 
		); 
		return $tabs; 
	}

	/**
	 * Displays the custom fields within the "Wholesale" coupon data panel.
	 * Outputs the HTML required for WooCommerce Admin settings fields.
	 *
	 * @return void
     
	 */
	public function data_panels() {
		global $post;
		$coupon_id = $post->ID;
		$roles     = array();
		$taxroles  =  get_terms(array( 'taxonomy' => wwp_env()->get('role_taxonomy'), 'hide_empty' => false ));
		if (! empty($taxroles) ) {
			foreach ( $taxroles as $key => $role ) {
				$roles[ $role->slug ] = $role->name;
			}
		}
		?>
		<div id="wwp_wholesale_data" class="panel woocommerce_options_panel">
			<?php 
			woocommerce_wp_checkbox( 
				array(
					'id' => 'wwp_coupon_enable',
					'label' => esc_html__('Enable Wholesale', 'woocommerce-wholesale-pricing'),
					'description' => esc_html__('Enable to restrict user roles for this coupons.', 'woocommerce-wholesale-pricing'),
				) 
			); 
			
			woocommerce_wp_select(
				array(
					'id' => 'wwp_coupon_type',
					'label' => esc_html__('Type', 'woocommerce-wholesale-pricing'),
					'options' => 
								array(
									'included' => esc_html__('Included', 'woocommerce-wholesale-pricing'),
									'excluded' => esc_html__('Excluded', 'woocommerce-wholesale-pricing'),
								),
					)
			);
			
			$value = get_post_meta($coupon_id, 'wwp_coupon_roles', true);      
			woocommerce_wp_select(
				array(
					'id'                => 'wwp_coupon_roles[]',
					'label'             => esc_html__('User Roles', 'woocommerce-wholesale-pricing'),
					'type'              => 'select',
					'class'             => 'wc-enhanced-select',
					'style'             => 'min-width: 50%;',
					'options'           => $roles,
					'value'             => $value,
					'custom_attributes' => array(
						'multiple' => 'multiple',
					),
				)
			); 
			
			woocommerce_wp_textarea_input(
				array(
					'id' => 'wwp_coupon_not_allowed_message',
					'placeholder' => esc_html__('You are not allowed to use this coupon code.', 'woocommerce-wholesale-pricing'),
					'label' => __('Invalid user role message', 'woocommerce-wholesale-pricing'),
				)
			);
			
			?>
		</div>
		<?php
	}
	
	/**
	 * Saves the custom wholesale meta data to the coupon post.
	 * Uses WC_Coupon data methods for saving.
	 *
	 * @action woocommerce_coupon_options_save
	 * @param  int|null $post_id The coupon post ID being saved.
	 * @return void
	 */
	public function options_save( $post_id = null ) {
		$post              = wwp_get_post_data('');
		$coupon            = new \WC_Coupon($post_id);

		$wwp_coupon_enable = isset($post['wwp_coupon_enable']) ? wc_clean($post['wwp_coupon_enable']) : '';
		//update_post_meta( $post_id, 'wwp_coupon_enable', $wwp_coupon_enable );
		$coupon->update_meta_data('wwp_coupon_enable', $wwp_coupon_enable);
		
		$wwp_coupon_type = isset($post['wwp_coupon_type']) ? wc_clean($post['wwp_coupon_type']) : '';
		//update_post_meta( $post_id, 'wwp_coupon_type', $wwp_coupon_type );    
		$coupon->update_meta_data('wwp_coupon_type', $wwp_coupon_type);
		
		$wwp_coupon_roles = isset($post['wwp_coupon_roles']) ? wc_clean($post['wwp_coupon_roles']) : '';
		//update_post_meta( $post_id, 'wwp_coupon_roles', $wwp_coupon_roles );
		$coupon->update_meta_data('wwp_coupon_roles', $wwp_coupon_roles);
		
		$wwp_coupon_not_allowed_message = isset($post['wwp_coupon_not_allowed_message']) ? wc_clean($post['wwp_coupon_not_allowed_message']) : '';
		//update_post_meta( $post_id, 'wwp_coupon_not_allowed_message', $wwp_coupon_not_allowed_message );
		$coupon->update_meta_data('wwp_coupon_not_allowed_message', $wwp_coupon_not_allowed_message);
		
		$coupon->save();
	}
	
	/**
	 * Filters whether coupons are enabled globally for the current session.
	 * Disabled if the user's current wholesale role dictates it, and removes existing coupons.
	 *
	 * @filter woocommerce_coupons_enabled
	 * @param  bool $enabled Current status of coupons enabled (true by default).
	 * @return bool New status of coupons enabled (false if wholesale role has them disabled).
	 */
	public function wwp_coupons_enabled( $enabled ) {
		if (isset($this->coupons_disabled) && $this->coupons_disabled ) {
			return $enabled;
		}
		$this->coupons_disabled = true;

		if ($this->wwp_coupons_disabled() ) {
			if (isset(WC()->cart) && ! WC()->cart->is_empty() && ! empty(WC()->cart->get_coupons()) ) {
				WC()->cart->remove_coupons();
			}
			return false;
		}

		// Reset the flag after processing
		$this->coupons_disabled = false;

		return $enabled;
	}
	/**
	 * Checks if the current user's wholesale role has coupons globally disabled based on term meta.
	 *
	 * @return bool True if coupons should be disabled for the user, false otherwise.
	 */
	public function wwp_coupons_disabled() {
		$user_role      = wwp_get_current_user_role();
		$wholesale_role = term_exists($user_role, wwp_env()->get('role_taxonomy'));
		if (! $wholesale_role ) {
			return false;
		}
		$settings = self::get_pricing_settings();
		if (isset($settings['wholesale_role']) && 'multiple' == $settings['wholesale_role'] && 'yes' == get_term_meta($wholesale_role['term_id'], 'wwp_wholesale_disable_coupons', true) ) {
			return true;
		} elseif (isset($settings['wholesale_role']) && 'single' == $settings['wholesale_role'] && 'yes' == get_term_meta($wholesale_role['term_id'], 'wwp_wholesale_disable_coupons', true) ) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Filters the coupon validity based on wholesale user role restriction settings stored in coupon meta.
	 *
	 * @filter woocommerce_coupon_is_valid
	 * @param  bool      $is_valid The default validity status (true if no other checks failed).
	 * @param  WC_Coupon $coupon     The coupon object being
	 *                             validated.
	 * @return bool True if the coupon is valid for the current user role, false otherwise.
	 */
	public function woocommerce_coupon_is_valid( $is_valid, $coupon ) {
		
		$coupon_id  = @$coupon->get_id();
		$setting    = self::get_pricing_settings();
		$enable     = get_post_meta($coupon_id, 'wwp_coupon_enable', true);
		$type       = get_post_meta($coupon_id, 'wwp_coupon_type', true);
		$roles      = ! empty(get_post_meta($coupon_id, 'wwp_coupon_roles', true)) ? get_post_meta($coupon_id, 'wwp_coupon_roles', true) : array();
		$message    = get_post_meta($coupon_id, 'wwp_coupon_not_allowed_message', true);
		
		if ('yes' == $enable ) {
			$user_role      = wwp_get_current_user_role();
			$wholesale_role = term_exists($user_role, 'wholesale_user_roles');
			$allterms       = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
			switch ( $type ) {
				case 'included':
					if (in_array(@$user_role, @$roles) ) { 
						return true;
					} else {
						add_filter(
						'woocommerce_coupon_error', 
						function ( $err, $err_code, $instance ) use ( $message, $coupon_id ) {
							if (!empty($message) ) {
								$err = $message; 
							}
							return $err; 
						},
						10, 
						3
						);
						return false;
					}
					break;
				case 'excluded':
					if (in_array(@$user_role, @$roles) ) { 
						add_filter(
						'woocommerce_coupon_error', 
						function ( $err, $err_code, $instance ) use ( $message, $coupon_id ) {
							if (!empty($message) ) {
								$err = $message; 
							}
							return $err; 
						},
						10, 
						3
						);
						return false;
					} else {
						return true;
					}
					break;
				default:
					return true;
			}
		}
		return true;
	}

	/**
	 * Filters the package rates to provide 'Free Shipping' if a free shipping coupon is applied.
	 * Overrides other shipping methods (like Flat Rate) to cost $0 if a Free Shipping coupon is active.
	 *
	 * @filter woocommerce_package_rates
	 * @param  array $rates Array of existing shipping rates (rate ID => WC_Shipping_Rate object).
	 * @return array Modified array of shipping rates.
	 */
	public function free_shipping_coupon( $rates ) {
		global $woocommerce;
		$free = array();
		foreach ( $woocommerce->cart->applied_coupons as $coupon ) {
			$coupon_posts = get_posts(
				array(
				'post_type'   => 'shop_coupon',
				'title'       => $coupon,
				'numberposts' => -1,
				'fields'      => 'ids',
				) 
			);
			if (isset($coupon_posts[0]) ) {
				$coupon = new \WC_Coupon($coupon_posts[0]);
				if ($coupon->get_free_shipping() ) {
					foreach ( $rates as $rate_id => $rate ) {
						if ('flat_rate' === $rate->method_id ) {
							$rate->label      = 'Free Shipping';
							$rate->cost       = 0.00;
							$free[ $rate_id ] = $rate;
							break;
						}
					}
				}
			}
		}
		return ! empty($free) ? $free : $rates;
	}

	/**
	 * Determines if this service should be loaded based on plugin settings.
	 * Implements the ServiceInterface contract.
	 *
	 * @static
	 * @return bool True if the 'enable_coupon' setting is 'yes', false otherwise.
	 */
	public static function resolveDependency() {
		$settings = self::get_pricing_settings();
		return isset($settings['enable_coupon']) && 'yes' == $settings['enable_coupon'];
	}
}
