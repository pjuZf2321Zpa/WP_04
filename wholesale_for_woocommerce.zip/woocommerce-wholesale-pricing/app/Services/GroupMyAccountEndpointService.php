<?php
/**
 * GroupMyAccountEndpointService class.
 *
 * Manages the creation and content rendering for the custom wholesale group
 * announcements endpoint in the WooCommerce My Account area. It also contains
 * logic for handling the activation and deactivation of wholesale group posts
 * in the WordPress admin area.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @implements ServiceInterface
 * @extends    Init
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Strategies\Init;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Service class for integrating wholesale group features into the My Account dashboard.
 * 
 * @implements ServiceInterface
 * @extends    Init
 */
class GroupMyAccountEndpointService extends Init implements ServiceInterface {

	/**
	 * Constructor.
	 *
	 * Hooks into WooCommerce and WordPress filters/actions to set up the My Account endpoint.
	 *
	 * @return void
	 */
	public function __construct() {
		parent::__construct();

		// Add custom endpoint to WordPress query vars.
		add_filter('query_vars', array( $this, 'query_var' ), 10);

		// Add custom menu item to the My Account navigation.
		add_filter('woocommerce_account_menu_items', array( $this, 'add_group_menu_item' ));

		// Define content displayed on the custom endpoint page.
		add_action('woocommerce_account_' . wwp_env()->get('group_endpoint') . '_endpoint', array( $this, 'tab_content' ));
	}

	/**
	 * Registers the necessary components for the service.
	 *
	 * Called during the Init phase to ensure components like rewrite rules are active.
	 *
	 * @return void
	 */
	public function register() {
		$this->rewrite_endpoint();
		$this->group_status_change();
	}

	/**
	 * Registers the custom rewrite endpoint for the My Account page.
	 *
	 * Flushes rewrite rules immediately after registration.
	 *
	 * @return void
	 */
	public function rewrite_endpoint() {
		$endpoint = wwp_env()->get( 'group_endpoint' );

		// Register the new endpoint using the slug defined in the environment.
		add_rewrite_endpoint( $endpoint, EP_ROOT | EP_PAGES );

		// Flush once when the endpoint changes — not on every request.
		$flushed_for = get_option( 'wwp_group_endpoint_rewrite_flushed', '' );
		if ( $flushed_for !== $endpoint ) {
			flush_rewrite_rules( false );
			update_option( 'wwp_group_endpoint_rewrite_flushed', $endpoint, false );
		}
	}

	/**
	 * Handles activation and deactivation of wholesale group posts (wwp_groups)
	 * via links in the WordPress admin area.
	 *
	 * Performs nonce verification and checks for necessary GET parameters.
	 *
	 * @return void
	 */
	public function group_status_change() {
		// Check if we're in the admin area and the correct action is set
		if (is_admin() && isset($_GET['post']) && 'wwp_groups' == sanitize_text_field($_GET['post']) && isset($_GET['action']) && isset($_GET['post_id']) && isset($_GET['_wpnonce']) ) {
			$post_id = intval($_GET['post_id']);
			$nonce = sanitize_text_field($_GET['_wpnonce']);
			$action = sanitize_text_field($_GET['action']);

			// Verify the nonce
			if (! wp_verify_nonce($nonce, 'wwp_group_nonce') ) {
				return;
			}

			// Handle activation
			if ('activate_group' === $action ) {
				// Update the post status to publish
				wp_update_post(
					array(
					'ID'          => $post_id,
					'post_status' => 'publish',
					) 
				);
				update_post_meta($post_id, '_wholesale_group_status', 'active');
			}

			// Handle deactivation
			if ('deactivate_group' === $action ) {
				// Update the post status to draft
				wp_update_post(
					array(
					'ID'          => $post_id,
					'post_status' => 'draft',
					) 
				);
				update_post_meta($post_id, '_wholesale_group_status', 'inactive');

			}

			// Redirect to avoid duplicate action execution on page refresh
			wp_safe_redirect( 
				add_query_arg( 
					array( 
						'post_type' => 'wwp_groups', // Replace with your post type
					),
					remove_query_arg(
						array( 
							'action', 
							'post', 
							'post_id', 
							'_wpnonce', 
						) 
					) 
				) 
			);
			exit;
		}
	}

	/**
	 * Adds the custom endpoint slug to the list of recognized query variables.
	 *
	 * @filter query_vars
	 * @param  array $vars The array of public query variables.
	 * @return array The modified array of query variables.
	 */
	public function query_var( $vars ) {
		$vars[] = wwp_env()->get('group_endpoint');
		return $vars;
	}

	/**
	 * Adds the "Announcements" menu item to the WooCommerce My Account navigation.
	 *
	 * The item is only added for users who belong to a wholesale group.
	 * It also reorders the "Log out" link to be the last item.
	 *
	 * @filter woocommerce_account_menu_items
	 * @param  array $items Existing My Account menu items (endpoint_slug => label).
	 * @return array Modified My Account menu items.
	 */
	public function add_group_menu_item( $items ) {
		if (is_user_logged_in() ) {
			$user_id = get_current_user_id();
			if (! empty(get_user_meta($user_id, 'add_in_wwp_group', true)) && 'true' == get_user_meta($user_id, 'add_in_wwp_group', true) ) {
				if (isset($items['customer-logout']) ) { 
					unset($items['customer-logout']);
				}
				$items[wwp_env()->get('group_endpoint')] = esc_html__('Announcements', 'woocommerce-wholesale-pricing');
				$items = array_merge($items, array( 'customer-logout' => esc_html__('Log out', 'woocommerce') ));
			}
		}

		return $items;
	}

	/**
	 * Renders the content for the custom group announcement endpoint in My Account.
	 *
	 * It uses a global `wwp_view()` function to pull the necessary template file.
	 *
	 * @action woocommerce_account_{group_endpoint}_endpoint
	 * @return mixed Assumed to return or echo the rendered HTML template.
	 */
	public function tab_content() {
		return wwp_view('group-announcement.content');
	}

	/**
	 * Determines if this service should be registered.
	 *
	 * The My Account endpoint service is primarily a frontend feature.
	 *
	 * @return bool True if the current request is NOT in the admin area, false otherwise.
	 */
	public static function resolveDependency() {
		return ! is_admin();
	}
}
