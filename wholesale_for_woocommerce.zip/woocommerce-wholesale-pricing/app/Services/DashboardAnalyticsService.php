<?php
/**
 * Read wholesale dashboard analytics via the existing dashboard controller.
 *
 * @package WooCommerceWholesalePricing\App\Services
 */

namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Modules\RestAPIs\Dashboard_V1_Controller;

/**
 * Delegates dashboard report queries to Dashboard_V1_Controller trait methods.
 */
class DashboardAnalyticsService {

	/**
	 * Supported report types.
	 *
	 * @var list<string>
	 */
	const REPORT_TYPES = array(
		'overview',
		'score_cards',
		'orders_by_status',
		'chart',
		'top_products',
		'top_customers',
		'recent_orders',
		'recent_requests',
		'user_metrics',
	);

	/**
	 * Supported period filters.
	 *
	 * @var list<string>
	 */
	const PERIOD_TYPES = array(
		'today',
		'last_7_days',
		'last_30_days',
		'last_6_months',
		'last_12_months',
		'custom',
	);

	/**
	 * Supported chart filter types.
	 *
	 * @var list<string>
	 */
	const CHART_FILTERS = array(
		'group-users',
		'orders',
		'refund',
		'customers',
	);

	/**
	 * Dashboard controller instance.
	 *
	 * @var Dashboard_V1_Controller|null
	 */
	private $controller;

	/**
	 * Constructor.
	 *
	 * @param Dashboard_V1_Controller|null $controller Optional controller for testing.
	 */
	public function __construct( $controller = null ) {
		$this->controller = $controller;
	}

	/**
	 * Run a dashboard analytics report.
	 *
	 * @param array<string, mixed> $input Ability input.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function get_report( array $input ) {
		$report = isset( $input['report'] ) ? sanitize_key( (string) $input['report'] ) : '';

		if ( '' === $report || ! in_array( $report, self::REPORT_TYPES, true ) ) {
			return new \WP_Error(
				'wwp_dashboard_invalid_report',
				sprintf(
					/* translators: %s: comma-separated report names */
					__( 'Invalid report. Use one of: %s', 'woocommerce-wholesale-pricing' ),
					implode( ', ', self::REPORT_TYPES )
				),
				array( 'status' => 400 )
			);
		}

		$period = $this->normalize_period(( isset( $input['period'] ) ? $input['period'] : 'last_30_days' ));
		if ( is_wp_error( $period ) ) {
			return $period;
		}

		if ( 'custom' === $period ) {
			$validation = $this->validate_custom_dates( $input );
			if ( is_wp_error( $validation ) ) {
				return $validation;
			}
		}

		$chart_filter = $this->normalize_chart_filter(( isset( $input['chart_filter'] ) ? $input['chart_filter'] : 'group-users' ));
		if ( is_wp_error( $chart_filter ) ) {
			return $chart_filter;
		}

		$limit   = isset( $input['limit'] ) ? max( 1, (int) $input['limit'] ) : 5;
		$request = $this->build_request( $input, $period, $chart_filter );

		$controller = $this->get_controller();
		$data       = $this->fetch_report_data( $controller, $report, $request, $limit, $chart_filter );

		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$result = array(
			'report'  => $report,
			'period'  => $period,
			'filters' => $this->build_filters_meta( $input, $period ),
			'data'    => $data,
		);

		if ( 'chart' === $report ) {
			$result['chart_filter'] = $chart_filter;
		}

		if ( in_array( $report, array( 'top_products', 'top_customers', 'recent_orders' ), true ) ) {
			$result['limit'] = $limit;
		}

		return $result;
	}

	/**
	 * Fetch report data
	 * 
	 * @param Dashboard_V1_Controller $controller   Controller.
	 * @param string                  $report       Report type.
	 * @param \WP_REST_Request        $request      REST request.
	 * @param int                     $limit        List limit.
	 * @param string                  $chart_filter Chart filter.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function fetch_report_data(
		Dashboard_V1_Controller $controller,
		$report,
		\WP_REST_Request $request,
		$limit,
		$chart_filter
	) {
		switch ( $report ) {
			case 'overview':
				$response = $controller->get_items( $request );
				if ( $response instanceof \WP_REST_Response ) {
					$payload = $response->get_data();
					if ( is_array(( isset( $payload['recentRequests'] ) ? $payload['recentRequests'] : null )) ) {
						$payload['recentRequests'] = $this->format_recent_requests( $payload['recentRequests'] );
					}
					if ( is_array(( isset( $payload['requests'] ) ? $payload['requests'] : null )) ) {
						$payload['userMetrics'] = $this->format_user_metrics( $payload['requests'] );
						unset( $payload['requests'] );
					}
					return is_array( $payload ) ? $payload : array();
				}
				return array();

			case 'score_cards':
				return $controller->get_score_cards( $request );

			case 'orders_by_status':
				return $this->format_orders_by_status( $controller->get_wholesale_orders_count_by_status( $request ) );

			case 'chart':
				return $this->format_chart_report( $controller->get_chart_data( $request, $chart_filter ), $chart_filter );

			case 'top_products':
				return $controller->get_top_products( $request, $limit );

			case 'top_customers':
				return $controller->get_top_customers( $request, $limit );

			case 'recent_orders':
				return $controller->get_recent_orders_data( $request, $limit );

			case 'recent_requests':
				return $this->format_recent_requests( $controller->get_recent_requests() );

			case 'user_metrics':
				return $this->format_user_metrics( $controller->get_user_information( $request ) );

			default:
				return new \WP_Error(
					'wwp_dashboard_unsupported_report',
					__( 'Unsupported dashboard report.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
		}
	}

	/**
	 * Build request
	 * 
	 * @param array<string, mixed> $input        Input.
	 * @param string               $period       Period key.
	 * @param string               $chart_filter Chart filter.
	 * @return \WP_REST_Request
	 */
	private function build_request( array $input, $period, $chart_filter ) {
		$request = new \WP_REST_Request( 'GET', '/wholesale/v1/wholesale-requests' );
		$request->set_param( 'period', $period );

		if ( 'custom' === $period ) {
			$request->set_param( 'start_date', sanitize_text_field( (string) $input['start_date'] ) );
			$request->set_param( 'end_date', sanitize_text_field( (string) $input['end_date'] ) );
		}

		$request->set_param( 'chart_filter', $chart_filter );
		$request->set_param( 'filter', $chart_filter );

		return $request;
	}

	/**
	 * Build filters metadata for the report result, based on input and period, to provide context for the returned data.
	 * 
	 * @param array<string, mixed> $input  Input.
	 * @param string               $period Period key.
	 * @return array<string, mixed>
	 */
	private function build_filters_meta( array $input, $period ) {
		$filters = array(
			'period' => $period,
		);

		if ( 'custom' === $period ) {
			$filters['start_date'] = sanitize_text_field( (string) ( ( isset( $input['start_date'] ) ? $input['start_date'] : '' ) ) );
			$filters['end_date']   = sanitize_text_field( (string) ( ( isset( $input['end_date'] ) ? $input['end_date'] : '' ) ) );
		}

		return $filters;
	}

	/**
	 * Normalize period input, ensuring it matches supported periods and providing clear error messages for invalid values.
	 * 
	 * @param mixed $period Period value.
	 * @return string|\WP_Error
	 */
	private function normalize_period( $period ) {
		$key = strtolower( trim( (string) $period ) );
		$key = str_replace( array( ' ', '-' ), '_', $key );

		if ( ! in_array( $key, self::PERIOD_TYPES, true ) ) {
			return new \WP_Error(
				'wwp_dashboard_invalid_period',
				sprintf(
					/* translators: %s: comma-separated period names */
					__( 'Invalid period. Use one of: %s', 'woocommerce-wholesale-pricing' ),
					implode( ', ', self::PERIOD_TYPES )
				),
				array( 'status' => 400 )
			);
		}

		return $key;
	}

	/**
	 * Normalize chart filter input, ensuring it matches supported filters and providing clear error messages for invalid values.
	 * 
	 * @param mixed $chart_filter Chart filter value.
	 * @return string|\WP_Error
	 */
	private function normalize_chart_filter( $chart_filter ) {
		$key = strtolower( trim( (string) $chart_filter ) );

		if ( ! in_array( $key, self::CHART_FILTERS, true ) ) {
			return new \WP_Error(
				'wwp_dashboard_invalid_chart_filter',
				sprintf(
					/* translators: %s: comma-separated chart filter names */
					__( 'Invalid chart_filter. Use one of: %s', 'woocommerce-wholesale-pricing' ),
					implode( ', ', self::CHART_FILTERS )
				),
				array( 'status' => 400 )
			);
		}

		return $key;
	}

	/**
	 * Validate custom date inputs for the 'custom' period filter, ensuring presence, format, and logical order.
	 * 
	 * @param array<string, mixed> $input Input.
	 * @return true|\WP_Error
	 */
	private function validate_custom_dates( array $input ) {
		$start = isset( $input['start_date'] ) ? trim( (string) $input['start_date'] ) : '';
		$end   = isset( $input['end_date'] ) ? trim( (string) $input['end_date'] ) : '';

		if ( '' === $start || '' === $end ) {
			return new \WP_Error(
				'wwp_dashboard_missing_custom_dates',
				__( 'start_date and end_date are required when period is custom.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$start_dt = \DateTime::createFromFormat( 'Y-m-d', $start );
		$end_dt   = \DateTime::createFromFormat( 'Y-m-d', $end );

		if ( ! $start_dt || $start_dt->format( 'Y-m-d' ) !== $start || ! $end_dt || $end_dt->format( 'Y-m-d' ) !== $end ) {
			return new \WP_Error(
				'wwp_dashboard_invalid_custom_dates',
				__( 'start_date and end_date must be valid Y-m-d dates.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( $start_dt > $end_dt ) {
			return new \WP_Error(
				'wwp_dashboard_invalid_date_range',
				__( 'start_date must be on or before end_date.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		return true;
	}

	/**
	 * Format orders by status payload into a structured array with counts and totals, while preserving original data for refunds.
	 * 
	 * @param array<string, mixed> $counts Orders count payload.
	 * @return array<string, mixed>
	 */
	private function format_orders_by_status( array $counts ) {
		$labels = is_array(( isset( $counts['labels'] ) ? $counts['labels'] : null )) ? $counts['labels'] : array();
		$data   = is_array(( isset( $counts['data'] ) ? $counts['data'] : null )) ? $counts['data'] : array();
		$items  = array();

		foreach ( $labels as $index => $label ) {
			$items[] = array(
				'status' => (string) $label,
				'count'  => isset( $data[ $index ] ) ? (int) $data[ $index ] : 0,
			);
		}

		$refunded_count = 0;
		foreach ( $items as $item ) {
			if ( false !== stripos( $item['status'], 'refund' ) ) {
				$refunded_count += $item['count'];
			}
		}

		return array(
			'items'          => $items,
			'refunded_count' => $refunded_count,
			'total_orders'   => array_sum( array_column( $items, 'count' ) ),
		);
	}

	/**
	 * Format chart report payload into a structured array with points and totals, while preserving original data for refunds.
	 * 
	 * @param array<string, mixed> $chart        Chart payload.
	 * @param string               $chart_filter Chart filter.
	 * @return array<string, mixed>
	 */
	private function format_chart_report( array $chart, $chart_filter ) {
		$series = is_array(( isset( $chart['series'] ) ? $chart['series'] : null )) ? $chart['series'] : array();
		$values = is_array(( isset( $chart['data'] ) ? $chart['data'] : null )) ? $chart['data'] : array();
		$points = array();

		foreach ( $series as $index => $label ) {
			$points[] = array(
				'label' => (string) $label,
				'value' => isset( $values[ $index ] ) ? (float) $values[ $index ] : 0.0,
			);
		}

		$total = array_sum( array_map( 'floatval', $values ) );

		$formatted = array(
			'chart_filter' => $chart_filter,
			'points'       => $points,
			'total'        => $total,
		);

		if ( 'refund' === $chart_filter ) {
			$formatted['refund_total'] = $total;
			$formatted['refund_periods'] = count(
				array_filter(
					$values,
					static function ( $value ) {
						return (float) $value > 0;
					}
				)
			);
		}

		return $formatted;
	}

	/**
	 * Format recent requests payload to extract pending count and label, while preserving original data.
	 * 
	 * @param array<string, mixed> $recent_requests Recent requests payload.
	 * @return array<string, mixed>
	 */
	private function format_recent_requests( array $recent_requests ) {
		$pending_label = isset( $recent_requests['pending'] ) ? (string) $recent_requests['pending'] : '';
		$pending_count = 0;

		if ( preg_match( '/(\d+)/', $pending_label, $matches ) ) {
			$pending_count = (int) $matches[1];
		}

		$recent_requests['pending_count'] = $pending_count;
		$recent_requests['pending_label'] = $pending_label;

		return $recent_requests;
	}

	/**
	 * Format user metrics payload into a structured array with defined keys.
	 * 
	 * @param array<int, mixed> $metrics Raw user information metrics.
	 * @return array<string, int>
	 */
	private function format_user_metrics( array $metrics ) {
		return array(
			'wholesale_users'   => isset( $metrics[0] ) ? (int) $metrics[0] : 0,
			'pending_requests'  => isset( $metrics[1] ) ? (int) $metrics[1] : 0,
			'rejected_requests' => isset( $metrics[2] ) ? (int) $metrics[2] : 0,
			'grouped_users'     => isset( $metrics[3] ) ? (int) $metrics[3] : 0,
		);
	}

	/**
	 * Get or create the dashboard controller instance.
	 * 
	 * @return Dashboard_V1_Controller
	 */
	private function get_controller() {
		if ( null === $this->controller ) {
			$this->controller = new Dashboard_V1_Controller();
		}

		return $this->controller;
	}
}
