<?php

namespace WooCommerceWholesalePricing\App\Services;

class MultilipiIntegrationService {
	
	public function __construct() {
		add_action( 'wwp_render_multilipi_ui', array( $this, 'settings_ui' ), 20 );

		add_action( 'admin_post_wwp_install_activate_multilipi', array( $this, 'handle_multilipi_activation' ) );
		add_action( 'admin_post_wwp_activate_multilipi', array( $this, 'handle_multilipi_activation' ) );
	}

	public function settings_ui() {
		if ( ! function_exists( 'is_plugin_active' ) || ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
	
		// If Multilipi is active, its own hook (priority 10) already ran. Skip.
		$mlms_active  = false;
		$is_installed = false;
		$plugin_file  = 'multilipi-multilingual-seo/multilipi-multilingual-seo.php';
		
		$all_plugins  = get_plugins();
		foreach ( $all_plugins as $path => $data ) {
			if ( isset( $data['TextDomain'] ) && 'multilipi-multilingual-seo' === $data['TextDomain'] ) {
				$is_installed = true;
				$plugin_file  = $path;
				if ( is_plugin_active( $path ) ) {
					$mlms_active = true;
				}
				break;
			}
		}
	
		// Secondary check: plugin might be active and loaded even if path differs
		if ( defined( 'MLMS_VERSION' ) ) {
			$mlms_active = true;
		}
	
		if ( $mlms_active ) {
			return;
		}

		wwp_view('admin.menus.multilipi-integration', compact('is_installed', 'mlms_active', 'plugin_file'));
	}

	public function handle_multilipi_activation() {
		$action = isset( $_GET['action'] ) ? sanitize_text_field( wp_unslash( $_GET['action'] ) ) : '';
		if ( ! in_array( $action, array( 'wwp_activate_multilipi', 'wwp_install_activate_multilipi' ), true ) ) {
			return;
		}

		// Include plugin.php which is required for activate_plugin() during admin-post.
		require_once ABSPATH . 'wp-admin/includes/plugin.php';


		// Verify nonce.
		if ( ! isset( $_GET['_wpnonce'] ) ||
			! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), $action )
		) {
			wp_die( esc_html__( 'Security check failed.', 'woocommerce-wholesale-pricing' ) );
		}


		// Must be an admin.
		if ( ! current_user_can( 'activate_plugins' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions.', 'woocommerce-wholesale-pricing' ) );
		}

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		
		$plugin_file = 'multilipi-multilingual-seo/multilipi-multilingual-seo.php';
		$all_plugins = get_plugins();
		foreach ( $all_plugins as $path => $data ) {
			if ( isset( $data['TextDomain'] ) && 'multilipi-multilingual-seo' === $data['TextDomain'] ) {
				$plugin_file = $path;
				break;
			}
		}

		$result = false;

		if ( 'wwp_install_activate_multilipi' === $action ) {
			if ( ! current_user_can( 'install_plugins' ) ) {
				wp_die( esc_html__( 'You do not have sufficient permissions.', 'woocommerce-wholesale-pricing' ) );
			}

			// Include needed files for installation.
			require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

			/**
			 * Filter
			 * 
			 * @var string $download_link The URL to download the Multilipi plugin ZIP from. Default is the value of 'multilipi_integration_zip' in our environment config.
			 * 
			 * @since 3.1.0
			 */
			$download_link = apply_filters( 'wwp_multilipi_download_url', wwp_env()->get('multilipi_integration_zip') );

			if ( empty( $download_link ) ) {
				// Get plugin info from WP API.
				$api = plugins_api( 'plugin_information', array(
					'slug'   => 'multilipi-multilingual-seo',
					'fields' => array(
						'sections' => false,
					),
				) );

				if ( is_wp_error( $api ) ) {
					$result = $api;
				} else {
					$download_link = $api->download_link;
				}
			}

			if ( ! is_wp_error( $result ) && ! empty( $download_link ) ) {
				// Perform the installation silently.
				$upgrader = new \Plugin_Upgrader( new \Automatic_Upgrader_Skin() );
				$installed = $upgrader->install( $download_link );

				if ( is_wp_error( $installed ) ) {
					$result = $installed;
				} elseif ( ! $installed ) {
					$result = new \WP_Error( 'install_failed', esc_html__( 'Installation failed.', 'woocommerce-wholesale-pricing' ) );
				} else {
					// Installation successful, clear plugins cache to locate the newly installed plugin.
					wp_cache_delete( 'plugins', 'plugins' );
					
					// Get the newly installed plugin file path to fix activation if the ZIP extracted to a differently named folder
					$plugin_info = $upgrader->plugin_info();
					if ( $plugin_info ) {
						$plugin_file = $plugin_info;
					}

					if ( ! is_wp_error( validate_plugin( $plugin_file ) ) ) {
						activate_plugin( $plugin_file );
					}
				}
			}

		}

		if ( ! is_wp_error( $result ) ) {
			if ( ! is_wp_error( validate_plugin( $plugin_file ) ) ) {
				activate_plugin( $plugin_file );
				$status = 1;
			} else {
				$status = 'failed';
			}
		} else {
			$status = 'failed';
		}
		
		wp_safe_redirect( admin_url( 'admin.php?page=wwp_wholesale_settings&multilipi_status=1' ) );
		exit;
	}
}
