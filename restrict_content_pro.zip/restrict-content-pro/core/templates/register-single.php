<?php
/**
 * Registration Form - Single
 *
 * This template is used to display the registration form for a single
 * membership level with [register_form id="3"]
 *
 * @link https://restrictcontentpro.com/knowledgebase/register_form
 *
 * For modifying this template, please see: https://restrictcontentpro.com/knowledgebase/editing-template-files/
 *
 * @package     Kadence Memberships Pro
 * @subpackage  Templates/Register/Single
 * @copyright   Copyright (c) 2017, Kadence Memberships Pro
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 */

rcp_get_template_part( 'register-common' );
?>
