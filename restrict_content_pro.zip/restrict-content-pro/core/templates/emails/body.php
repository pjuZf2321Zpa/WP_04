<?php
/**
 * Email Body for the Default Template
 *
 * Use {email} as a placeholder for the content entered in Restrict > Settings > Emails.
 *
 * For modifying this template, please see: https://restrictcontentpro.com/knowledgebase/editing-template-files/
 *
 * @package     Kadence Memberships Pro
 * @subpackage  Templates/Emails/Body
 * @copyright   Copyright (c) 2017, Kadence Memberships Pro
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.7
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// {email} is replaced by the content entered in Restrict > Settings > Emails
?>
{email}
