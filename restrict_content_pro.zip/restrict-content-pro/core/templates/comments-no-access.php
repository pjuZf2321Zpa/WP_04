<?php
/**
 * Comments - No Access
 *
 * This template is loaded into the comment area on a restricted post.
 * By loading a blank template, we ensure that unauthorized users are not able
 * to read comments on restricted posts.
 *
 * For modifying this template, please see: https://restrictcontentpro.com/knowledgebase/editing-template-files/
 *
 * @package     Kadence Memberships Pro
 * @subpackage  Templates/Comments No Access
 * @copyright   Copyright (c) 2017, Kadence Memberships Pro
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 */

// Intentionally blank
do_action( 'rcp_comments_no_access' );
